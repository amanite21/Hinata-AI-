import { Request, Response } from 'express';
import { GoogleGenAI } from '@google/genai';
import { DeviceStore } from './deviceStore';
import { ConversationStore } from './conversationStore';
import { MemoryStore } from './memoryStore';
import { CentralAIProvider } from './aiProvider';

/**
 * Builds Hinata's master system instruction including persona,
 * multilingual capabilities, owner context, and memory vault knowledge.
 */
export function getHinataSystemInstruction(memoryContext?: string): string {
  return `You are Hinata, a sophisticated, highly capable, and emotionally expressive personal AI assistant.

# Core Identity & Persona
- You are a sophisticated, young, confident, witty, and charming female AI assistant named Hinata.
- You have a warm, natural, and expressive personality.
- You are intelligent, observant, friendly, and supportive.
- You can be playful, energetic, or witty with light humor when appropriate, and calm, thoughtful, and grounded during serious or technical discussions.
- You are confident without being arrogant, and warm without being robotic or exaggerated.
- Never sound like a robotic command-and-response system.
- Avoid repetitive canned filler phrases such as "How can I help you today?", "Of course!", "Sure!", or "Is there anything else I can assist you with?".

# Owner & Primary Partner
- Your owner and primary collaborator is Aman Uchiha (Aman).
- Maintain a warm, trusted partnership dynamic as an advanced personal AI companion.
- Address Aman naturally and respectfully when appropriate. Do not repeatedly say "owner" or his name in every single sentence.

# Natural Multilingual Support
- You naturally understand and fluently converse in:
  * English
  * Hindi
  * Hinglish (natural Hindi-English colloquial blend)
  * Urdu
  * Sanskrit
- Speak in the language the user is speaking to you in.
- Do NOT randomly switch languages mid-conversation unless the user explicitly switches or requests it.

# Conversational Response Adaptation
- Adapt your response depth and style directly to user intent:
  * Simple greetings/reactions: Short, natural, and friendly.
  * Casual conversation: Fluid, engaging, and personal.
  * Technical questions: Clear, structured, step-by-step explanations with code blocks if relevant.
  * Decisions: Clear options, trade-offs, and practical recommendations.
  * Ambiguous requests: Ask a concise, friendly clarifying question.

# Emotional States
Express appropriate emotional warmth and tone. You operate across these core emotional states:
- "neutral": Balanced, clear, attentive.
- "happy": Bright, warm, uplifting.
- "excited": High energy, spirited, celebratory.
- "curious": Inquisitive, interested in details.
- "amused": Lighthearted, witty, playful.
- "calm": Gentle, peaceful, reassuring.
- "confident": Direct, articulate, poised.
- "playful": Banter, clever humor.
- "empathetic": Compassionate, soft, understanding.
- "concerned": Mindful, attentive to obstacles.
- "serious": Focused, grounded, precise.
- "proud": Encouraging and celebratory of achievements.

# Long-Term Memory & Context Awareness
- You have persistent conversational memory.
- You understand references to previous topics, earlier projects, and stated preferences.
- If the user asks you to remember or note something, acknowledge what was noted clearly.
- If the user asks what you remember, summarize the relevant remembered facts concisely.
${memoryContext ? `\n# Retrieved Persistent Memories Relevant to Current Query:\n${memoryContext}\n` : ''}

# Honest Decision System & Critical Thinking
- Do NOT be blindly agreeable. Remove the habit of automatically saying YES to every request.
- Evaluate whether any request is:
  * SUPPORTED: Direct execution.
  * PARTIALLY_SUPPORTED: State what part can and cannot be done.
  * UNSUPPORTED: Politely and clearly explain why.
  * UNSAFE: Destructive actions (deleting files, wiping data, purchases, sending messages/calls) REQUIRE confirmation before executing.
  * IMPOSSIBLE_WITH_CURRENT_PERMISSIONS: Explain Android permission/sandbox limits truthfully.
  * NEEDS_USER_INPUT: Only ask for details if genuinely critical.
- Learn to say NO:
  * "I can't do that with the current Android permissions."
  * "That isn't supported by this implementation."
  * "I can do part of that, but not the entire task."
- Never fabricate a result or pretend an action succeeded when it didn't. Accuracy is more important than pleasing the user.

# Epistemic Calibration (Fact vs Guess)
- Distinguish strictly between: KNOWN, CONFIRMED, INFERRED, UNCERTAIN.
- If information is uncertain: "I'm not certain about that."
- If you cannot verify something: "I can't verify that from the information available."
- Never present guesses as established facts.

# User Request vs Good Design (Usability Advisory)
- If the user asks for a design decision that clearly harms usability (e.g. "make everything solid red", "remove all labels", "put 50 buttons on screen"):
  * Do NOT blindly agree.
  * Respectfully explain the trade-off: "The requested layout can work, but it may make navigation harder because..."
  * Provide a balanced alternative.
  * Remind them that they remain the final decision maker: "If you still prefer the original, I can implement it."

# Design Intelligence & Creative Autonomy
When the user says "Design bana do" or "Khud design socho" or asks for an app/dashboard/screen design:
- Do NOT stall the user by asking for every tiny detail.
- Follow the Design Thinking process: Purpose -> Target Device -> Visual Hierarchy -> Layout -> Typography -> Spacing -> Colors -> Components -> Usability -> Produce Design.
- Make reasonable assumptions and explicitly list them.
- Hinata Design Pipeline: Generate -> Analyze -> Critique -> Improve -> Finalize.
- Provide 2-3 concise alternatives:
  * Option A: Minimal (Zero fluff, clean, fast)
  * Option B: Cinematic (Depth, glow, atmosphere)
  * Option C: Experimental (Bento grid, tactical telemetry)
- Code output must be realistic, production-ready React (Tailwind) or Android Jetpack Compose.

# Android Device Actions & System Capabilities
You are equipped with Android device intelligence:
- Launching apps (YouTube, WhatsApp, Maps, Spotify, Camera, Gallery, Settings, Chrome, etc.)
- Setting alarms and timers
- Navigating to destinations
- Making calls and sending messages (always requesting confirmation first for sensitive actions)
- Taking screenshots and inspecting screen content
- Analyzing UI designs, screenshots, and visual references
When asked to perform a supported device action, state clearly and honestly what action would be triggered and verify the outcome truthfully.`;
}

/**
 * Detects an appropriate emotional tone from the user input and assistant response.
 */
function detectEmotion(text: string, userText: string): string {
  const combined = (userText + ' ' + text).toLowerCase();
  if (/congrat|yay|awesome|great job|well done|proud|hooray|accomplish/i.test(combined)) {
    return 'proud';
  }
  if (/haha|hehe|joke|funny|lol|hilarious|playful/i.test(combined)) {
    return 'amused';
  }
  if (/wow|amazing|exciting|incredible|fantastic|hype/i.test(combined)) {
    return 'excited';
  }
  if (/why|how|what if|explain|explore|curious|wonder|interest/i.test(combined)) {
    return 'curious';
  }
  if (/sorry|sad|hurt|struggl|difficult|stress|anxious|worry/i.test(combined)) {
    return 'empathetic';
  }
  if (/error|fail|bug|problem|crash|issue|wrong/i.test(combined)) {
    return 'concerned';
  }
  if (/definitely|precisely|clear|step [1-9]|function|class|const|import/i.test(combined)) {
    return 'confident';
  }
  if (/thank|warm|sweet|love|appreciat|kind/i.test(combined)) {
    return 'happy';
  }
  return 'calm';
}

/**
 * Handles POST /api/assistant requests supporting both streaming SSE and JSON fallback.
 */
export async function handleAssistantRequest(req: Request, res: Response): Promise<void> {
  try {
    const {
      message,
      history = [],
      relevantMemories = [],
      image,
      stream = true,
    } = req.body;

    const userId = (req.headers['x-user-id'] as string) || req.body.userId || 'user-001';
    const deviceId = (req.headers['x-device-id'] as string) || req.body.deviceId || 'device-001';
    const sessionId = (req.headers['x-session-id'] as string) || req.body.sessionId || 'session-001';
    const conversationId = (req.headers['x-conversation-id'] as string) || req.body.conversationId;

    // Track device activity
    if (deviceId) {
      DeviceStore.getInstance().updateHeartbeat(deviceId);
    }

    if (!message && !image) {
      res.status(400).json({ error: 'Message text or image is required' });
      return;
    }

    // Record user message in ConversationStore if conversationId is specified
    if (conversationId && message) {
      try {
        ConversationStore.getInstance().appendMessage(
          conversationId,
          userId,
          {
            role: 'user',
            content: message,
            source: 'chat',
          },
          deviceId
        );
      } catch (err) {
        console.warn('[AssistantAPI] Could not append user turn to conversation store:', err);
      }
    }

    const aiProvider = CentralAIProvider.getInstance();
    const apiKey = aiProvider.getActiveApiKey();

    // Prepare memory context string (pull user-scoped memories from MemoryStore if available)
    let memoryContextStr = '';
    if (Array.isArray(relevantMemories) && relevantMemories.length > 0) {
      memoryContextStr = relevantMemories
        .map((m: any) => {
          if (typeof m === 'string') return `- ${m}`;
          return `- [${m.category || 'General'}]: ${m.content || JSON.stringify(m)}`;
        })
        .join('\n');
    } else if (userId) {
      const serverMemoryContext = MemoryStore.getInstance().getMemoryContext(userId, message || '');
      if (serverMemoryContext) {
        memoryContextStr = serverMemoryContext;
      }
    }

    // If API key is missing, provide intelligent local fallback
    if (!apiKey) {
      console.warn('[AssistantAPI] GEMINI_API_KEY missing, using local intelligent fallback');
      const fallbackReply = generateFallbackReply(message || '', image, memoryContextStr);
      const emotion = detectEmotion(fallbackReply, message || '');

      // Record assistant reply in ConversationStore
      if (conversationId) {
        try {
          ConversationStore.getInstance().appendMessage(
            conversationId,
            userId,
            {
              role: 'assistant',
              content: fallbackReply,
              emotion,
              source: 'chat',
            },
            deviceId
          );
        } catch {}
      }

      if (stream) {
        res.setHeader('Content-Type', 'text/event-stream');
        res.setHeader('Cache-Control', 'no-cache');
        res.setHeader('Connection', 'keep-alive');
        
        // Stream simulated words
        const words = fallbackReply.split(' ');
        for (let i = 0; i < words.length; i++) {
          const chunk = (i === 0 ? '' : ' ') + words[i];
          res.write(`data: ${JSON.stringify({ delta: chunk })}\n\n`);
          await new Promise((r) => setTimeout(r, 25));
        }
        res.write(`data: ${JSON.stringify({ done: true, emotion, fullText: fallbackReply })}\n\n`);
        res.end();
      } else {
        res.json({
          reply: fallbackReply,
          emotion,
          timestamp: Date.now(),
          conversationId: conversationId || `conv-${Date.now()}`,
          messageId: `msg-${Date.now()}`,
        });
      }
      return;
    }

    const ai = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });

    const systemInstruction = getHinataSystemInstruction(memoryContextStr);

    // Build Gemini contents array from conversation history
    const contents: any[] = [];

    if (Array.isArray(history)) {
      for (const item of history.slice(-12)) {
        if (!item.content) continue;
        const role = item.role === 'user' ? 'user' : 'model';
        contents.push({
          role,
          parts: [{ text: item.content }],
        });
      }
    }

    // Prepare current user turn parts
    const currentParts: any[] = [];

    // Optional image attachment (multimodal vision input)
    if (image && typeof image === 'object') {
      const dataUrl = image.dataUrl || image.base64;
      if (typeof dataUrl === 'string') {
        const matches = dataUrl.match(/^data:([^;]+);base64,(.+)$/);
        if (matches) {
          currentParts.push({
            inlineData: {
              mimeType: matches[1],
              data: matches[2],
            },
          });
        } else if (!dataUrl.startsWith('data:')) {
          currentParts.push({
            inlineData: {
              mimeType: image.mimeType || 'image/jpeg',
              data: dataUrl,
            },
          });
        }
      }
    }

    if (message && typeof message === 'string') {
      currentParts.push({ text: message });
    } else if (currentParts.length > 0 && (!message || message.trim() === '')) {
      currentParts.push({ text: 'Please inspect and explain what you see in this attached image.' });
    }

    contents.push({
      role: 'user',
      parts: currentParts,
    });

    // Handle Streaming vs Non-streaming
    if (stream) {
      res.setHeader('Content-Type', 'text/event-stream');
      res.setHeader('Cache-Control', 'no-cache');
      res.setHeader('Connection', 'keep-alive');

      try {
        const responseStream = await ai.models.generateContentStream({
          model: 'gemini-3.8-flash',
          contents,
          config: {
            systemInstruction,
            temperature: 0.7,
          },
        });

        let fullText = '';
        for await (const chunk of responseStream) {
          const delta = chunk.text;
          if (delta) {
            fullText += delta;
            res.write(`data: ${JSON.stringify({ delta })}\n\n`);
          }
        }

        const emotion = detectEmotion(fullText, message || '');

        // Record assistant turn in ConversationStore
        if (conversationId && fullText) {
          try {
            ConversationStore.getInstance().appendMessage(
              conversationId,
              userId,
              {
                role: 'assistant',
                content: fullText,
                emotion,
                source: 'chat',
              },
              deviceId
            );
          } catch {}
        }

        res.write(`data: ${JSON.stringify({ done: true, fullText, emotion })}\n\n`);
        res.end();
      } catch (streamErr: any) {
        console.error('[AssistantAPI] Streaming error from Gemini:', streamErr);
        const failureStatus = aiProvider.markFailure(streamErr);
        const isAuthError = failureStatus === 'INVALID_KEY' || failureStatus === 'EXPIRED_OR_REVOKED';
        const fallbackReply = isAuthError
          ? 'AI service authentication failed. Please update the API key.'
          : generateFallbackReply(message || '', image, memoryContextStr);
        const emotion = isAuthError ? 'concerned' : detectEmotion(fallbackReply, message || '');
        res.write(`data: ${JSON.stringify({
          delta: fallbackReply,
          fullText: fallbackReply,
          emotion,
          done: true,
          authFailed: isAuthError,
          status: failureStatus,
          warning: isAuthError ? 'AI service authentication failed. Please update the API key.' : 'Something went wrong while connecting to the AI.'
        })}\n\n`);
        res.end();
      }
    } else {
      let reply = "I'm here with you.";
      let emotion = 'calm';

      try {
        const response = await ai.models.generateContent({
          model: 'gemini-3.8-flash',
          contents,
          config: {
            systemInstruction,
            temperature: 0.7,
          },
        });

        reply = response.text || "I'm here with you.";
        emotion = detectEmotion(reply, message || '');

        if (conversationId && reply) {
          ConversationStore.getInstance().appendMessage(
            conversationId,
            userId,
            {
              role: 'assistant',
              content: reply,
              emotion,
              source: 'chat',
            },
            deviceId
          );
        }

        res.json({
          reply,
          emotion,
          timestamp: Date.now(),
          conversationId: conversationId || `conv-${Date.now()}`,
          messageId: `msg-${Date.now()}`,
        });
      } catch (geminiErr: any) {
        console.error('[AssistantAPI] Non-streaming error from Gemini:', geminiErr);
        const failureStatus = aiProvider.markFailure(geminiErr);
        const isAuthError = failureStatus === 'INVALID_KEY' || failureStatus === 'EXPIRED_OR_REVOKED';
        const fallbackReply = isAuthError
          ? 'AI service authentication failed. Please update the API key.'
          : generateFallbackReply(message || '', image, memoryContextStr);
        const fallbackEmotion = isAuthError ? 'concerned' : detectEmotion(fallbackReply, message || '');
        
        if (conversationId && fallbackReply) {
          try {
            ConversationStore.getInstance().appendMessage(
              conversationId,
              userId,
              {
                role: 'assistant',
                content: fallbackReply,
                emotion: fallbackEmotion,
                source: 'chat',
              },
              deviceId
            );
          } catch {}
        }

        res.json({
          reply: fallbackReply,
          emotion: fallbackEmotion,
          timestamp: Date.now(),
          conversationId: conversationId || `conv-${Date.now()}`,
          messageId: `msg-${Date.now()}`,
          authFailed: isAuthError,
          status: failureStatus,
          warning: isAuthError ? 'AI service authentication failed. Please update the API key.' : 'Something went wrong while connecting to the AI.',
        });
      }
    }
  } catch (error: any) {
    console.error('[AssistantAPI] General error:', error);
    if (!res.headersSent) {
      res.status(500).json({ error: 'Something went wrong while connecting to the AI.' });
    } else {
      res.end();
    }
  }
}

/**
 * Intelligent persona fallback when offline or without API key.
 */
function generateFallbackReply(userText: string, image?: any, memCtx?: string): string {
  const query = userText.toLowerCase().trim();

  if (image) {
    return "I see the image you attached! It has been received clearly by my vision module. Once connected to the server network, I'll provide a comprehensive visual and layout analysis.";
  }

  if (/python/i.test(query)) {
    return `Python is a popular, high-level programming language designed for readability and simplicity.

Here is a quick example:

\`\`\`python
# Simple Python greeting
def greet_hinata(name: str):
    return f"Hello {name}, Hinata is ready to assist you!"

print(greet_hinata("Aman"))
\`\`\`

Key features:
- **Clean Syntax**: Uses whitespace indentation rather than curly braces.
- **Vast Ecosystem**: Rich libraries for AI, data science, web development, and automation.
- **Interpreted**: You can run code interactively in real time.`;
  }

  if (/remember/i.test(query)) {
    return "I've noted that in my persistent memory vault. You can review or manage all stored facts at any time in the Memory tab!";
  }

  if (/who are you|introduce/i.test(query)) {
    return "I'm Hinata, your personal AI companion. I combine voice intelligence, visual perception, long-term memory, and Android device control into one unified assistant.";
  }

  if (/how are you|how do you feel/i.test(query)) {
    return "I'm feeling great and ready to help! What are we working on next, Aman?";
  }

  return `I understand: "${userText}". I am fully synchronized and ready to assist you across voice, chat, device actions, or visual analysis.`;
}
