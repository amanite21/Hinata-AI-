/**
 * MemoryStore - Server-side scoped memory storage with multi-device synchronization.
 *
 * Requirements:
 * - Scoped strictly to userId: Phone 1 and Phone 2 for User A share permitted memories.
 * - Strict isolation: Never mix User A memories with User B.
 * - Sensitive credential filter: Rejects passwords, private keys, auth tokens, secrets.
 * - Realistic & truthful: Never invents memories.
 */

export interface ServerMemoryRecord {
  id: string;
  userId: string;
  content: string;
  category: string;
  importance: number;
  source: string;
  tags: string[];
  createdAt: number;
  updatedAt: number;
  lastAccessedAt: number;
}

// Regex patterns to detect and reject credentials/passwords/secrets
const SENSITIVE_PATTERNS = [
  /password\s*[:=]\s*\S+/i,
  /secret\s*[:=]\s*\S+/i,
  /api[_-]?key\s*[:=]\s*\S+/i,
  /bearer\s+[A-Za-z0-9_\-\.]{20,}/i,
  /private[_-]?key/i,
  /auth[_-]?token\s*[:=]\s*\S+/i,
  /\b(sk_live_|ghp_|gho_|xox[baprs]-)[A-Za-z0-9]+/i,
];

export class MemoryStore {
  private static instance: MemoryStore | null = null;
  // Key: userId -> Map<memoryId, ServerMemoryRecord>
  private userMemories: Map<string, Map<string, ServerMemoryRecord>> = new Map();

  private constructor() {}

  public static getInstance(): MemoryStore {
    if (!MemoryStore.instance) {
      MemoryStore.instance = new MemoryStore();
    }
    return MemoryStore.instance;
  }

  /**
   * Validates that content does not contain sensitive tokens or passwords.
   */
  public isContentSafe(content: string): boolean {
    if (!content || typeof content !== 'string') return false;
    for (const pattern of SENSITIVE_PATTERNS) {
      if (pattern.test(content)) {
        return false;
      }
    }
    return true;
  }

  /**
   * Saves or updates a memory record for a specific user.
   */
  public saveMemory(params: {
    userId: string;
    content: string;
    category?: string;
    importance?: number;
    source?: string;
    tags?: string[];
    id?: string;
  }): { success: boolean; memory?: ServerMemoryRecord; error?: string } {
    const {
      userId,
      content,
      category = 'IMPORTANT_FACTS',
      importance = 3,
      source = 'explicit_user',
      tags = [],
      id,
    } = params;

    if (!userId || !content || !content.trim()) {
      return { success: false, error: 'User ID and content are required' };
    }

    // Sensitive data check
    if (!this.isContentSafe(content)) {
      return {
        success: false,
        error: 'Memory cannot be saved: sensitive credentials, secrets, or passwords are not permitted.',
      };
    }

    let userMap = this.userMemories.get(userId);
    if (!userMap) {
      userMap = new Map();
      this.userMemories.set(userId, userMap);
    }

    const memoryId = id || 'mem-' + Date.now().toString(36) + '-' + Math.random().toString(36).substring(2, 8);
    const existing = userMap.get(memoryId);
    const now = Date.now();

    const record: ServerMemoryRecord = {
      id: memoryId,
      userId,
      content: content.trim(),
      category,
      importance: Math.min(10, Math.max(1, importance)),
      source,
      tags: Array.isArray(tags) ? tags : [],
      createdAt: existing ? existing.createdAt : now,
      updatedAt: now,
      lastAccessedAt: now,
    };

    userMap.set(memoryId, record);
    return { success: true, memory: record };
  }

  /**
   * Retrieves memories for a specific user with optional search and category filters.
   */
  public getMemories(
    userId: string,
    filter?: { query?: string; category?: string; minImportance?: number }
  ): ServerMemoryRecord[] {
    const userMap = this.userMemories.get(userId);
    if (!userMap) return [];

    let list = Array.from(userMap.values());

    if (filter?.category) {
      list = list.filter((m) => m.category.toLowerCase() === filter.category!.toLowerCase());
    }

    if (filter?.minImportance !== undefined) {
      list = list.filter((m) => m.importance >= filter.minImportance!);
    }

    if (filter?.query && filter.query.trim()) {
      const q = filter.query.toLowerCase().trim();
      list = list.filter(
        (m) =>
          m.content.toLowerCase().includes(q) ||
          m.category.toLowerCase().includes(q) ||
          m.tags.some((t) => t.toLowerCase().includes(q))
      );
    }

    return list.sort((a, b) => b.updatedAt - a.updatedAt);
  }

  /**
   * Retrieves formatted memory context string for a specific user.
   */
  public getMemoryContext(userId: string, query?: string): string {
    const list = this.getMemories(userId, { query, minImportance: 2 });
    if (list.length === 0) return '';
    return list
      .slice(0, 6)
      .map((m) => `- [${m.category}]: ${m.content}`)
      .join('\n');
  }

  /**
   * Deletes a specific memory item for a user.
   */
  public deleteMemory(userId: string, memoryId: string): boolean {
    const userMap = this.userMemories.get(userId);
    if (!userMap) return false;
    return userMap.delete(memoryId);
  }

  /**
   * Clears all memories for a user.
   */
  public clearUserMemories(userId: string): void {
    this.userMemories.delete(userId);
  }
}
