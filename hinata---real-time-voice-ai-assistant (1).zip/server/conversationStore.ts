/**
 * ConversationStore - User-scoped and device-aware conversation management.
 *
 * Requirements addressed:
 * - Unique conversationId per thread (e.g., conversation-xxxxxxxx).
 * - Scoped strictly to userId so conversations are never mixed between different users.
 * - Supports multiple devices for the same user (e.g. Phone 1 voice conversation continued on Phone 2 in chat).
 * - Simultaneous conversations on different phones remain isolated without context contamination.
 */

export interface ConversationTurnMessage {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp: number;
  emotion?: string;
  source?: 'chat' | 'voice' | 'vision';
  deviceId?: string;
}

export interface ConversationThread {
  id: string; // conversationId
  userId: string;
  title: string;
  messages: ConversationTurnMessage[];
  createdAt: number;
  updatedAt: number;
  lastDeviceId?: string;
}

export class ConversationStore {
  private static instance: ConversationStore | null = null;
  // Key: conversationId -> ConversationThread
  private conversations: Map<string, ConversationThread> = new Map();

  private constructor() {}

  public static getInstance(): ConversationStore {
    if (!ConversationStore.instance) {
      ConversationStore.instance = new ConversationStore();
    }
    return ConversationStore.instance;
  }

  /**
   * Generates a unique conversation ID
   */
  public generateConversationId(): string {
    return 'conversation-' + Date.now().toString(36) + '-' + Math.random().toString(36).substring(2, 8);
  }

  /**
   * Gets or creates a conversation thread, verifying that it belongs to the given userId.
   */
  public getOrCreateConversation(
    conversationId: string | undefined,
    userId: string = 'user-001',
    deviceId?: string,
    initialTitle?: string
  ): ConversationThread {
    const id = conversationId || this.generateConversationId();
    const existing = this.conversations.get(id);

    if (existing) {
      // Security check: ensure userId matches
      if (existing.userId !== userId) {
        console.warn(`[ConversationStore] Security mismatch: conv ${id} belongs to ${existing.userId}, not ${userId}`);
        // Create new scoped conversation instead of leaking User A to User B
        const safeNewId = this.generateConversationId();
        const safeThread: ConversationThread = {
          id: safeNewId,
          userId,
          title: initialTitle || 'New Conversation',
          messages: [],
          createdAt: Date.now(),
          updatedAt: Date.now(),
          lastDeviceId: deviceId,
        };
        this.conversations.set(safeNewId, safeThread);
        return safeThread;
      }
      if (deviceId) {
        existing.lastDeviceId = deviceId;
      }
      return existing;
    }

    const newThread: ConversationThread = {
      id,
      userId,
      title: initialTitle || 'New Conversation',
      messages: [],
      createdAt: Date.now(),
      updatedAt: Date.now(),
      lastDeviceId: deviceId,
    };
    this.conversations.set(id, newThread);
    return newThread;
  }

  /**
   * Retrieves a conversation only if it belongs to the specified userId.
   */
  public getConversation(conversationId: string, userId: string): ConversationThread | null {
    const conv = this.conversations.get(conversationId);
    if (!conv || conv.userId !== userId) {
      return null;
    }
    return conv;
  }

  /**
   * Appends a message to a conversation thread.
   */
  public appendMessage(
    conversationId: string,
    userId: string,
    message: Omit<ConversationTurnMessage, 'id' | 'timestamp'> & { id?: string; timestamp?: number },
    deviceId?: string
  ): ConversationTurnMessage | null {
    const thread = this.getOrCreateConversation(conversationId, userId, deviceId);
    if (thread.userId !== userId) {
      return null;
    }

    const fullMessage: ConversationTurnMessage = {
      id: message.id || 'msg-' + Date.now() + '-' + Math.random().toString(36).substring(2, 6),
      role: message.role,
      content: message.content,
      timestamp: message.timestamp || Date.now(),
      emotion: message.emotion,
      source: message.source || 'chat',
      deviceId: deviceId || thread.lastDeviceId,
    };

    thread.messages.push(fullMessage);
    thread.updatedAt = Date.now();
    if (deviceId) {
      thread.lastDeviceId = deviceId;
    }

    // Auto-update title from first user message if default
    if (thread.title === 'New Conversation' && message.role === 'user' && message.content.trim()) {
      const trimmed = message.content.trim();
      thread.title = trimmed.slice(0, 36) + (trimmed.length > 36 ? '...' : '');
    }

    return fullMessage;
  }

  /**
   * Lists all conversations belonging to a user (sorted by updatedAt descending).
   */
  public listConversations(userId: string): ConversationThread[] {
    const result: ConversationThread[] = [];
    for (const conv of this.conversations.values()) {
      if (conv.userId === userId) {
        result.push(conv);
      }
    }
    return result.sort((a, b) => b.updatedAt - a.updatedAt);
  }

  /**
   * Deletes a conversation if it belongs to the specified userId.
   */
  public deleteConversation(conversationId: string, userId: string): boolean {
    const conv = this.conversations.get(conversationId);
    if (!conv || conv.userId !== userId) {
      return false;
    }
    return this.conversations.delete(conversationId);
  }

  /**
   * Clears all conversations for a specific user.
   */
  public clearUserConversations(userId: string): void {
    for (const [id, conv] of this.conversations.entries()) {
      if (conv.userId === userId) {
        this.conversations.delete(id);
      }
    }
  }
}
