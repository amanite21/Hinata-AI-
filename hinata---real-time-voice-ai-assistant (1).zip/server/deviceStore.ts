/**
 * DeviceStore - In-memory multi-device registry for Hinata online backend.
 *
 * Supports multiple Android phones and client installations connecting to the same backend:
 * - Tracks deviceId, userId, deviceName, platform, appVersion, and lastActive timestamp.
 * - Associates multiple devices with a single userId (e.g. Phone 1 and Phone 2 owned by user-001).
 * - Safe: Never stores private credentials or unnecessary personal information.
 */

export interface DeviceRecord {
  deviceId: string;
  userId: string;
  deviceName: string;
  platform: 'android' | 'web' | 'ios' | string;
  appVersion: string;
  registeredAt: number;
  lastActiveAt: number;
  ipAddress?: string;
  metadata?: Record<string, any>;
}

export class DeviceStore {
  private static instance: DeviceStore | null = null;
  private devices: Map<string, DeviceRecord> = new Map();

  private constructor() {}

  public static getInstance(): DeviceStore {
    if (!DeviceStore.instance) {
      DeviceStore.instance = new DeviceStore();
    }
    return DeviceStore.instance;
  }

  /**
   * Registers or updates a device record.
   */
  public registerDevice(params: {
    deviceId: string;
    deviceName?: string;
    platform?: string;
    appVersion?: string;
    userId?: string;
    ipAddress?: string;
    metadata?: Record<string, any>;
  }): DeviceRecord {
    const {
      deviceId,
      deviceName = 'Android Device',
      platform = 'android',
      appVersion = '1.0.0',
      userId = 'user-001',
      ipAddress,
      metadata = {},
    } = params;

    const existing = this.devices.get(deviceId);
    const now = Date.now();

    const record: DeviceRecord = {
      deviceId,
      userId: userId || existing?.userId || 'user-001',
      deviceName: deviceName || existing?.deviceName || 'Android Device',
      platform: platform || existing?.platform || 'android',
      appVersion: appVersion || existing?.appVersion || '1.0.0',
      registeredAt: existing ? existing.registeredAt : now,
      lastActiveAt: now,
      ipAddress,
      metadata: { ...(existing?.metadata || {}), ...metadata },
    };

    this.devices.set(deviceId, record);
    return record;
  }

  public getDevice(deviceId: string): DeviceRecord | undefined {
    return this.devices.get(deviceId);
  }

  public updateHeartbeat(deviceId: string): void {
    const dev = this.devices.get(deviceId);
    if (dev) {
      dev.lastActiveAt = Date.now();
    }
  }

  public getDevicesByUserId(userId: string): DeviceRecord[] {
    const result: DeviceRecord[] = [];
    for (const dev of this.devices.values()) {
      if (dev.userId === userId) {
        result.push(dev);
      }
    }
    return result;
  }

  public getAllDevices(): DeviceRecord[] {
    return Array.from(this.devices.values());
  }

  public removeDevice(deviceId: string): boolean {
    return this.devices.delete(deviceId);
  }
}
