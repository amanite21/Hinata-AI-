import { GoogleGenAI } from '@google/genai';

/**
 * Supported granular status states for Hinata AI Service
 */
export type AIStatusState =
  | 'NOT_CONFIGURED'
  | 'TESTING'
  | 'CONNECTED'
  | 'INVALID_KEY'
  | 'EXPIRED_OR_REVOKED'
  | 'QUOTA_EXCEEDED'
  | 'RATE_LIMITED'
  | 'NETWORK_ERROR'
  | 'PROVIDER_ERROR';

/**
 * Safe Configuration Model (Strictly zero raw secrets)
 */
export interface AIProviderStatus {
  provider: 'gemini';
  model: string;
  status: AIStatusState;
  statusMessage?: string;
  lastTestedAt: number | null;
  keyUpdatedAt: number | null;
  maskedKeySuffix: string; // e.g. "••••••••••••ABCD"
  isConfigured: boolean;
  environmentSource: 'env' | 'runtime';
}

/**
 * Formats a key so only the last 4 characters are visible.
 * Never leaks the full key or any intermediate prefix.
 */
export function maskKey(key?: string | null): string {
  if (!key || typeof key !== 'string' || key.trim().length === 0) {
    return '';
  }
  const clean = key.trim();
  if (clean.length <= 4) {
    return '••••••••••••' + clean;
  }
  const suffix = clean.slice(-4);
  return '••••••••••••' + suffix;
}

/**
 * Accurately categorizes errors without generic mislabeling.
 */
export function categorizeGeminiError(err: any): { status: AIStatusState; message: string } {
  const errMsg = (err?.message || err?.toString() || '').toLowerCase();
  const status = err?.status || err?.statusCode || 0;

  // 401 or invalid credential
  if (
    status === 401 ||
    errMsg.includes('api_key_invalid') ||
    errMsg.includes('api key not valid') ||
    errMsg.includes('invalid api key') ||
    errMsg.includes('api key invalid') ||
    errMsg.includes('unauthenticated') ||
    errMsg.includes('bad request') && errMsg.includes('key')
  ) {
    return {
      status: 'INVALID_KEY',
      message: 'Invalid API Key. The credential provided was rejected by Gemini.',
    };
  }

  // 403 or revoked / suspended / expired
  if (
    status === 403 ||
    errMsg.includes('permission_denied') ||
    errMsg.includes('consumer_suspended') ||
    errMsg.includes('revoked') ||
    errMsg.includes('expired') ||
    errMsg.includes('forbidden') ||
    errMsg.includes('permission denied')
  ) {
    return {
      status: 'EXPIRED_OR_REVOKED',
      message: 'API Key Expired or Revoked. The credential is no longer authorized.',
    };
  }

  // Quota exceeded
  if (
    errMsg.includes('quota') ||
    errMsg.includes('resource_exhausted') ||
    errMsg.includes('billing') ||
    errMsg.includes('exceeded your current quota') ||
    (status === 429 && errMsg.includes('quota'))
  ) {
    return {
      status: 'QUOTA_EXCEEDED',
      message: 'Quota Exceeded. Check your Gemini API tier or billing account.',
    };
  }

  // Rate limited
  if (
    status === 429 ||
    errMsg.includes('rate limit') ||
    errMsg.includes('rate_limit') ||
    errMsg.includes('too many requests')
  ) {
    return {
      status: 'RATE_LIMITED',
      message: 'Rate Limited. Too many requests sent in a short period.',
    };
  }

  // Network failure
  if (
    errMsg.includes('enotfound') ||
    errMsg.includes('econnrefused') ||
    errMsg.includes('etimedout') ||
    errMsg.includes('timeout') ||
    errMsg.includes('fetch failed') ||
    errMsg.includes('network') ||
    errMsg.includes('socket hang up') ||
    errMsg.includes('connection refused')
  ) {
    return {
      status: 'NETWORK_ERROR',
      message: 'Network Error. Could not connect to Gemini API servers.',
    };
  }

  return {
    status: 'PROVIDER_ERROR',
    message: err?.message ? `Provider Error: ${err.message}` : 'Gemini provider error occurred.',
  };
}

/**
 * Lightweight verification probe to validate a Gemini API key.
 * Never logs or prints the raw key.
 */
export async function verifyKeyWithGemini(
  keyToVerify: string
): Promise<{ ok: boolean; status: AIStatusState; message: string; latencyMs: number }> {
  const trimmed = keyToVerify?.trim() || '';
  if (!trimmed) {
    return {
      ok: false,
      status: 'NOT_CONFIGURED',
      message: 'No API key provided.',
      latencyMs: 0,
    };
  }

  // Pre-validate obviously malformed keys
  if (trimmed.length < 10 || /\s/.test(trimmed)) {
    return {
      ok: false,
      status: 'INVALID_KEY',
      message: 'Invalid API Key format. Gemini API keys do not contain spaces and must be valid credentials.',
      latencyMs: 5,
    };
  }

  const start = Date.now();
  let timer: NodeJS.Timeout | null = null;
  try {
    const timeoutPromise = new Promise<never>((_, reject) => {
      timer = setTimeout(() => {
        reject(new Error('Network timeout: Gemini API servers did not respond within 6 seconds.'));
      }, 6000);
    });

    const verifyPromise = (async () => {
      const ai = new GoogleGenAI({
        apiKey: trimmed,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build',
          },
        },
      });

      // Fast 1-token query to verify authentication and quota
      return await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: 'ping',
        config: {
          maxOutputTokens: 1,
        },
      });
    })();

    await Promise.race([verifyPromise, timeoutPromise]);
    if (timer) clearTimeout(timer);

    const latencyMs = Date.now() - start;
    return {
      ok: true,
      status: 'CONNECTED',
      message: 'API key verified and connected successfully.',
      latencyMs,
    };
  } catch (err: any) {
    if (timer) clearTimeout(timer);
    const latencyMs = Date.now() - start;
    const cat = categorizeGeminiError(err);
    return {
      ok: false,
      status: cat.status,
      message: cat.message,
      latencyMs,
    };
  }
}

/**
 * Centralized Server-Side AI Provider & Key Manager.
 *
 * Provides:
 * - Runtime secret rotation without container/APK rebuild
 * - Safe test and verification without leaking secrets
 * - Centralized key consumption for Chat, Voice, Vision, and Design
 * - Automatic failure state tracking and reactive status
 */
export class CentralAIProvider {
  private static instance: CentralAIProvider | null = null;

  // Active key kept exclusively in server memory
  private runtimeApiKey: string | null = null;
  private currentStatus: AIStatusState = 'NOT_CONFIGURED';
  private statusMessage: string = '';
  private lastTestedAt: number | null = null;
  private keyUpdatedAt: number | null = null;
  private environmentSource: 'env' | 'runtime' = 'env';

  private constructor() {
    this.initFromEnv();
  }

  public static getInstance(): CentralAIProvider {
    if (!CentralAIProvider.instance) {
      CentralAIProvider.instance = new CentralAIProvider();
    }
    return CentralAIProvider.instance;
  }

  private initFromEnv(): void {
    const envKey = process.env.GEMINI_API_KEY;
    if (envKey && envKey.trim().length > 0) {
      this.runtimeApiKey = envKey.trim();
      this.currentStatus = 'CONNECTED';
      this.statusMessage = 'Configured via environment variable';
      this.keyUpdatedAt = Date.now();
      this.environmentSource = 'env';
    } else {
      this.runtimeApiKey = null;
      this.currentStatus = 'NOT_CONFIGURED';
      this.statusMessage = 'No API key configured';
      this.environmentSource = 'env';
    }
  }

  /**
   * Returns the current active API key for server-side operations.
   * Strictly server-side: NEVER export or send to client.
   */
  public getActiveApiKey(): string | null {
    return this.runtimeApiKey || process.env.GEMINI_API_KEY || null;
  }

  /**
   * Creates a GoogleGenAI SDK client using the current active key.
   * Throws clear error if key is not configured.
   */
  public createClient(): GoogleGenAI {
    const key = this.getActiveApiKey();
    if (!key) {
      throw new Error('GEMINI_API_KEY is not configured on the backend.');
    }
    return new GoogleGenAI({
      apiKey: key,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }

  /**
   * Returns safe metadata for client consumption (No secrets!).
   */
  public getStatus(): AIProviderStatus {
    const activeKey = this.getActiveApiKey();
    const isConfigured = Boolean(activeKey && activeKey.trim().length > 0);

    return {
      provider: 'gemini',
      model: 'gemini-3.8-flash / gemini-3.1-flash-live-preview',
      status: this.currentStatus,
      statusMessage: this.statusMessage,
      lastTestedAt: this.lastTestedAt,
      keyUpdatedAt: this.keyUpdatedAt,
      maskedKeySuffix: maskKey(activeKey),
      isConfigured,
      environmentSource: this.environmentSource,
    };
  }

  /**
   * Tests either the currently active key or an entered candidate key.
   * Does NOT alter the active configuration.
   */
  public async testCandidateKey(
    candidateKey?: string
  ): Promise<{ ok: boolean; status: AIStatusState; message: string; latencyMs: number; maskedKeySuffix: string }> {
    const keyToTest = candidateKey && candidateKey.trim().length > 0 ? candidateKey.trim() : this.getActiveApiKey();

    if (!keyToTest) {
      return {
        ok: false,
        status: 'NOT_CONFIGURED',
        message: 'No API key to test.',
        latencyMs: 0,
        maskedKeySuffix: '',
      };
    }

    const testRes = await verifyKeyWithGemini(keyToTest);
    this.lastTestedAt = Date.now();

    // If testing the active key, reflect verified status
    if (!candidateKey || candidateKey.trim() === this.getActiveApiKey()) {
      this.currentStatus = testRes.status;
      this.statusMessage = testRes.message;
    }

    return {
      ok: testRes.ok,
      status: testRes.status,
      message: testRes.message,
      latencyMs: testRes.latencyMs,
      maskedKeySuffix: maskKey(keyToTest),
    };
  }

  /**
   * Rotates to a new API key following the strict safety requirement:
   * NEW KEY -> TEST CONNECTION -> SUCCESS?
   *   YES -> Activate New Key
   *   NO  -> Keep Existing Key
   */
  public async rotateKey(
    newKey: string
  ): Promise<{ success: boolean; status: AIStatusState; message: string; maskedKeySuffix: string }> {
    if (!newKey || typeof newKey !== 'string' || newKey.trim().length === 0) {
      return {
        success: false,
        status: 'NOT_CONFIGURED',
        message: 'API key cannot be empty.',
        maskedKeySuffix: maskKey(this.getActiveApiKey()),
      };
    }

    const cleanNewKey = newKey.trim();

    // 1. Test candidate key before touching active key
    const testResult = await verifyKeyWithGemini(cleanNewKey);

    if (!testResult.ok) {
      // KEEP EXISTING KEY! Do not overwrite working configuration
      return {
        success: false,
        status: testResult.status,
        message: `${testResult.message} Existing key has been preserved.`,
        maskedKeySuffix: maskKey(this.getActiveApiKey()),
      };
    }

    // 2. Activate new key
    this.runtimeApiKey = cleanNewKey;
    this.currentStatus = 'CONNECTED';
    this.statusMessage = 'New API key activated successfully';
    this.lastTestedAt = Date.now();
    this.keyUpdatedAt = Date.now();
    this.environmentSource = 'runtime';

    return {
      success: true,
      status: 'CONNECTED',
      message: 'New API key activated and verified.',
      maskedKeySuffix: maskKey(cleanNewKey),
    };
  }

  /**
   * Tracks runtime errors thrown by Gemini API consumers (Chat, Voice, Vision).
   * Updates central status to trigger automatic failure detection.
   */
  public markFailure(err: any): AIStatusState {
    const cat = categorizeGeminiError(err);
    this.currentStatus = cat.status;
    this.statusMessage = cat.message;
    return cat.status;
  }
}
