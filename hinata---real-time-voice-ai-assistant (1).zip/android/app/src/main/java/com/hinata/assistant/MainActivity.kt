package com.hinata.assistant

import android.Manifest
import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.util.Log
import android.view.Gravity
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.util.Locale
import kotlin.concurrent.thread

/**
 * MainActivity - Primary Companion Application for Hinata AI on Android.
 *
 * Implements:
 * - Connection to online Hinata backend via HTTPS (configured via HINATA_BACKEND_URL).
 * - Multi-device support: scoped with unique deviceId and userId.
 * - Live Connection State tracker (CONNECTED, CONNECTING, DISCONNECTED, ERROR).
 * - Native speech recognition & Text-To-Speech pipeline directly tied to POST /api/assistant.
 * - Clean separation between DEVELOPMENT and PRODUCTION backend URLs.
 * - In-app health test dialog to verify online backend connectivity (/health).
 * - Zero hardcoded Gemini API key on Android.
 */
class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {

    companion object {
        private const val TAG = "HinataMainActivity"
        private const val PERMISSION_REQUEST_RECORD_AUDIO = 1001
    }

    private lateinit var rootContainer: FrameLayout
    private lateinit var webView: WebView
    private lateinit var statusBanner: TextView
    private lateinit var config: HinataConfig
    private lateinit var apiClient: HinataApiClient

    private var tts: TextToSpeech? = null
    private var isTtsReady = false
    private var speechRecognizer: SpeechRecognizer? = null
    private val mainHandler = Handler(Looper.getMainLooper())

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        config = HinataConfig.getInstance(this)
        apiClient = HinataApiClient.getInstance(this)

        tts = TextToSpeech(this, this)

        rootContainer = FrameLayout(this).apply {
            id = View.generateViewId()
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
            setBackgroundColor(Color.parseColor("#0B0F19"))
        }

        webView = WebView(this).apply {
            id = View.generateViewId()
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
        }

        statusBanner = TextView(this).apply {
            id = View.generateViewId()
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                gravity = Gravity.TOP
            }
            setBackgroundColor(Color.parseColor("#E11D48"))
            setTextColor(Color.WHITE)
            setPadding(32, 20, 32, 20)
            textSize = 13f
            gravity = Gravity.CENTER
            visibility = View.GONE
        }

        rootContainer.addView(webView)
        rootContainer.addView(statusBanner)
        setContentView(rootContainer)

        setupConnectionListener()
        configureWebView()
        requestRequiredPermissions()
        startVoiceServiceIfPermitted()

        // Perform initial health check asynchronously
        verifyBackendConnectivity()
        loadBackend()
    }

    private fun setupConnectionListener() {
        apiClient.addConnectionListener(object : HinataApiClient.ConnectionStateListener {
            override fun onStateChanged(state: HinataApiClient.ConnectionState, message: String?) {
                mainHandler.post {
                    when (state) {
                        HinataApiClient.ConnectionState.CONNECTED -> {
                            statusBanner.visibility = View.GONE
                        }
                        HinataApiClient.ConnectionState.CONNECTING -> {
                            statusBanner.text = "Connecting to Hinata server..."
                            statusBanner.setBackgroundColor(Color.parseColor("#D97706"))
                            statusBanner.visibility = View.VISIBLE
                        }
                        HinataApiClient.ConnectionState.DISCONNECTED -> {
                            statusBanner.text = message ?: "No internet connection."
                            statusBanner.setBackgroundColor(Color.parseColor("#DC2626"))
                            statusBanner.visibility = View.VISIBLE
                        }
                        HinataApiClient.ConnectionState.ERROR -> {
                            statusBanner.text = message ?: "Can't reach Hinata's server."
                            statusBanner.setBackgroundColor(Color.parseColor("#E11D48"))
                            statusBanner.visibility = View.VISIBLE
                        }
                    }
                }
            }
        })
    }

    private fun verifyBackendConnectivity() {
        thread {
            val status = apiClient.checkHealth()
            Log.i(TAG, "Backend health status: ${status.service}, healthy: ${status.isHealthy}")
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun configureWebView() {
        val settings = webView.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.databaseEnabled = true
        settings.mediaPlaybackRequiresUserGesture = false
        settings.cacheMode = WebSettings.LOAD_DEFAULT

        webView.addJavascriptInterface(HinataNativeBridge(), "HinataAndroid")

        webView.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: PermissionRequest?) {
                request?.let {
                    it.grant(it.resources)
                }
            }
        }

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val url = request?.url?.toString() ?: return false
                val backendUri = Uri.parse(config.activeBackendUrl)

                if (request.url.host == backendUri.host || url.startsWith("http://10.0.2.2")) {
                    return false
                }

                try {
                    val intent = Intent(Intent.ACTION_VIEW, request.url)
                    startActivity(intent)
                    return true
                } catch (e: Exception) {
                    return false
                }
            }

            override fun onReceivedError(
                view: WebView?,
                request: WebResourceRequest?,
                error: WebResourceError?
            ) {
                super.onReceivedError(view, request, error)
                if (request?.isForMainFrame == true) {
                    mainHandler.post {
                        statusBanner.text = "Can't reach Hinata's server. Tap to configure."
                        statusBanner.visibility = View.VISIBLE
                        statusBanner.setOnClickListener { showBackendSettingsDialog() }
                    }
                }
            }
        }

        webView.setOnLongClickListener {
            showBackendSettingsDialog()
            true
        }
    }

    private fun loadBackend() {
        val url = config.activeBackendUrl
        val extraHeaders = config.getHeaders()
        Log.i(TAG, "Loading Hinata backend: $url")
        webView.loadUrl(url, extraHeaders)
    }

    /**
     * Settings dialog to view, test, and switch between PRODUCTION and DEVELOPMENT backends.
     */
    private fun showBackendSettingsDialog() {
        val context = this
        val layout = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 24, 48, 24)
        }

        val radioGroup = RadioGroup(context)
        val rbProd = RadioButton(context).apply {
            text = "Production Backend (HTTPS Online Cloud)"
            id = View.generateViewId()
        }
        val rbDev = RadioButton(context).apply {
            text = "Development Backend (10.0.2.2 / Localhost)"
            id = View.generateViewId()
        }
        val rbCustom = RadioButton(context).apply {
            text = "Custom Online Server URL (HTTPS)"
            id = View.generateViewId()
        }

        radioGroup.addView(rbProd)
        radioGroup.addView(rbDev)
        radioGroup.addView(rbCustom)

        when (config.environment.uppercase()) {
            "DEVELOPMENT" -> radioGroup.check(rbDev.id)
            "CUSTOM" -> radioGroup.check(rbCustom.id)
            else -> radioGroup.check(rbProd.id)
        }

        val currentUrlLabel = TextView(context).apply {
            text = "Active Target: ${config.activeBackendUrl}"
            textSize = 12f
            setTextColor(Color.DKGRAY)
            setPadding(0, 16, 0, 8)
        }

        val customUrlInput = EditText(context).apply {
            hint = "https://YOUR-REAL-BACKEND-DOMAIN.com"
            setText(config.customBackendUrl)
            visibility = if (config.environment.uppercase() == "CUSTOM") View.VISIBLE else View.GONE
        }

        val userIdInput = EditText(context).apply {
            hint = "User ID (e.g. user-001 for cross-phone sync)"
            setText(config.userId)
        }

        val testConnectionButton = Button(context).apply {
            text = "Test Connection (/health)"
            setOnClickListener {
                thread {
                    val status = apiClient.checkHealth()
                    mainHandler.post {
                        val message = if (status.isHealthy) {
                            "Connection OK! Service: ${status.service}"
                        } else {
                            status.rawMessage ?: "Connection failed."
                        }
                        Toast.makeText(context, message, Toast.LENGTH_LONG).show()
                    }
                }
            }
        }

        radioGroup.setOnCheckedChangeListener { _, checkedId ->
            customUrlInput.visibility = if (checkedId == rbCustom.id) View.VISIBLE else View.GONE
        }

        layout.addView(radioGroup)
        layout.addView(currentUrlLabel)
        layout.addView(customUrlInput)
        layout.addView(userIdInput)
        layout.addView(testConnectionButton)

        AlertDialog.Builder(context)
            .setTitle("Hinata Backend Configuration")
            .setView(layout)
            .setPositiveButton("Save & Reconnect") { _, _ ->
                val chosenEnv = when (radioGroup.checkedRadioButtonId) {
                    rbDev.id -> "DEVELOPMENT"
                    rbCustom.id -> "CUSTOM"
                    else -> "PRODUCTION"
                }
                config.environment = chosenEnv
                config.customBackendUrl = customUrlInput.text.toString().trim()
                if (userIdInput.text.isNotBlank()) {
                    config.userId = userIdInput.text.toString().trim()
                }

                Toast.makeText(this, "Connecting to: ${config.activeBackendUrl}", Toast.LENGTH_SHORT).show()
                verifyBackendConnectivity()
                loadBackend()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun requestRequiredPermissions() {
        val permissions = mutableListOf<String>()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            permissions.add(Manifest.permission.RECORD_AUDIO)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                permissions.add(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
        if (permissions.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, permissions.toTypedArray(), PERMISSION_REQUEST_RECORD_AUDIO)
        }
    }

    private fun startVoiceServiceIfPermitted() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            val serviceIntent = Intent(this, HinataForegroundVoiceService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(serviceIntent)
            } else {
                startService(serviceIntent)
            }
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == PERMISSION_REQUEST_RECORD_AUDIO) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                startVoiceServiceIfPermitted()
            }
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.language = Locale.US
            isTtsReady = true
            Log.i(TAG, "Native TextToSpeech initialized successfully.")
        }
    }

    /**
     * Native bridge interface exposed to WebView JavaScript as window.HinataAndroid
     */
    inner class HinataNativeBridge {
        @JavascriptInterface
        fun getBackendUrl(): String = config.activeBackendUrl

        @JavascriptInterface
        fun getDeviceId(): String = config.deviceId

        @JavascriptInterface
        fun getUserId(): String = config.userId

        @JavascriptInterface
        fun getConnectionState(): String = apiClient.currentState.name

        @JavascriptInterface
        fun speakText(text: String) {
            if (isTtsReady && !text.isNullOrBlank()) {
                mainHandler.post {
                    tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "hinata_utterance")
                }
            }
        }

        @JavascriptInterface
        fun sendNativeAssistantMessage(message: String, conversationId: String) {
            thread {
                val result = apiClient.sendAssistantMessage(message, conversationId)
                result.onSuccess { res ->
                    mainHandler.post {
                        if (isTtsReady) {
                            tts?.speak(res.reply, TextToSpeech.QUEUE_FLUSH, null, "hinata_utterance")
                        }
                        webView.evaluateJavascript(
                            "window.onNativeAssistantResponse && window.onNativeAssistantResponse(${JSONObject(mapOf("reply" to res.reply, "emotion" to res.emotion, "conversationId" to res.conversationId)).toString()});",
                            null
                        )
                    }
                }.onFailure { err ->
                    mainHandler.post {
                        Toast.makeText(this@MainActivity, err.message ?: "Connection error", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        tts?.stop()
        tts?.shutdown()
        speechRecognizer?.destroy()
    }

    override fun onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }
}
