package com.hinata.assistant

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log

/**
 * HinataWakeWordDetector - Lightweight local keyword spotter on Android.
 *
 * Uses Android's offline/on-device SpeechRecognizer or embedded model to listen
 * locally for "Hey Hinata" without sending continuous audio streams to remote servers.
 */
class HinataWakeWordDetector(
    private val context: Context,
    private val onWakeDetected: (phrase: String) -> Unit
) {
    companion object {
        private const val TAG = "HinataWakeDetector"
        const val WAKE_PHRASE = "hey hinata"
    }

    private var speechRecognizer: SpeechRecognizer? = null
    private var isListening = false

    fun startListening() {
        if (isListening) return

        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            Log.w(TAG, "SpeechRecognizer not available on device.")
            return
        }

        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onError(error: Int) {
                    if (isListening) {
                        restartListening()
                    }
                }

                override fun onResults(results: Bundle?) {
                    val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    matches?.forEach { candidate ->
                        val lower = candidate.lowercase().trim()
                        if (lower.contains(WAKE_PHRASE) || lower == "hinata") {
                            Log.i(TAG, "✦ Wake phrase spotted: $candidate")
                            onWakeDetected(candidate)
                            return
                        }
                    }
                    if (isListening) {
                        restartListening()
                    }
                }

                override fun onPartialResults(partialResults: Bundle?) {
                    val partialMatches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    partialMatches?.forEach { candidate ->
                        if (candidate.lowercase().contains(WAKE_PHRASE)) {
                            Log.i(TAG, "✦ Wake phrase spotted in partials: $candidate")
                            onWakeDetected(candidate)
                            return
                        }
                    }
                }

                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
        }

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true) // Local on-device processing
        }

        try {
            speechRecognizer?.startListening(intent)
            isListening = true
            Log.i(TAG, "WakeWordDetector is actively listening for: $WAKE_PHRASE")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to start wake-word listening", e)
        }
    }

    private fun restartListening() {
        speechRecognizer?.cancel()
        startListening()
    }

    fun stopListening() {
        isListening = false
        speechRecognizer?.stopListening()
        speechRecognizer?.destroy()
        speechRecognizer = null
        Log.i(TAG, "WakeWordDetector stopped.")
    }
}
