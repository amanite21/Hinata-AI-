package com.hinata.assistant

import android.os.Bundle
import android.service.voice.VoiceInteractionSession
import android.service.voice.VoiceInteractionSessionService

/**
 * HinataVoiceInteractionSessionService
 * Factory service that instantiates HinataVoiceInteractionSession when summoned.
 */
class HinataVoiceInteractionSessionService : VoiceInteractionSessionService() {

    override fun onNewSession(args: Bundle?): VoiceInteractionSession {
        return HinataVoiceInteractionSession(this)
    }
}
