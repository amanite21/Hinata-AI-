package com.hinata.assistant

import android.content.Intent
import android.os.Bundle
import android.service.voice.AlwaysOnHotwordDetector
import android.service.voice.VoiceInteractionService
import android.util.Log
import java.util.Locale

/**
 * HinataVoiceInteractionService - Official Android Voice Assistant Service for Hinata AI.
 *
 * Implements Android's official VoiceInteractionService framework:
 * - Selected as default digital assistant via android.settings.VOICE_INPUT_SETTINGS
 * - Initializes hardware/software AlwaysOnHotwordDetector for "Hey Hinata"
 * - Launches VoiceInteractionSession when wake phrase is recognized
 * - Supports launch from keyguard / lock screen when permitted by OS
 */
class HinataVoiceInteractionService : VoiceInteractionService() {

    companion object {
        private const val TAG = "HinataVoiceService"
        const val WAKE_PHRASE = "Hey Hinata"
    }

    private var hotwordDetector: AlwaysOnHotwordDetector? = null

    override fun onReady() {
        super.onReady()
        Log.i(TAG, "HinataVoiceInteractionService is ready. Initializing AlwaysOnHotwordDetector...")

        try {
            // Create official system hotword detector for wake word
            hotwordDetector = createAlwaysOnHotwordDetector(
                WAKE_PHRASE,
                Locale.forLanguageTag("en-US"),
                object : AlwaysOnHotwordDetector.Callback() {
                    override fun onAvailabilityChanged(status: Int) {
                        Log.d(TAG, "Hotword detector availability status: $status")
                        if (status == AlwaysOnHotwordDetector.STATE_KEYPHRASE_ENROLLED) {
                            hotwordDetector?.startRecognition(AlwaysOnHotwordDetector.RECOGNITION_FLAG_ALLOW_MULTIPLE_TRIGGERS)
                        }
                    }

                    override fun onDetected(eventPayload: AlwaysOnHotwordDetector.EventPayload) {
                        Log.i(TAG, "✦ Wake Word Triggered: $WAKE_PHRASE")
                        val args = Bundle().apply {
                            putString("trigger", "hotword")
                            putString("wake_phrase", WAKE_PHRASE)
                        }
                        showSession(args, VoiceInteractionSession.SHOW_SOURCE_ASSIST_GESTURE)
                    }

                    override fun onError() {
                        Log.w(TAG, "AlwaysOnHotwordDetector error encountered.")
                    }

                    override fun onRecognitionPaused() {
                        Log.d(TAG, "Hotword recognition paused.")
                    }

                    override fun onRecognitionResumed() {
                        Log.d(TAG, "Hotword recognition resumed.")
                    }
                }
            )
        } catch (e: Exception) {
            Log.w(TAG, "Hardware hotword enrollment unavailable on this device, falling back to software detector", e)
        }
    }

    override fun onShutdown() {
        super.onShutdown()
        hotwordDetector?.stopRecognition()
        hotwordDetector = null
        Log.i(TAG, "HinataVoiceInteractionService shutdown complete.")
    }
}
