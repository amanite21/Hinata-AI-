package com.hinata.assistant

import android.content.Context
import android.content.SharedPreferences
import android.os.Build
import android.util.Log
import java.util.UUID

/**
 * HinataConfig - Master configuration manager for the Hinata Android Assistant.
 *
 * Implements:
 * 1. Single configurable production backend URL: HINATA_BACKEND_URL
 *    Placeholder: https://YOUR-REAL-BACKEND-DOMAIN.com
 * 2. Complete removal of localhost / 127.0.0.1 / 10.0.2.2 from production.
 * 3. Gradle BuildConfig integration with clean separation between Development and Production.
 * 4. Runtime validation enforcing HTTPS for production.
 * 5. App-specific persistent UUID deviceId stored in SharedPreferences (zero IMEI / hardware secrets).
 * 6. User ID abstraction for multi-phone account synchronization.
 * 7. In-app settings override capability allowing user to specify the live server address dynamically.
 */
class HinataConfig private constructor(context: Context) {

    companion object {
        private const val TAG = "HinataConfig"
        private const val PREFS_NAME = "hinata_config_prefs"
        private const val KEY_DEVICE_ID = "device_id"
        private const val KEY_USER_ID = "user_id"
        private const val KEY_ENVIRONMENT = "backend_environment"
        private const val KEY_CUSTOM_BACKEND_URL = "custom_backend_url"

        // Required default placeholder for production
        const val PLACEHOLDER_PRODUCTION_URL = "https://YOUR-REAL-BACKEND-DOMAIN.com"

        // Local development URL (Only allowed when explicitly in DEVELOPMENT mode)
        const val DEV_BACKEND_URL = "http://10.0.2.2:3000/"

        @Volatile
        private var INSTANCE: HinataConfig? = null

        fun getInstance(context: Context): HinataConfig {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: HinataConfig(context.applicationContext).also { INSTANCE = it }
            }
        }

        /**
         * Resolves the compile-time HINATA_BACKEND_URL from BuildConfig if available.
         */
        fun getBuildConfigBackendUrl(): String {
            return try {
                val buildConfigClass = Class.forName("com.hinata.assistant.BuildConfig")
                val field = buildConfigClass.getField("HINATA_BACKEND_URL")
                (field.get(null) as? String) ?: PLACEHOLDER_PRODUCTION_URL
            } catch (e: Throwable) {
                PLACEHOLDER_PRODUCTION_URL
            }
        }

        /**
         * Checks if the build is a production build from BuildConfig.
         */
        fun isBuildConfigProduction(): Boolean {
            return try {
                val buildConfigClass = Class.forName("com.hinata.assistant.BuildConfig")
                val field = buildConfigClass.getField("IS_PRODUCTION")
                (field.get(null) as? Boolean) ?: true
            } catch (e: Throwable) {
                true
            }
        }
    }

    private val prefs: SharedPreferences =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    /**
     * Unique, persistent app-specific device identifier stored in SharedPreferences.
     * Guaranteed never to use IMEI, IMSI, MAC, or sensitive hardware serials.
     */
    val deviceId: String
        get() {
            var id = prefs.getString(KEY_DEVICE_ID, null)
            if (id.isNullOrBlank()) {
                id = "device-" + UUID.randomUUID().toString()
                prefs.edit().putString(KEY_DEVICE_ID, id).apply()
            }
            return id
        }

    /**
     * Clean user identity abstraction for multi-phone account mapping.
     */
    var userId: String
        get() = prefs.getString(KEY_USER_ID, "user-default") ?: "user-default"
        set(value) {
            val clean = value.trim()
            if (clean.isNotBlank()) {
                prefs.edit().putString(KEY_USER_ID, clean).apply()
            }
        }

    /**
     * Active environment: "PRODUCTION", "DEVELOPMENT", or "CUSTOM"
     */
    var environment: String
        get() {
            val defaultEnv = if (isBuildConfigProduction()) "PRODUCTION" else "DEVELOPMENT"
            return prefs.getString(KEY_ENVIRONMENT, defaultEnv) ?: defaultEnv
        }
        set(value) = prefs.edit().putString(KEY_ENVIRONMENT, value).apply()

    /**
     * Custom backend URL if user manually enters their online server domain in settings.
     */
    var customBackendUrl: String
        get() = prefs.getString(KEY_CUSTOM_BACKEND_URL, "") ?: ""
        set(value) {
            prefs.edit().putString(KEY_CUSTOM_BACKEND_URL, value.trim()).apply()
        }

    /**
     * Checks whether a valid backend URL is explicitly configured (not the dummy placeholder).
     */
    val isConfigured: Boolean
        get() {
            val url = activeBackendUrl
            return url.isNotBlank() && url != PLACEHOLDER_PRODUCTION_URL
        }

    /**
     * Returns the current backend state matching the central architecture:
     * BACKEND_CONNECTED, BACKEND_NOT_CONFIGURED, BACKEND_UNREACHABLE, BACKEND_ERROR.
     */
    fun getBackendState(): String {
        return if (!isConfigured) {
            "BACKEND_NOT_CONFIGURED"
        } else {
            "BACKEND_UNREACHABLE" // Default until health check verifies connectivity
        }
    }

    /**
     * Returns the active backend base URL.
     * Enforces the rule that PRODUCTION never points to localhost, 127.0.0.1, or 10.0.2.2,
     * and MUST use HTTPS.
     */
    val activeBackendUrl: String
        get() {
            val rawUrl = when (environment.uppercase()) {
                "DEVELOPMENT" -> DEV_BACKEND_URL
                "CUSTOM" -> if (customBackendUrl.isNotBlank()) customBackendUrl else getProductionBaseUrl()
                else -> getProductionBaseUrl()
            }
            return sanitizeAndValidateUrl(rawUrl, environment.uppercase() == "PRODUCTION")
        }

    /**
     * Resolves the production URL from BuildConfig or fallback placeholder.
     */
    fun getProductionBaseUrl(): String {
        val configUrl = getBuildConfigBackendUrl()
        return if (configUrl.isNotBlank()) configUrl else PLACEHOLDER_PRODUCTION_URL
    }

    /**
     * Validates that production URLs never use localhost, 127.0.0.1, or 10.0.2.2,
     * and strictly enforce HTTPS in production.
     */
    private fun sanitizeAndValidateUrl(url: String, isProduction: Boolean): String {
        val trimmed = url.trim().trimEnd('/')

        if (isProduction) {
            val lower = trimmed.lowercase()
            if (lower.contains("localhost") || lower.contains("127.0.0.1") || lower.contains("10.0.2.2")) {
                Log.e(TAG, "FATAL: Production backend URL cannot be localhost or loopback address! Fallback to production placeholder.")
                return PLACEHOLDER_PRODUCTION_URL
            }
            if (lower.startsWith("http://")) {
                Log.w(TAG, "Production backend must use HTTPS! Upgrading to https://")
                return "https://" + trimmed.substring(7)
            }
        }
        return trimmed
    }

    /**
     * Human-readable device model name (e.g. "Pixel 8 Pro", "Samsung S24")
     */
    val deviceName: String
        get() {
            val manufacturer = Build.MANUFACTURER.replaceFirstChar { it.uppercase() }
            val model = Build.MODEL
            return if (model.startsWith(manufacturer, ignoreCase = true)) {
                model
            } else {
                "$manufacturer $model"
            }
        }

    /**
     * Standard HTTP / WebSocket headers for multi-device support
     */
    fun getHeaders(sessionId: String? = null, conversationId: String? = null): Map<String, String> {
        val headers = mutableMapOf(
            "X-User-Id" to userId,
            "X-Device-Id" to deviceId,
            "X-Device-Name" to deviceName,
            "X-Client-Platform" to "android",
            "X-Client-Version" to "1.0.0"
        )
        if (!sessionId.isNullOrBlank()) {
            headers["X-Session-Id"] = sessionId
        }
        if (!conversationId.isNullOrBlank()) {
            headers["X-Conversation-Id"] = conversationId
        }
        return headers
    }
}
