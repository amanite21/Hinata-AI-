package com.hinata.assistant

import android.app.assist.AssistContent
import android.app.assist.AssistStructure
import android.content.Context
import android.graphics.Bitmap
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.service.voice.VoiceInteractionSession
import android.speech.tts.TextToSpeech
import android.util.Base64
import android.util.Log
import java.io.ByteArrayOutputStream
import java.util.Locale
import kotlin.concurrent.thread

/**
 * HinataVoiceInteractionSession
 * Handles the floating assistant overlay and processes system assist data, screenshots & voice input.
 * Connected directly to HINATA_BACKEND_URL via HinataApiClient.
 */
class HinataVoiceInteractionSession(context: Context) : VoiceInteractionSession(context), TextToSpeech.OnInitListener {

    companion object {
        private const val TAG = "HinataVoiceSession"
    }

    private val apiClient = HinataApiClient.getInstance(context)
    private var tts: TextToSpeech? = null
    private var isTtsReady = false
    private val mainHandler = Handler(Looper.getMainLooper())

    override fun onCreate() {
        super.onCreate()
        Log.i(TAG, "Hinata VoiceInteractionSession created.")
        tts = TextToSpeech(context, this)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.language = Locale.US
            isTtsReady = true
        }
    }

    override fun onShow(args: Bundle?, showFlags: Int) {
        super.onShow(args, showFlags)
        Log.i(TAG, "Hinata session shown with flags: $showFlags")
    }

    override fun onHandleAssist(
        data: Bundle?,
        structure: AssistStructure?,
        content: AssistContent?
    ) {
        super.onHandleAssist(data, structure, content)
        Log.d(TAG, "Received assist structure context from active application.")
    }

    override fun onHandleScreenshot(screenshot: Bitmap?) {
        super.onHandleScreenshot(screenshot)
        if (screenshot != null) {
            Log.d(TAG, "Received screenshot of active screen for visual intelligence. Forwarding to backend...")
            thread {
                try {
                    val stream = ByteArrayOutputStream()
                    screenshot.compress(Bitmap.CompressFormat.JPEG, 80, stream)
                    val base64Image = Base64.encodeToString(stream.toByteArray(), Base64.NO_WRAP)
                    val result = apiClient.sendVisionAnalysis(
                        imageBase64 = base64Image,
                        prompt = "Analyze this screen and provide a quick helpful assistant summary of what the user is looking at."
                    )
                    result.onSuccess { summary ->
                        mainHandler.post {
                            if (isTtsReady) {
                                tts?.speak(summary, TextToSpeech.QUEUE_FLUSH, null, "hinata_vision")
                            }
                        }
                    }.onFailure { error ->
                        Log.w(TAG, "Vision analysis error from backend: ${error.message}")
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "Screenshot encoding failure", e)
                }
            }
        }
    }

    override fun onHide() {
        super.onHide()
        tts?.stop()
        Log.i(TAG, "Hinata session hidden.")
    }

    override fun onDestroy() {
        super.onDestroy()
        tts?.shutdown()
    }
}
