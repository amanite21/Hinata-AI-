package com.hinata.assistant

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.util.Log
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.ConnectException
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL
import java.net.UnknownHostException
import javax.net.ssl.HttpsURLConnection

/**
 * HinataApiClient - Official Android Native Networking Layer for Hinata AI.
 *
 * Implements:
 * - Direct connection to HINATA_BACKEND_URL over HTTPS in production.
 * - Zero Gemini API key requirement on Android (AI key remains strictly server-side).
 * - Full multi-phone support (scoped with X-User-Id, X-Device-Id, X-Conversation-Id).
 * - Connection state tracking (CONNECTED, CONNECTING, DISCONNECTED, ERROR).
 * - Health verification via GET /health.
 * - Assistant message dispatch via POST /api/assistant.
 * - Vision intelligence dispatch via POST /api/vision/analyze.
 * - User-friendly network error translation without exposing technical stack traces.
 * - Robust timeouts (15s connect, 60s read for AI response streaming/generation).
 * - Strict HTTPS SSL validation for production without certificate bypasses.
 */
class HinataApiClient private constructor(private val context: Context) {

    companion object {
        private const val TAG = "HinataApiClient"

        // Timeouts configured to support rich AI inference
        private const val CONNECT_TIMEOUT_MS = 15_000 // 15s
        private const val READ_TIMEOUT_MS = 60_000    // 60s for AI inference
        
        @Volatile
        private var INSTANCE: HinataApiClient? = null

        fun getInstance(context: Context): HinataApiClient {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: HinataApiClient(context.applicationContext).also { INSTANCE = it }
            }
        }
    }

    enum class ConnectionState {
        CONNECTED,
        CONNECTING,
        DISCONNECTED,
        ERROR
    }

    data class AssistantResponse(
        val reply: String,
        val conversationId: String,
        val messageId: String,
        val emotion: String,
        val timestamp: Long = System.currentTimeMillis()
    )

    data class HealthStatus(
        val isHealthy: Boolean,
        val service: String,
        val rawMessage: String? = null
    )

    interface ConnectionStateListener {
        fun onStateChanged(state: ConnectionState, message: String? = null)
    }

    private val config = HinataConfig.getInstance(context)
    private val listeners = mutableListOf<ConnectionStateListener>()

    var currentState: ConnectionState = ConnectionState.DISCONNECTED
        private set(value) {
            field = value
            notifyStateChanged(value, null)
        }

    fun addConnectionListener(listener: ConnectionStateListener) {
        synchronized(listeners) {
            listeners.add(listener)
            listener.onStateChanged(currentState, null)
        }
    }

    fun removeConnectionListener(listener: ConnectionStateListener) {
        synchronized(listeners) {
            listeners.remove(listener)
        }
    }

    private fun notifyStateChanged(state: ConnectionState, message: String?) {
        synchronized(listeners) {
            for (listener in listeners) {
                try {
                    listener.onStateChanged(state, message)
                } catch (e: Exception) {
                    Log.w(TAG, "Listener error", e)
                }
            }
        }
    }

    /**
     * Checks if physical internet connection is available on the Android device.
     */
    fun isNetworkAvailable(): Boolean {
        val connectivityManager =
            context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
                ?: return false

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val network = connectivityManager.activeNetwork ?: return false
            val capabilities = connectivityManager.getNetworkCapabilities(network) ?: return false
            return capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
        } else {
            @Suppress("DEPRECATION")
            val networkInfo = connectivityManager.activeNetworkInfo
            @Suppress("DEPRECATION")
            return networkInfo != null && networkInfo.isConnected
        }
    }

    /**
     * Requirement 19: Health check verifying connectivity with GET /health.
     */
    fun checkHealth(): HealthStatus {
        if (!isNetworkAvailable()) {
            currentState = ConnectionState.DISCONNECTED
            notifyStateChanged(ConnectionState.DISCONNECTED, "No internet connection.")
            return HealthStatus(false, "offline", "No internet connection.")
        }

        currentState = ConnectionState.CONNECTING
        val baseUrl = config.activeBackendUrl
        val endpoint = "$baseUrl/health"

        var connection: HttpURLConnection? = null
        return try {
            val url = URL(endpoint)
            connection = createConnection(url, "GET")
            connection.connectTimeout = 8_000
            connection.readTimeout = 8_000

            val responseCode = connection.responseCode
            if (responseCode in 200..299) {
                val reader = BufferedReader(InputStreamReader(connection.inputStream))
                val responseText = reader.use { it.readText() }
                val json = JSONObject(responseText)
                val status = json.optString("status", "ok")
                val service = json.optString("service", "hinata-backend")

                currentState = ConnectionState.CONNECTED
                HealthStatus(status == "ok", service, "Connected to $service")
            } else {
                currentState = ConnectionState.ERROR
                notifyStateChanged(ConnectionState.ERROR, "Can't reach Hinata's server.")
                HealthStatus(false, "unknown", "Server responded with code $responseCode")
            }
        } catch (e: Exception) {
            val friendlyError = mapExceptionToUserMessage(e)
            currentState = ConnectionState.ERROR
            notifyStateChanged(ConnectionState.ERROR, friendlyError)
            HealthStatus(false, "error", friendlyError)
        } finally {
            connection?.disconnect()
        }
    }

    /**
     * Requirement 5 & 6: Sends assistant request to POST /api/assistant.
     */
    fun sendAssistantMessage(
        message: String,
        conversationId: String? = null,
        imageBase64: String? = null,
        stream: Boolean = false
    ): Result<AssistantResponse> {
        if (!isNetworkAvailable()) {
            currentState = ConnectionState.DISCONNECTED
            return Result.failure(Exception("No internet connection."))
        }

        val baseUrl = config.activeBackendUrl
        val endpoint = "$baseUrl/api/assistant"

        var connection: HttpURLConnection? = null
        return try {
            val url = URL(endpoint)
            connection = createConnection(url, "POST")

            // Multi-phone identification headers
            val headers = config.getHeaders(conversationId = conversationId)
            for ((key, value) in headers) {
                connection.setRequestProperty(key, value)
            }

            // Build request payload
            val payload = JSONObject().apply {
                put("message", message)
                put("userId", config.userId)
                put("deviceId", config.deviceId)
                if (!conversationId.isNullOrBlank()) {
                    put("conversationId", conversationId)
                }
                if (!imageBase64.isNullOrBlank()) {
                    put("image", imageBase64)
                }
                put("stream", stream)
            }

            OutputStreamWriter(connection.outputStream, "UTF-8").use { writer ->
                writer.write(payload.toString())
                writer.flush()
            }

            val responseCode = connection.responseCode
            if (responseCode in 200..299) {
                val responseText = BufferedReader(InputStreamReader(connection.inputStream, "UTF-8")).use {
                    it.readText()
                }

                currentState = ConnectionState.CONNECTED

                val json = JSONObject(responseText)
                val reply = json.optString("reply", "I'm here with you.")
                val convId = json.optString("conversationId", conversationId ?: "conv-default")
                val msgId = json.optString("messageId", "msg-${System.currentTimeMillis()}")
                val emotion = json.optString("emotion", "CALM")

                Result.success(
                    AssistantResponse(
                        reply = reply,
                        conversationId = convId,
                        messageId = msgId,
                        emotion = emotion
                    )
                )
            } else {
                val errorMsg = mapHttpCodeToUserMessage(responseCode)
                currentState = ConnectionState.ERROR
                Result.failure(Exception(errorMsg))
            }
        } catch (e: Exception) {
            val friendlyError = mapExceptionToUserMessage(e)
            currentState = ConnectionState.ERROR
            Result.failure(Exception(friendlyError))
        } finally {
            connection?.disconnect()
        }
    }

    /**
     * Requirement 9: Image & Vision request dispatched to POST /api/vision/analyze.
     */
    fun sendVisionAnalysis(
        imageBase64: String,
        prompt: String = "Describe what you see and highlight any interactive UI or objects"
    ): Result<String> {
        if (!isNetworkAvailable()) {
            return Result.failure(Exception("No internet connection."))
        }

        val baseUrl = config.activeBackendUrl
        val endpoint = "$baseUrl/api/vision/analyze"

        var connection: HttpURLConnection? = null
        return try {
            val url = URL(endpoint)
            connection = createConnection(url, "POST")

            val headers = config.getHeaders()
            for ((key, value) in headers) {
                connection.setRequestProperty(key, value)
            }

            val payload = JSONObject().apply {
                put("image", imageBase64)
                put("prompt", prompt)
            }

            OutputStreamWriter(connection.outputStream, "UTF-8").use { writer ->
                writer.write(payload.toString())
                writer.flush()
            }

            val responseCode = connection.responseCode
            if (responseCode in 200..299) {
                val responseText = BufferedReader(InputStreamReader(connection.inputStream, "UTF-8")).use {
                    it.readText()
                }
                val json = JSONObject(responseText)
                val analysis = json.optString("summary", json.optString("reply", "Vision analysis completed."))
                Result.success(analysis)
            } else {
                Result.failure(Exception(mapHttpCodeToUserMessage(responseCode)))
            }
        } catch (e: Exception) {
            Result.failure(Exception(mapExceptionToUserMessage(e)))
        } finally {
            connection?.disconnect()
        }
    }

    /**
     * Requirement 10: Syncs long-term memories with the online backend.
     */
    fun syncMemories(localMemoriesJsonArray: JSONArray): Result<Int> {
        if (!isNetworkAvailable()) {
            return Result.failure(Exception("No internet connection."))
        }

        val baseUrl = config.activeBackendUrl
        val endpoint = "$baseUrl/api/memory/sync"

        var connection: HttpURLConnection? = null
        return try {
            val url = URL(endpoint)
            connection = createConnection(url, "POST")

            val headers = config.getHeaders()
            for ((key, value) in headers) {
                connection.setRequestProperty(key, value)
            }

            val payload = JSONObject().apply {
                put("items", localMemoriesJsonArray)
            }

            OutputStreamWriter(connection.outputStream, "UTF-8").use { writer ->
                writer.write(payload.toString())
                writer.flush()
            }

            val responseCode = connection.responseCode
            if (responseCode in 200..299) {
                val responseText = BufferedReader(InputStreamReader(connection.inputStream, "UTF-8")).use {
                    it.readText()
                }
                val json = JSONObject(responseText)
                val syncedCount = json.optInt("syncedCount", 0)
                Result.success(syncedCount)
            } else {
                Result.failure(Exception(mapHttpCodeToUserMessage(responseCode)))
            }
        } catch (e: Exception) {
            Result.failure(Exception(mapExceptionToUserMessage(e)))
        } finally {
            connection?.disconnect()
        }
    }

    /**
     * Creates and configures HttpURLConnection with strict security, headers, and timeouts.
     * Enforces SSL verification for HTTPS connections.
     */
    private fun createConnection(url: URL, method: String): HttpURLConnection {
        val conn = url.openConnection() as HttpURLConnection
        conn.requestMethod = method
        conn.connectTimeout = CONNECT_TIMEOUT_MS
        conn.readTimeout = READ_TIMEOUT_MS
        conn.useCaches = false
        conn.doInput = true

        if (method == "POST" || method == "PUT") {
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
        }

        conn.setRequestProperty("Accept", "application/json")
        conn.setRequestProperty("User-Agent", "Hinata-Android-Companion/1.0")

        // In production, enforce HTTPS
        if (config.environment.uppercase() == "PRODUCTION" && conn is HttpsURLConnection) {
            // Default SSLSocketFactory ensures strict certificate verification (no custom bypass)
            conn.hostnameVerifier = HttpsURLConnection.getDefaultHostnameVerifier()
        }

        return conn
    }

    /**
     * Requirement 14: Translates low-level network exceptions to user-friendly messages.
     */
    private fun mapExceptionToUserMessage(e: Throwable): String {
        return when (e) {
            is UnknownHostException -> "Can't reach Hinata's server."
            is ConnectException -> "No internet connection."
            is SocketTimeoutException -> "The server is taking too long to respond."
            else -> {
                val msg = e.message ?: ""
                if (msg.contains("ENETUNREACH") || msg.contains("network unreachable")) {
                    "No internet connection."
                } else {
                    "Can't reach Hinata's server."
                }
            }
        }
    }

    /**
     * Requirement 14: Translates HTTP status codes to user-friendly messages.
     */
    private fun mapHttpCodeToUserMessage(code: Int): String {
        return when (code) {
            400 -> "Invalid request sent to server."
            401, 403 -> "Access unauthorized."
            404 -> "Service endpoint not found on server."
            429 -> "The server is busy. Try again in a moment."
            500, 502, 503, 504 -> "Something went wrong while connecting to the AI."
            else -> "Can't reach Hinata's server."
        }
    }
}
