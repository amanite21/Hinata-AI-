package com.hinata.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.util.Log

/**
 * HinataForegroundVoiceService
 *
 * Official Android Microphone Foreground Service:
 * - Adheres strictly to Android 14+ FOREGROUND_SERVICE_MICROPHONE policies
 * - Transparent ongoing notification indicating active microphone monitoring
 * - Action button to immediately stop and disable hands-free mode
 * - Zero hidden background surveillance
 */
class HinataForegroundVoiceService : Service() {

    companion object {
        const val CHANNEL_ID = "hinata_voice_channel"
        const val NOTIFICATION_ID = 4001
        const val ACTION_STOP = "com.hinata.assistant.ACTION_STOP_HANDS_FREE"
        private const val TAG = "HinataForegroundVoice"
    }

    private var detector: HinataWakeWordDetector? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            Log.i(TAG, "Stop action requested by user via notification.")
            stopSelf()
            return START_NOT_STICKY
        }

        val notification = buildForegroundNotification()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }

        // Initialize local lightweight wake-word detector
        if (detector == null) {
            detector = HinataWakeWordDetector(this) { phrase ->
                Log.i(TAG, "Wake word detected in background service: $phrase")
                // Launch assist overlay session
                val assistIntent = Intent(this, MainActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                    putExtra("wake_triggered", true)
                }
                startActivity(assistIntent)
            }
            detector?.startListening()
        }

        return START_STICKY
    }

    private fun buildForegroundNotification(): Notification {
        val stopIntent = Intent(this, HinataForegroundVoiceService::class.java).apply {
            action = ACTION_STOP
        }
        val stopPendingIntent = PendingIntent.getService(
            this,
            0,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, CHANNEL_ID)
        } else {
            Notification.Builder(this)
        }

        return builder
            .setContentTitle("Hinata Voice Assistant Active")
            .setContentText("Listening hands-free for \"Hey Hinata\" • Microphone in use")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .addAction(
                android.R.drawable.ic_menu_close_clear_cancel,
                "Turn Off",
                stopPendingIntent
            )
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Hinata Hands-Free Assistant",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Notifies when Hinata is listening hands-free for wake word."
                setShowBadge(false)
            }
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        detector?.stopListening()
        detector = null
        Log.i(TAG, "HinataForegroundVoiceService stopped.")
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
