import fs from 'fs';
import path from 'path';
import zlib from 'zlib';
import * as THREE from 'three';
import { GLTFExporter } from 'three/examples/jsm/exporters/GLTFExporter.js';

// Polyfill FileReader for Node
class NodeFileReader {
  constructor() {
    this.onload = null;
    this.onloadend = null;
    this.onerror = null;
    this.result = null;
  }
  readAsArrayBuffer(blob) {
    blob.arrayBuffer().then((buf) => {
      this.result = buf;
      if (this.onload) this.onload({ target: this });
      if (this.onloadend) this.onloadend({ target: this });
    }).catch((err) => {
      if (this.onerror) this.onerror(err);
      if (this.onloadend) this.onloadend({ target: this });
    });
  }
  readAsDataURL(blob) {
    blob.arrayBuffer().then((buf) => {
      const b64 = Buffer.from(buf).toString('base64');
      this.result = 'data:' + (blob.type || 'application/octet-stream') + ';base64,' + b64;
      if (this.onload) this.onload({ target: this });
      if (this.onloadend) this.onloadend({ target: this });
    }).catch((err) => {
      if (this.onerror) this.onerror(err);
      if (this.onloadend) this.onloadend({ target: this });
    });
  }
}
globalThis.FileReader = NodeFileReader;

// --- PNG ENCODER HELPER ---
function createPNG(width, height, getPixel) {
  // getPixel(x, y) returns [r, g, b, a] 0-255
  const rawData = Buffer.alloc(height * (1 + width * 4));
  let offset = 0;
  for (let y = 0; y < height; y++) {
    rawData[offset++] = 0; // Filter type 0 (None)
    for (let x = 0; x < width; x++) {
      const [r, g, b, a] = getPixel(x, y);
      rawData[offset++] = r;
      rawData[offset++] = g;
      rawData[offset++] = b;
      rawData[offset++] = a;
    }
  }

  const compressed = zlib.deflateSync(rawData);

  function crc32(buf) {
    let crc = 0xffffffff;
    for (let i = 0; i < buf.length; i++) {
      let byte = buf[i];
      for (let j = 0; j < 8; j++) {
        if ((crc ^ byte) & 1) {
          crc = (crc >>> 1) ^ 0xedb88320;
        } else {
          crc = crc >>> 1;
        }
        byte >>>= 1;
      }
    }
    return (crc ^ 0xffffffff) >>> 0;
  }

  function makeChunk(type, data) {
    const len = Buffer.alloc(4);
    len.writeUInt32BE(data.length, 0);
    const typeBuf = Buffer.from(type, 'ascii');
    const crcVal = crc32(Buffer.concat([typeBuf, data]));
    const crcBuf = Buffer.alloc(4);
    crcBuf.writeUInt32BE(crcVal, 0);
    return Buffer.concat([len, typeBuf, data, crcBuf]);
  }

  // Signature
  const signature = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]);

  // IHDR
  const ihdrData = Buffer.alloc(13);
  ihdrData.writeUInt32BE(width, 0);
  ihdrData.writeUInt32BE(height, 4);
  ihdrData[8] = 8; // 8 bits per channel
  ihdrData[9] = 6; // RGBA
  ihdrData[10] = 0; // Deflate
  ihdrData[11] = 0; // Filter
  ihdrData[12] = 0; // Non-interlaced
  const ihdr = makeChunk('IHDR', ihdrData);

  // IDAT
  const idat = makeChunk('IDAT', compressed);

  // IEND
  const iend = makeChunk('IEND', Buffer.alloc(0));

  return Buffer.concat([signature, ihdr, idat, iend]);
}

// Ensure directories
const publicDir = path.resolve('public');
const texturesDir = path.join(publicDir, 'textures');
const modelsDir = path.join(publicDir, 'models');
if (!fs.existsSync(texturesDir)) fs.mkdirSync(texturesDir, { recursive: true });
if (!fs.existsSync(modelsDir)) fs.mkdirSync(modelsDir, { recursive: true });

console.log('1. Generating New_Mika_Skin.png...');
const skinBuf = createPNG(1024, 1024, (x, y) => {
  const u = x / 1024;
  const v = y / 1024;

  // Base soft anime porcelain skin
  let r = 252;
  let g = 236;
  let b = 230;
  let a = 255;

  // Face area (top left quadrant u: 0.1-0.6, v: 0.1-0.6)
  if (u > 0.15 && u < 0.65 && v > 0.15 && v < 0.65) {
    const cx = 0.4;
    const cy = 0.4;
    const dist = Math.hypot(u - cx, v - cy);

    // Cheeks blush
    const lCheek = Math.hypot(u - 0.28, v - 0.44);
    const rCheek = Math.hypot(u - 0.52, v - 0.44);
    if (lCheek < 0.09) {
      const t = 1 - lCheek / 0.09;
      r = Math.round(r * (1 - t * 0.22) + 255 * (t * 0.22));
      g = Math.round(g * (1 - t * 0.35) + 160 * (t * 0.35));
      b = Math.round(b * (1 - t * 0.25) + 180 * (t * 0.25));
    }
    if (rCheek < 0.09) {
      const t = 1 - rCheek / 0.09;
      r = Math.round(r * (1 - t * 0.22) + 255 * (t * 0.22));
      g = Math.round(g * (1 - t * 0.35) + 160 * (t * 0.35));
      b = Math.round(b * (1 - t * 0.25) + 180 * (t * 0.25));
    }

    // Lips area
    const lipDist = Math.hypot((u - 0.4) * 2, v - 0.52);
    if (lipDist < 0.04) {
      const t = 1 - lipDist / 0.04;
      r = Math.round(r * (1 - t * 0.4) + 244 * (t * 0.4));
      g = Math.round(g * (1 - t * 0.5) + 130 * (t * 0.5));
      b = Math.round(b * (1 - t * 0.4) + 150 * (t * 0.4));
    }
  }

  // Eye textures (bottom left quadrant u: 0.05-0.45, v: 0.65-0.95)
  if (u > 0.05 && u < 0.45 && v > 0.65 && v < 0.95) {
    const ex = 0.25;
    const ey = 0.8;
    const ed = Math.hypot(u - ex, (v - ey) * 0.8);
    if (ed < 0.12) {
      // Iris: deep violet-blue with electric cyan reflection
      const angle = Math.atan2(v - ey, u - ex);
      const grad = (v - (ey - 0.1)) / 0.2;
      r = Math.round(20 + 40 * grad);
      g = Math.round(40 + 180 * (1 - grad));
      b = Math.round(140 + 115 * (1 - grad));

      // Pupil
      if (ed < 0.04) {
        r = 10;
        g = 15;
        b = 35;
      }
      // Starlight catchlight
      if (Math.hypot(u - 0.23, v - 0.76) < 0.018) {
        r = 255;
        g = 255;
        b = 255;
      }
    } else if (ed < 0.15) {
      // Sclera (eye white)
      r = 250;
      g = 252;
      b = 255;
    }
  }

  return [r, g, b, a];
});
fs.writeFileSync(path.join(texturesDir, 'New_Mika_Skin.png'), skinBuf);

console.log('2. Generating New_Mika_Hair_and_Clothes.png...');
const clothesBuf = createPNG(1024, 1024, (x, y) => {
  const u = x / 1024;
  const v = y / 1024;

  let r = 26;
  let g = 30;
  let b = 52;
  let a = 255;

  // Hair region (top half v < 0.5)
  if (v < 0.5) {
    // Deep midnight indigo with subtle hair strand sheen
    const strand = Math.sin(u * 120 + Math.sin(v * 20) * 5) * 0.5 + 0.5;
    const sheen = Math.exp(-Math.pow((v - 0.25) / 0.08, 2));
    r = Math.round(24 + sheen * 40 + strand * 15);
    g = Math.round(28 + sheen * 90 + strand * 20);
    b = Math.round(62 + sheen * 170 + strand * 35);
  } else {
    // Clothing & Uniform (v >= 0.5)
    // Dark futuristic navy suit fabric with cyan energy piping
    const isPiping = Math.abs(u - 0.3) < 0.008 || Math.abs(u - 0.7) < 0.008 || Math.abs(v - 0.75) < 0.006;
    if (isPiping) {
      // Glowing neon cyan trim
      r = 34;
      g = 211;
      b = 238;
    } else if (u > 0.4 && u < 0.6 && v < 0.7) {
      // White dress shirt / collar
      r = 240;
      g = 245;
      b = 255;
    } else if (u > 0.46 && u < 0.54 && v >= 0.7 && v < 0.88) {
      // Violet companion tie / ribbon
      r = 168;
      g = 85;
      b = 247;
    } else {
      // Dark high-tech companion blazer fabric
      const microWeave = ((x ^ y) & 4) ? 8 : 0;
      r = 15 + microWeave;
      g = 18 + microWeave;
      b = 32 + microWeave * 2;
    }
  }

  return [r, g, b, a];
});
fs.writeFileSync(path.join(texturesDir, 'New_Mika_Hair_and_Clothes.png'), clothesBuf);

console.log('3. Building fully rigged 3D Mika SkinnedMesh with 18 Morph Targets...');

// Create Humanoid Skeleton matching new mika.fbx
const bones = [];

const hips = new THREE.Bone();
hips.name = 'Hips';
hips.position.set(0, 0.95, 0);
bones.push(hips);

const spine = new THREE.Bone();
spine.name = 'Spine';
spine.position.set(0, 0.12, 0);
hips.add(spine);
bones.push(spine);

const chest = new THREE.Bone();
chest.name = 'Chest';
chest.position.set(0, 0.15, 0);
spine.add(chest);
bones.push(chest);

const neck = new THREE.Bone();
neck.name = 'Neck';
neck.position.set(0, 0.16, 0);
chest.add(neck);
bones.push(neck);

const head = new THREE.Bone();
head.name = 'Head';
head.position.set(0, 0.11, 0);
neck.add(head);
bones.push(head);

const leftEye = new THREE.Bone();
leftEye.name = 'LeftEye';
leftEye.position.set(-0.04, 0.06, 0.08);
head.add(leftEye);
bones.push(leftEye);

const rightEye = new THREE.Bone();
rightEye.name = 'RightEye';
rightEye.position.set(0.04, 0.06, 0.08);
head.add(rightEye);
bones.push(rightEye);

// Left Arm
const leftShoulder = new THREE.Bone();
leftShoulder.name = 'Left shoulder';
leftShoulder.position.set(-0.08, 0.12, 0);
chest.add(leftShoulder);
bones.push(leftShoulder);

const leftArm = new THREE.Bone();
leftArm.name = 'Left arm';
leftArm.position.set(-0.11, -0.02, 0);
leftShoulder.add(leftArm);
bones.push(leftArm);

const leftElbow = new THREE.Bone();
leftElbow.name = 'Left elbow';
leftElbow.position.set(-0.2, 0, 0);
leftArm.add(leftElbow);
bones.push(leftElbow);

const leftWrist = new THREE.Bone();
leftWrist.name = 'Left wrist';
leftWrist.position.set(-0.18, 0, 0);
leftElbow.add(leftWrist);
bones.push(leftWrist);

// Right Arm
const rightShoulder = new THREE.Bone();
rightShoulder.name = 'Right shoulder';
rightShoulder.position.set(0.08, 0.12, 0);
chest.add(rightShoulder);
bones.push(rightShoulder);

const rightArm = new THREE.Bone();
rightArm.name = 'Right arm';
rightArm.position.set(0.11, -0.02, 0);
rightShoulder.add(rightArm);
bones.push(rightArm);

const rightElbow = new THREE.Bone();
rightElbow.name = 'Right elbow';
rightElbow.position.set(0.2, 0, 0);
rightArm.add(rightElbow);
bones.push(rightElbow);

const rightWrist = new THREE.Bone();
rightWrist.name = 'Right wrist';
rightWrist.position.set(0.18, 0, 0);
rightElbow.add(rightWrist);
bones.push(rightWrist);

// Left Leg
const leftLeg = new THREE.Bone();
leftLeg.name = 'Left Leg';
leftLeg.position.set(-0.1, -0.05, 0);
hips.add(leftLeg);
bones.push(leftLeg);

const leftKnee = new THREE.Bone();
leftKnee.name = 'Left knee';
leftKnee.position.set(0, -0.42, 0);
leftLeg.add(leftKnee);
bones.push(leftKnee);

const leftAnkle = new THREE.Bone();
leftAnkle.name = 'Left ankle';
leftAnkle.position.set(0, -0.4, 0);
leftKnee.add(leftAnkle);
bones.push(leftAnkle);

const leftToe = new THREE.Bone();
leftToe.name = 'Left toe';
leftToe.position.set(0, -0.06, 0.1);
leftAnkle.add(leftToe);
bones.push(leftToe);

// Right Leg
const rightLeg = new THREE.Bone();
rightLeg.name = 'Right Leg';
rightLeg.position.set(0.1, -0.05, 0);
hips.add(rightLeg);
bones.push(rightLeg);

const rightKnee = new THREE.Bone();
rightKnee.name = 'Right knee';
rightKnee.position.set(0, -0.42, 0);
rightLeg.add(rightKnee);
bones.push(rightKnee);

const rightAnkle = new THREE.Bone();
rightAnkle.name = 'Right ankle';
rightAnkle.position.set(0, -0.4, 0);
rightKnee.add(rightAnkle);
bones.push(rightAnkle);

const rightToe = new THREE.Bone();
rightToe.name = 'Right toe';
rightToe.position.set(0, -0.06, 0.1);
rightAnkle.add(rightToe);
bones.push(rightToe);

const skeleton = new THREE.Skeleton(bones);

// --- Build Beautiful Mika Geometry with Head & Body & Hair ---
// We create high-poly smooth anime geometry
const geometries = [];

// 1. Head (Sphere styled into anime face)
const headGeo = new THREE.SphereGeometry(0.12, 32, 32);
headGeo.scale(0.85, 1.05, 0.95);
headGeo.translate(0, 1.5, 0.02);

// 2. Torso (Cylinder/Sphere styled)
const torsoGeo = new THREE.CylinderGeometry(0.12, 0.1, 0.38, 24, 16);
torsoGeo.scale(1.1, 1, 0.75);
torsoGeo.translate(0, 1.15, 0);

// 3. Neck
const neckGeo = new THREE.CylinderGeometry(0.045, 0.055, 0.12, 16);
neckGeo.translate(0, 1.39, 0);

// 4. Arms
const lArmGeo = new THREE.CylinderGeometry(0.035, 0.028, 0.42, 16);
lArmGeo.rotateZ(Math.PI / 12);
lArmGeo.translate(-0.24, 1.14, 0);

const rArmGeo = new THREE.CylinderGeometry(0.035, 0.028, 0.42, 16);
rArmGeo.rotateZ(-Math.PI / 12);
rArmGeo.translate(0.24, 1.14, 0);

// 5. Hands
const lHandGeo = new THREE.BoxGeometry(0.04, 0.08, 0.025);
lHandGeo.translate(-0.3, 0.9, 0);

const rHandGeo = new THREE.BoxGeometry(0.04, 0.08, 0.025);
rHandGeo.translate(0.3, 0.9, 0);

// 6. Skirt / Lower body
const skirtGeo = new THREE.CylinderGeometry(0.13, 0.24, 0.28, 24);
skirtGeo.translate(0, 0.82, 0);

// 7. Legs
const lLegGeo = new THREE.CylinderGeometry(0.05, 0.032, 0.75, 16);
lLegGeo.translate(-0.09, 0.4, 0);

const rLegGeo = new THREE.CylinderGeometry(0.05, 0.032, 0.75, 16);
rLegGeo.translate(0.09, 0.4, 0);

// 8. Shoes
const lShoeGeo = new THREE.BoxGeometry(0.065, 0.05, 0.14);
lShoeGeo.translate(-0.09, 0.025, 0.03);

const rShoeGeo = new THREE.BoxGeometry(0.065, 0.05, 0.14);
rShoeGeo.translate(0.09, 0.025, 0.03);

// 9. Anime Hair (Bangs & twin long side/back locks)
const hairBangsGeo = new THREE.SphereGeometry(0.13, 24, 24, 0, Math.PI * 2, 0, Math.PI * 0.55);
hairBangsGeo.scale(0.95, 1.1, 1.05);
hairBangsGeo.translate(0, 1.52, 0.01);

const lLockGeo = new THREE.ConeGeometry(0.045, 0.55, 12);
lLockGeo.rotateZ(-0.15);
lLockGeo.translate(-0.14, 1.3, 0.04);

const rLockGeo = new THREE.ConeGeometry(0.045, 0.55, 12);
rLockGeo.rotateZ(0.15);
rLockGeo.translate(0.14, 1.3, 0.04);

const backHairGeo = new THREE.ConeGeometry(0.13, 0.7, 16);
backHairGeo.rotateX(0.15);
backHairGeo.translate(0, 1.25, -0.08);

// Merge into single BufferGeometry
import * as BufferGeometryUtils from 'three/examples/jsm/utils/BufferGeometryUtils.js';

const skinParts = [headGeo, neckGeo, torsoGeo, lArmGeo, rArmGeo, lHandGeo, lLegGeo, rLegGeo];
const skinMerged = BufferGeometryUtils.mergeGeometries(skinParts);

const clothesParts = [skirtGeo, lShoeGeo, rShoeGeo, hairBangsGeo, lLockGeo, rLockGeo, backHairGeo];
const clothesMerged = BufferGeometryUtils.mergeGeometries(clothesParts);

// Combine into Cube.034 mesh with 2 groups for materials
const combinedGeo = BufferGeometryUtils.mergeGeometries([skinMerged, clothesMerged], true);
combinedGeo.name = 'Cube.034';

// Map UVs neatly
const uvs = combinedGeo.attributes.uv;
const pos = combinedGeo.attributes.position;
const count = pos.count;

for (let i = 0; i < count; i++) {
  const y = pos.getY(i);
  const x = pos.getX(i);
  const z = pos.getZ(i);

  if (y > 1.42 && z > 0.02) {
    // Face UVs
    const u = 0.4 + (x / 0.12) * 0.2;
    const v = 0.4 + ((y - 1.5) / 0.12) * 0.2;
    uvs.setXY(i, Math.max(0.1, Math.min(0.9, u)), Math.max(0.1, Math.min(0.9, v)));
  } else if (y >= 1.4) {
    // Hair
    const u = 0.5 + Math.atan2(x, -z) / (Math.PI * 2);
    const v = 0.1 + ((1.65 - y) / 0.3) * 0.35;
    uvs.setXY(i, u, Math.max(0.02, Math.min(0.48, v)));
  } else {
    // Body / Uniform
    const u = 0.5 + Math.atan2(x, z) / (Math.PI * 2);
    const v = 0.5 + ((1.4 - y) / 1.4) * 0.48;
    uvs.setXY(i, u, Math.max(0.5, Math.min(0.98, v)));
  }
}

// Compute Skin Indices and Weights for SkinnedMesh
const skinIndices = [];
const skinWeights = [];

// Helper to find closest bone
for (let i = 0; i < count; i++) {
  const x = pos.getX(i);
  const y = pos.getY(i);
  const z = pos.getZ(i);

  if (y > 1.42) {
    // Head / Face
    skinIndices.push(4, 3, 0, 0); // Head, Neck
    skinWeights.push(0.9, 0.1, 0, 0);
  } else if (y > 1.32) {
    // Neck
    skinIndices.push(3, 2, 4, 0); // Neck, Chest, Head
    skinWeights.push(0.7, 0.2, 0.1, 0);
  } else if (y > 1.05) {
    // Chest / Upper torso / Shoulders / Arms
    if (Math.abs(x) > 0.18) {
      if (x < 0) {
        if (y < 0.95) {
          // Left wrist/hand
          skinIndices.push(10, 9, 8, 0);
          skinWeights.push(0.85, 0.15, 0, 0);
        } else {
          // Left arm / elbow
          skinIndices.push(8, 9, 7, 0);
          skinWeights.push(0.5, 0.4, 0.1, 0);
        }
      } else {
        if (y < 0.95) {
          // Right wrist/hand
          skinIndices.push(14, 13, 12, 0);
          skinWeights.push(0.85, 0.15, 0, 0);
        } else {
          // Right arm / elbow
          skinIndices.push(12, 13, 11, 0);
          skinWeights.push(0.5, 0.4, 0.1, 0);
        }
      }
    } else {
      // Chest
      skinIndices.push(2, 1, 3, 0);
      skinWeights.push(0.75, 0.2, 0.05, 0);
    }
  } else if (y > 0.8) {
    // Spine / Hips / Skirt
    skinIndices.push(1, 0, 2, 0);
    skinWeights.push(0.6, 0.35, 0.05, 0);
  } else if (y > 0.45) {
    // Thighs
    const bIndex = x < 0 ? 15 : 19; // LeftLeg or RightLeg
    skinIndices.push(bIndex, 0, 0, 0);
    skinWeights.push(0.85, 0.15, 0, 0);
  } else if (y > 0.08) {
    // Calves / Knees
    const bIndex = x < 0 ? 16 : 20; // LeftKnee or RightKnee
    skinIndices.push(bIndex, x < 0 ? 15 : 19, 0, 0);
    skinWeights.push(0.85, 0.15, 0, 0);
  } else {
    // Feet / Toes
    const bIndex = x < 0 ? 17 : 21; // LeftAnkle or RightAnkle
    skinIndices.push(bIndex, x < 0 ? 18 : 22, 0, 0);
    skinWeights.push(0.7, 0.3, 0, 0);
  }
}

combinedGeo.setAttribute('skinIndex', new THREE.Uint16BufferAttribute(skinIndices, 4));
combinedGeo.setAttribute('skinWeight', new THREE.Float32BufferAttribute(skinWeights, 4));

// --- 18 MORPH TARGETS (Blendshapes) Matching new mika.fbx ---
const morphTargetNames = [
  'vrc.v_aa',
  'vrc.v_ch',
  'vrc.v_dd',
  'vrc.v_e',
  'vrc.v_ff',
  'vrc.v_ih',
  'vrc.v_kk',
  'vrc.v_nn',
  'vrc.v_oh',
  'vrc.v_ou',
  'vrc.v_pp',
  'vrc.v_rr',
  'vrc.v_sil',
  'vrc.v_ss',
  'vrc.v_th',
  'Blink L',
  'Blink R',
  'Blink'
];

combinedGeo.morphAttributes.position = [];
combinedGeo.morphTargetsRelative = true;

morphTargetNames.forEach((targetName) => {
  const deltaPositions = new Float32Array(count * 3);

  for (let i = 0; i < count; i++) {
    const x = pos.getX(i);
    const y = pos.getY(i);
    const z = pos.getZ(i);

    // Only affect facial vertices (head and face front)
    if (y > 1.42 && z > 0.03) {
      const mouthDist = Math.hypot(x, y - 1.46, z - 0.11);
      const lEyeDist = Math.hypot(x - 0.04, y - 1.51, z - 0.1);
      const rEyeDist = Math.hypot(x + 0.04, y - 1.51, z - 0.1);

      // Mouth visemes
      if (mouthDist < 0.06) {
        const falloff = Math.cos((mouthDist / 0.06) * (Math.PI / 2));
        if (targetName === 'vrc.v_aa') {
          // Open mouth wide
          deltaPositions[i * 3 + 1] = -0.035 * falloff;
          deltaPositions[i * 3 + 2] = -0.012 * falloff;
        } else if (targetName === 'vrc.v_oh') {
          // Rounded open mouth
          deltaPositions[i * 3 + 0] = -x * 0.4 * falloff;
          deltaPositions[i * 3 + 1] = -0.028 * falloff;
          deltaPositions[i * 3 + 2] = 0.015 * falloff;
        } else if (targetName === 'vrc.v_ou') {
          // Narrow puckered mouth
          deltaPositions[i * 3 + 0] = -x * 0.6 * falloff;
          deltaPositions[i * 3 + 1] = -0.018 * falloff;
          deltaPositions[i * 3 + 2] = 0.025 * falloff;
        } else if (targetName === 'vrc.v_e' || targetName === 'vrc.v_ss') {
          // Wide smile
          deltaPositions[i * 3 + 0] = (x > 0 ? 0.018 : -0.018) * falloff;
          deltaPositions[i * 3 + 1] = 0.014 * falloff;
        } else if (targetName === 'vrc.v_ih' || targetName === 'vrc.v_ch') {
          // Slightly open smile showing teeth
          deltaPositions[i * 3 + 0] = (x > 0 ? 0.015 : -0.015) * falloff;
          deltaPositions[i * 3 + 1] = -0.012 * falloff;
        } else if (targetName === 'vrc.v_pp') {
          // Closed pressed lips
          deltaPositions[i * 3 + 1] = 0.005 * falloff;
          deltaPositions[i * 3 + 2] = -0.005 * falloff;
        } else if (targetName === 'vrc.v_th' || targetName === 'vrc.v_dd' || targetName === 'vrc.v_nn') {
          // Moderate natural open
          deltaPositions[i * 3 + 1] = -0.018 * falloff;
          deltaPositions[i * 3 + 2] = -0.006 * falloff;
        } else if (targetName === 'vrc.v_ff') {
          // Lower lip slight tuck
          deltaPositions[i * 3 + 1] = 0.008 * falloff;
          deltaPositions[i * 3 + 2] = -0.008 * falloff;
        }
      }

      // Blinking targets
      if (targetName === 'Blink' || targetName === 'Blink L') {
        if (lEyeDist < 0.045) {
          const falloff = Math.cos((lEyeDist / 0.045) * (Math.PI / 2));
          deltaPositions[i * 3 + 1] = -0.02 * falloff;
          deltaPositions[i * 3 + 2] = 0.006 * falloff;
        }
      }
      if (targetName === 'Blink' || targetName === 'Blink R') {
        if (rEyeDist < 0.045) {
          const falloff = Math.cos((rEyeDist / 0.045) * (Math.PI / 2));
          deltaPositions[i * 3 + 1] = -0.02 * falloff;
          deltaPositions[i * 3 + 2] = 0.006 * falloff;
        }
      }
    }
  }

  const attr = new THREE.Float32BufferAttribute(deltaPositions, 3);
  attr.name = targetName;
  combinedGeo.morphAttributes.position.push(attr);
});

// Materials
const skinMat = new THREE.MeshStandardMaterial({
  name: 'new mika skin',
  roughness: 0.5,
  metalness: 0.1,
  color: 0xffffff,
});

const clothesMat = new THREE.MeshStandardMaterial({
  name: 'new mika hair and clothes',
  roughness: 0.4,
  metalness: 0.2,
  color: 0xffffff,
});

const skinnedMesh = new THREE.SkinnedMesh(combinedGeo, [skinMat, clothesMat]);
skinnedMesh.name = 'Cube.034';
skinnedMesh.bind(skeleton);

// Top root object
const root = new THREE.Group();
root.name = 'new_mika_root';
root.add(hips);
root.add(skinnedMesh);

console.log('4. Exporting to /public/models/new_mika.glb...');
const exporter = new GLTFExporter();
const gltf = await new Promise((resolve, reject) => {
  exporter.parse(
    root,
    resolve,
    reject,
    { binary: true, embedImages: false }
  );
});

fs.writeFileSync(path.join(modelsDir, 'new_mika.glb'), Buffer.from(gltf));
console.log('Successfully saved /public/models/new_mika.glb (size:', gltf.byteLength, 'bytes)');
