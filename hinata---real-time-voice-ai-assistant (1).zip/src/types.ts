/**
 * Core type definitions for Hinata AI Assistant
 */

export type LiveSessionState =
  | 'disconnected'
  | 'connecting'
  | 'listening'
  | 'processing'
  | 'speaking'
  | 'interrupted'
  | 'completed'
  | 'error';

export type WakeWordState =
  | 'WAKE_IDLE'
  | 'WAKE_LISTENING'
  | 'WAKE_DETECTED'
  | 'LISTENING'
  | 'THINKING'
  | 'SPEAKING'
  | 'ERROR'
  | 'DISABLED';

export type MascotState =
  | 'IDLE'
  | 'LISTENING'
  | 'THINKING'
  | 'SPEAKING'
  | 'VISION_ANALYZING'
  | 'SCREEN_SHARING'
  | 'SCREEN_ANALYZING'
  | 'ERROR';

export interface SelectedImage {
  id: string;
  dataUrl: string;
  base64: string;
  mimeType: string;
  name: string;
  timestamp: number;
  width?: number;
  height?: number;
}

export interface ScreenShareState {
  isActive: boolean;
  fps: number;
  lastFrameTimestamp: number;
  error: string | null;
}

export interface VisionObjectItem {
  name: string;
  boundingBox?: [number, number, number, number];
  confidence?: number;
}

export interface VisionUIElementItem {
  type: string;
  label?: string;
  bounds?: string;
  state?: string;
  confidence?: number;
}

export interface DesignAnalysisPayload {
  layout?: {
    spacing?: string;
    alignment?: string;
    hierarchy?: string;
    composition?: string;
    responsiveStructure?: string;
  };
  colors?: {
    primary?: string;
    secondary?: string;
    accent?: string;
    background?: string;
    contrastAssessment?: string;
    palette?: string[];
  };
  typography?: {
    fontStyle?: string;
    hierarchy?: string;
    sizeRelationships?: string;
    readability?: string;
  };
  components?: {
    cards?: string;
    buttons?: string;
    navigation?: string;
    icons?: string;
    controls?: string;
    containers?: string;
  };
  visualStyle?: {
    category?: string;
    description?: string;
  };
  ux?: {
    usability?: string;
    navigation?: string;
    accessibility?: string;
    interactionClarity?: string;
  };
  improvements?: Array<{
    area: string;
    issue: string;
    suggestion: string;
    rationale: string;
  }>;
  codeImplementation?: {
    framework: 'react-tailwind' | 'html-css' | 'jetpack-compose' | 'typescript';
    snippet: string;
    notes?: string;
  };
}

export interface StructuredVisionAnalysis {
  type: 'vision_analysis';
  summary: string;
  objects: VisionObjectItem[];
  text: string[];
  uiElements: VisionUIElementItem[];
  designAnalysis: DesignAnalysisPayload;
  confidence: number;
  provider?: 'gemini' | 'heuristic';
  source?: 'image' | 'screen';
}

export interface VisionAnalysisResult {
  summary: string;
  uiElements?: string[];
  designCritique?: string;
  suggestedActions?: string[];
  extractedText?: string;
  structured?: StructuredVisionAnalysis;
  confidence?: number;
}

export type EmotionalState =
  | 'neutral'
  | 'happy'
  | 'excited'
  | 'sad'
  | 'angry'
  | 'furious'
  | 'surprised'
  | 'thinking'
  | 'sleepy'
  | 'cute'
  | 'confused'
  | 'laughing'
  | 'worried'
  | 'confident'
  | 'shy'
  | 'determined'
  | 'focused'
  | 'calm'
  | 'embarrassed'
  | 'curious'
  | 'amused'
  | 'playful'
  | 'serious'
  | 'frustrated'
  | 'affectionate'
  | 'jealous'
  | 'annoyed'
  | 'proud'
  | 'disappointed'
  | 'empathetic'
  | 'concerned'
  | 'relieved'
  | 'idle'
  | 'error'
  | 'success';

export type HinataEmotion =
  | 'idle'
  | 'happy'
  | 'excited'
  | 'curious'
  | 'thinking'
  | 'confused'
  | 'surprised'
  | 'concerned'
  | 'serious'
  | 'focused'
  | 'calm'
  | 'sad'
  | 'disappointed'
  | 'laughing'
  | 'proud'
  | 'relieved'
  | 'worried'
  | 'error'
  | 'success';

export type HinataMouthState =
  | 'NEUTRAL'
  | 'SMILE'
  | 'SPEAKING'
  | 'SMALL_SMILE'
  | 'CONCERNED'
  | 'SURPRISED'
  | 'SERIOUS'
  | 'LAUGHING';

export type HinataAIState =
  | 'IDLE'
  | 'LISTENING'
  | 'UNDERSTANDING'
  | 'THINKING'
  | 'TOOL_USING'
  | 'SPEAKING'
  | 'SUCCESS'
  | 'ERROR'
  | 'STOPPED';

export interface EmotionMetadata {
  emotion: HinataEmotion | EmotionalState;
  intensity: number; // 0.0 to 1.0 (e.g., 0.2 subtle, 0.5 normal, 0.8 strong, 1.0 max safe)
  reason?: string;
}

export type EmotionalIntensity = 0 | 1 | 2 | 3 | 4 | 5;

// Backwards compatibility alias
export type AssistantMood = EmotionalState;

export interface ToolCallItem {
  id: string;
  name: string;
  args: Record<string, any>;
  status: 'invoked' | 'executed' | 'failed';
  result?: any;
  timestamp: number;
}

export interface SessionStats {
  latencyMs: number;
  inputVolume: number;
  outputVolume: number;
  turnsCount: number;
  sessionStartTime: number | null;
}

export interface ClientConfig {
  voiceName: string;
  micMuted: boolean;
  gain: number;
  autoReconnect: boolean;
}

export type ServerMessage =
  | { type: 'connected'; model: string; voice: string }
  | { type: 'audio'; audio: string }
  | { type: 'interrupted' }
  | { type: 'turn_complete' }
  | { type: 'tool_call'; calls: Array<{ id: string; name: string; args: Record<string, any> }> }
  | { type: 'tool_result'; id: string; name: string; result: any }
  | { type: 'emotion_update'; emotion: EmotionalState; intensity?: EmotionalIntensity; reason?: string }
  | { type: 'mood_update'; mood: EmotionalState }
  | { type: 'transcript'; role: 'user' | 'assistant'; text: string }
  | { type: 'error'; message: string }
  | { type: 'closed'; reason?: string };

export type ClientMessage =
  | {
      type: 'init';
      voice?: string;
      memoryContext?: string;
      userId?: string;
      deviceId?: string;
      sessionId?: string;
      conversationId?: string;
    }
  | { type: 'realtime_audio'; audio: string }
  | { type: 'realtime_video'; video: string; mimeType?: string }
  | { type: 'realtime_image'; image: string; mimeType?: string }
  | { type: 'tool_response'; id: string; name: string; response: Record<string, any> }
  | { type: 'set_voice'; voice: string }
  | { type: 'close' };
