/**
 * Hinata Backend & Multi-Device Network Configuration
 *
 * Requirements:
 * - Uses the CURRENT AI Studio Build Mode server/backend that already exists in this project by default.
 * - Same-origin / local API routes (/api/*, /health) are used for all communication.
 * - No fake or placeholder backend URLs (Render, Railway, Vercel, etc.).
 * - HINATA_BACKEND_URL / VITE_HINATA_BACKEND_URL are NOT required for normal AI Studio preview.
 * - Supports optional external overrides only when explicitly provided by the user.
 * - Persistent device ID, user profile, and session management.
 * - Real health verification via GET /health.
 * - Strictly zero raw API key exposure to client/browser.
 */

export type BackendState =
  | 'BACKEND_CONNECTED'
  | 'BACKEND_NOT_CONFIGURED'
  | 'BACKEND_UNREACHABLE'
  | 'BACKEND_ERROR';

export type BackendStatusType = 'connected' | 'not_configured' | 'connection_failed';

export interface DeviceProfile {
  userId: string;
  deviceId: string;
  deviceName: string;
  platform: 'android' | 'web' | 'ios';
  appVersion: string;
}

export interface BackendHealthResult {
  ok: boolean;
  status?: string;
  service?: string;
  latencyMs: number;
  error?: string;
}

const STORAGE_KEY_BACKEND_URL = 'hinata_custom_backend_url_v1';
const STORAGE_KEY_USER_ID = 'hinata_user_id_v1';
const STORAGE_KEY_DEVICE_ID = 'hinata_device_id_v1';
const STORAGE_KEY_DEVICE_NAME = 'hinata_device_name_v1';
const STORAGE_KEY_ACTIVE_CONV = 'hinata_active_conversation_id_v1';

// Ephemeral per-session ID (resets on fresh app start)
const runtimeSessionId = 'session-' + Date.now().toString(36) + '-' + Math.random().toString(36).substring(2, 7);

/**
 * Checks if a candidate backend URL is a fake, dead, or placeholder address.
 * Never connects to or accepts unconfirmed/fake URLs like Render, Railway, Vercel, or placeholders.
 */
export function isFakeOrPlaceholderUrl(url: string | null | undefined): boolean {
  if (!url || typeof url !== 'string') return false;
  const lower = url.trim().toLowerCase();
  return (
    lower.includes('onrender.com') ||
    lower.includes('render.com') ||
    lower.includes('railway.app') ||
    lower.includes('vercel.app') ||
    lower.includes('your-real-backend-domain.com') ||
    lower.includes('your-production-app.run.app') ||
    lower.includes('example.com') ||
    lower.includes('placeholder')
  );
}

class BackendConfigService {
  private static instance: BackendConfigService | null = null;
  private listeners: Array<() => void> = [];
  private backendState: BackendState = 'BACKEND_CONNECTED';
  private connectionStatus: BackendStatusType = 'connected';
  private lastHealthResult: BackendHealthResult | null = null;
  private lastCheckedTimestamp: number = 0;

  private constructor() {
    // 1. Purge any stale, fake, or placeholder URLs stored in localStorage
    this.purgePlaceholderUrls();

    // 2. Ensure persistent device ID exists
    this.initDeviceIdentity();

    // 3. In AI Studio / Web environment, the internal server is active and ready.
    // Automatically verify connection to the actual project server
    if (typeof window !== 'undefined') {
      setTimeout(() => {
        this.checkHealth().catch(() => {});
      }, 50);
    }
  }

  public static getInstance(): BackendConfigService {
    if (!BackendConfigService.instance) {
      BackendConfigService.instance = new BackendConfigService();
    }
    return BackendConfigService.instance;
  }

  public subscribe(listener: () => void): () => void {
    this.listeners.push(listener);
    return () => {
      this.listeners = this.listeners.filter((l) => l !== listener);
    };
  }

  private notify(): void {
    this.listeners.forEach((l) => {
      try { l(); } catch {}
    });
  }

  /**
   * Purges any fake or placeholder URLs (Render, Railway, etc.) from local storage.
   */
  private purgePlaceholderUrls(): void {
    if (typeof window === 'undefined') return;
    try {
      const saved = localStorage.getItem(STORAGE_KEY_BACKEND_URL);
      if (saved && isFakeOrPlaceholderUrl(saved)) {
        console.warn('[BackendConfig] Purging invalid or placeholder URL from localStorage:', saved);
        localStorage.removeItem(STORAGE_KEY_BACKEND_URL);
      }
      // Also check legacy storage keys if any
      const legacyKeys = ['hinata_backend_url', 'backend_url', 'custom_backend_url'];
      for (const k of legacyKeys) {
        const val = localStorage.getItem(k);
        if (val && isFakeOrPlaceholderUrl(val)) {
          localStorage.removeItem(k);
        }
      }
    } catch {}
  }

  // ----------------------------------------------------
  // Backend URL Resolution & Configuration State
  // ----------------------------------------------------

  /**
   * Checks whether the backend is configured.
   * In AI Studio Build mode / web preview, the internal server runs on the same origin,
   * so backend is ALWAYS configured by default without requiring external env vars.
   */
  public isConfigured(): boolean {
    return true;
  }

  /**
   * Returns whether the application is using the internal AI Studio Server (same-origin).
   */
  public isUsingAiStudioServer(): boolean {
    return !this.getBackendUrl();
  }

  /**
   * Returns human-readable name of current backend target:
   * e.g. "AI Studio Server" or a custom external URL if specified.
   */
  public getBackendDisplayName(): string {
    const custom = this.getBackendUrl();
    if (custom) {
      return custom;
    }
    return 'AI Studio Server';
  }

  /**
   * Returns the currently configured Backend Base URL.
   * In normal AI Studio preview, returns '' (empty string) to perform same-origin relative requests.
   * If a valid, non-placeholder external URL is explicitly configured, returns that URL.
   */
  public getBackendUrl(): string {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem(STORAGE_KEY_BACKEND_URL);
      if (saved && saved.trim() && !isFakeOrPlaceholderUrl(saved)) {
        return saved.trim().replace(/\/+$/, '');
      }
    }

    const envUrl =
      (import.meta as any).env?.VITE_HINATA_BACKEND_URL ||
      (import.meta as any).env?.HINATA_BACKEND_URL;

    if (envUrl && typeof envUrl === 'string' && envUrl.trim() && !isFakeOrPlaceholderUrl(envUrl)) {
      return envUrl.trim().replace(/\/+$/, '');
    }

    // Default to same-origin (AI Studio internal server)
    return '';
  }

  /**
   * Returns current backend state enum:
   * - 'BACKEND_CONNECTED': Successfully verified via test connection (HTTP 200)
   * - 'BACKEND_NOT_CONFIGURED': Only for headless non-browser runs without server
   * - 'BACKEND_UNREACHABLE': Configured URL cannot be reached
   * - 'BACKEND_ERROR': Configured URL returned server error
   */
  public getBackendState(): BackendState {
    return this.backendState;
  }

  /**
   * Returns current backend status:
   * - 'connected': Verified via test connection
   * - 'not_configured': When offline/missing
   * - 'connection_failed': Unreachable or error
   */
  public getStatus(): BackendStatusType {
    return this.connectionStatus;
  }

  public getLastHealthResult(): BackendHealthResult | null {
    return this.lastHealthResult;
  }

  public getLastCheckedTimestamp(): number {
    return this.lastCheckedTimestamp;
  }

  /**
   * Returns the corresponding WebSocket URL (ws:// or wss://) for the backend.
   * In AI Studio preview / local development, defaults to current host so WebSocket connects directly to server.ts.
   */
  public getWsBackendUrl(): string {
    const httpUrl = this.getBackendUrl();
    if (!httpUrl) {
      if (typeof window !== 'undefined' && window.location) {
        const wsProto = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
        return `${wsProto}//${window.location.host}`;
      }
      return '';
    }

    try {
      const parsed = new URL(httpUrl);
      const wsProto = parsed.protocol === 'https:' ? 'wss:' : 'ws:';
      return `${wsProto}//${parsed.host}`;
    } catch {
      return httpUrl.replace(/^http:/i, 'ws:').replace(/^https:/i, 'wss:');
    }
  }

  /**
   * Updates the custom backend URL.
   * Rejects fake/placeholder URLs (Render, Railway, Vercel) and reverts to AI Studio Server.
   */
  public setBackendUrl(url: string | null): void {
    if (typeof window !== 'undefined') {
      if (!url || !url.trim() || isFakeOrPlaceholderUrl(url)) {
        localStorage.removeItem(STORAGE_KEY_BACKEND_URL);
        this.backendState = 'BACKEND_CONNECTED';
        this.connectionStatus = 'connected';
        setTimeout(() => {
          this.checkHealth().catch(() => {});
        }, 50);
      } else {
        localStorage.setItem(STORAGE_KEY_BACKEND_URL, url.trim().replace(/\/+$/, ''));
        this.backendState = 'BACKEND_UNREACHABLE';
        this.connectionStatus = 'connection_failed';
        setTimeout(() => {
          this.checkHealth().catch(() => {});
        }, 50);
      }
    }
    this.notify();
  }

  /**
   * Helper for local preview testing: sets the backend URL to current web host
   */
  public useCurrentWebPreviewHost(): void {
    if (typeof window !== 'undefined') {
      this.clearCustomBackendUrl();
    }
  }

  /**
   * Resets any custom backend URL, reverting to AI Studio Server.
   */
  public clearCustomBackendUrl(): void {
    if (typeof window !== 'undefined') {
      localStorage.removeItem(STORAGE_KEY_BACKEND_URL);
      this.backendState = 'BACKEND_CONNECTED';
      this.connectionStatus = 'connected';
      this.lastHealthResult = null;
      setTimeout(() => {
        this.checkHealth().catch(() => {});
      }, 50);
      this.notify();
    }
  }

  public isCustomUrlActive(): boolean {
    if (typeof window === 'undefined') return false;
    const saved = localStorage.getItem(STORAGE_KEY_BACKEND_URL);
    return Boolean(saved && !isFakeOrPlaceholderUrl(saved));
  }

  public isProduction(): boolean {
    const url = this.getBackendUrl();
    if (!url) return false;
    return url.startsWith('https://') && !url.includes('localhost') && !url.includes('127.0.0.1');
  }

  // ----------------------------------------------------
  // Multi-Device Identity & State
  // ----------------------------------------------------

  private initDeviceIdentity(): void {
    if (typeof window === 'undefined') return;

    if (!localStorage.getItem(STORAGE_KEY_DEVICE_ID)) {
      const generated = 'device-' + Date.now().toString(36) + '-' + Math.random().toString(36).substring(2, 8);
      localStorage.setItem(STORAGE_KEY_DEVICE_ID, generated);
    }

    if (!localStorage.getItem(STORAGE_KEY_USER_ID)) {
      localStorage.setItem(STORAGE_KEY_USER_ID, 'user-001');
    }

    if (!localStorage.getItem(STORAGE_KEY_DEVICE_NAME)) {
      const isAndroid = /android/i.test(navigator.userAgent);
      const defaultName = isAndroid ? 'Android Phone' : 'Hinata Device';
      localStorage.setItem(STORAGE_KEY_DEVICE_NAME, defaultName);
    }
  }

  public getUserId(): string {
    if (typeof window === 'undefined') return 'user-001';
    return localStorage.getItem(STORAGE_KEY_USER_ID) || 'user-001';
  }

  public setUserId(userId: string): void {
    if (typeof window !== 'undefined') {
      localStorage.setItem(STORAGE_KEY_USER_ID, userId.trim() || 'user-001');
    }
    this.notify();
  }

  public getDeviceId(): string {
    if (typeof window === 'undefined') return 'device-unknown';
    let devId = localStorage.getItem(STORAGE_KEY_DEVICE_ID);
    if (!devId) {
      devId = 'device-' + Date.now().toString(36) + '-' + Math.random().toString(36).substring(2, 8);
      localStorage.setItem(STORAGE_KEY_DEVICE_ID, devId);
    }
    return devId;
  }

  public getDeviceName(): string {
    if (typeof window === 'undefined') return 'Hinata Device';
    return localStorage.getItem(STORAGE_KEY_DEVICE_NAME) || 'Android Device';
  }

  public setDeviceName(name: string): void {
    if (typeof window !== 'undefined') {
      localStorage.setItem(STORAGE_KEY_DEVICE_NAME, name.trim() || 'Android Device');
    }
    this.notify();
  }

  public getSessionId(): string {
    return runtimeSessionId;
  }

  public getActiveConversationId(): string | null {
    if (typeof window === 'undefined') return null;
    return localStorage.getItem(STORAGE_KEY_ACTIVE_CONV) || null;
  }

  public setActiveConversationId(convId: string | null): void {
    if (typeof window !== 'undefined') {
      if (convId) {
        localStorage.setItem(STORAGE_KEY_ACTIVE_CONV, convId);
      } else {
        localStorage.removeItem(STORAGE_KEY_ACTIVE_CONV);
      }
    }
  }

  public getDeviceProfile(): DeviceProfile {
    const isAndroid = typeof navigator !== 'undefined' && /android/i.test(navigator.userAgent);
    return {
      userId: this.getUserId(),
      deviceId: this.getDeviceId(),
      deviceName: this.getDeviceName(),
      platform: isAndroid ? 'android' : 'web',
      appVersion: '1.2.0',
    };
  }

  // ----------------------------------------------------
  // Network Request Helpers & Error Handling
  // ----------------------------------------------------

  /**
   * Builds the full API URL for a given endpoint.
   * If using AI Studio Server, returns clean same-origin relative path (e.g. /api/assistant).
   * If an external URL is configured, prepends the base URL.
   */
  public buildApiUrl(endpoint: string): string {
    const base = this.getBackendUrl();
    const cleanEndpoint = endpoint.startsWith('/') ? endpoint : `/${endpoint}`;
    return base ? `${base}${cleanEndpoint}` : cleanEndpoint;
  }

  /**
   * Performs an HTTP request with standard multi-device headers:
   * - X-User-Id
   * - X-Device-Id
   * - X-Session-Id
   * - X-Conversation-Id
   */
  public async fetchWithHeaders(endpoint: string, init?: RequestInit): Promise<Response> {
    const url = this.buildApiUrl(endpoint);
    const headers = new Headers(init?.headers || {});

    if (!headers.has('Content-Type') && init?.method && init.method !== 'GET') {
      headers.set('Content-Type', 'application/json');
    }
    headers.set('X-User-Id', this.getUserId());
    headers.set('X-Device-Id', this.getDeviceId());
    headers.set('X-Session-Id', this.getSessionId());

    const activeConv = this.getActiveConversationId();
    if (activeConv) {
      headers.set('X-Conversation-Id', activeConv);
    }

    try {
      const res = await fetch(url, {
        ...init,
        headers,
      });
      return res;
    } catch (networkErr: any) {
      console.warn(`[BackendConfig] Network error communicating with ${url}:`, networkErr);
      this.connectionStatus = 'connection_failed';
      this.notify();
      throw new Error('Connection unavailable.');
    }
  }

  /**
   * Registers this device with the backend (POST /api/devices/register).
   */
  public async registerDevice(): Promise<{ success: boolean; deviceId: string }> {
    try {
      const profile = this.getDeviceProfile();
      const res = await this.fetchWithHeaders('/api/devices/register', {
        method: 'POST',
        body: JSON.stringify(profile),
      });

      if (!res.ok) {
        return { success: false, deviceId: profile.deviceId };
      }

      const data = await res.json();
      return { success: true, deviceId: data.deviceId || profile.deviceId };
    } catch (e) {
      console.warn('[BackendConfig] Device registration skipped or offline:', e);
      return { success: false, deviceId: this.getDeviceId() };
    }
  }

  /**
   * Checks the health of the currently active backend (GET /health).
   * Tests the actual project server used by this application.
   */
  public async checkHealth(): Promise<BackendHealthResult> {
    const start = Date.now();
    const healthUrl = this.buildApiUrl('/health');
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 6000);

      const res = await fetch(healthUrl, {
        method: 'GET',
        headers: {
          'Accept': 'application/json',
          'X-User-Id': this.getUserId(),
          'X-Device-Id': this.getDeviceId(),
        },
        signal: controller.signal,
      });
      clearTimeout(timeoutId);

      const latencyMs = Date.now() - start;
      if (!res.ok) {
        this.backendState = 'BACKEND_ERROR';
        this.connectionStatus = 'connection_failed';
        const result: BackendHealthResult = {
          ok: false,
          latencyMs,
          error: `HTTP ${res.status}: Backend error`,
        };
        this.lastHealthResult = result;
        this.lastCheckedTimestamp = Date.now();
        this.notify();
        return result;
      }

      const data = await res.json().catch(() => ({}));
      this.backendState = 'BACKEND_CONNECTED';
      this.connectionStatus = 'connected';
      const result: BackendHealthResult = {
        ok: true,
        status: data.status || 'ok',
        service: this.isUsingAiStudioServer() ? 'AI Studio Server' : (data.service || 'hinata-backend'),
        latencyMs,
      };
      this.lastHealthResult = result;
      this.lastCheckedTimestamp = Date.now();
      this.notify();
      return result;
    } catch (err: any) {
      const latencyMs = Date.now() - start;
      const errorMsg =
        err.name === 'AbortError'
          ? 'Connection timed out (6s)'
          : (err.message || 'Connection unavailable.');
      this.backendState = 'BACKEND_UNREACHABLE';
      this.connectionStatus = 'connection_failed';
      const result: BackendHealthResult = {
        ok: false,
        latencyMs,
        error: errorMsg,
      };
      this.lastHealthResult = result;
      this.lastCheckedTimestamp = Date.now();
      this.notify();
      return result;
    }
  }

  public async checkBackendHealth(): Promise<BackendHealthResult> {
    return this.checkHealth();
  }
}

export const backendConfig = BackendConfigService.getInstance();
export const BackendConfig = BackendConfigService.getInstance();
export { BackendConfigService };

