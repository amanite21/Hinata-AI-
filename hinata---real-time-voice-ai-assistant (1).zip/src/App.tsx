import React, { useState, useEffect, useRef, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { AlertCircle, Eye, Sparkles, Smartphone, Loader2, Heart, Key } from 'lucide-react';
import { LiveSession } from './modules/LiveSession';
import { StateManager, AppState } from './modules/StateManager';
import { HeaderBar } from './components/HeaderBar';
import { VoiceStatusBar } from './components/VoiceStatusBar';
import { HinataMascotAvatar } from './components/HinataMascotAvatar';
import { BottomNav } from './components/BottomNav';
import { FuturisticBackground } from './components/FuturisticBackground';
import { ToolExecutionBadge } from './components/ToolExecutionBadge';
import { SettingsModal } from './components/SettingsModal';
import { MemoryModal } from './components/MemoryModal';
import { ToolsModal } from './components/ToolsModal';
import { MoreModal } from './components/MoreModal';
import { VisualDesignModal } from './components/VisualDesignModal';
import { DeviceActionModal } from './components/DeviceActionModal';
import { HandsFreeSetupModal } from './components/wake/HandsFreeSetupModal';
import { SensitiveActionConfirmationToast } from './components/SensitiveActionConfirmationToast';
import { FeatureShowcase } from './components/FeatureShowcase';
import { RightProfileCard } from './components/RightProfileCard';
import { LeftFloatingCards } from './components/LeftFloatingCards';
import { VisionIntelligencePanel } from './components/VisionIntelligencePanel';
import { ChatScreen } from './components/chat/ChatScreen';
import { WorkDashboard } from './components/work/WorkDashboard';
import { BackendStatusModal } from './components/BackendStatusModal';
import { ConversationManager } from './modules/conversation/ConversationManager';
import { MemoryManager } from './modules/memory/MemoryManager';
import { useVisualDesign } from './modules/visualDesign/useVisualDesign';
import { VisionManager } from './modules/VisionManager';
import { backendConfig } from './config/backendConfig';
import { ClientAIProvider, AIProviderStatus } from './modules/ai/AIProvider';
import { EmotionalState } from './types';

export default function App() {
  const stateManagerRef = useRef<StateManager>(new StateManager('Kore'));
  const [appState, setAppState] = useState<AppState>(() => stateManagerRef.current.getState());
  const [isSettingsOpen, setIsSettingsOpen] = useState<boolean>(false);
  const [initialSettingsTab, setInitialSettingsTab] = useState<'voice' | 'permissions' | 'identity' | 'backend' | 'ai'>('voice');
  const [aiStatus, setAiStatus] = useState<AIProviderStatus>(() => ClientAIProvider.getInstance().getStatus());

  useEffect(() => {
    const unsub = ClientAIProvider.getInstance().subscribe((st) => {
      setAiStatus(st);
    });
    return unsub;
  }, []);
  const [isBackendStatusOpen, setIsBackendStatusOpen] = useState<boolean>(false);
  const [isMemoryOpen, setIsMemoryOpen] = useState<boolean>(false);
  const [isToolsOpen, setIsToolsOpen] = useState<boolean>(false);
  const [isMoreOpen, setIsMoreOpen] = useState<boolean>(false);
  const [isVisionOpen, setIsVisionOpen] = useState<boolean>(false);
  const [isDeviceActionOpen, setIsDeviceActionOpen] = useState<boolean>(false);
  const [isHandsFreeSetupOpen, setIsHandsFreeSetupOpen] = useState<boolean>(false);
  const [isDraggingOver, setIsDraggingOver] = useState<boolean>(false);
  const [memoryCount, setMemoryCount] = useState<number>(() => MemoryManager.getInstance().longTerm.getAll().length);
  const [lastTranscript, setLastTranscript] = useState<string>('');
  const [transcriptRole, setTranscriptRole] = useState<'user' | 'assistant'>('assistant');
  const [viewMode, setViewMode] = useState<'companion' | 'chat' | 'work' | 'showcase'>('companion');

  const {
    references,
    activeReference,
    activeTheme,
    addReference,
    isBusy: isVisionBusy,
  } = useVisualDesign();

  const liveSessionRef = useRef<LiveSession | null>(null);

  // Subscribe to MemoryManager changes for badge update
  useEffect(() => {
    const mm = MemoryManager.getInstance();
    const updateCount = () => {
      setMemoryCount(mm.longTerm.getAll().length);
    };
    updateCount();
    return mm.subscribe(updateCount);
  }, []);

  // Subscribe to reactive StateManager
  useEffect(() => {
    const sm = stateManagerRef.current;
    const unsubscribe = sm.subscribe((updatedState) => {
      setAppState(updatedState);
    });
    return unsubscribe;
  }, []);

  // Initialize and bind LiveSession to StateManager
  useEffect(() => {
    const sm = stateManagerRef.current;
    const session = new LiveSession({
      onStateChange: (newState) => {
        sm.setSessionState(newState);
      },
      onEmotionChange: (newEmotion, intensity) => {
        sm.setEmotionalState(newEmotion, intensity);
      },
      onMoodChange: (newMood) => {
        sm.setMood(newMood);
      },
      onToolCall: (toolItem) => {
        sm.addToolCall(toolItem);
      },
      onError: (err) => {
        sm.setErrorMessage(err);
      },
      onLatencyUpdate: (lat) => {
        sm.setLatency(lat);
      },
      onInputVolume: (vol) => {
        sm.setInputVolume(vol);
      },
      onOutputVolume: (vol) => {
        sm.setOutputVolume(vol);
      },
      onTranscript: (role, text) => {
        setLastTranscript(text);
        setTranscriptRole(role);
        try {
          ConversationManager.getInstance().syncVoiceTurn(
            role === 'user' ? 'user' : 'assistant',
            text
          );
        } catch (e) {
          console.warn('[App] Transcript sync warning:', e);
        }
      },
    });

    liveSessionRef.current = session;

    // Connect VisionManager to stream video frames into Gemini Live session
    const vm = VisionManager.getInstance();
    vm.bindLiveSessionSender((base64, mimeType) => {
      if (liveSessionRef.current) {
        liveSessionRef.current.sendVideoFrame(base64, mimeType);
      }
    });

    const unsubscribeVision = vm.subscribe((vState) => {
      sm.setSelectedImage(vState.selectedImage);
      sm.setScreenSharing(vState.screenShareState.isActive);
      sm.setVisionAnalyzing(vState.isAnalyzing);
    });

    // Sync ConversationManager TTS speech volume & chat states to mascot avatar
    const cm = ConversationManager.getInstance();
    const unsubCmState = cm.onChatStateChange((chatState) => {
      if (liveSessionRef.current?.getState() === 'disconnected') {
        if (chatState === 'speaking') {
          sm.setMascotState('SPEAKING');
        } else if (chatState === 'thinking' || chatState === 'streaming' || chatState === 'sending') {
          sm.setMascotState('THINKING');
        } else {
          sm.setMascotState('IDLE');
        }
      }
    });

    const unsubCmVol = cm.onSpeechVolume((vol) => {
      if (liveSessionRef.current?.getState() === 'disconnected') {
        sm.setOutputVolume(vol);
      }
    });

    return () => {
      unsubscribeVision();
      unsubCmState();
      unsubCmVol();
      vm.bindLiveSessionSender(null);
      session.disconnect();
    };
  }, []);

  const handleConnect = useCallback(async () => {
    const sm = stateManagerRef.current;
    sm.setErrorMessage(null);

    // In AI Studio preview, connect to the integrated development backend.
    // External backend URL is optional and does not block the app.
    if (liveSessionRef.current) {
      try {
        await liveSessionRef.current.connect(appState.selectedVoice);
      } catch (err: any) {
        sm.setErrorMessage(err?.message || 'Failed to start live session.');
      }
    }
  }, [appState.selectedVoice]);

  const handleDisconnect = useCallback(() => {
    if (liveSessionRef.current) {
      liveSessionRef.current.disconnect();
    }
  }, []);

  const handleToggleMute = useCallback(() => {
    if (liveSessionRef.current) {
      const muted = liveSessionRef.current.toggleMute();
      stateManagerRef.current.setMuted(muted);
    }
  }, []);

  const handleInterrupt = useCallback(() => {
    if (liveSessionRef.current) {
      liveSessionRef.current.interrupt();
    }
  }, []);

  const handleVolumeChange = useCallback((vol: number) => {
    stateManagerRef.current.setSpeechGain(vol);
    if (liveSessionRef.current) {
      liveSessionRef.current.setVolume(vol);
    }
  }, []);

  const handleDismissTool = useCallback((id: string) => {
    stateManagerRef.current.removeToolCall(id);
  }, []);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDraggingOver(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDraggingOver(false);
  }, []);

  const handleDrop = useCallback(async (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDraggingOver(false);
    const files = e.dataTransfer.files;
    if (files && files.length > 0) {
      for (let i = 0; i < files.length; i++) {
        const file = files[i];
        if (file.type.startsWith('image/')) {
          await addReference(file, file.name.replace(/\.[^/.]+$/, ''));
        }
      }
      setIsVisionOpen(true);
    }
  }, [addReference]);

  const handleSelectEmotion = useCallback((newEmotion: EmotionalState) => {
    stateManagerRef.current.setEmotionalState(newEmotion, 3);
  }, []);

  const {
    sessionState: state,
    mood,
    emotionalIntensity,
    isMuted,
    latencyMs,
    inputVolume,
    outputVolume,
    activeTools,
    errorMessage,
    selectedVoice,
    speechGain,
  } = appState;

  return (
    <main
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      onDrop={handleDrop}
      className="relative w-full h-[100dvh] bg-[#050612] text-slate-100 flex flex-col justify-between overflow-x-hidden overflow-y-auto select-none"
    >
      {/* Cinematic Dark Futuristic Stage Background */}
      <FuturisticBackground />

      {/* Drag & Drop Holographic Overlay */}
      <AnimatePresence>
        {isDraggingOver && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-[#060a22]/85 backdrop-blur-xl border-4 border-dashed border-cyan-400 flex flex-col items-center justify-center p-6 pointer-events-none"
          >
            <div className="w-20 h-20 rounded-3xl bg-cyan-500/20 border border-cyan-400 flex items-center justify-center shadow-[0_0_50px_rgba(0,229,255,0.6)] mb-4 animate-bounce">
              <Eye className="w-10 h-10 text-cyan-300" />
            </div>
            <h2 className="text-xl font-bold text-white tracking-wide">
              Release to Analyze Visual Reference
            </h2>
            <p className="text-sm text-cyan-200/80 mt-1 max-w-sm text-center">
              Hinata will extract layout, colors, typography, and styling.
            </p>
          </motion.div>
        )}
      </AnimatePresence>

      {/* TOP SECTION: Header bar */}
      <div className="w-full flex-shrink-0">
        <HeaderBar
          state={state}
          onOpenSettings={() => {
            setInitialSettingsTab('voice');
            setIsSettingsOpen(true);
          }}
          onOpenBackendStatus={() => setIsBackendStatusOpen(true)}
          onOpenVision={() => setIsVisionOpen(true)}
          onOpenDeviceActions={() => setIsDeviceActionOpen(true)}
          onOpenHandsFree={() => setIsHandsFreeSetupOpen(true)}
          activeReferenceCount={references.length}
          isVisionCustomApplied={activeTheme.isCustomApplied}
        />

        {/* View Switcher Pills */}
        <div className="flex items-center justify-center gap-2 mt-1 mb-1 px-4 z-30">
          <div className="p-1 rounded-full bg-[#080d24]/90 border border-cyan-500/30 flex items-center gap-1 shadow-md">
            <button
              onClick={() => setViewMode('companion')}
              className={`px-3 py-1 rounded-full text-xs font-semibold transition-all ${
                viewMode === 'companion'
                  ? 'bg-cyan-500 text-slate-950 shadow-[0_0_12px_#00e5ff]'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              ✦ Voice Mode
            </button>
            <button
              onClick={() => setViewMode('chat')}
              className={`px-3 py-1 rounded-full text-xs font-semibold transition-all ${
                viewMode === 'chat'
                  ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white shadow-[0_0_12px_#00e5ff]'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              💬 Chat Mode
            </button>
            <button
              onClick={() => setViewMode('showcase')}
              className={`px-3 py-1 rounded-full text-xs font-semibold transition-all ${
                viewMode === 'showcase'
                  ? 'bg-purple-600 text-white shadow-[0_0_12px_#c084fc]'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              All Features & 18 Emotions
            </button>
          </div>
        </div>

        {/* Voice Status Greeting Bar */}
        <VoiceStatusBar
          state={state}
          mascotState={appState.mascotState}
          isScreenSharing={appState.isScreenSharing}
          hasImage={!!appState.selectedImage}
          lastTranscript={lastTranscript}
          transcriptRole={transcriptRole}
          outputVolume={outputVolume}
          inputVolume={inputVolume}
        />
      </div>

      {/* Cognitive State & Device Activity Pill */}
      <AnimatePresence>
        {appState.cognitiveState !== 'idle' && (
          <motion.div
            initial={{ opacity: 0, y: -8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            className="flex items-center justify-center -mt-1 mb-1 z-30"
          >
            <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-cyan-950/80 border border-cyan-400/40 text-[11px] text-cyan-200 backdrop-blur-md shadow-[0_0_15px_rgba(0,229,255,0.25)]">
              <Loader2 className="w-3 h-3 text-cyan-400 animate-spin" />
              <span className="capitalize">{appState.cognitiveDetails || `${appState.cognitiveState}...`}</span>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Active Tool Execution Toast */}
      <ToolExecutionBadge
        activeTools={activeTools}
        onDismiss={handleDismissTool}
      />

      {/* Sensitive Action Explicit Confirmation Toast */}
      <SensitiveActionConfirmationToast
        pendingAction={appState.pendingSensitiveAction}
        onDismiss={() => stateManagerRef.current.dismissPendingSensitiveAction()}
      />

      {/* Error / Status Alert Notification */}
      <AnimatePresence>
        {errorMessage && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="fixed top-16 left-1/2 -translate-x-1/2 z-50 w-full max-w-md px-4"
          >
            <div className="glass-panel border border-rose-500/40 rounded-2xl p-4 shadow-2xl flex items-start gap-3 bg-rose-950/70 text-rose-200 text-xs">
              <AlertCircle className="w-5 h-5 text-rose-400 flex-shrink-0 mt-0.5" />
              <div className="flex-1">
                <p className="font-semibold text-rose-100 text-sm">Session Notice</p>
                <p className="mt-0.5">{errorMessage}</p>
              </div>
              <button
                onClick={() => stateManagerRef.current.setErrorMessage(null)}
                className="text-rose-400 hover:text-rose-100 font-bold text-base p-1"
              >
                ✕
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Active Theme Indicator Pill */}
      <AnimatePresence>
        {activeTheme.isCustomApplied && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="fixed top-24 left-1/2 -translate-x-1/2 z-30 pointer-events-auto"
          >
            <button
              onClick={() => setIsVisionOpen(true)}
              className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#080e29]/80 border border-cyan-400/40 text-[11px] text-cyan-200 backdrop-blur-md shadow-[0_0_15px_rgba(0,229,255,0.25)] hover:border-cyan-300 transition-all active:scale-95"
            >
              <Sparkles className="w-3 h-3 text-cyan-300 animate-pulse" />
              <span>Aesthetic: {activeTheme.name}</span>
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Global AI Service Auth Warning Banner */}
      <AnimatePresence>
        {(aiStatus.status === 'EXPIRED_OR_REVOKED' || aiStatus.status === 'INVALID_KEY') && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="w-full max-w-2xl mx-auto px-4 z-30 mb-2 pointer-events-auto"
          >
            <div className="p-3 rounded-2xl bg-rose-950/70 border border-rose-500/60 shadow-[0_0_25px_rgba(244,63,94,0.25)] flex items-center justify-between gap-3 text-xs">
              <div className="flex items-center gap-2.5 text-rose-300 min-w-0">
                <AlertCircle className="w-4 h-4 text-rose-400 flex-shrink-0" />
                <span className="truncate">
                  <strong>AI Authentication Failed:</strong> Please update the API key in settings.
                </span>
              </div>
              <button
                onClick={() => {
                  setInitialSettingsTab('ai');
                  setIsSettingsOpen(true);
                }}
                className="px-3 py-1.5 rounded-xl bg-rose-500/30 hover:bg-rose-500/40 text-rose-100 border border-rose-400/60 font-semibold text-[11px] flex items-center gap-1.5 transition-all flex-shrink-0"
              >
                <Key className="w-3.5 h-3.5 text-rose-300" />
                <span>Update API Key</span>
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* CENTER ARENA: Switching between Voice Mode, Dedicated Chat Mode, Work Hub, and Showcase Mode */}
      {viewMode === 'chat' ? (
        <div className="relative flex-1 w-full max-w-5xl mx-auto flex flex-col z-20 overflow-hidden min-h-0">
          <ChatScreen
            liveSessionState={state}
            currentMood={mood}
            emotionalIntensity={emotionalIntensity}
            audioPlayer={liveSessionRef.current?.getAudioPlayer() || null}
            onOpenMemory={() => setIsMemoryOpen(true)}
            onOpenDeviceActions={() => setIsDeviceActionOpen(true)}
            onOpenBackendStatus={() => setIsBackendStatusOpen(true)}
            onOpenSettings={(tab) => {
              setInitialSettingsTab(tab || 'backend');
              setIsSettingsOpen(true);
            }}
          />
        </div>
      ) : viewMode === 'work' ? (
        <div className="relative flex-1 w-full max-w-6xl mx-auto flex flex-col z-20 overflow-hidden min-h-0">
          <WorkDashboard onOpenChat={() => setViewMode('chat')} />
        </div>
      ) : viewMode === 'companion' ? (
        <div className="relative flex-1 w-full max-w-6xl mx-auto flex items-center justify-center z-20 my-auto px-4 overflow-visible">
          {/* Left card on desktop: Speech dialogue preview */}
          <div className="hidden lg:block w-[260px] flex-shrink-0">
            <LeftFloatingCards
              state={state}
              lastTranscript={lastTranscript}
              transcriptRole={transcriptRole}
              inputVolume={inputVolume}
              outputVolume={outputVolume}
            />
          </div>

          {/* Center Mascot with Halo and Tilted Orbital Rings */}
          <div className="flex-1 max-w-md mx-auto flex flex-col items-center justify-center">
            <HinataMascotAvatar
              state={state}
              mascotState={appState.mascotState}
              mood={mood}
              intensity={emotionalIntensity}
              outputVolume={outputVolume}
              inputVolume={inputVolume}
              audioPlayer={liveSessionRef.current?.getAudioPlayer() || null}
              onAvatarClick={() => {
                if (state === 'disconnected') {
                  handleConnect();
                } else if (state === 'speaking') {
                  handleInterrupt();
                }
              }}
            />
          </div>

          {/* Right card on desktop: Capabilities & Language Badges */}
          <div className="hidden lg:block w-[240px] flex-shrink-0">
            <RightProfileCard />
          </div>
        </div>
      ) : (
        <div className="relative flex-1 w-full z-20 overflow-y-auto px-2 py-4">
          <FeatureShowcase
            currentEmotion={mood}
            currentIntensity={emotionalIntensity}
            onSelectEmotion={handleSelectEmotion}
            onSelectIntensity={(lvl) => stateManagerRef.current.setEmotionalState(mood, lvl)}
            onPickImage={async () => {
              try {
                await VisionManager.getInstance().imageInput.pickImage();
              } catch (e) {
                console.warn('[App] Pick image error:', e);
              }
            }}
            onToggleScreenShare={async () => {
              try {
                const vm = VisionManager.getInstance();
                if (vm.screenShare.isScreenSharing()) {
                  vm.screenShare.stopScreenShare();
                } else {
                  await vm.screenShare.startScreenShare();
                }
              } catch (e) {
                console.warn('[App] Screen share toggle error:', e);
              }
            }}
            isScreenSharing={appState.isScreenSharing}
            onOpenDeviceActions={() => setIsDeviceActionOpen(true)}
            onStartVoice={() => {
              if (state === 'disconnected') {
                handleConnect();
              }
            }}
            isVoiceActive={state === 'listening' || state === 'speaking'}
          />
        </div>
      )}

      {/* BOTTOM SECTION: 5-Button Control Dock + Bottom Nav */}
      <div className="w-full flex-shrink-0">
        <BottomNav
          state={state}
          inputVolume={inputVolume}
          outputVolume={outputVolume}
          selectedImage={appState.selectedImage}
          isScreenSharing={appState.isScreenSharing}
          isVisionAnalyzing={appState.isVisionAnalyzing}
          activeTab={viewMode === 'chat' ? 'chat' : viewMode === 'work' ? 'work' : 'home'}
          onTabChange={(tab) => {
            if (tab === 'chat') {
              setViewMode('chat');
            } else if (tab === 'work') {
              setViewMode('work');
            } else if (tab === 'home') {
              setViewMode('companion');
            }
          }}
          onOpenWork={() => setViewMode('work')}
          onPickImage={async () => {
            try {
              await VisionManager.getInstance().imageInput.pickImage();
            } catch (e) {
              console.warn('[App] Pick image error:', e);
            }
          }}
          onRemoveImage={() => {
            VisionManager.getInstance().imageInput.clearImage();
          }}
          onToggleScreenShare={async () => {
            try {
              const vm = VisionManager.getInstance();
              if (vm.screenShare.isScreenSharing()) {
                vm.screenShare.stopScreenShare();
              } else {
                await vm.screenShare.startScreenShare();
              }
            } catch (e) {
              console.warn('[App] Screen share toggle error:', e);
            }
          }}
          onStopScreenShare={() => {
            VisionManager.getInstance().screenShare.stopScreenShare();
          }}
          onMicClick={() => {
            if (state === 'disconnected') {
              handleConnect();
            } else if (state === 'speaking') {
              handleInterrupt();
            } else {
              handleDisconnect();
            }
          }}
          onOpenDeviceActions={() => setIsDeviceActionOpen(true)}
          onOpenMore={() => setIsMoreOpen(true)}
          onOpenMemory={() => setIsMemoryOpen(true)}
          onOpenVision={() => setIsVisionOpen(true)}
        />
      </div>

      {/* Backend Status & Health Test Modal */}
      <BackendStatusModal
        isOpen={isBackendStatusOpen}
        onClose={() => setIsBackendStatusOpen(false)}
        onOpenSettings={() => {
          setIsBackendStatusOpen(false);
          setInitialSettingsTab('backend');
          setIsSettingsOpen(true);
        }}
      />

      {/* Settings Modal */}
      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        selectedVoice={selectedVoice}
        onSelectVoice={(v) => stateManagerRef.current.setSelectedVoice(v)}
        outputVolume={speechGain}
        onVolumeChange={handleVolumeChange}
        initialTab={initialSettingsTab}
      />

      {/* Memory Vault Modal */}
      <MemoryModal
        isOpen={isMemoryOpen}
        onClose={() => setIsMemoryOpen(false)}
      />

      {/* Tools Capability Modal */}
      <ToolsModal
        isOpen={isToolsOpen}
        onClose={() => setIsToolsOpen(false)}
        activeTools={activeTools}
        onOpenVision={() => setIsVisionOpen(true)}
        onOpenDeviceActions={() => setIsDeviceActionOpen(true)}
      />

      {/* Telemetry & System Info Modal */}
      <MoreModal
        isOpen={isMoreOpen}
        onClose={() => setIsMoreOpen(false)}
        state={state}
        latencyMs={latencyMs}
        inputVolume={inputVolume}
        outputVolume={outputVolume}
        onOpenVision={() => setIsVisionOpen(true)}
        onOpenDeviceActions={() => setIsDeviceActionOpen(true)}
      />

      {/* Visual Design Intelligence Studio Modal */}
      <VisualDesignModal
        isOpen={isVisionOpen}
        onClose={() => setIsVisionOpen(false)}
      />

      {/* Android Device Action & Automation Hub */}
      <DeviceActionModal
        isOpen={isDeviceActionOpen}
        onClose={() => setIsDeviceActionOpen(false)}
      />

      {/* Hands-Free Wake Word & Android Digital Assistant Setup Modal */}
      <HandsFreeSetupModal
        isOpen={isHandsFreeSetupOpen}
        onClose={() => setIsHandsFreeSetupOpen(false)}
        onTestTrigger={handleConnect}
      />
    </main>
  );
}
