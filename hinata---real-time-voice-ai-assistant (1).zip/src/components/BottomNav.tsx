import React, { useRef, useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Image as ImageIcon,
  Monitor,
  MonitorOff,
  Mic,
  Square,
  Smartphone,
  MoreHorizontal,
  Home,
  MessageSquare,
  Brain,
  CheckSquare,
  User,
  RefreshCw,
  X,
  Wifi,
  Briefcase,
  Loader2,
  Sparkles,
  Upload,
  Palette,
  ClipboardPaste,
  Eye,
  Camera,
} from 'lucide-react';
import { LiveSessionState, SelectedImage } from '../types';
import { ImageInputManager } from '../modules/ImageInputManager';
import { VisionManager } from '../modules/VisionManager';
import { getSampleDashboardDataUrl } from '../utils/sampleUiImage';

interface BottomNavProps {
  state: LiveSessionState;
  inputVolume?: number;
  outputVolume?: number;
  selectedImage: SelectedImage | null;
  isScreenSharing: boolean;
  isVisionAnalyzing?: boolean;
  activeTab?: 'home' | 'chat' | 'work' | 'memory' | 'tasks' | 'profile';
  onTabChange?: (tab: 'home' | 'chat' | 'work' | 'memory' | 'tasks' | 'profile') => void;
  onPickImage: () => void;
  onRemoveImage: () => void;
  onToggleScreenShare: () => void;
  onStopScreenShare: () => void;
  onMicClick: () => void;
  onOpenDeviceActions: () => void;
  onOpenMore: () => void;
  onOpenMemory: () => void;
  onOpenWork?: () => void;
  onOpenVision?: () => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  state,
  inputVolume = 0,
  outputVolume = 0,
  selectedImage,
  isScreenSharing,
  isVisionAnalyzing = false,
  activeTab = 'home',
  onTabChange,
  onPickImage,
  onRemoveImage,
  onToggleScreenShare,
  onStopScreenShare,
  onMicClick,
  onOpenDeviceActions,
  onOpenMore,
  onOpenMemory,
  onOpenWork,
  onOpenVision,
}) => {
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [isVisionMenuOpen, setIsVisionMenuOpen] = useState(false);
  const isVoiceActive = state === 'listening' || state === 'speaking';
  const effectiveVol = state === 'speaking' ? outputVolume : inputVolume;

  // Listen for global clipboard paste (e.g. Snipping tool / screenshot Ctrl+V)
  useEffect(() => {
    const handlePaste = async (e: ClipboardEvent) => {
      const items = e.clipboardData?.items;
      if (!items) return;

      for (let i = 0; i < items.length; i++) {
        if (items[i].type.indexOf('image') !== -1) {
          const file = items[i].getAsFile();
          if (file) {
            try {
              await ImageInputManager.getInstance().setImageFromFile(file);
              setIsVisionMenuOpen(false);
            } catch (err) {
              console.error('[BottomNav] Paste image error:', err);
            }
          }
          break;
        }
      }
    };

    window.addEventListener('paste', handlePaste);
    return () => window.removeEventListener('paste', handlePaste);
  }, []);

  const handleImageButtonClick = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsVisionMenuOpen((prev) => !prev);
  };

  const handleFileInputChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      try {
        await ImageInputManager.getInstance().setImageFromFile(file);
        setIsVisionMenuOpen(false);
      } catch (err) {
        console.error('[BottomNav] Error loading selected file:', err);
      }
    }
    // Reset so selecting the same file triggers change again
    e.target.value = '';
  };

  const handleLoadSampleUi = async () => {
    try {
      const sampleDataUrl = getSampleDashboardDataUrl();
      await ImageInputManager.getInstance().setImageFromDataUrl(sampleDataUrl, 'Cyberpunk_UI_Dashboard.png');
      setIsVisionMenuOpen(false);
    } catch (err) {
      console.error('[BottomNav] Error loading demo screenshot:', err);
    }
  };

  const handleClipboardRead = async () => {
    try {
      if (navigator.clipboard?.read) {
        const clipboardItems = await navigator.clipboard.read();
        for (const item of clipboardItems) {
          const imageType = item.types.find((type) => type.startsWith('image/'));
          if (imageType) {
            const blob = await item.getType(imageType);
            const file = new File([blob], 'Clipboard_Image.png', { type: imageType });
            await ImageInputManager.getInstance().setImageFromFile(file);
            setIsVisionMenuOpen(false);
            return;
          }
        }
      }
      // If no image in clipboard, prompt user to press Ctrl+V
      alert('To paste a screenshot, take a screenshot and press Ctrl+V / Cmd+V anywhere on the screen!');
    } catch {
      alert('Press Ctrl+V / Cmd+V to paste your screenshot directly into Hinata.');
    }
  };

  const getMicIcon = () => {
    switch (state) {
      case 'speaking':
        return <Square className="w-5 h-5 text-white fill-white" />;
      case 'listening':
        return <Mic className="w-6 h-6 text-white animate-pulse" />;
      case 'connecting':
        return <Wifi className="w-5 h-5 text-white animate-spin" />;
      default:
        return <Mic className="w-6 h-6 text-white" />;
    }
  };

  return (
    <div className="w-full max-w-md mx-auto px-4 pb-3 pt-1 z-40 select-none pointer-events-auto flex flex-col items-center gap-2">
      {/* 1. Optional Floating Selected Image Pill */}
      <AnimatePresence>
        {selectedImage && !isVisionMenuOpen && (
          <motion.div
            initial={{ opacity: 0, y: 15, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 10, scale: 0.95 }}
            transition={{ duration: 0.2 }}
            className="w-full max-w-sm px-3 py-1.5 rounded-2xl bg-[#080d24]/95 backdrop-blur-xl border border-cyan-400/40 shadow-[0_4px_20px_rgba(0,229,255,0.25)] flex items-center justify-between gap-2.5"
          >
            <div className="relative w-9 h-9 rounded-xl overflow-hidden border border-cyan-400/50 flex-shrink-0 bg-slate-900">
              <img
                src={selectedImage.dataUrl}
                alt="Selected vision input"
                className="w-full h-full object-cover"
              />
            </div>
            <div className="flex-1 min-w-0 flex flex-col">
              <span className="text-[11px] font-semibold text-cyan-300 truncate">
                {selectedImage.name || 'Image Attached'}
              </span>
              <span className="text-[10px] text-slate-400 truncate">
                Hinata can see this • Ask questions via voice
              </span>
            </div>
            <div className="flex items-center gap-1 flex-shrink-0">
              <button
                type="button"
                onClick={() => setIsVisionMenuOpen(true)}
                title="Manage image"
                className="p-1 rounded-lg text-slate-400 hover:text-cyan-300 transition-colors"
              >
                <RefreshCw className="w-3.5 h-3.5" />
              </button>
              <button
                type="button"
                onClick={onRemoveImage}
                title="Remove image"
                className="p-1 rounded-lg text-slate-400 hover:text-rose-400 transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Visual Intelligence Quick Action Sheet */}
      <AnimatePresence>
        {isVisionMenuOpen && (
          <motion.div
            initial={{ opacity: 0, y: 12, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 8, scale: 0.95 }}
            transition={{ duration: 0.18 }}
            className="w-full max-w-sm p-3 rounded-2xl bg-[#080d24]/98 backdrop-blur-2xl border border-cyan-400/40 shadow-[0_12px_40px_rgba(0,0,0,0.8),0_0_25px_rgba(0,229,255,0.2)] flex flex-col gap-2.5 z-50"
          >
            <div className="flex items-center justify-between pb-1 border-b border-cyan-500/20">
              <div className="flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-cyan-400" />
                <span className="text-xs font-bold text-cyan-200 tracking-wide">
                  Visual Intelligence &amp; Image Intake
                </span>
              </div>
              <button
                type="button"
                onClick={() => setIsVisionMenuOpen(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
                title="Close"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* If an image is currently loaded */}
            {selectedImage ? (
              <div className="flex flex-col gap-2 p-2 rounded-xl bg-cyan-950/40 border border-cyan-400/30">
                <div className="flex items-center gap-2.5">
                  <img
                    src={selectedImage.dataUrl}
                    alt="Active screenshot"
                    className="w-12 h-12 object-cover rounded-lg border border-cyan-400/50"
                  />
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-semibold text-cyan-200 truncate">
                      {selectedImage.name || 'Current Image'}
                    </p>
                    <p className="text-[10px] text-emerald-400 font-medium">
                      ✓ Active in Hinata's visual field
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-1.5 pt-1">
                  <button
                    type="button"
                    onClick={() => {
                      VisionManager.getInstance().analyzeVisual(
                        'Explain everything you see in this screenshot in detail, including layout, colors, typography, components, and purpose.',
                        'image'
                      );
                      setIsVisionMenuOpen(false);
                    }}
                    className="flex items-center justify-center gap-1 px-2.5 py-2 rounded-lg bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-200 border border-cyan-400/40 text-[11px] font-semibold transition-all"
                  >
                    <Eye className="w-3.5 h-3.5" />
                    Explain Again
                  </button>
                  {onOpenVision && (
                    <button
                      type="button"
                      onClick={() => {
                        setIsVisionMenuOpen(false);
                        onOpenVision();
                      }}
                      className="flex items-center justify-center gap-1 px-2.5 py-2 rounded-lg bg-purple-500/20 hover:bg-purple-500/30 text-purple-200 border border-purple-400/40 text-[11px] font-semibold transition-all"
                    >
                      <Palette className="w-3.5 h-3.5" />
                      Design Studio
                    </button>
                  )}
                </div>
              </div>
            ) : null}

            {/* Quick Actions Grid */}
            <div className="grid grid-cols-1 gap-1.5">
              {/* Native File Upload with Label (Bypasses iframe security blocks) */}
              <label
                htmlFor="dock-image-file-input"
                className="flex items-center gap-2.5 p-2 rounded-xl bg-slate-900/80 hover:bg-cyan-950/60 border border-cyan-500/25 hover:border-cyan-400/60 transition-all cursor-pointer group"
              >
                <div className="w-8 h-8 rounded-lg bg-cyan-500/15 border border-cyan-400/40 flex items-center justify-center text-cyan-300 group-hover:scale-105 transition-transform flex-shrink-0">
                  <Upload className="w-4 h-4" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-semibold text-slate-200 group-hover:text-cyan-200">
                    Upload Screenshot or Photo
                  </p>
                  <p className="text-[10px] text-slate-400">
                    Select PNG, JPG, or WebP from your device
                  </p>
                </div>
                <input
                  id="dock-image-file-input"
                  type="file"
                  accept="image/*"
                  className="sr-only"
                  onChange={handleFileInputChange}
                />
              </label>

              {/* Instant Test Sample UI Screenshot */}
              <button
                type="button"
                onClick={handleLoadSampleUi}
                className="flex items-center gap-2.5 p-2 rounded-xl bg-slate-900/80 hover:bg-cyan-950/60 border border-cyan-500/25 hover:border-cyan-400/60 transition-all text-left group"
              >
                <div className="w-8 h-8 rounded-lg bg-emerald-500/15 border border-emerald-400/40 flex items-center justify-center text-emerald-300 group-hover:scale-105 transition-transform flex-shrink-0">
                  <Sparkles className="w-4 h-4" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-semibold text-slate-200 group-hover:text-emerald-200">
                    Instant Demo Dashboard
                  </p>
                  <p className="text-[10px] text-slate-400">
                    Load high-res cybernetic UI to test AI vision now
                  </p>
                </div>
                <span className="px-1.5 py-0.5 rounded text-[9px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  INSTANT
                </span>
              </button>

              {/* Open Visual Design Studio */}
              {onOpenVision && (
                <button
                  type="button"
                  onClick={() => {
                    setIsVisionMenuOpen(false);
                    onOpenVision();
                  }}
                  className="flex items-center gap-2.5 p-2 rounded-xl bg-slate-900/80 hover:bg-purple-950/60 border border-purple-500/25 hover:border-purple-400/60 transition-all text-left group"
                >
                  <div className="w-8 h-8 rounded-lg bg-purple-500/15 border border-purple-400/40 flex items-center justify-center text-purple-300 group-hover:scale-105 transition-transform flex-shrink-0">
                    <Palette className="w-4 h-4" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-semibold text-slate-200 group-hover:text-purple-200">
                      Visual Design Studio
                    </p>
                    <p className="text-[10px] text-slate-400">
                      Deep palette extraction, layout critique &amp; React code gen
                    </p>
                  </div>
                </button>
              )}

              {/* Paste Screenshot from Clipboard */}
              <button
                type="button"
                onClick={handleClipboardRead}
                className="flex items-center gap-2.5 p-2 rounded-xl bg-slate-900/80 hover:bg-cyan-950/60 border border-cyan-500/25 hover:border-cyan-400/60 transition-all text-left group"
              >
                <div className="w-8 h-8 rounded-lg bg-blue-500/15 border border-blue-400/40 flex items-center justify-center text-blue-300 group-hover:scale-105 transition-transform flex-shrink-0">
                  <ClipboardPaste className="w-4 h-4" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-semibold text-slate-200 group-hover:text-blue-200">
                    Paste Screenshot (Ctrl+V)
                  </p>
                  <p className="text-[10px] text-slate-400">
                    Clipboard paste active • Click or press Ctrl+V
                  </p>
                </div>
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* 2. PRIMARY 5-BUTTON CONTROL DOCK (Directly from Reference Image) */}
      <div className="relative w-full flex items-center justify-between px-3 py-2 rounded-3xl bg-[#080d24]/90 backdrop-blur-2xl border border-cyan-500/30 shadow-[0_10px_35px_rgba(0,0,0,0.8),0_0_20px_rgba(0,229,255,0.15)]">
        {/* Soft floor glow */}
        <div className="absolute inset-x-8 -bottom-1 h-5 bg-gradient-to-r from-cyan-500/20 via-blue-600/25 to-purple-600/20 filter blur-xl pointer-events-none" />

        {/* Direct Synchronous File Picker Input for Browser / iFrame Security */}
        <input
          ref={fileInputRef}
          type="file"
          accept="image/*"
          className="hidden"
          aria-hidden="true"
          onChange={handleFileInputChange}
        />

        {/* BUTTON 1: [ IMAGE ] */}
        <button
          id="btn-bottom-image-analyze"
          type="button"
          onClick={handleImageButtonClick}
          disabled={isVisionAnalyzing}
          className={`relative flex flex-col items-center justify-center w-16 py-1 rounded-2xl transition-all active:scale-95 group ${
            isVisionMenuOpen || isVisionAnalyzing
              ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-400/50 shadow-[0_0_15px_rgba(0,229,255,0.4)]'
              : selectedImage
              ? 'bg-cyan-950/60 text-cyan-300 border border-cyan-400/40 shadow-[0_0_12px_rgba(0,229,255,0.25)]'
              : 'text-slate-300 hover:text-cyan-300 hover:bg-cyan-500/10'
          }`}
          title={
            isVisionAnalyzing
              ? 'Scanning image with Gemini Vision...'
              : selectedImage
              ? 'Image attached (Tap for options)'
              : 'Image: Analyze & Understand'
          }
        >
          {isVisionAnalyzing ? (
            <Loader2 className="w-5 h-5 text-cyan-400 animate-spin pointer-events-none" />
          ) : (
            <ImageIcon className="w-5 h-5 text-cyan-400 group-hover:scale-110 transition-transform pointer-events-none" />
          )}
          {selectedImage && !isVisionAnalyzing && (
            <span className="absolute top-1 right-2 w-2 h-2 rounded-full bg-cyan-400 shadow-[0_0_6px_#00e5ff] animate-pulse pointer-events-none" />
          )}
          <span className="text-[10px] font-bold mt-1 text-slate-200 group-hover:text-cyan-300 pointer-events-none">
            {isVisionAnalyzing ? 'SCANNING' : 'IMAGE'}
          </span>
          <span className="text-[8px] text-slate-400 hidden sm:inline pointer-events-none">
            {isVisionAnalyzing ? 'AI Working' : 'Analyze'}
          </span>
        </button>

        {/* BUTTON 2: [ SCREEN ] */}
        {isScreenSharing ? (
          <button
            type="button"
            onClick={onStopScreenShare}
            className="flex flex-col items-center justify-center w-16 py-1 rounded-2xl bg-emerald-950/70 border border-emerald-400/60 shadow-[0_0_12px_rgba(16,185,129,0.3)] text-emerald-300 hover:bg-emerald-900/80 transition-all active:scale-95"
            title="Stop Screen Sharing"
          >
            <MonitorOff className="w-5 h-5 text-emerald-400 animate-pulse" />
            <span className="text-[10px] font-bold mt-1 text-emerald-300">
              STOP
            </span>
            <span className="text-[8px] text-emerald-400/80 hidden sm:inline">
              Sharing
            </span>
          </button>
        ) : (
          <button
            type="button"
            onClick={onToggleScreenShare}
            className="flex flex-col items-center justify-center w-16 py-1 rounded-2xl text-slate-300 hover:text-emerald-300 hover:bg-emerald-500/10 transition-all active:scale-95 group"
            title="Screen: Share & Get Insights"
          >
            <Monitor className="w-5 h-5 text-purple-400 group-hover:text-emerald-300 group-hover:scale-110 transition-transform" />
            <span className="text-[10px] font-bold mt-1 text-slate-200 group-hover:text-emerald-300">
              SCREEN
            </span>
            <span className="text-[8px] text-slate-400 hidden sm:inline">
              Insights
            </span>
          </button>
        )}

        {/* BUTTON 3 (CENTER): [ TAP TO TALK ] MIC CIRCLE */}
        <div className="relative flex items-center justify-center">
          <motion.button
            whileHover={{ scale: 1.06 }}
            whileTap={{ scale: 0.94 }}
            onClick={onMicClick}
            className="relative w-15 h-15 -mt-5 rounded-full flex flex-col items-center justify-center focus:outline-none transition-transform"
            style={{
              background: 'linear-gradient(135deg, #00e5ff 0%, #287bff 50%, #9b5cff 80%, #ff4fd8 100%)',
              padding: '2.5px',
              boxShadow: isVoiceActive
                ? '0 0 25px rgba(0, 229, 255, 0.7), 0 0 45px rgba(155, 92, 255, 0.5)'
                : '0 0 18px rgba(0, 229, 255, 0.45)',
            }}
            title={state === 'disconnected' ? 'Tap to Talk with Hinata' : 'Tap to Stop / Interrupt'}
          >
            <div className="w-full h-full rounded-full bg-gradient-to-b from-[#0f1d44] to-[#060917] flex items-center justify-center relative overflow-hidden">
              {isVoiceActive && (
                <span className="absolute inset-0 rounded-full border border-cyan-400 animate-ping pointer-events-none opacity-60" />
              )}
              {getMicIcon()}
            </div>
          </motion.button>
        </div>

        {/* BUTTON 4: [ DEVICE ] */}
        <button
          type="button"
          onClick={onOpenDeviceActions}
          className="flex flex-col items-center justify-center w-16 py-1 rounded-2xl text-slate-300 hover:text-purple-300 hover:bg-purple-500/10 transition-all active:scale-95 group"
          title="Device: Control Your Phone"
        >
          <Smartphone className="w-5 h-5 text-pink-400 group-hover:scale-110 transition-transform" />
          <span className="text-[10px] font-bold mt-1 text-slate-200 group-hover:text-purple-300">
            DEVICE
          </span>
          <span className="text-[8px] text-slate-400 hidden sm:inline">
            Control
          </span>
        </button>

        {/* BUTTON 5: [ MORE ] */}
        <button
          type="button"
          onClick={onOpenMore}
          className="flex flex-col items-center justify-center w-16 py-1 rounded-2xl text-slate-300 hover:text-cyan-300 hover:bg-cyan-500/10 transition-all active:scale-95 group"
          title="More: Settings & Tools"
        >
          <MoreHorizontal className="w-5 h-5 text-slate-400 group-hover:text-cyan-300 group-hover:scale-110 transition-transform" />
          <span className="text-[10px] font-bold mt-1 text-slate-200 group-hover:text-cyan-300">
            MORE
          </span>
          <span className="text-[8px] text-slate-400 hidden sm:inline">
            Tools
          </span>
        </button>
      </div>

      {/* 3. BOTTOM NAVIGATION BAR (Home, Chat, Memory, Tasks, Profile) */}
      <div className="w-full flex items-center justify-around py-1.5 px-3 rounded-2xl bg-[#060a1d]/85 backdrop-blur-xl border border-slate-800/80 shadow-md">
        {/* Home Tab */}
        <button
          onClick={() => onTabChange && onTabChange('home')}
          className={`flex flex-col items-center gap-0.5 text-xs font-medium transition-colors ${
            activeTab === 'home' ? 'text-cyan-400 font-semibold' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Home className="w-4 h-4" />
          <span className="text-[10px]">Home</span>
          {activeTab === 'home' && (
            <span className="w-1 h-1 rounded-full bg-cyan-400 shadow-[0_0_6px_#00e5ff]" />
          )}
        </button>

        {/* Chat Tab */}
        <button
          onClick={() => onTabChange && onTabChange('chat')}
          className={`flex flex-col items-center gap-0.5 text-xs font-medium transition-colors ${
            activeTab === 'chat' ? 'text-cyan-400 font-semibold' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <MessageSquare className="w-4 h-4" />
          <span className="text-[10px]">Chat</span>
          {activeTab === 'chat' && (
            <span className="w-1 h-1 rounded-full bg-cyan-400 shadow-[0_0_6px_#00e5ff]" />
          )}
        </button>

        {/* Work Hub Tab */}
        <button
          onClick={() => {
            if (onTabChange) onTabChange('work');
            if (onOpenWork) onOpenWork();
          }}
          className={`flex flex-col items-center gap-0.5 text-xs font-medium transition-colors ${
            activeTab === 'work' ? 'text-purple-400 font-semibold' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Briefcase className="w-4 h-4" />
          <span className="text-[10px]">Work</span>
          {activeTab === 'work' && (
            <span className="w-1 h-1 rounded-full bg-purple-400 shadow-[0_0_6px_#c084fc]" />
          )}
        </button>

        {/* Memory Tab */}
        <button
          onClick={() => {
            if (onTabChange) onTabChange('memory');
            onOpenMemory();
          }}
          className={`flex flex-col items-center gap-0.5 text-xs font-medium transition-colors ${
            activeTab === 'memory' ? 'text-cyan-400 font-semibold' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Brain className="w-4 h-4" />
          <span className="text-[10px]">Memory</span>
          {activeTab === 'memory' && (
            <span className="w-1 h-1 rounded-full bg-cyan-400 shadow-[0_0_6px_#00e5ff]" />
          )}
        </button>

        {/* Tasks Tab */}
        <button
          onClick={() => onOpenDeviceActions()}
          className="flex flex-col items-center gap-0.5 text-xs font-medium text-slate-400 hover:text-slate-200 transition-colors"
        >
          <CheckSquare className="w-4 h-4" />
          <span className="text-[10px]">Tasks</span>
        </button>

        {/* Profile Tab */}
        <button
          onClick={onOpenMore}
          className="flex flex-col items-center gap-0.5 text-xs font-medium text-slate-400 hover:text-slate-200 transition-colors"
        >
          <User className="w-4 h-4" />
          <span className="text-[10px]">Profile</span>
        </button>
      </div>
    </div>
  );
};
