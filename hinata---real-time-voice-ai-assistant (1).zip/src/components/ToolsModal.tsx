import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Wrench, Globe, Brain, Sparkles, CheckCircle2, Search, Calculator, Clock, Eye, Smartphone, ShieldAlert, ListOrdered } from 'lucide-react';
import { ToolCallItem } from '../types';

interface ToolsModalProps {
  isOpen: boolean;
  onClose: () => void;
  activeTools: ToolCallItem[];
  onOpenVision?: () => void;
  onOpenDeviceActions?: () => void;
}

export const ToolsModal: React.FC<ToolsModalProps> = ({
  isOpen,
  onClose,
  activeTools,
  onOpenVision,
  onOpenDeviceActions,
}) => {
  const registeredTools = [
    {
      name: 'executeDeviceAction',
      label: 'Android Device Controls & Apps',
      description: 'Launches apps (YouTube, WhatsApp, Camera, Gallery), opens system settings, sets alarms & navigates Maps.',
      icon: <Smartphone className="w-4 h-4 text-emerald-400" />,
      status: 'Active',
      action: onOpenDeviceActions,
    },
    {
      name: 'planMultiStepTask',
      label: 'Multi-Step Task Planner',
      description: 'Breaks down compound user commands into sequential, verified execution plans.',
      icon: <ListOrdered className="w-4 h-4 text-cyan-400" />,
      status: 'Active',
      action: onOpenDeviceActions,
    },
    {
      name: 'confirmSensitiveAction',
      label: 'Sensitive Action Verifier',
      description: 'Enforces explicit owner confirmation for phone calls, messages, and external communication.',
      icon: <ShieldAlert className="w-4 h-4 text-amber-400" />,
      status: 'Active',
      action: onOpenDeviceActions,
    },
    {
      name: 'visualDesignIntelligence',
      label: 'Visual Design Intelligence',
      description: 'Analyzes UI screenshots, palettes & layouts, transforms interface and saves design preferences.',
      icon: <Eye className="w-4 h-4 text-cyan-300" />,
      status: 'Active',
      action: onOpenVision,
    },
    {
      name: 'openWebsite',
      label: 'Open Browser Web Page',
      description: 'Navigates to external web resources, documents, or apps on command.',
      icon: <Globe className="w-4 h-4 text-cyan-400" />,
      status: 'Ready',
    },
    {
      name: 'rememberFact',
      label: 'Store Long-Term Memory',
      description: 'Persists user personal preferences, facts, and conversation context.',
      icon: <Brain className="w-4 h-4 text-purple-400" />,
      status: 'Active',
    },
    {
      name: 'recallFacts',
      label: 'Semantic Memory Retrieval',
      description: 'Recalls facts and contextual knowledge during live voice turns.',
      icon: <Search className="w-4 h-4 text-pink-400" />,
      status: 'Active',
    },
    {
      name: 'updateEmotionalState',
      label: 'Dynamic Emotion Engine',
      description: 'Adjusts Hinata’s internal emotional state across 21 nuanced moods.',
      icon: <Sparkles className="w-4 h-4 text-yellow-400" />,
      status: 'Active',
    },
    {
      name: 'calculateExpression',
      label: 'Arithmetic & Computation',
      description: 'Evaluates numeric calculations and financial expressions.',
      icon: <Calculator className="w-4 h-4 text-emerald-400" />,
      status: 'Ready',
    },
    {
      name: 'getCurrentTime',
      label: 'Chronological Time & Date',
      description: 'Retrieves current timezone-accurate date and time information.',
      icon: <Clock className="w-4 h-4 text-blue-400" />,
      status: 'Ready',
    },
  ];

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-md select-none">
          <motion.div
            initial={{ opacity: 0, scale: 0.94 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.94 }}
            className="w-full max-w-lg glass-panel rounded-3xl p-6 border border-white/15 shadow-[0_16px_50px_rgba(0,0,0,0.8)] relative overflow-hidden"
          >
            {/* Header */}
            <div className="flex items-center justify-between pb-4 border-b border-white/10 mb-4">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-cyan-500/20 border border-cyan-400/30 flex items-center justify-center text-cyan-400">
                  <Wrench className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white font-mono-tech">
                    Live Tools & Capabilities
                  </h3>
                  <p className="text-xs text-neutral-400">
                    Gemini Live Function Calling Modules
                  </p>
                </div>
              </div>
              <button
                onClick={onClose}
                className="w-8 h-8 rounded-full glass-button flex items-center justify-center text-neutral-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Recent Executions (if any) */}
            {activeTools.length > 0 && (
              <div className="mb-4">
                <span className="text-[11px] font-mono-tech text-cyan-400 uppercase tracking-wider block mb-2">
                  Recent Invocations
                </span>
                <div className="flex flex-col gap-2 max-h-32 overflow-y-auto pr-1">
                  {activeTools.map((t) => (
                    <div
                      key={t.id}
                      className="p-2.5 rounded-xl bg-white/5 border border-cyan-500/30 flex items-center justify-between text-xs"
                    >
                      <div className="flex items-center gap-2">
                        <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400" />
                        <span className="font-mono text-neutral-200">{t.name}</span>
                      </div>
                      <span className="text-[11px] text-neutral-400 font-mono">
                        {new Date(t.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Registered Capability List */}
            <div className="flex flex-col gap-2.5 max-h-[320px] overflow-y-auto pr-1">
              {registeredTools.map((tool, idx) => (
                <div
                  key={idx}
                  className="p-3 rounded-2xl bg-white/5 border border-white/8 hover:border-white/20 transition-colors flex items-start gap-3"
                >
                  <div className="p-2 rounded-xl bg-white/5 border border-white/10 flex-shrink-0 mt-0.5">
                    {tool.icon}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2">
                      <h4 className="text-xs font-semibold text-neutral-100 truncate">
                        {tool.label}
                      </h4>
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 font-mono-tech flex-shrink-0">
                        {tool.status}
                      </span>
                    </div>
                    <p className="text-[11px] text-neutral-400 mt-0.5 line-clamp-2">
                      {tool.description}
                    </p>
                    {tool.action && (
                      <button
                        onClick={() => {
                          onClose();
                          tool.action!();
                        }}
                        className="mt-2 px-3 py-1 rounded-lg bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 border border-cyan-400/40 text-[10px] font-bold flex items-center gap-1.5 transition-all shadow-[0_0_10px_rgba(0,229,255,0.2)]"
                      >
                        <Eye className="w-3 h-3 text-cyan-300" />
                        <span>Launch Visual Design Studio</span>
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>

            {/* Footer */}
            <div className="mt-4 pt-3 border-t border-white/10 flex justify-end">
              <button
                onClick={onClose}
                className="px-5 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white font-medium text-xs tracking-wider uppercase transition-colors"
              >
                Close
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
