import React from 'react';
import { motion } from 'motion/react';
import {
  Mic,
  Image as ImageIcon,
  Monitor,
  Smartphone,
  Sparkles,
  Heart,
  CheckCircle2,
  Camera,
  Compass,
  Globe,
  Settings,
  Bell,
  Clock,
  Grid,
  Shield,
  Eye,
  Smile,
  Volume2,
} from 'lucide-react';
import { EmotionalState, EmotionalIntensity } from '../types';

interface FeatureShowcaseProps {
  currentEmotion: EmotionalState;
  currentIntensity?: EmotionalIntensity;
  onSelectEmotion: (emotion: EmotionalState) => void;
  onSelectIntensity?: (intensity: EmotionalIntensity) => void;
  onPickImage: () => void;
  onToggleScreenShare: () => void;
  isScreenSharing: boolean;
  onOpenDeviceActions: () => void;
  onStartVoice: () => void;
  isVoiceActive: boolean;
}

const ALL_EMOTIONS: { state: EmotionalState; label: string; emoji: string; color: string }[] = [
  { state: 'idle', label: 'Idle', emoji: '✨', color: '#00e5ff' },
  { state: 'happy', label: 'Happy', emoji: '😊', color: '#00e5ff' },
  { state: 'excited', label: 'Excited', emoji: '😄', color: '#ff4fd8' },
  { state: 'curious', label: 'Curious', emoji: '🤔', color: '#38bdf8' },
  { state: 'thinking', label: 'Thinking', emoji: '🧐', color: '#c084fc' },
  { state: 'confused', label: 'Confused', emoji: '❓', color: '#38bdf8' },
  { state: 'surprised', label: 'Surprised', emoji: '😲', color: '#00e5ff' },
  { state: 'concerned', label: 'Concerned', emoji: '🥺', color: '#facc15' },
  { state: 'serious', label: 'Serious', emoji: '😐', color: '#0284c7' },
  { state: 'focused', label: 'Focused', emoji: '🎯', color: '#00e5ff' },
  { state: 'calm', label: 'Calm', emoji: '😌', color: '#34d399' },
  { state: 'sad', label: 'Sad', emoji: '😢', color: '#38bdf8' },
  { state: 'disappointed', label: 'Disappointed', emoji: '😞', color: '#64748b' },
  { state: 'laughing', label: 'Laughing', emoji: '😆', color: '#ff4fd8' },
  { state: 'proud', label: 'Proud', emoji: '😎', color: '#00e5ff' },
  { state: 'relieved', label: 'Relieved', emoji: '😌', color: '#34d399' },
  { state: 'worried', label: 'Worried', emoji: '😰', color: '#eab308' },
  { state: 'error', label: 'Error', emoji: '⚠️', color: '#ef4444' },
  { state: 'success', label: 'Success', emoji: '🎉', color: '#10b981' },
];

export const FeatureShowcase: React.FC<FeatureShowcaseProps> = ({
  currentEmotion,
  currentIntensity = 2,
  onSelectEmotion,
  onSelectIntensity,
  onPickImage,
  onToggleScreenShare,
  isScreenSharing,
  onOpenDeviceActions,
  onStartVoice,
  isVoiceActive,
}) => {
  return (
    <div className="w-full max-w-5xl mx-auto px-4 py-8 space-y-10 text-slate-100 select-none">
      {/* SECTION HEADER */}
      <div className="text-center space-y-2">
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-cyan-950/60 border border-cyan-400/30 text-cyan-300 text-xs font-semibold tracking-wider uppercase backdrop-blur-md">
          <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
          <span>Interactive Feature Showcase</span>
        </div>
        <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-white">
          Everything Hinata Can Do
        </h2>
        <p className="text-sm text-slate-400 max-w-xl mx-auto">
          Voice-first intelligence, multimodal computer vision, screen understanding, real-time emotion engine, and device automation.
        </p>
      </div>

      {/* 2x2 GRID OF CORE FEATURES (Voice, Image, Screen, Device) */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* 1. VOICE CONVERSATION CARD */}
        <div className="p-5 rounded-3xl bg-[#080d24]/90 border border-cyan-500/30 backdrop-blur-xl shadow-[0_8px_30px_rgba(0,0,0,0.5)] flex flex-col justify-between relative overflow-hidden group hover:border-cyan-400/60 transition-all">
          <div className="absolute top-0 right-0 w-48 h-48 bg-cyan-500/10 rounded-full filter blur-3xl pointer-events-none" />

          <div>
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-2xl bg-cyan-500/20 border border-cyan-400/40 flex items-center justify-center text-cyan-300">
                  <Mic className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white">Voice Conversation</h3>
                  <p className="text-xs text-cyan-300/80">Natural • Emotional • Human-like</p>
                </div>
              </div>
              <button
                onClick={onStartVoice}
                className={`px-3 py-1 rounded-full text-xs font-semibold transition-all ${
                  isVoiceActive
                    ? 'bg-cyan-500 text-slate-950 shadow-[0_0_12px_#00e5ff]'
                    : 'bg-cyan-500/20 text-cyan-300 hover:bg-cyan-500/30'
                }`}
              >
                {isVoiceActive ? 'Active Live' : 'Start Talking'}
              </button>
            </div>

            {/* Conversation Preview Bubbles */}
            <div className="space-y-2.5 my-3 p-3 rounded-2xl bg-[#040614]/80 border border-slate-800">
              {/* User Bubble */}
              <div className="flex items-start justify-end gap-2">
                <div className="px-3 py-1.5 rounded-2xl rounded-tr-sm bg-blue-600/30 border border-blue-500/30 text-xs text-blue-100 max-w-[85%]">
                  "Hi Hinata, how are you?"
                </div>
                <div className="w-6 h-6 rounded-full bg-blue-500/20 text-[10px] font-bold text-blue-300 flex items-center justify-center flex-shrink-0">
                  YOU
                </div>
              </div>

              {/* Hinata Bubble */}
              <div className="flex items-start gap-2">
                <div className="w-6 h-6 rounded-full bg-cyan-500/20 border border-cyan-400/40 text-[10px] font-bold text-cyan-300 flex items-center justify-center flex-shrink-0">
                  H
                </div>
                <div className="px-3 py-2 rounded-2xl rounded-tl-sm bg-[#09102c] border border-cyan-500/30 text-xs text-cyan-100 max-w-[85%]">
                  <p>I'm great! 💖 I'm always happy to talk with you. How about you? What can I do for you today?</p>
                  <div className="flex items-center gap-1.5 mt-1.5 text-[10px] text-cyan-400">
                    <Volume2 className="w-3 h-3 animate-pulse" />
                    <span>Hinata Voice • Speaking</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="flex items-center justify-between text-xs text-slate-400 pt-2 border-t border-slate-800/80">
            <span className="flex items-center gap-1"><CheckCircle2 className="w-3.5 h-3.5 text-cyan-400" /> Real-time speech</span>
            <span className="flex items-center gap-1"><CheckCircle2 className="w-3.5 h-3.5 text-purple-400" /> Emotion-based voice</span>
            <span className="flex items-center gap-1"><CheckCircle2 className="w-3.5 h-3.5 text-pink-400" /> Natural flow</span>
          </div>
        </div>

        {/* 2. IMAGE ANALYSIS CARD */}
        <div className="p-5 rounded-3xl bg-[#080d24]/90 border border-blue-500/30 backdrop-blur-xl shadow-[0_8px_30px_rgba(0,0,0,0.5)] flex flex-col justify-between relative overflow-hidden group hover:border-blue-400/60 transition-all">
          <div className="absolute top-0 right-0 w-48 h-48 bg-blue-500/10 rounded-full filter blur-3xl pointer-events-none" />

          <div>
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-2xl bg-blue-500/20 border border-blue-400/40 flex items-center justify-center text-blue-300">
                  <ImageIcon className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white">Image Analysis</h3>
                  <p className="text-xs text-blue-300/80">Select • Analyze • Get Results</p>
                </div>
              </div>
              <button
                onClick={onPickImage}
                className="px-3 py-1 rounded-full text-xs font-semibold bg-blue-500/20 text-blue-300 hover:bg-blue-500/30 border border-blue-500/40 transition-all"
              >
                Upload / Pick
              </button>
            </div>

            {/* Image Preview & Hinata's Analysis */}
            <div className="space-y-2.5 my-3 p-3 rounded-2xl bg-[#040614]/80 border border-slate-800">
              <div className="flex items-center gap-3">
                <div className="w-16 h-12 rounded-xl overflow-hidden bg-slate-800 border border-cyan-400/40 relative flex-shrink-0">
                  <img
                    src="https://images.unsplash.com/photo-1506744038136-46273834b3fb?w=150&auto=format&fit=crop&q=80"
                    alt="Mountain Landscape"
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute bottom-0 inset-x-0 bg-black/60 text-[8px] text-center text-cyan-200 py-0.5">
                    Mountain
                  </div>
                </div>
                <div className="flex-1 text-xs text-slate-300 leading-relaxed">
                  <span className="font-semibold text-cyan-300">Hinata: </span>
                  "This looks like a beautiful mountain landscape. The sky is clear, there are snowy peaks, and a lake in the foreground..."
                </div>
              </div>
            </div>
          </div>

          <div className="pt-2 border-t border-slate-800/80">
            <div className="flex flex-wrap gap-1.5 text-[10px] text-slate-300">
              <span className="px-2 py-0.5 rounded-md bg-slate-800/70 border border-slate-700">✓ Objects</span>
              <span className="px-2 py-0.5 rounded-md bg-slate-800/70 border border-slate-700">✓ Text</span>
              <span className="px-2 py-0.5 rounded-md bg-slate-800/70 border border-slate-700">✓ Scenes</span>
              <span className="px-2 py-0.5 rounded-md bg-slate-800/70 border border-slate-700">✓ Documents</span>
              <span className="px-2 py-0.5 rounded-md bg-slate-800/70 border border-slate-700">✓ OCR</span>
            </div>
          </div>
        </div>

        {/* 3. SCREEN SHARING CARD */}
        <div className="p-5 rounded-3xl bg-[#080d24]/90 border border-emerald-500/30 backdrop-blur-xl shadow-[0_8px_30px_rgba(0,0,0,0.5)] flex flex-col justify-between relative overflow-hidden group hover:border-emerald-400/60 transition-all">
          <div className="absolute top-0 right-0 w-48 h-48 bg-emerald-500/10 rounded-full filter blur-3xl pointer-events-none" />

          <div>
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-2xl bg-emerald-500/20 border border-emerald-400/40 flex items-center justify-center text-emerald-300">
                  <Monitor className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white">Screen Sharing</h3>
                  <p className="text-xs text-emerald-300/80">Share Your Screen • Get Insights</p>
                </div>
              </div>
              <button
                onClick={onToggleScreenShare}
                className={`px-3 py-1 rounded-full text-xs font-semibold transition-all ${
                  isScreenSharing
                    ? 'bg-rose-500 text-white shadow-[0_0_12px_#f43f5e]'
                    : 'bg-emerald-500/20 text-emerald-300 hover:bg-emerald-500/30 border border-emerald-500/40'
                }`}
              >
                {isScreenSharing ? 'STOP' : 'SHARE SCREEN'}
              </button>
            </div>

            {/* Screen State Indicator */}
            <div className="my-3 p-3 rounded-2xl bg-[#040614]/80 border border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className={`w-2.5 h-2.5 rounded-full ${isScreenSharing ? 'bg-emerald-400 animate-ping' : 'bg-slate-600'}`} />
                <span className="text-xs font-semibold text-slate-200">
                  {isScreenSharing ? 'SCREEN SHARING ON' : 'Ready to Project'}
                </span>
              </div>
              <span className="text-[11px] text-slate-400">AI Vision Analyzing</span>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed mb-3">
              Hinata can see and analyze your screen in real-time, helping you debug, navigate apps, or read articles.
            </p>
          </div>

          <div className="flex items-center justify-between text-xs text-slate-400 pt-2 border-t border-slate-800/80">
            <span className="flex items-center gap-1"><CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> Permission gated</span>
            <span className="flex items-center gap-1"><CheckCircle2 className="w-3.5 h-3.5 text-cyan-400" /> Secure & private</span>
            <span className="flex items-center gap-1"><CheckCircle2 className="w-3.5 h-3.5 text-purple-400" /> Real-time help</span>
          </div>
        </div>

        {/* 4. DEVICE ACTIONS CARD */}
        <div className="p-5 rounded-3xl bg-[#080d24]/90 border border-purple-500/30 backdrop-blur-xl shadow-[0_8px_30px_rgba(0,0,0,0.5)] flex flex-col justify-between relative overflow-hidden group hover:border-purple-400/60 transition-all">
          <div className="absolute top-0 right-0 w-48 h-48 bg-purple-500/10 rounded-full filter blur-3xl pointer-events-none" />

          <div>
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-2xl bg-purple-500/20 border border-purple-400/40 flex items-center justify-center text-purple-300">
                  <Smartphone className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white">Device Actions</h3>
                  <p className="text-xs text-purple-300/80">Control Your Phone (With Permission)</p>
                </div>
              </div>
              <button
                onClick={onOpenDeviceActions}
                className="px-3 py-1 rounded-full text-xs font-semibold bg-purple-500/20 text-purple-300 hover:bg-purple-500/30 border border-purple-500/40 transition-all"
              >
                Control Hub
              </button>
            </div>

            {/* 3x3 Grid of Interactive Device Actions */}
            <div className="grid grid-cols-3 gap-2 my-2">
              <button onClick={onOpenDeviceActions} className="p-2 rounded-xl bg-slate-900/80 hover:bg-purple-950/60 border border-slate-800 flex flex-col items-center gap-1 transition-all">
                <Grid className="w-4 h-4 text-purple-400" />
                <span className="text-[10px] text-slate-300">Open Apps</span>
              </button>
              <button onClick={onOpenDeviceActions} className="p-2 rounded-xl bg-slate-900/80 hover:bg-cyan-950/60 border border-slate-800 flex flex-col items-center gap-1 transition-all">
                <Camera className="w-4 h-4 text-cyan-400" />
                <span className="text-[10px] text-slate-300">Camera</span>
              </button>
              <button onClick={onOpenDeviceActions} className="p-2 rounded-xl bg-slate-900/80 hover:bg-pink-950/60 border border-slate-800 flex flex-col items-center gap-1 transition-all">
                <ImageIcon className="w-4 h-4 text-pink-400" />
                <span className="text-[10px] text-slate-300">Gallery</span>
              </button>
              <button onClick={onOpenDeviceActions} className="p-2 rounded-xl bg-slate-900/80 hover:bg-blue-950/60 border border-slate-800 flex flex-col items-center gap-1 transition-all">
                <Compass className="w-4 h-4 text-blue-400" />
                <span className="text-[10px] text-slate-300">Maps</span>
              </button>
              <button onClick={onOpenDeviceActions} className="p-2 rounded-xl bg-slate-900/80 hover:bg-amber-950/60 border border-slate-800 flex flex-col items-center gap-1 transition-all">
                <Globe className="w-4 h-4 text-amber-400" />
                <span className="text-[10px] text-slate-300">Chrome</span>
              </button>
              <button onClick={onOpenDeviceActions} className="p-2 rounded-xl bg-slate-900/80 hover:bg-emerald-950/60 border border-slate-800 flex flex-col items-center gap-1 transition-all">
                <Settings className="w-4 h-4 text-emerald-400" />
                <span className="text-[10px] text-slate-300">Settings</span>
              </button>
            </div>
          </div>

          <div className="flex items-center justify-between text-[11px] text-slate-400 pt-2 border-t border-slate-800/80">
            <span>Uses Android APIs & Intents</span>
            <span className="text-purple-300">With your permission ✓</span>
          </div>
        </div>
      </div>

      {/* ALL EMOTIONS INTERACTIVE GALLERY (Directly from Reference Image) */}
      <div className="p-6 rounded-3xl bg-[#080d24]/90 border border-cyan-500/30 backdrop-blur-xl shadow-[0_10px_35px_rgba(0,0,0,0.6)] space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-cyan-500/20 border border-cyan-400/40 flex items-center justify-center text-cyan-300">
              <Smile className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-white">ALL EMOTIONS</h3>
              <p className="text-xs text-cyan-300/80">Every Emotion • Real Expression</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-400">Intensity:</span>
            {([1, 2, 3, 4, 5] as EmotionalIntensity[]).map((lvl) => (
              <button
                key={lvl}
                onClick={() => onSelectIntensity?.(lvl)}
                className={`px-2.5 py-0.5 rounded-lg text-xs font-semibold border transition-all ${
                  currentIntensity === lvl
                    ? 'bg-cyan-500/30 border-cyan-400 text-cyan-200'
                    : 'bg-slate-900 border-slate-700 text-slate-400 hover:text-white'
                }`}
              >
                {lvl === 1 ? 'Subtle (1)' : lvl === 3 ? 'Medium (3)' : lvl === 5 ? 'Max (5)' : `${lvl}`}
              </button>
            ))}
          </div>
        </div>

        {/* 19 Expressive Emotion Buttons */}
        <div className="grid grid-cols-3 sm:grid-cols-6 lg:grid-cols-10 gap-2.5 pt-2">
          {ALL_EMOTIONS.map((e) => {
            const isSelected = currentEmotion === e.state;
            return (
              <motion.button
                key={e.state}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => onSelectEmotion(e.state)}
                className={`p-2.5 rounded-2xl border flex flex-col items-center justify-center gap-1 transition-all ${
                  isSelected
                    ? 'bg-cyan-500/25 border-cyan-400 shadow-[0_0_15px_rgba(0,229,255,0.4)] text-white'
                    : 'bg-[#040614]/80 border-slate-800 hover:border-slate-700 text-slate-300'
                }`}
              >
                <span className="text-xl leading-none">{e.emoji}</span>
                <span className="text-[11px] font-medium tracking-tight truncate w-full text-center">
                  {e.label}
                </span>
                {isSelected && (
                  <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-ping" />
                )}
              </motion.button>
            );
          })}
        </div>
      </div>

      {/* REAL-TIME TALKING TIMELINE WORKFLOW STRIP */}
      <div className="p-4 rounded-2xl bg-[#080d24]/70 border border-slate-800 text-xs flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2 text-cyan-300 font-semibold">
          <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
          <span>Real-time Talking:</span>
        </div>
        <div className="flex items-center gap-2 text-slate-400">
          <span className="text-slate-200">Listening</span> (You talk...) →
          <span className="text-slate-200">Processing</span> (Thinking...) →
          <span className="text-slate-200">Speaking</span> (Natural Voice) →
          <span className="text-pink-300">Emotional</span> (Happy) →
          <span className="text-cyan-300">Laughing</span> (With you) →
          <span className="text-slate-400">Back to Idle</span>
        </div>
      </div>

      {/* FOOTER SIGNATURE */}
      <div className="text-center pt-4 pb-2 text-xs text-slate-500 space-y-1">
        <p className="font-semibold text-slate-400 tracking-wider">
          ✦ Hinata ✦ Smart • Kind • Always With You
        </p>
        <p className="italic font-serif text-cyan-400/80">
          Your Personal AI Companion ♡
        </p>
      </div>
    </div>
  );
};
