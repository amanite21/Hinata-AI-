import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Server,
  Wifi,
  WifiOff,
  AlertTriangle,
  CheckCircle2,
  AlertCircle,
  RefreshCw,
  SlidersHorizontal,
  X,
  ShieldCheck,
  Globe,
  Loader2,
  ExternalLink,
  Info,
} from 'lucide-react';
import {
  backendConfig,
  BackendStatusType,
  BackendState,
  BackendHealthResult,
} from '../config/backendConfig';

interface BackendStatusModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenSettings?: () => void;
}

export const BackendStatusModal: React.FC<BackendStatusModalProps> = ({
  isOpen,
  onClose,
  onOpenSettings,
}) => {
  const [status, setStatus] = useState<BackendStatusType>(() => backendConfig.getStatus());
  const [backendState, setBackendState] = useState<BackendState>(() => backendConfig.getBackendState());
  const [backendUrl, setBackendUrl] = useState<string>(() => backendConfig.getBackendUrl());
  const [isConfigured, setIsConfigured] = useState<boolean>(() => backendConfig.isConfigured());
  const [healthResult, setHealthResult] = useState<BackendHealthResult | null>(() =>
    backendConfig.getLastHealthResult()
  );
  const [testing, setTesting] = useState<boolean>(false);
  const [customInputUrl, setCustomInputUrl] = useState<string>(() => backendConfig.getBackendUrl());
  const [showUrlEdit, setShowUrlEdit] = useState<boolean>(false);

  const syncState = () => {
    setStatus(backendConfig.getStatus());
    setBackendState(backendConfig.getBackendState());
    setBackendUrl(backendConfig.getBackendUrl());
    setIsConfigured(backendConfig.isConfigured());
    setHealthResult(backendConfig.getLastHealthResult());
  };

  useEffect(() => {
    syncState();
    const unsub = backendConfig.subscribe(syncState);
    return unsub;
  }, []);

  // Run a quick check when opened if a URL is configured and no test has been run recently
  useEffect(() => {
    if (isOpen && backendConfig.isConfigured() && !healthResult) {
      handleTestConnection();
    }
  }, [isOpen]);

  const handleTestConnection = async () => {
    setTesting(true);
    try {
      const result = await backendConfig.checkBackendHealth();
      setHealthResult(result);
      setStatus(backendConfig.getStatus());
    } finally {
      setTesting(false);
    }
  };

  const handleSaveCustomUrl = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    backendConfig.setBackendUrl(customInputUrl.trim() || null);
    syncState();
    setShowUrlEdit(false);
    if (customInputUrl.trim()) {
      handleTestConnection();
    }
  };

  const handleUseCurrentOrigin = () => {
    if (typeof window !== 'undefined' && window.location?.origin) {
      backendConfig.useCurrentWebPreviewHost();
      setCustomInputUrl(window.location.origin);
      syncState();
      handleTestConnection();
    }
  };

  const handleClearUrl = () => {
    backendConfig.clearCustomBackendUrl();
    setCustomInputUrl('');
    syncState();
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 15 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 15 }}
          transition={{ duration: 0.2 }}
          className="relative w-full max-w-lg rounded-3xl bg-[#060a1d] border border-cyan-500/30 shadow-[0_0_40px_rgba(0,229,255,0.18)] text-slate-100 overflow-hidden flex flex-col max-h-[90vh]"
        >
          {/* Header */}
          <div className="p-5 border-b border-white/10 flex items-center justify-between bg-gradient-to-r from-slate-900/90 to-[#070e28]/90">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-cyan-950/80 border border-cyan-400/40 flex items-center justify-center text-cyan-300 shadow-[0_0_10px_rgba(0,229,255,0.2)]">
                <Server className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-base font-bold text-white tracking-wide flex items-center gap-1.5">
                  <span>Backend Status</span>
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-cyan-950/80 border border-cyan-500/40 text-cyan-300 font-mono">
                    System Architecture
                  </span>
                </h2>
                <p className="text-[11px] text-slate-400">
                  Production Cloud Connection & Status
                </p>
              </div>
            </div>

            <button
              onClick={onClose}
              className="w-8 h-8 rounded-full bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white flex items-center justify-center transition-all"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Body Content */}
          <div className="p-5 overflow-y-auto space-y-4 text-xs">
            {/* 1. PRIMARY STATUS BANNER */}
            {status === 'connected' && (
              <div className="p-4 rounded-2xl bg-emerald-950/40 border border-emerald-500/50 shadow-[0_0_20px_rgba(16,185,129,0.15)] flex flex-col gap-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-emerald-400 font-bold text-sm">
                    <CheckCircle2 className="w-5 h-5" />
                    <div className="flex flex-col">
                      <span className="text-[11px] uppercase tracking-wider text-emerald-500/80 font-mono">Backend Status</span>
                      <span className="text-base font-extrabold text-emerald-300">CONNECTED</span>
                    </div>
                  </div>
                  <span className="px-2.5 py-0.5 rounded-full bg-emerald-900/60 border border-emerald-400/40 text-emerald-300 font-mono text-[10px] font-bold">
                    ONLINE • {healthResult?.latencyMs ?? 0}ms
                  </span>
                </div>
                <div className="text-slate-300 text-xs space-y-1">
                  <p className="font-semibold text-emerald-200">
                    Backend: {backendConfig.getBackendDisplayName()}
                  </p>
                  <p className="text-[11px] text-slate-300">
                    Direct same-origin connection to the project server. Full-duplex Gemini Live voice, streaming AI chat, and cloud memory synchronization are active.
                  </p>
                </div>
              </div>
            )}

            {status === 'not_configured' && (
              <div className="p-4 rounded-2xl bg-amber-950/40 border border-amber-500/40 shadow-[0_0_20px_rgba(245,158,11,0.15)] flex flex-col gap-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-amber-300 font-bold text-sm">
                    <AlertTriangle className="w-5 h-5 text-amber-400" />
                    <div className="flex flex-col">
                      <span className="text-[11px] uppercase tracking-wider text-amber-500/80 font-mono">Backend</span>
                      <span className="text-base font-extrabold text-amber-200">Connecting to AI Studio Server</span>
                    </div>
                  </div>
                  <span className="px-2.5 py-0.5 rounded-full bg-cyan-950/80 border border-cyan-400/40 text-cyan-300 font-mono text-[10px] font-bold">
                    AI Studio Server
                  </span>
                </div>
                <div className="space-y-1.5 text-slate-300 text-xs leading-relaxed">
                  <p className="text-slate-300">
                    Connecting to the internal project server...
                  </p>
                </div>
                <div className="flex items-center gap-2 pt-1">
                  <button
                    onClick={handleTestConnection}
                    disabled={testing}
                    className="px-3.5 py-1.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs flex items-center gap-1.5 transition-all"
                  >
                    {testing ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <RefreshCw className="w-3.5 h-3.5" />}
                    <span>Test Connection</span>
                  </button>
                </div>
              </div>
            )}

            {status === 'connection_failed' && (
              <div className="p-4 rounded-2xl bg-rose-950/40 border border-rose-500/50 shadow-[0_0_20px_rgba(244,63,94,0.15)] flex flex-col gap-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-rose-400 font-bold text-sm">
                    <AlertCircle className="w-5 h-5" />
                    <div className="flex flex-col">
                      <span className="text-[11px] uppercase tracking-wider text-rose-500/80 font-mono">Backend</span>
                      <span className="text-base font-extrabold text-rose-300">Connection Failed</span>
                    </div>
                  </div>
                  <span className="px-2.5 py-0.5 rounded-full bg-rose-900/60 border border-rose-400/40 text-rose-300 font-mono text-[10px] font-bold">
                    OFFLINE
                  </span>
                </div>
                <p className="text-slate-300 text-xs">
                  Could not reach server: <span className="text-rose-300 font-medium">{healthResult?.error || 'Connection unavailable.'}</span>
                </p>
                <div className="flex items-center gap-2 pt-1">
                  <button
                    onClick={handleClearUrl}
                    className="px-3.5 py-1.5 rounded-xl bg-cyan-500/20 hover:bg-cyan-500/30 border border-cyan-400/50 text-cyan-200 font-semibold text-xs flex items-center gap-1.5 transition-all"
                  >
                    <Globe className="w-3.5 h-3.5 text-cyan-400" />
                    <span>Reset to AI Studio Server</span>
                  </button>
                  <button
                    onClick={handleTestConnection}
                    disabled={testing}
                    className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs border border-white/10 flex items-center gap-1.5 transition-all"
                  >
                    {testing ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <RefreshCw className="w-3.5 h-3.5 text-cyan-400" />}
                    <span>Retry Connection</span>
                  </button>
                </div>
              </div>
            )}

            {/* 2. TEST CONNECTION & ACTIONS */}
            <div className="p-4 rounded-2xl bg-[#09102b] border border-cyan-500/20 flex flex-col gap-3">
              <div className="flex items-center justify-between">
                <span className="font-semibold text-slate-200">Diagnostics & Controls</span>
                <span className="text-[10px] text-slate-400">Endpoint: GET /health</span>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <button
                  onClick={handleTestConnection}
                  disabled={testing}
                  className="px-4 py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 disabled:opacity-60 text-slate-950 font-bold text-xs shadow-[0_0_14px_rgba(0,229,255,0.3)] flex items-center gap-2 transition-all active:scale-95"
                >
                  {testing ? (
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  ) : (
                    <RefreshCw className="w-3.5 h-3.5" />
                  )}
                  <span>Test Connection</span>
                </button>

                <button
                  onClick={() => setShowUrlEdit(!showUrlEdit)}
                  className="px-3 py-2 rounded-xl bg-cyan-950/60 hover:bg-cyan-900/60 text-cyan-200 text-xs border border-cyan-500/40 flex items-center gap-1.5 transition-all"
                >
                  <Globe className="w-3.5 h-3.5 text-cyan-400" />
                  <span>{showUrlEdit ? 'Hide Configuration' : 'Configure Backend'}</span>
                </button>

                {onOpenSettings && (
                  <button
                    onClick={() => {
                      onClose();
                      onOpenSettings();
                    }}
                    className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs border border-white/10 flex items-center gap-1.5 transition-all"
                  >
                    <SlidersHorizontal className="w-3.5 h-3.5 text-cyan-400" />
                    <span>Open Settings</span>
                  </button>
                )}
              </div>

              {/* Optional URL Config Panel */}
              {showUrlEdit && (
                <div className="pt-3 border-t border-white/10 flex flex-col gap-2 animate-fadeIn">
                  <label className="text-[11px] font-semibold text-slate-300">
                    Backend Base URL (Optional Override):
                  </label>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={customInputUrl}
                      onChange={(e) => setCustomInputUrl(e.target.value)}
                      placeholder="Same-origin AI Studio Server (Default)"
                      className="flex-1 px-3 py-2 rounded-xl bg-black/60 border border-white/15 text-white text-xs font-mono focus:outline-none focus:border-cyan-400"
                    />
                    <button
                      type="button"
                      onClick={() => handleSaveCustomUrl()}
                      className="px-3 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs"
                    >
                      Save
                    </button>
                  </div>

                  <div className="flex items-center gap-2 pt-1 text-[10px]">
                    {typeof window !== 'undefined' && window.location?.origin && (
                      <button
                        type="button"
                        onClick={handleUseCurrentOrigin}
                        className="text-cyan-400 hover:underline flex items-center gap-1"
                      >
                        Use current web origin for preview
                      </button>
                    )}
                    {backendConfig.isCustomUrlActive() && (
                      <>
                        <span className="text-slate-600">•</span>
                        <button
                          type="button"
                          onClick={handleClearUrl}
                          className="text-rose-400 hover:underline"
                        >
                          Clear custom URL
                        </button>
                      </>
                    )}
                  </div>
                </div>
              )}
            </div>

            {/* 3. CURRENT CONNECTION DETAILS */}
            <div className="p-3.5 rounded-2xl bg-black/40 border border-white/10 space-y-2 font-mono text-[11px]">
              <div className="flex items-center justify-between text-slate-400">
                <span>Active Target</span>
                <span className="text-slate-200">
                  <span className="text-cyan-300">{backendConfig.getBackendDisplayName()}</span>
                </span>
              </div>
              <div className="flex items-center justify-between text-slate-400">
                <span>API Route Type</span>
                <span className="text-emerald-300">
                  {backendConfig.isUsingAiStudioServer() ? 'Same-Origin (/api/*, /health)' : 'External Override'}
                </span>
              </div>
              <div className="flex items-center justify-between text-slate-400">
                <span>WebSocket Target</span>
                <span className="text-slate-200">
                  {backendConfig.getWsBackendUrl() ? (
                    <span className="text-purple-300">{backendConfig.getWsBackendUrl()}/api/live</span>
                  ) : (
                    <span className="text-slate-500 italic">(none)</span>
                  )}
                </span>
              </div>
              <div className="flex items-center justify-between text-slate-400">
                <span>Backend Status</span>
                <span className={`font-mono font-semibold ${
                  backendState === 'BACKEND_CONNECTED'
                    ? 'text-emerald-300'
                    : backendState === 'BACKEND_NOT_CONFIGURED'
                    ? 'text-amber-300'
                    : 'text-rose-300'
                }`}>
                  {backendState === 'BACKEND_CONNECTED' ? 'CONNECTED ✓' : backendState}
                </span>
              </div>
              <div className="flex items-center justify-between text-slate-400">
                <span>Device ID</span>
                <span className="text-slate-300 truncate max-w-[200px]">
                  {backendConfig.getDeviceId()}
                </span>
              </div>
            </div>

            {/* 4. SECURITY & ARCHITECTURE GUARANTEE */}
            <div className="p-3 rounded-2xl bg-[#09112e]/60 border border-cyan-500/20 flex items-start gap-2.5 text-[11px] text-slate-400">
              <ShieldCheck className="w-4 h-4 text-emerald-400 flex-shrink-0 mt-0.5" />
              <div>
                <span className="font-semibold text-slate-200">Server-Side Secret Architecture: </span>
                <span>The Gemini API key is managed strictly on the server. Neither the browser frontend nor Android APK builds contain any API keys.</span>
              </div>
            </div>
          </div>

          {/* Footer */}
          <div className="p-4 border-t border-white/10 bg-slate-900/60 flex items-center justify-between">
            <span className="text-[11px] text-slate-400">
              Status: <strong className={status === 'connected' ? 'text-emerald-400' : status === 'not_configured' ? 'text-amber-400' : 'text-rose-400'}>{status.toUpperCase()}</strong>
            </span>
            <button
              onClick={onClose}
              className="px-4 py-1.5 rounded-xl bg-white/10 hover:bg-white/15 text-white font-semibold text-xs transition-all"
            >
              Close
            </button>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
