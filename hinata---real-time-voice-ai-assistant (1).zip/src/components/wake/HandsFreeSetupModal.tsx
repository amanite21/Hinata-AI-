import React, { useState, useEffect } from 'react';
import {
  X,
  Mic,
  Sliders,
  ShieldCheck,
  Smartphone,
  CheckCircle2,
  AlertCircle,
  Play,
  Volume2,
  Radio,
  Sparkles,
  ArrowRight,
  Battery,
  HelpCircle,
} from 'lucide-react';
import { WakeWordManager } from '../../modules/wake/WakeWordManager';
import { WakeWordDetector } from '../../modules/wake/WakeWordDetector';
import { VoiceInteractionService } from '../../modules/voice/VoiceInteractionService';
import { PermissionManager } from '../../modules/device/PermissionManager';
import { WakeWordState, WakeSensitivity, WakeWordConfig } from '../../modules/wake/types';

interface HandsFreeSetupModalProps {
  isOpen: boolean;
  onClose: () => void;
  onTestTrigger?: () => void;
}

export const HandsFreeSetupModal: React.FC<HandsFreeSetupModalProps> = ({
  isOpen,
  onClose,
  onTestTrigger,
}) => {
  const wakeManager = WakeWordManager.getInstance();
  const wakeDetector = WakeWordDetector.getInstance();
  const voiceService = VoiceInteractionService.getInstance();
  const permManager = PermissionManager.getInstance();

  const [activeStep, setActiveStep] = useState<number>(1);
  const [config, setConfig] = useState<WakeWordConfig>(() => wakeManager.getConfig());
  const [currentState, setCurrentState] = useState<WakeWordState>(() => wakeManager.getState());
  const [micPermissionGranted, setMicPermissionGranted] = useState<boolean>(false);
  const [isDefaultAssistant, setIsDefaultAssistant] = useState<boolean>(() =>
    voiceService.getStatus().isDefaultAssistant
  );
  const [acousticLevel, setAcousticLevel] = useState<number>(0);
  const [testResult, setTestResult] = useState<string | null>(null);
  const [isTesting, setIsTesting] = useState<boolean>(false);

  // Subscribe to wake word manager state
  useEffect(() => {
    const unsubState = wakeManager.onStateChange((state) => {
      setCurrentState(state);
      if (state === 'WAKE_DETECTED' || state === 'LISTENING') {
        setTestResult('✦ Wake word detected! Hinata is ready to listen.');
      }
    });

    const unsubLevel = wakeDetector.onAcousticLevel((level) => {
      setAcousticLevel(level);
    });

    const unsubVoice = voiceService.addStatusListener((status) => {
      setIsDefaultAssistant(status.isDefaultAssistant);
    });

    // Check mic permission
    permManager.checkPermission('microphone').then((st) => {
      setMicPermissionGranted(st === 'granted');
    });

    return () => {
      unsubState();
      unsubLevel();
      unsubVoice();
    };
  }, []);

  if (!isOpen) return null;

  const handleRequestMic = async () => {
    const res = await permManager.requestPermission('microphone');
    setMicPermissionGranted(res.granted);
    if (res.granted) {
      wakeManager.startWakeWordMonitoring();
      setActiveStep(2);
    }
  };

  const handleToggleHandsFree = async (enabled: boolean) => {
    wakeManager.saveConfig({ enabled });
    setConfig(wakeManager.getConfig());
    if (enabled) {
      await wakeManager.enableHandsFree();
      voiceService.startForegroundService();
    } else {
      wakeManager.disableHandsFree();
      voiceService.stopForegroundService();
    }
  };

  const handleUpdatePhrase = (phrase: string) => {
    wakeManager.saveConfig({ phrase });
    setConfig(wakeManager.getConfig());
  };

  const handleUpdateSensitivity = (sensitivity: WakeSensitivity) => {
    wakeManager.saveConfig({ sensitivity });
    setConfig(wakeManager.getConfig());
  };

  const handleUpdateTimeout = (autoListenTimeoutMs: number) => {
    wakeManager.saveConfig({ autoListenTimeoutMs });
    setConfig(wakeManager.getConfig());
  };

  const handleToggleVoiceResponse = (voiceResponse: boolean) => {
    wakeManager.saveConfig({ voiceResponse });
    setConfig(wakeManager.getConfig());
  };

  const handleRunWakeTest = () => {
    setIsTesting(true);
    setTestResult('Say "Hey Hinata" now into your microphone...');
    wakeDetector.triggerManualWakeTest();
    if (onTestTrigger) onTestTrigger();
    setTimeout(() => {
      setIsTesting(false);
    }, 4000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
      <div
        className="w-full max-w-xl glass-panel-glow rounded-3xl border border-cyan-500/30 p-6 flex flex-col gap-5 max-h-[92vh] overflow-y-auto text-neutral-100 shadow-[0_0_50px_rgba(0,229,255,0.25)] relative"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between border-b border-white/10 pb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-cyan-500/20 border border-cyan-400/40 flex items-center justify-center text-cyan-400 shadow-[0_0_15px_rgba(0,229,255,0.3)]">
              <Radio className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-bold tracking-wide font-mono-tech text-white">
                  Hands-Free Assistant Setup
                </h2>
                <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded-full bg-cyan-950 border border-cyan-400/60 text-cyan-300">
                  Wake Word
                </span>
              </div>
              <p className="text-xs text-neutral-400">
                Official Android voice assistant integration & local keyword spotting
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full glass-button flex items-center justify-center text-neutral-400 hover:text-white"
            aria-label="Close setup modal"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* 5-Step Progress Indicators */}
        <div className="grid grid-cols-5 gap-1.5 p-1 rounded-xl bg-black/40 border border-white/10 text-center">
          {[
            { step: 1, label: 'Mic Access' },
            { step: 2, label: 'Hands-Free' },
            { step: 3, label: 'Assistant' },
            { step: 4, label: 'Settings' },
            { step: 5, label: 'Live Test' },
          ].map((item) => (
            <button
              key={item.step}
              onClick={() => setActiveStep(item.step)}
              className={`py-2 px-1 rounded-lg text-xs font-semibold transition-all flex flex-col items-center gap-1 ${
                activeStep === item.step
                  ? 'bg-cyan-500/25 border border-cyan-400/60 text-white shadow-sm'
                  : 'text-neutral-400 hover:text-neutral-200'
              }`}
            >
              <span className="text-[10px] font-mono-tech opacity-75">Step {item.step}</span>
              <span className="truncate text-[11px]">{item.label}</span>
            </button>
          ))}
        </div>

        {/* STEP 1: Enable Microphone Permission */}
        {activeStep === 1 && (
          <div className="flex flex-col gap-4 p-4 rounded-2xl bg-white/5 border border-white/10">
            <div className="flex items-start gap-3">
              <div
                className={`p-2.5 rounded-xl border ${
                  micPermissionGranted
                    ? 'bg-emerald-500/20 border-emerald-400/40 text-emerald-400'
                    : 'bg-cyan-500/20 border-cyan-400/40 text-cyan-400'
                }`}
              >
                <Mic className="w-6 h-6" />
              </div>
              <div className="flex-1">
                <h3 className="font-bold text-sm text-white">Step 1: Microphone Permission</h3>
                <p className="text-xs text-neutral-300 mt-1 leading-relaxed">
                  Hinata requires access to the microphone for hands-free wake word recognition.
                  Microphone audio is processed <strong>locally on your device</strong> and is never
                  streamed to external servers unless a command is spoken after activation.
                </p>
              </div>
            </div>

            <div className="flex items-center justify-between p-3 rounded-xl bg-black/30 border border-white/10">
              <div className="flex items-center gap-2 text-xs">
                {micPermissionGranted ? (
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                ) : (
                  <AlertCircle className="w-4 h-4 text-amber-400" />
                )}
                <span>
                  Permission Status:{' '}
                  <strong className={micPermissionGranted ? 'text-emerald-400' : 'text-amber-400'}>
                    {micPermissionGranted ? 'Granted' : 'Needs Approval'}
                  </strong>
                </span>
              </div>
              <button
                onClick={handleRequestMic}
                className="px-4 py-1.5 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs transition-all shadow-[0_0_12px_rgba(0,229,255,0.4)]"
              >
                {micPermissionGranted ? 'Permission Granted ✓' : 'Grant Permission'}
              </button>
            </div>

            <div className="flex justify-end pt-2">
              <button
                onClick={() => setActiveStep(2)}
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-semibold"
              >
                <span>Continue to Step 2</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        )}

        {/* STEP 2: Enable Hands-Free Mode */}
        {activeStep === 2 && (
          <div className="flex flex-col gap-4 p-4 rounded-2xl bg-white/5 border border-white/10">
            <div className="flex items-start gap-3">
              <div className="p-2.5 rounded-xl bg-purple-500/20 border border-purple-400/40 text-purple-400">
                <Radio className="w-6 h-6" />
              </div>
              <div className="flex-1">
                <h3 className="font-bold text-sm text-white">Step 2: Enable Hands-Free Mode</h3>
                <p className="text-xs text-neutral-300 mt-1 leading-relaxed">
                  When enabled, Hinata stands by in lightweight idle mode and activates whenever you say{' '}
                  <span className="text-cyan-300 font-mono">"{config.phrase}"</span>. You can disable this
                  at any time.
                </p>
              </div>
            </div>

            <div className="flex items-center justify-between p-3.5 rounded-xl bg-black/30 border border-white/10">
              <div>
                <p className="text-xs font-bold text-white">Always-Available Hands-Free Mode</p>
                <p className="text-[11px] text-neutral-400 mt-0.5">
                  Current state:{' '}
                  <span className={config.enabled ? 'text-emerald-400 font-bold' : 'text-neutral-500'}>
                    {config.enabled ? 'Active (ON)' : 'Disabled (OFF)'}
                  </span>
                </p>
              </div>
              <button
                onClick={() => handleToggleHandsFree(!config.enabled)}
                className={`relative inline-flex h-6 w-12 items-center rounded-full transition-colors ${
                  config.enabled ? 'bg-cyan-500' : 'bg-neutral-700'
                }`}
              >
                <span
                  className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                    config.enabled ? 'translate-x-7' : 'translate-x-1'
                  }`}
                />
              </button>
            </div>

            <div className="flex justify-between pt-2">
              <button
                onClick={() => setActiveStep(1)}
                className="text-xs text-neutral-400 hover:text-white"
              >
                Back
              </button>
              <button
                onClick={() => setActiveStep(3)}
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-semibold"
              >
                <span>Continue to Step 3</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        )}

        {/* STEP 3: Android Digital Assistant Setup */}
        {activeStep === 3 && (
          <div className="flex flex-col gap-4 p-4 rounded-2xl bg-white/5 border border-white/10">
            <div className="flex items-start gap-3">
              <div className="p-2.5 rounded-xl bg-blue-500/20 border border-blue-400/40 text-blue-400">
                <Smartphone className="w-6 h-6" />
              </div>
              <div className="flex-1">
                <h3 className="font-bold text-sm text-white">Step 3: Default Digital Assistant</h3>
                <p className="text-xs text-neutral-300 mt-1 leading-relaxed">
                  For Hinata to listen while other apps are active or when the device is locked, Android requires
                  selecting Hinata as the <strong>Default Digital Assistant</strong> in system settings.
                </p>
              </div>
            </div>

            <div className="p-3 rounded-xl bg-black/40 border border-white/10 flex flex-col gap-2.5">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-white">Android System Assistant Settings</span>
                <button
                  onClick={() => voiceService.openVoiceInputSettings()}
                  className="px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white font-medium text-xs transition-all shadow-[0_0_10px_rgba(59,130,246,0.4)]"
                >
                  Open Android Settings ↗
                </button>
              </div>
              <p className="text-[11px] text-neutral-400 leading-normal">
                Path in Settings: <em>Settings &gt; Apps &gt; Default apps &gt; Digital assistant app &gt; Select Hinata</em>.
              </p>
            </div>

            <div className="flex items-center justify-between p-3 rounded-xl bg-black/30 border border-white/10">
              <span className="text-xs text-neutral-300">Selected Hinata in System Settings?</span>
              <button
                onClick={() => {
                  const nextVal = !isDefaultAssistant;
                  setIsDefaultAssistant(nextVal);
                  voiceService.setAssignedAsDefaultAssistant(nextVal);
                }}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold border transition-all ${
                  isDefaultAssistant
                    ? 'bg-emerald-500/20 border-emerald-400 text-emerald-300'
                    : 'bg-white/5 border-white/10 text-neutral-400 hover:text-white'
                }`}
              >
                {isDefaultAssistant ? 'Confirmed Default Assistant ✓' : 'Mark as Selected'}
              </button>
            </div>

            <div className="flex justify-between pt-2">
              <button
                onClick={() => setActiveStep(2)}
                className="text-xs text-neutral-400 hover:text-white"
              >
                Back
              </button>
              <button
                onClick={() => setActiveStep(4)}
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-semibold"
              >
                <span>Continue to Step 4</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        )}

        {/* STEP 4: Configure Wake Word & Sensitivity */}
        {activeStep === 4 && (
          <div className="flex flex-col gap-4 p-4 rounded-2xl bg-white/5 border border-white/10">
            <div className="flex items-start gap-3">
              <div className="p-2.5 rounded-xl bg-amber-500/20 border border-amber-400/40 text-amber-400">
                <Sliders className="w-6 h-6" />
              </div>
              <div className="flex-1">
                <h3 className="font-bold text-sm text-white">Step 4: Wake Word Preferences</h3>
                <p className="text-xs text-neutral-300 mt-1 leading-relaxed">
                  Customize the trigger phrase, sensitivity threshold, and response audio.
                </p>
              </div>
            </div>

            {/* Phrase Input */}
            <div className="flex flex-col gap-1.5">
              <label className="text-xs font-semibold text-neutral-300">Wake Phrase</label>
              <input
                type="text"
                value={config.phrase}
                onChange={(e) => handleUpdatePhrase(e.target.value)}
                placeholder="Hey Hinata"
                className="w-full px-3.5 py-2 rounded-xl bg-black/40 border border-white/15 text-white font-mono text-sm focus:border-cyan-400 focus:outline-none"
              />
            </div>

            {/* Sensitivity Selection */}
            <div className="flex flex-col gap-1.5">
              <label className="text-xs font-semibold text-neutral-300">Wake Sensitivity</label>
              <div className="grid grid-cols-3 gap-2">
                {(['low', 'medium', 'high'] as WakeSensitivity[]).map((level) => (
                  <button
                    key={level}
                    onClick={() => handleUpdateSensitivity(level)}
                    className={`py-2 px-2 rounded-xl text-xs font-semibold border capitalize transition-all ${
                      config.sensitivity === level
                        ? 'bg-cyan-500/20 border-cyan-400 text-cyan-300'
                        : 'bg-black/30 border-white/10 text-neutral-400 hover:text-white'
                    }`}
                  >
                    {level}
                  </button>
                ))}
              </div>
              <p className="text-[11px] text-neutral-400 mt-0.5">
                {config.sensitivity === 'high'
                  ? 'High: Triggers instantly; slightly higher chance of false activations.'
                  : config.sensitivity === 'low'
                  ? 'Low: Requires strict phonetic match; virtually zero false activations.'
                  : 'Medium: Optimal balance of quick wake and false-positive prevention.'}
              </p>
            </div>

            {/* Auto-listening timeout */}
            <div className="flex flex-col gap-1.5">
              <label className="text-xs font-semibold text-neutral-300">Auto-Listening Timeout</label>
              <div className="grid grid-cols-3 gap-2">
                {[5000, 8000, 12000].map((timeout) => (
                  <button
                    key={timeout}
                    onClick={() => handleUpdateTimeout(timeout)}
                    className={`py-2 px-2 rounded-xl text-xs font-semibold border transition-all ${
                      config.autoListenTimeoutMs === timeout
                        ? 'bg-purple-500/20 border-purple-400 text-purple-300'
                        : 'bg-black/30 border-white/10 text-neutral-400 hover:text-white'
                    }`}
                  >
                    {timeout / 1000} seconds
                  </button>
                ))}
              </div>
            </div>

            {/* Voice Response Toggle */}
            <div className="flex items-center justify-between p-3 rounded-xl bg-black/30 border border-white/10">
              <div>
                <p className="text-xs font-semibold text-white">Spoken Voice Responses</p>
                <p className="text-[11px] text-neutral-400">Speak replies aloud after wake word commands</p>
              </div>
              <input
                type="checkbox"
                checked={config.voiceResponse}
                onChange={(e) => handleToggleVoiceResponse(e.target.checked)}
                className="w-4 h-4 accent-cyan-400 rounded cursor-pointer"
              />
            </div>

            <div className="flex justify-between pt-2">
              <button
                onClick={() => setActiveStep(3)}
                className="text-xs text-neutral-400 hover:text-white"
              >
                Back
              </button>
              <button
                onClick={() => setActiveStep(5)}
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-semibold"
              >
                <span>Continue to Step 5</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        )}

        {/* STEP 5: Live Test */}
        {activeStep === 5 && (
          <div className="flex flex-col gap-4 p-4 rounded-2xl bg-white/5 border border-white/10">
            <div className="flex items-start gap-3">
              <div className="p-2.5 rounded-xl bg-emerald-500/20 border border-emerald-400/40 text-emerald-400">
                <Sparkles className="w-6 h-6" />
              </div>
              <div className="flex-1">
                <h3 className="font-bold text-sm text-white">Step 5: Test "Hey Hinata"</h3>
                <p className="text-xs text-neutral-300 mt-1 leading-relaxed">
                  Speak into your microphone or tap the test trigger. Hinata will immediately wake up and respond!
                </p>
              </div>
            </div>

            {/* Acoustic Level Meter & Status */}
            <div className="p-4 rounded-2xl bg-black/50 border border-cyan-500/30 flex flex-col gap-3 text-center">
              <div className="flex items-center justify-between text-xs text-neutral-300">
                <span>Microphone Acoustic Level:</span>
                <span className="font-mono text-cyan-300">{Math.round(acousticLevel * 100)}%</span>
              </div>
              <div className="w-full h-2.5 rounded-full bg-neutral-800 overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-cyan-500 to-emerald-400 transition-all duration-75 rounded-full"
                  style={{ width: `${Math.max(5, Math.min(100, acousticLevel * 100))}%` }}
                />
              </div>

              <div className="p-3 rounded-xl bg-cyan-950/40 border border-cyan-500/30 text-xs text-cyan-200 min-h-[44px] flex items-center justify-center">
                {testResult || `Waiting for: "${config.phrase}"...`}
              </div>

              <div className="flex justify-center">
                <button
                  onClick={handleRunWakeTest}
                  disabled={isTesting}
                  className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-bold text-xs shadow-[0_0_20px_rgba(0,229,255,0.4)] active:scale-95 transition-all"
                >
                  <Play className="w-4 h-4 fill-slate-950" />
                  <span>Simulate "Hey Hinata" Wake Test</span>
                </button>
              </div>
            </div>

            <div className="flex justify-between pt-2">
              <button
                onClick={() => setActiveStep(4)}
                className="text-xs text-neutral-400 hover:text-white"
              >
                Back
              </button>
              <button
                onClick={onClose}
                className="px-5 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs shadow-[0_0_15px_rgba(16,185,129,0.3)]"
              >
                Done &amp; Save
              </button>
            </div>
          </div>
        )}

        {/* Privacy & Android Battery Architecture Note */}
        <div className="p-3 rounded-2xl bg-neutral-900/60 border border-white/5 flex items-start gap-2.5 text-[11px] text-neutral-400">
          <ShieldCheck className="w-4 h-4 text-cyan-400 flex-shrink-0 mt-0.5" />
          <div className="leading-relaxed">
            <strong>Privacy &amp; Battery Guarantee:</strong> No audio is recorded or transmitted to the cloud
            while waiting for the wake word. The wake-word detector runs locally using low-power hardware/VAD.
            On Android devices with aggressive battery savers (MIUI, OneUI), allow background activity in app info.
          </div>
        </div>
      </div>
    </div>
  );
};
