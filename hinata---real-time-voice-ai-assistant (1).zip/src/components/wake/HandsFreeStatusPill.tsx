import React, { useState, useEffect } from 'react';
import { Radio, Mic, MicOff, Volume2, Sparkles, Loader2, AlertCircle } from 'lucide-react';
import { WakeWordManager } from '../../modules/wake/WakeWordManager';
import { WakeWordState } from '../../modules/wake/types';

interface HandsFreeStatusPillProps {
  onOpenSetup: () => void;
}

export const HandsFreeStatusPill: React.FC<HandsFreeStatusPillProps> = ({ onOpenSetup }) => {
  const wakeManager = WakeWordManager.getInstance();
  const [state, setState] = useState<WakeWordState>(() => wakeManager.getState());
  const [details, setDetails] = useState<string>(() => wakeManager.getStateDetails());

  useEffect(() => {
    const unsub = wakeManager.onStateChange((newState, newDetails) => {
      setState(newState);
      if (newDetails) setDetails(newDetails);
    });
    return unsub;
  }, []);

  const getPillConfig = () => {
    switch (state) {
      case 'WAKE_DETECTED':
        return {
          label: 'Wake Detected!',
          border: 'border-yellow-400/60 bg-yellow-950/80 text-yellow-300 shadow-[0_0_15px_rgba(234,179,8,0.4)]',
          dot: 'bg-yellow-400 shadow-[0_0_8px_#facc15] animate-ping',
          icon: <Sparkles className="w-3 h-3 text-yellow-300" />,
        };
      case 'LISTENING':
        return {
          label: 'Listening...',
          border: 'border-cyan-400/70 bg-cyan-950/90 text-cyan-200 shadow-[0_0_18px_rgba(0,229,255,0.4)]',
          dot: 'bg-cyan-400 shadow-[0_0_10px_#00e5ff] animate-pulse',
          icon: <Mic className="w-3 h-3 text-cyan-300" />,
        };
      case 'THINKING':
        return {
          label: 'Thinking...',
          border: 'border-purple-400/60 bg-purple-950/80 text-purple-300 shadow-[0_0_15px_rgba(192,132,252,0.3)]',
          dot: 'bg-purple-400 animate-spin',
          icon: <Loader2 className="w-3 h-3 text-purple-300 animate-spin" />,
        };
      case 'SPEAKING':
        return {
          label: 'Speaking...',
          border: 'border-pink-400/60 bg-pink-950/80 text-pink-300 shadow-[0_0_15px_rgba(244,114,182,0.3)]',
          dot: 'bg-pink-400 animate-pulse',
          icon: <Volume2 className="w-3 h-3 text-pink-300" />,
        };
      case 'ERROR':
        return {
          label: 'Mic Issue',
          border: 'border-rose-500/60 bg-rose-950/80 text-rose-300 shadow-[0_0_12px_rgba(244,63,94,0.3)]',
          dot: 'bg-rose-500',
          icon: <AlertCircle className="w-3 h-3 text-rose-300" />,
        };
      case 'DISABLED':
        return {
          label: 'Hands-Free Off',
          border: 'border-neutral-700 bg-neutral-900/80 text-neutral-400',
          dot: 'bg-neutral-600',
          icon: <MicOff className="w-3 h-3 text-neutral-400" />,
        };
      case 'WAKE_LISTENING':
      case 'WAKE_IDLE':
      default:
        return {
          label: 'Say "Hey Hinata"',
          border: 'border-cyan-400/40 bg-[#080d24]/90 text-cyan-300 hover:border-cyan-400 shadow-[0_0_12px_rgba(0,229,255,0.2)]',
          dot: 'bg-emerald-400 shadow-[0_0_6px_#10b981]',
          icon: <Radio className="w-3 h-3 text-cyan-400" />,
        };
    }
  };

  const pill = getPillConfig();

  return (
    <button
      onClick={onOpenSetup}
      className={`relative flex items-center gap-1.5 px-3 py-1 rounded-full border backdrop-blur-md text-[11px] font-semibold transition-all duration-200 active:scale-95 ${pill.border}`}
      title="Hands-Free Voice Assistant Settings & Setup"
    >
      <span className={`w-2 h-2 rounded-full ${pill.dot}`} />
      {pill.icon}
      <span className="tracking-wide font-mono-tech">{pill.label}</span>
    </button>
  );
};
