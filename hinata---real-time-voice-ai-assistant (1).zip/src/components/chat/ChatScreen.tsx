import React, { useState, useEffect, useRef, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import ReactMarkdown from 'react-markdown';
import {
  Send,
  Mic,
  MicOff,
  Image as ImageIcon,
  Plus,
  Trash2,
  Volume2,
  VolumeX,
  Copy,
  Check,
  RotateCcw,
  Sparkles,
  History,
  X,
  Edit2,
  Loader2,
  ChevronDown,
  AlertCircle,
  AlertTriangle,
  Radio,
  PenTool,
  Server,
  Key,
} from 'lucide-react';
import { HinataMascotAvatar } from '../HinataMascotAvatar';
import { ConversationManager } from '../../modules/conversation/ConversationManager';
import { VoiceInputService } from '../../modules/voice/VoiceInputService';
import { VisionManager } from '../../modules/VisionManager';
import { VoiceChatCoordinator, HybridMode, HybridStatus } from '../../modules/voiceChat/VoiceChatCoordinator';
import { MicrophoneManager, MicrophoneState, MicPermissionStatus } from '../../modules/audio/MicrophoneManager';
import { OwnerManager } from '../../modules/OwnerManager';
import { ChatMessage, Conversation, ChatState } from '../../modules/conversation/types';
import { LiveSessionState, EmotionalState, EmotionalIntensity, MascotState } from '../../types';
import { AudioPlayer } from '../../modules/AudioPlayer';
import { backendConfig, BackendStatusType } from '../../config/backendConfig';
import { ClientAIProvider, AIProviderStatus } from '../../modules/ai/AIProvider';

interface ChatScreenProps {
  liveSessionState: LiveSessionState;
  currentMood: EmotionalState;
  emotionalIntensity?: EmotionalIntensity;
  audioPlayer?: AudioPlayer | null;
  onOpenMemory?: () => void;
  onOpenDeviceActions?: () => void;
  onOpenBackendStatus?: () => void;
  onOpenSettings?: (tab?: 'voice' | 'permissions' | 'identity' | 'backend' | 'ai') => void;
}

export const ChatScreen: React.FC<ChatScreenProps> = ({
  liveSessionState,
  currentMood,
  emotionalIntensity = 2,
  audioPlayer = null,
  onOpenMemory,
  onOpenDeviceActions,
  onOpenBackendStatus,
  onOpenSettings,
}) => {
  const convManager = useRef<ConversationManager>(ConversationManager.getInstance()).current;
  const coordinator = useRef<VoiceChatCoordinator>(VoiceChatCoordinator.getInstance()).current;
  const visionManager = useRef<VisionManager>(VisionManager.getInstance()).current;

  // Local state
  const [conversations, setConversations] = useState<Conversation[]>(() => convManager.getAllConversations());
  const [activeConversation, setActiveConversation] = useState<Conversation>(() => convManager.getActiveConversation());
  const [chatState, setChatState] = useState<ChatState>(() => convManager.getChatState());
  const [speechVolume, setSpeechVolume] = useState<number>(0);
  const [inputVolume, setInputVolume] = useState<number>(0);
  const [inputText, setInputText] = useState<string>('');
  const [attachedImage, setAttachedImage] = useState<{ dataUrl: string; name?: string } | null>(null);
  const [isRecognizingSpeech, setIsRecognizingSpeech] = useState<boolean>(false);
  const [copiedMessageId, setCopiedMessageId] = useState<string | null>(null);
  const [isHistoryDrawerOpen, setIsHistoryDrawerOpen] = useState<boolean>(false);
  const [isEditingTitle, setIsEditingTitle] = useState<boolean>(false);
  const [editedTitle, setEditedTitle] = useState<string>('');
  const [speakingMessageId, setSpeakingMessageId] = useState<string | null>(null);
  const [previewModalImage, setPreviewModalImage] = useState<string | null>(null);
  const [backendStatus, setBackendStatus] = useState<BackendStatusType>(() => backendConfig.getStatus());
  const aiProvider = useRef<ClientAIProvider>(ClientAIProvider.getInstance()).current;
  const [aiStatus, setAiStatus] = useState<AIProviderStatus>(() => aiProvider.getStatus());

  useEffect(() => {
    const unsub = backendConfig.subscribe(() => {
      setBackendStatus(backendConfig.getStatus());
    });
    const unsubAi = aiProvider.subscribe((st) => {
      setAiStatus(st);
    });
    return () => {
      unsub();
      unsubAi();
    };
  }, [aiProvider]);

  // Hybrid Mode & Coordinator State
  const [hybridMode, setHybridMode] = useState<HybridMode>(() => coordinator.getSnapshot().mode);
  const [hybridStatus, setHybridStatus] = useState<HybridStatus>(() => coordinator.getSnapshot().status);
  const [lastActionMessage, setLastActionMessage] = useState<string | null>(null);
  const [autoVoiceReply, setAutoVoiceReply] = useState<boolean>(() => convManager.getAutoVoiceReply());

  // Centralized Microphone & Android Permission State
  const micManager = useRef<MicrophoneManager>(MicrophoneManager.getInstance()).current;
  const ownerManager = useRef<OwnerManager>(OwnerManager.getInstance()).current;
  const [assistantName, setAssistantName] = useState<string>(() => ownerManager.getAssistantName());
  const [userName, setUserName] = useState<string>(() => ownerManager.getOwnerName());
  const [micHardwareState, setMicHardwareState] = useState<MicrophoneState>(() => micManager.getState());
  const [micPermStatus, setMicPermStatus] = useState<MicPermissionStatus>(() => micManager.getPermissionStatus());
  const [showPermissionBanner, setShowPermissionBanner] = useState<boolean>(false);

  const messagesEndRef = useRef<HTMLDivElement | null>(null);
  const textareaRef = useRef<HTMLTextAreaElement | null>(null);

  // Subscribe to VoiceChatCoordinator
  useEffect(() => {
    const unsubCoord = coordinator.subscribe((snap) => {
      setHybridMode(snap.mode);
      setHybridStatus(snap.status);
      setIsRecognizingSpeech(snap.isListening);
      setInputVolume(snap.inputVolume);
      setSpeechVolume(snap.speechVolume);
      setLastActionMessage(snap.lastActionMessage);
      setAutoVoiceReply(snap.autoVoiceReply);

      // If draftText was updated via voice or "Likho" command, reflect in composer
      if (snap.draftText !== undefined) {
        setInputText((prev) => (prev !== snap.draftText ? snap.draftText : prev));
      }
    });

    return () => {
      unsubCoord();
    };
  }, [coordinator]);

  // Subscribe to ConversationManager
  useEffect(() => {
    const unsubConv = convManager.subscribe((all, active) => {
      setConversations(all);
      setActiveConversation(active);
    });

    const unsubState = convManager.onChatStateChange((state) => {
      setChatState(state);
      setSpeakingMessageId(convManager.getCurrentlySpeakingMessageId());
    });

    const unsubVol = convManager.onSpeechVolume((vol) => {
      setSpeechVolume(vol);
    });

    return () => {
      unsubConv();
      unsubState();
      unsubVol();
    };
  }, [convManager]);

  // Subscribe to VisionManager's selected image
  useEffect(() => {
    const unsubVision = visionManager.subscribe((vState) => {
      if (vState.selectedImage) {
        setAttachedImage({
          dataUrl: vState.selectedImage.dataUrl,
          name: vState.selectedImage.name,
        });
      }
    });
    return unsubVision;
  }, [visionManager]);

  // Subscribe to MicrophoneManager state & Android permission status
  useEffect(() => {
    const unsubState = micManager.onStateChange((state, _owner, err) => {
      setMicHardwareState(state);
      if (state === 'ERROR' && err) {
        setShowPermissionBanner(true);
      }
    });

    const unsubPerm = micManager.onPermissionChange((perm) => {
      setMicPermStatus(perm);
      if (perm === 'granted') {
        setShowPermissionBanner(false);
      }
    });

    return () => {
      unsubState();
      unsubPerm();
    };
  }, [micManager]);

  // Subscribe to OwnerManager for dynamic assistant name and user name updates
  useEffect(() => {
    const unsubOwner = ownerManager.onProfileChange(() => {
      setAssistantName(ownerManager.getAssistantName());
      setUserName(ownerManager.getOwnerName());
    });
    return unsubOwner;
  }, [ownerManager]);

  // Scroll to bottom on new messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [activeConversation.messages, chatState]);

  // Auto-resize textarea & sync draft with coordinator
  const handleTextChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const val = e.target.value;
    setInputText(val);
    coordinator.setDraftText(val);
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = Math.min(120, textareaRef.current.scrollHeight) + 'px';
    }
  };

  // Send message
  const handleSendMessage = useCallback(async () => {
    const clean = inputText.trim();
    if (!clean && !attachedImage) return;

    const imgToSend = attachedImage;
    setInputText('');
    coordinator.clearDraft();
    setAttachedImage(null);

    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
    }

    if (isRecognizingSpeech) {
      coordinator.stopListening();
    }

    await convManager.sendMessage({
      text: clean,
      image: imgToSend || undefined,
      speakVoice: hybridMode === 'VOICE_MODE' ? true : autoVoiceReply,
    });
  }, [inputText, attachedImage, isRecognizingSpeech, convManager, coordinator, hybridMode, autoVoiceReply]);

  // Send draft button handler in dictation mode
  const handleSendDraft = useCallback(() => {
    coordinator.sendCurrentDraft();
  }, [coordinator]);

  // Clear draft button handler
  const handleClearDraft = useCallback(() => {
    coordinator.clearDraft();
    setInputText('');
  }, [coordinator]);

  // Focus composer textarea
  const handleFocusComposer = useCallback(() => {
    textareaRef.current?.focus();
  }, []);

  // Enter to send
  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  // Check whether voice input or dictation is actively capturing for chat
  const isChatMicActive =
    isRecognizingSpeech ||
    (micHardwareState === 'LISTENING' &&
      (micManager.getOwner() === 'chat_voice' || micManager.getOwner() === 'dictation'));

  // Toggle speech recognition inside chat via coordinator & MicrophoneManager
  const handleToggleVoiceInput = useCallback(async () => {
    // 1. Prevent double-tap race conditions while starting, stopping, or requesting permission
    if (
      micManager.isBusy() ||
      micHardwareState === 'STARTING' ||
      micHardwareState === 'STOPPING' ||
      micHardwareState === 'REQUESTING_PERMISSION'
    ) {
      console.log('[ChatScreen] Mic toggle ignored: operation in progress.');
      return;
    }

    // 2. If currently listening for chat, stop immediately (preserves Android permission!)
    if (isChatMicActive) {
      coordinator.stopListening();
      return;
    }

    // 3. Permission checks
    const perm = micManager.getPermissionStatus();
    if (perm === 'permanently_denied') {
      setShowPermissionBanner(true);
      return;
    }

    if (perm !== 'granted') {
      const res = await micManager.requestPermission();
      if (!res.granted) {
        setShowPermissionBanner(true);
        return;
      }
    }

    setShowPermissionBanner(false);
    coordinator.startListening();
  }, [coordinator, micHardwareState, isChatMicActive, micManager]);

  // Copy message text
  const handleCopyMessage = (id: string, text: string) => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(text);
      setCopiedMessageId(id);
      setTimeout(() => setCopiedMessageId(null), 2000);
    }
  };

  // Speak assistant message aloud
  const handleToggleSpeak = (id: string) => {
    convManager.speakMessage(id);
  };

  // Image picker trigger
  const handlePickImage = async () => {
    try {
      await visionManager.imageInput.pickImage();
      const sel = visionManager.imageInput.getSelectedImage();
      if (sel) {
        setAttachedImage({ dataUrl: sel.dataUrl, name: sel.name });
      }
    } catch (e) {
      console.warn('[ChatScreen] Pick image warning:', e);
    }
  };

  // Derive compact mascot visual state
  const compactMascotState: MascotState =
    chatState === 'speaking'
      ? 'SPEAKING'
      : chatState === 'thinking' || chatState === 'sending'
      ? 'THINKING'
      : chatState === 'streaming'
      ? 'THINKING'
      : isRecognizingSpeech
      ? 'LISTENING'
      : chatState === 'error'
      ? 'ERROR'
      : liveSessionState === 'speaking'
      ? 'SPEAKING'
      : liveSessionState === 'listening'
      ? 'LISTENING'
      : 'IDLE';

  const getStateBadge = () => {
    switch (chatState) {
      case 'thinking':
        return (
          <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-cyan-950/80 border border-cyan-400/50 text-[11px] text-cyan-200 shadow-[0_0_12px_rgba(0,229,255,0.3)]">
            <Loader2 className="w-3 h-3 text-cyan-400 animate-spin" />
            <span>Hinata Thinking...</span>
          </div>
        );
      case 'streaming':
        return (
          <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-purple-950/80 border border-purple-400/50 text-[11px] text-purple-200 shadow-[0_0_12px_rgba(192,132,252,0.3)]">
            <Sparkles className="w-3 h-3 text-purple-300 animate-pulse" />
            <span>Replying...</span>
          </div>
        );
      case 'speaking':
        return (
          <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-950/80 border border-emerald-400/50 text-[11px] text-emerald-200 shadow-[0_0_12px_rgba(52,211,153,0.3)]">
            <Volume2 className="w-3 h-3 text-emerald-300 animate-bounce" />
            <span>Speaking...</span>
          </div>
        );
      case 'error':
        return (
          <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-rose-950/80 border border-rose-400/50 text-[11px] text-rose-200 shadow-[0_0_12px_rgba(244,63,94,0.3)]">
            <AlertCircle className="w-3 h-3 text-rose-400" />
            <span>Connection Issue</span>
          </div>
        );
      default:
        if (isRecognizingSpeech) {
          return (
            <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-950/80 border border-cyan-400/50 text-[11px] text-cyan-300 shadow-[0_0_12px_rgba(0,229,255,0.3)]">
              <Mic className="w-3 h-3 text-cyan-300 animate-pulse" />
              <span>Listening to your voice...</span>
            </div>
          );
        }
        return (
          <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#080e29]/80 border border-slate-700/60 text-[11px] text-slate-300">
            <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 shadow-[0_0_6px_#00e5ff]" />
            <span className="capitalize">{assistantName} • {currentMood}</span>
          </div>
        );
    }
  };

  return (
    <div className="relative w-full h-full flex flex-col justify-between overflow-hidden">
      {/* 1. TOP COMPACT HINATA AVATAR & CONVERSATION BAR */}
      <div className="flex-shrink-0 w-full pt-1 pb-2 px-4 border-b border-cyan-950/60 bg-[#050818]/80 backdrop-blur-md z-30">
        <div className="w-full max-w-4xl mx-auto flex items-center justify-between gap-3">
          {/* Active Conversation Title & Dropdown */}
          <div className="flex items-center gap-2 min-w-0">
            {isEditingTitle ? (
              <div className="flex items-center gap-1">
                <input
                  type="text"
                  value={editedTitle}
                  onChange={(e) => setEditedTitle(e.target.value)}
                  className="px-2 py-0.5 rounded bg-slate-900 border border-cyan-400 text-xs text-cyan-200 focus:outline-none"
                  autoFocus
                />
                <button
                  onClick={() => {
                    convManager.renameConversation(activeConversation.id, editedTitle);
                    setIsEditingTitle(false);
                  }}
                  className="p-1 text-cyan-400 hover:text-white text-xs"
                >
                  ✓
                </button>
                <button
                  onClick={() => setIsEditingTitle(false)}
                  className="p-1 text-slate-400 hover:text-white text-xs"
                >
                  ✕
                </button>
              </div>
            ) : (
              <button
                onClick={() => setIsHistoryDrawerOpen((prev) => !prev)}
                className="flex items-center gap-1.5 group text-left max-w-[200px] sm:max-w-xs truncate"
                title="View Conversation History"
              >
                <h2 className="text-xs sm:text-sm font-semibold text-slate-200 group-hover:text-cyan-300 transition-colors truncate">
                  {activeConversation.title}
                </h2>
                <ChevronDown className="w-3.5 h-3.5 text-slate-400 group-hover:text-cyan-300 flex-shrink-0 transition-transform" />
              </button>
            )}

            <button
              onClick={() => {
                setEditedTitle(activeConversation.title);
                setIsEditingTitle(true);
              }}
              className="p-1 text-slate-500 hover:text-cyan-300 transition-colors hidden sm:inline"
              title="Rename conversation"
            >
              <Edit2 className="w-3 h-3" />
            </button>
          </div>

          {/* Compact Face Avatar */}
          <div className="flex flex-col items-center justify-center -my-2 flex-shrink-0">
            <div className="relative w-24 h-24 sm:w-28 sm:h-28 flex items-center justify-center overflow-visible">
              <HinataMascotAvatar
                state={liveSessionState}
                mascotState={compactMascotState}
                mood={currentMood}
                intensity={emotionalIntensity}
                outputVolume={speechVolume}
                inputVolume={inputVolume}
                audioPlayer={audioPlayer}
                size={110}
              />
            </div>
            <div className="-mt-1 z-10">{getStateBadge()}</div>
          </div>

          {/* Action buttons: New Chat & Clear */}
          <div className="flex items-center gap-1.5 flex-shrink-0">
            <button
              onClick={() => convManager.createConversation()}
              className="flex items-center gap-1 px-2.5 py-1 rounded-xl bg-cyan-950/70 border border-cyan-400/40 text-cyan-300 hover:bg-cyan-900/80 hover:text-white text-[11px] font-medium transition-all shadow-[0_0_10px_rgba(0,229,255,0.2)] active:scale-95"
              title="Start a fresh conversation"
            >
              <Plus className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">New Chat</span>
            </button>

            <button
              onClick={() => setIsHistoryDrawerOpen((prev) => !prev)}
              className="p-1.5 rounded-xl bg-slate-900/80 border border-slate-800 text-slate-300 hover:text-cyan-300 hover:border-cyan-500/40 transition-colors"
              title="Past Conversations"
            >
              <History className="w-4 h-4" />
            </button>

            <button
              onClick={() => {
                if (window.confirm('Clear all messages in this conversation?')) {
                  convManager.clearMessages();
                }
              }}
              className="p-1.5 rounded-xl bg-slate-900/80 border border-slate-800 text-slate-400 hover:text-rose-400 hover:border-rose-500/40 transition-colors"
              title="Clear messages"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* 2. CONVERSATION HISTORY DRAWER OVERLAY */}
      <AnimatePresence>
        {isHistoryDrawerOpen && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="absolute top-16 inset-x-4 max-w-lg mx-auto z-40 p-4 rounded-2xl bg-[#080d24]/95 border border-cyan-400/40 backdrop-blur-2xl shadow-[0_15px_40px_rgba(0,0,0,0.8),0_0_20px_rgba(0,229,255,0.2)]"
          >
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <History className="w-4 h-4 text-cyan-400" />
                <span className="text-xs font-bold text-white tracking-wider uppercase">
                  Conversation Vault ({conversations.length})
                </span>
              </div>
              <button
                onClick={() => setIsHistoryDrawerOpen(false)}
                className="p-1 text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="max-h-60 overflow-y-auto divide-y divide-slate-800/60 mt-2">
              {conversations.map((c) => {
                const isActive = c.id === activeConversation.id;
                return (
                  <div
                    key={c.id}
                    className={`flex items-center justify-between py-2.5 px-2 rounded-xl transition-all ${
                      isActive
                        ? 'bg-cyan-500/15 border border-cyan-400/40'
                        : 'hover:bg-slate-800/40'
                    }`}
                  >
                    <button
                      onClick={() => {
                        convManager.switchConversation(c.id);
                        setIsHistoryDrawerOpen(false);
                      }}
                      className="flex-1 text-left min-w-0 pr-2"
                    >
                      <p
                        className={`text-xs font-semibold truncate ${
                          isActive ? 'text-cyan-300' : 'text-slate-200'
                        }`}
                      >
                        {c.title}
                      </p>
                      <p className="text-[10px] text-slate-500 mt-0.5">
                        {c.messages.length} messages • {new Date(c.updatedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </p>
                    </button>

                    {conversations.length > 1 && (
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          convManager.deleteConversation(c.id);
                        }}
                        className="p-1 rounded-lg text-slate-500 hover:text-rose-400 transition-colors"
                        title="Delete conversation"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                );
              })}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* 3. SCROLLABLE MESSAGE HISTORY AREA */}
      <div className="flex-1 overflow-y-auto px-4 py-4 space-y-4 max-w-4xl w-full mx-auto select-text">
        {/* Backend not configured notification banner */}
        {backendStatus === 'not_configured' && (
          <div className="p-3.5 rounded-2xl bg-amber-950/40 border border-amber-500/40 text-xs shadow-[0_0_20px_rgba(245,158,11,0.12)] flex items-center justify-between gap-3 animate-fadeIn">
            <div className="flex items-start gap-2.5 min-w-0">
              <AlertTriangle className="w-4 h-4 text-amber-400 flex-shrink-0 mt-0.5" />
              <div>
                <span className="font-bold text-amber-300">Server Connecting: </span>
                <span className="text-slate-300">
                  Connecting to AI Studio Server. You can check diagnostics anytime in Backend Status.
                </span>
              </div>
            </div>
            <div className="flex items-center gap-2 flex-shrink-0">
              <button
                onClick={() => onOpenBackendStatus ? onOpenBackendStatus() : onOpenSettings && onOpenSettings()}
                className="px-3 py-1.5 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-200 border border-amber-500/50 font-semibold text-[11px] transition-all"
              >
                Status
              </button>
            </div>
          </div>
        )}

        {/* Backend offline / connection failed notice */}
        {backendStatus === 'connection_failed' && (
          <div className="p-3.5 rounded-2xl bg-rose-950/40 border border-rose-500/40 text-xs shadow-[0_0_20px_rgba(244,63,94,0.12)] flex items-center justify-between gap-3 animate-fadeIn">
            <div className="flex items-start gap-2.5 min-w-0">
              <AlertCircle className="w-4 h-4 text-rose-400 flex-shrink-0 mt-0.5" />
              <div>
                <span className="font-bold text-rose-300">Server Offline: </span>
                <span className="text-slate-300">
                  Could not reach the server. Check server diagnostics or reset to AI Studio Server.
                </span>
              </div>
            </div>
            <div className="flex items-center gap-2 flex-shrink-0">
              <button
                onClick={() => onOpenBackendStatus ? onOpenBackendStatus() : onOpenSettings && onOpenSettings()}
                className="px-3 py-1.5 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 text-rose-200 border border-rose-500/50 font-semibold text-[11px] transition-all"
              >
                Diagnostics
              </button>
            </div>
          </div>
        )}

        {/* AI Service Auth Failure Banner */}
        {(aiStatus.status === 'EXPIRED_OR_REVOKED' || aiStatus.status === 'INVALID_KEY') && (
          <div className="p-3.5 rounded-2xl bg-rose-950/50 border border-rose-500/50 text-xs shadow-[0_0_20px_rgba(244,63,94,0.15)] flex items-center justify-between gap-3 animate-fadeIn">
            <div className="flex items-start gap-2.5 min-w-0">
              <AlertCircle className="w-4 h-4 text-rose-400 flex-shrink-0 mt-0.5" />
              <div>
                <span className="font-bold text-rose-300">
                  {aiStatus.status === 'EXPIRED_OR_REVOKED' ? 'API Key Expired or Revoked: ' : 'Invalid API Key: '}
                </span>
                <span className="text-slate-300">
                  AI service authentication failed. Please update the API key.
                </span>
              </div>
            </div>
            <div className="flex items-center gap-2 flex-shrink-0">
              <button
                onClick={() => onOpenSettings && onOpenSettings('ai')}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-rose-500/30 hover:bg-rose-500/40 text-rose-100 border border-rose-400/60 font-semibold text-[11px] transition-all shadow-sm"
              >
                <Key className="w-3.5 h-3.5 text-rose-300" />
                <span>Update API Key</span>
              </button>
            </div>
          </div>
        )}

        {activeConversation.messages.map((msg) => {
          const isUser = msg.role === 'user';
          const isSpeakingThis = speakingMessageId === msg.id;

          return (
            <motion.div
              key={msg.id}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.2 }}
              className={`flex flex-col ${isUser ? 'items-end' : 'items-start'}`}
            >
              {/* Message Bubble Container */}
              <div
                className={`relative max-w-[88%] sm:max-w-[80%] rounded-2xl p-3.5 text-xs sm:text-sm leading-relaxed ${
                  isUser
                    ? 'bg-gradient-to-br from-[#0c1840] to-[#080d24] text-slate-100 border border-cyan-500/40 shadow-[0_4px_16px_rgba(0,229,255,0.15)] rounded-br-sm'
                    : 'bg-[#080f2c]/90 text-slate-200 border border-slate-700/60 shadow-[0_4px_20px_rgba(0,0,0,0.6)] rounded-bl-sm backdrop-blur-xl'
                }`}
              >
                {/* Assistant Label & Glow accent */}
                {!isUser && (
                  <div className="flex items-center justify-between gap-2 mb-2 pb-1.5 border-b border-cyan-900/40">
                    <div className="flex items-center gap-1.5">
                      <span className="w-2 h-2 rounded-full bg-cyan-400 shadow-[0_0_8px_#00e5ff]" />
                      <span className="text-[11px] font-bold text-cyan-300 tracking-wider">{assistantName.toUpperCase()}</span>
                      {msg.emotion && (
                        <span className="text-[9px] px-1.5 py-0.2 rounded-full bg-purple-950/60 border border-purple-400/30 text-purple-300">
                          {msg.emotion}
                        </span>
                      )}
                    </div>
                  </div>
                )}

                {/* Attached Image Preview */}
                {msg.image && (
                  <div className="mb-2.5 rounded-xl overflow-hidden border border-cyan-400/40 max-w-[240px] bg-slate-950">
                    <img
                      src={msg.image.dataUrl}
                      alt="User attachment"
                      onClick={() => setPreviewModalImage(msg.image!.dataUrl)}
                      className="w-full max-h-48 object-cover cursor-pointer hover:opacity-90 transition-opacity"
                    />
                  </div>
                )}

                {/* Message Text / Safe Markdown Rendering */}
                {isUser ? (
                  <p className="whitespace-pre-wrap">{msg.content}</p>
                ) : (
                  <div className="prose prose-invert prose-xs sm:prose-sm max-w-none text-slate-200 break-words leading-relaxed space-y-2">
                    <ReactMarkdown
                      components={{
                        code({ className, children, ...props }) {
                          const isInline = !className;
                          return isInline ? (
                            <code
                              className="px-1.5 py-0.5 rounded bg-slate-900 text-cyan-300 font-mono text-[11px] border border-cyan-900/50"
                              {...props}
                            >
                              {children}
                            </code>
                          ) : (
                            <pre className="p-3 rounded-xl bg-[#030614] border border-cyan-500/30 overflow-x-auto text-[11px] font-mono text-cyan-100 shadow-inner">
                              <code className={className} {...props}>
                                {children}
                              </code>
                            </pre>
                          );
                        },
                        p({ children }) {
                          return <p className="mb-2 last:mb-0">{children}</p>;
                        },
                        ul({ children }) {
                          return <ul className="list-disc pl-4 space-y-1 mb-2">{children}</ul>;
                        },
                        ol({ children }) {
                          return <ol className="list-decimal pl-4 space-y-1 mb-2">{children}</ol>;
                        },
                        strong({ children }) {
                          return <strong className="font-bold text-cyan-200">{children}</strong>;
                        },
                        a({ href, children }) {
                          return (
                            <a
                              href={href}
                              target="_blank"
                              rel="noreferrer"
                              className="text-cyan-400 hover:text-cyan-300 underline underline-offset-2"
                            >
                              {children}
                            </a>
                          );
                        },
                      }}
                    >
                      {msg.content}
                    </ReactMarkdown>
                  </div>
                )}

                {/* Message Actions Row */}
                <div
                  className={`mt-2 pt-1 flex items-center gap-2 text-[10px] text-slate-400 ${
                    isUser ? 'justify-end' : 'justify-between'
                  }`}
                >
                  <span className="text-[9px] opacity-70">
                    {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </span>

                  {!isUser && msg.status !== 'streaming' && (
                    <div className="flex items-center gap-1.5">
                      {/* Speaker [🔊] Button */}
                      <button
                        onClick={() => handleToggleSpeak(msg.id)}
                        className={`p-1 rounded-lg transition-colors ${
                          isSpeakingThis
                            ? 'text-emerald-300 bg-emerald-950/60 border border-emerald-400/40'
                            : 'text-slate-400 hover:text-cyan-300 hover:bg-slate-800/60'
                        }`}
                        title={isSpeakingThis ? 'Stop voice reading' : 'Read aloud with Hinata voice'}
                      >
                        {isSpeakingThis ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5" />}
                      </button>

                      {/* Copy Button */}
                      <button
                        onClick={() => handleCopyMessage(msg.id, msg.content)}
                        className="p-1 rounded-lg text-slate-400 hover:text-cyan-300 hover:bg-slate-800/60 transition-colors"
                        title="Copy message text"
                      >
                        {copiedMessageId === msg.id ? (
                          <Check className="w-3.5 h-3.5 text-emerald-400" />
                        ) : (
                          <Copy className="w-3.5 h-3.5" />
                        )}
                      </button>
                    </div>
                  )}
                </div>

                {/* Error & Retry */}
                {msg.status === 'error' && (
                  <div className={`mt-2 pt-2 border-t flex items-center justify-between text-[11px] ${
                    msg.error === 'Backend not configured'
                      ? 'border-amber-500/30 text-amber-300'
                      : (msg.authFailed || msg.content?.includes('AI service authentication failed'))
                      ? 'border-rose-500/30 text-rose-300'
                      : 'border-rose-900/60 text-rose-300'
                  }`}>
                    <span>{msg.error || 'Failed to complete generation'}</span>
                    {msg.authFailed || msg.content?.includes('AI service authentication failed') ? (
                      <button
                        onClick={() => onOpenSettings && onOpenSettings('ai')}
                        className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-rose-500/20 hover:bg-rose-500/30 border border-rose-400/50 text-rose-200 text-[10px] font-semibold transition-all active:scale-95 shadow-sm"
                      >
                        <Key className="w-3 h-3 text-rose-300" />
                        <span>Update API Key</span>
                      </button>
                    ) : msg.error === 'Backend not configured' ? (
                      <button
                        onClick={() => {
                          if (onOpenBackendStatus) onOpenBackendStatus();
                          else if (onOpenSettings) onOpenSettings();
                        }}
                        className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-amber-500/20 hover:bg-amber-500/30 border border-amber-400/50 text-amber-200 text-[10px] font-semibold transition-all active:scale-95"
                      >
                        <Server className="w-3 h-3 text-amber-400" />
                        <span>Configure Backend</span>
                      </button>
                    ) : (
                      <button
                        onClick={() => convManager.retryMessage(msg.id)}
                        className="flex items-center gap-1 px-2 py-0.5 rounded-lg bg-rose-950/80 border border-rose-400/40 text-rose-200 hover:bg-rose-900 text-[10px]"
                      >
                        <RotateCcw className="w-3 h-3" />
                        <span>Retry</span>
                      </button>
                    )}
                  </div>
                )}
              </div>
            </motion.div>
          );
        })}

        {/* Streaming / Thinking pulse if waiting for response */}
        {chatState === 'thinking' && (
          <motion.div
            initial={{ opacity: 0, y: 6 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex items-center gap-2 text-xs text-cyan-300/90 pl-2"
          >
            <Loader2 className="w-3.5 h-3.5 animate-spin text-cyan-400" />
            <span>Hinata is formulating a response...</span>
          </motion.div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* 4. ATTACHED IMAGE PREVIEW BAR */}
      <AnimatePresence>
        {attachedImage && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 10 }}
            className="flex-shrink-0 px-4 pb-2 max-w-4xl w-full mx-auto"
          >
            <div className="flex items-center gap-3 p-2 rounded-2xl bg-[#0a1236]/90 border border-cyan-400/50 backdrop-blur-xl shadow-[0_4px_20px_rgba(0,229,255,0.2)]">
              <div className="relative w-12 h-12 rounded-xl overflow-hidden border border-cyan-400/40 flex-shrink-0 bg-slate-900">
                <img
                  src={attachedImage.dataUrl}
                  alt="Attached preview"
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-xs font-semibold text-cyan-200 truncate">
                  {attachedImage.name || 'Visual Reference Attached'}
                </p>
                <p className="text-[10px] text-slate-400">
                  Ready to send to Hinata's visual understanding engine
                </p>
              </div>
              <div className="flex items-center gap-1">
                <button
                  onClick={handlePickImage}
                  className="px-2 py-1 rounded-lg bg-slate-800 text-[10px] text-slate-300 hover:text-white"
                >
                  Replace
                </button>
                <button
                  onClick={() => setAttachedImage(null)}
                  className="p-1 rounded-lg text-slate-400 hover:text-rose-400"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* 5. BOTTOM INPUT DOCK BAR */}
      <div className="flex-shrink-0 px-4 pt-1 pb-3 w-full bg-gradient-to-t from-[#040612] via-[#060a1e] to-transparent z-30">
        {/* HYBRID MODE & STATUS BAR */}
        <div className="max-w-4xl mx-auto mb-2 flex flex-wrap items-center justify-between gap-2 px-1 text-xs">
          {/* Left: Mode Indicator Pill (VOICE / DICTATION / THINKING / SPEAKING) */}
          <div className="flex items-center gap-2">
            {hybridStatus === 'SPEAKING' || chatState === 'speaking' ? (
              <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-950/80 border border-emerald-400/60 text-emerald-200 shadow-[0_0_12px_rgba(52,211,153,0.4)]">
                <Volume2 className="w-3.5 h-3.5 text-emerald-300 animate-bounce" />
                <span className="font-bold tracking-wider text-[10px]">SPEAKING</span>
              </div>
            ) : hybridStatus === 'THINKING' || chatState === 'thinking' || chatState === 'streaming' ? (
              <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-cyan-950/80 border border-cyan-400/60 text-cyan-200 shadow-[0_0_12px_rgba(0,229,255,0.4)]">
                <Loader2 className="w-3.5 h-3.5 text-cyan-300 animate-spin" />
                <span className="font-bold tracking-wider text-[10px]">THINKING</span>
              </div>
            ) : hybridMode === 'DICTATION_MODE' ? (
              <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-950/80 border border-amber-400/60 text-amber-200 shadow-[0_0_12px_rgba(251,191,36,0.4)]">
                <PenTool className="w-3.5 h-3.5 text-amber-300" />
                <span className="font-bold tracking-wider text-[10px]">DICTATION</span>
                {isRecognizingSpeech && (
                  <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping" />
                )}
              </div>
            ) : (
              <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-cyan-950/80 border border-cyan-500/50 text-cyan-200 shadow-[0_0_12px_rgba(0,229,255,0.3)]">
                <Radio className="w-3.5 h-3.5 text-cyan-400" />
                <span className="font-bold tracking-wider text-[10px]">VOICE</span>
                {isRecognizingSpeech && (
                  <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
                )}
              </div>
            )}

            {/* Mode Switcher Buttons */}
            <div className="flex items-center bg-slate-900/80 border border-slate-700/60 rounded-full p-0.5">
              <button
                type="button"
                onClick={() => coordinator.setMode('VOICE_MODE')}
                className={`px-2.5 py-0.5 rounded-full text-[10px] font-semibold transition-all ${
                  hybridMode === 'VOICE_MODE'
                    ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-400/40'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
                title="Voice Mode: Speaks answer aloud & outputs to chat"
              >
                Voice
              </button>
              <button
                type="button"
                onClick={() => coordinator.setMode('DICTATION_MODE')}
                className={`px-2.5 py-0.5 rounded-full text-[10px] font-semibold transition-all ${
                  hybridMode === 'DICTATION_MODE'
                    ? 'bg-amber-500/20 text-amber-300 border border-amber-400/40'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
                title="Dictation Mode: User speech drafts in composer for editing"
              >
                Dictate
              </button>
            </div>
          </div>

          {/* Right: Auto Voice Reply Toggle */}
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => coordinator.setAutoVoiceReply(!autoVoiceReply)}
              className={`flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-medium border transition-all ${
                autoVoiceReply
                  ? 'bg-emerald-950/60 border-emerald-500/40 text-emerald-300 hover:bg-emerald-900/60'
                  : 'bg-slate-900/80 border-slate-700/60 text-slate-400 hover:text-slate-200'
              }`}
              title="When enabled, Hinata speaks AI responses aloud"
            >
              {autoVoiceReply ? <Volume2 className="w-3 h-3" /> : <VolumeX className="w-3 h-3" />}
              <span>{autoVoiceReply ? 'Voice Reply ON' : 'Voice Reply OFF'}</span>
            </button>
          </div>
        </div>

        {/* Prominent Visual Indicator & Controls for Dictation Mode */}
        {hybridMode === 'DICTATION_MODE' && (
          <div className="max-w-4xl mx-auto mb-1.5 flex items-center justify-between gap-2 px-3 py-1.5 bg-gradient-to-r from-amber-950/50 via-amber-900/40 to-[#0c1638] border border-amber-500/40 rounded-xl shadow-[0_0_15px_rgba(245,158,11,0.15)]">
            <div className="flex items-center gap-2 text-xs text-amber-300 font-medium truncate">
              <span className="relative flex h-2.5 w-2.5 flex-shrink-0">
                {isRecognizingSpeech && (
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75"></span>
                )}
                <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-amber-500"></span>
              </span>
              <PenTool className="w-3.5 h-3.5 text-amber-400 flex-shrink-0" />
              <span className="font-semibold tracking-wide">
                {isRecognizingSpeech ? '✎ Writing to Chat...' : '✎ Dictation Mode'}
              </span>
              <span className="text-[10px] text-amber-400/70 hidden sm:inline">
                (Text appears in composer; say "Send this" or click Send)
              </span>
            </div>

            {/* Dictation Controls: [Edit] [Send] [Clear] */}
            <div className="flex items-center gap-1.5 flex-shrink-0">
              <button
                type="button"
                onClick={handleFocusComposer}
                className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-amber-950/60 border border-amber-500/30 text-amber-200 hover:bg-amber-900/80 text-[11px] transition-colors"
                title="Edit text in composer"
              >
                <Edit2 className="w-3 h-3" />
                <span>Edit</span>
              </button>

              <button
                type="button"
                onClick={handleClearDraft}
                disabled={!inputText.trim()}
                className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-800/80 border border-slate-700/60 text-slate-300 hover:text-rose-300 hover:border-rose-500/30 text-[11px] disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
                title="Clear composer draft"
              >
                <X className="w-3 h-3" />
                <span>Clear</span>
              </button>

              <button
                type="button"
                onClick={handleSendDraft}
                disabled={!inputText.trim()}
                className="flex items-center gap-1.5 px-3 py-1 rounded-lg bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-semibold text-[11px] shadow-[0_0_12px_rgba(16,185,129,0.35)] disabled:opacity-40 disabled:cursor-not-allowed transition-all"
                title="Send current message"
              >
                <Send className="w-3 h-3" />
                <span>Send</span>
              </button>
            </div>
          </div>
        )}

        {/* Action status message toast */}
        {lastActionMessage && (
          <div className="max-w-4xl mx-auto mb-1.5 flex items-center gap-1.5 px-3 py-1 rounded-xl bg-cyan-950/60 border border-cyan-500/30 text-[11px] text-cyan-200">
            <Sparkles className="w-3 h-3 text-cyan-400 animate-pulse flex-shrink-0" />
            <span className="truncate">{lastActionMessage}</span>
          </div>
        )}

        {/* Microphone Permission Banner & Settings Trigger */}
        {showPermissionBanner && (
          <motion.div
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            className="max-w-4xl mx-auto mb-2 p-3 rounded-2xl bg-gradient-to-r from-amber-950/90 via-slate-900/90 to-amber-950/90 border border-amber-500/50 shadow-xl backdrop-blur-xl flex flex-wrap items-center justify-between gap-3 text-amber-200"
          >
            <div className="flex items-center gap-2.5 min-w-0 flex-1">
              <AlertCircle className="w-5 h-5 text-amber-400 flex-shrink-0" />
              <div className="text-xs">
                <p className="font-semibold text-white">
                  {micPermStatus === 'permanently_denied'
                    ? 'Microphone permission is disabled.'
                    : 'Microphone access is required.'}
                </p>
                <p className="text-amber-300/80 text-[11px]">
                  {micPermStatus === 'permanently_denied'
                    ? 'Open Settings to enable microphone access.'
                    : 'Grant microphone permission to speak or dictate to Hinata.'}
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2 flex-shrink-0">
              {micPermStatus === 'permanently_denied' ? (
                <button
                  type="button"
                  onClick={() => micManager.openAppSettings()}
                  className="px-3.5 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs shadow-[0_0_12px_rgba(245,158,11,0.4)] active:scale-95 transition-all"
                >
                  Open Settings
                </button>
              ) : (
                <button
                  type="button"
                  onClick={async () => {
                    const res = await micManager.requestPermission();
                    if (res.granted) {
                      setShowPermissionBanner(false);
                      coordinator.startListening();
                    }
                  }}
                  className="px-3.5 py-1.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs shadow-[0_0_12px_rgba(0,229,255,0.4)] active:scale-95 transition-all"
                >
                  Allow Access
                </button>
              )}
              <button
                type="button"
                onClick={() => setShowPermissionBanner(false)}
                className="p-1 rounded-lg text-amber-400/80 hover:text-white"
                title="Dismiss"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </motion.div>
        )}

        <div className="max-w-4xl mx-auto flex items-end gap-2 p-1.5 rounded-3xl bg-[#080e2b]/95 border border-cyan-500/30 backdrop-blur-2xl shadow-[0_10px_35px_rgba(0,0,0,0.8),0_0_20px_rgba(0,229,255,0.15)]">
          {/* Image Attachment Button */}
          <button
            type="button"
            onClick={handlePickImage}
            className="p-2.5 rounded-2xl text-slate-400 hover:text-cyan-300 hover:bg-cyan-500/10 transition-colors active:scale-95 flex-shrink-0"
            title="Attach Image / Screenshot"
          >
            <ImageIcon className="w-5 h-5 text-cyan-400" />
          </button>

          {/* Multiline Text Input */}
          <div className="flex-1 min-w-0 py-1">
            <textarea
              ref={textareaRef}
              rows={1}
              value={inputText}
              onChange={handleTextChange}
              onKeyDown={handleKeyDown}
              placeholder={
                isRecognizingSpeech || micHardwareState === 'LISTENING'
                  ? hybridMode === 'DICTATION_MODE'
                    ? 'Dictating into composer... Speak now'
                    : 'Listening to speech... Hinata will reply with voice & text'
                  : micHardwareState === 'STARTING'
                  ? 'Connecting microphone...'
                  : hybridMode === 'DICTATION_MODE'
                  ? "Dictation Mode: speak or edit text (say 'Send this' to send)..."
                  : attachedImage
                  ? 'Ask a question about this image...'
                  : "Message Hinata, or say 'Likho: ...' to dictate (Enter to send)"
              }
              className="w-full bg-transparent text-slate-100 placeholder-slate-500 text-xs sm:text-sm resize-none focus:outline-none max-h-32 px-1"
            />
          </div>

          {/* If speaking: Interrupt Button */}
          {chatState === 'speaking' && (
            <button
              type="button"
              onClick={() => convManager.interrupt()}
              className="px-3 py-2 rounded-2xl bg-rose-950/80 border border-rose-500/50 text-rose-300 hover:bg-rose-900 text-xs font-semibold flex items-center gap-1 active:scale-95 flex-shrink-0"
              title="Stop speech playback immediately"
            >
              <VolumeX className="w-4 h-4" />
              <span className="hidden sm:inline">Stop</span>
            </button>
          )}

          {/* Centralized Microphone Button with Full State Machine Fidelity */}
          <button
            type="button"
            onClick={handleToggleVoiceInput}
            disabled={
              micHardwareState === 'STARTING' ||
              micHardwareState === 'STOPPING' ||
              micHardwareState === 'REQUESTING_PERMISSION'
            }
            className={`p-2.5 rounded-2xl transition-all active:scale-95 flex-shrink-0 ${
              isChatMicActive
                ? hybridMode === 'DICTATION_MODE'
                  ? 'bg-amber-500 text-slate-950 shadow-[0_0_15px_#f59e0b] animate-pulse'
                  : 'bg-cyan-500 text-slate-950 shadow-[0_0_15px_#00e5ff] animate-pulse'
                : micHardwareState === 'STARTING' ||
                  micHardwareState === 'STOPPING' ||
                  micHardwareState === 'REQUESTING_PERMISSION'
                ? 'bg-slate-800 text-cyan-400 cursor-wait'
                : micHardwareState === 'ERROR'
                ? 'bg-rose-950/80 border border-rose-500 text-rose-300'
                : 'text-slate-400 hover:text-cyan-300 hover:bg-cyan-500/10'
            }`}
            title={
              isChatMicActive
                ? 'Stop listening (tap to turn mic OFF)'
                : micHardwareState === 'REQUESTING_PERMISSION'
                ? 'Requesting microphone permission...'
                : micHardwareState === 'STARTING'
                ? 'Starting microphone...'
                : micHardwareState === 'STOPPING'
                ? 'Stopping microphone...'
                : micHardwareState === 'ERROR'
                ? 'Microphone error - tap to retry'
                : hybridMode === 'DICTATION_MODE'
                ? 'Start dictation'
                : 'Speak to Hinata (Voice reply + text)'
            }
          >
            {micHardwareState === 'STARTING' ||
            micHardwareState === 'STOPPING' ||
            micHardwareState === 'REQUESTING_PERMISSION' ? (
              <Loader2 className="w-5 h-5 animate-spin text-cyan-400" />
            ) : isChatMicActive ? (
              <MicOff className="w-5 h-5" />
            ) : micHardwareState === 'ERROR' ? (
              <AlertCircle className="w-5 h-5 text-rose-400" />
            ) : (
              <Mic className="w-5 h-5" />
            )}
          </button>

          {/* Send Button */}
          <button
            type="button"
            onClick={handleSendMessage}
            disabled={(!inputText.trim() && !attachedImage) || chatState === 'thinking'}
            className={`p-2.5 rounded-2xl flex items-center justify-center transition-all flex-shrink-0 ${
              (inputText.trim() || attachedImage) && chatState !== 'thinking'
                ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white shadow-[0_0_15px_rgba(0,229,255,0.6)] active:scale-95'
                : 'bg-slate-900 text-slate-600 cursor-not-allowed'
            }`}
            title="Send message"
          >
            <Send className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* 6. MODAL FOR FULL-SIZE IMAGE PREVIEW */}
      <AnimatePresence>
        {previewModalImage && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/90 backdrop-blur-xl flex flex-col items-center justify-center p-4"
            onClick={() => setPreviewModalImage(null)}
          >
            <button
              onClick={() => setPreviewModalImage(null)}
              className="absolute top-4 right-4 p-2 rounded-full bg-slate-900/80 text-white hover:bg-slate-800"
            >
              <X className="w-6 h-6" />
            </button>
            <img
              src={previewModalImage}
              alt="Enlarged preview"
              className="max-w-full max-h-[85vh] object-contain rounded-2xl border border-cyan-400/40 shadow-2xl"
              onClick={(e) => e.stopPropagation()}
            />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
