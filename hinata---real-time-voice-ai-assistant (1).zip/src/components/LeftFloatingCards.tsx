import React from 'react';
import { motion } from 'motion/react';
import { Radio } from 'lucide-react';
import { LiveSessionState } from '../types';

interface LeftFloatingCardsProps {
  state: LiveSessionState;
  lastTranscript?: string;
  transcriptRole?: 'user' | 'assistant';
  inputVolume?: number;
  outputVolume?: number;
  isMobileCompact?: boolean;
}

export const LeftFloatingCards: React.FC<LeftFloatingCardsProps> = ({
  state,
  lastTranscript,
  transcriptRole,
  inputVolume = 0,
  outputVolume = 0,
  isMobileCompact = false,
}) => {
  const isVoiceActive = state === 'listening' || state === 'speaking';
  const effectiveVol = state === 'speaking' ? outputVolume : inputVolume;

  // Default greeting if no transcript has arrived yet
  const speechText = lastTranscript
    ? lastTranscript
    : "Hey Aman...\nI'm here. Tell me what's on your mind...";

  if (isMobileCompact) {
    return (
      <div className="w-full flex flex-col gap-2 pointer-events-auto select-none px-2">
        <div className="glass-panel rounded-xl px-3 py-2 border border-white/12 shadow-lg backdrop-blur-xl flex items-center justify-between gap-2">
          <div className="flex items-center gap-2 overflow-hidden">
            <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 shadow-[0_0_6px_#22d3ee] animate-pulse flex-shrink-0" />
            <p className="text-xs text-neutral-100 font-medium truncate">
              "{speechText.replace('\n', ' ')}"
            </p>
          </div>
          <div className="flex items-center gap-0.5 h-3 flex-shrink-0">
            {[0, 1, 2, 3].map((bar) => {
              const activeHeight = state === 'speaking'
                ? Math.max(3, Math.min(12, 3 + Math.sin(Date.now() / 150 + bar) * 4 + outputVolume * 10))
                : state === 'listening'
                ? Math.max(3, Math.min(10, 3 + Math.sin(Date.now() / 200 + bar) * 3 + inputVolume * 6))
                : 3;
              return (
                <div
                  key={bar}
                  className="w-0.5 bg-cyan-400 rounded-full transition-all duration-75"
                  style={{
                    height: `${activeHeight}px`,
                    opacity: isVoiceActive ? 0.9 : 0.35,
                  }}
                />
              );
            })}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-4 pointer-events-auto select-none z-30 max-w-[260px] sm:max-w-[280px]">
      {/* Upper Floating Glassmorphism Speech Card */}
      <motion.div
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.6, ease: 'easeOut' }}
        className="glass-panel rounded-2xl p-4 border border-white/12 shadow-[0_8px_32px_rgba(0,0,0,0.5)] backdrop-blur-xl relative overflow-hidden group hover:border-cyan-400/30 transition-all duration-300"
      >
        {/* Subtle cyan glow gradient corner */}
        <div className="absolute -top-8 -right-8 w-24 h-24 bg-cyan-500/15 rounded-full filter blur-xl pointer-events-none" />

        <div className="flex items-start justify-between gap-2 mb-2">
          <span className="text-[11px] font-mono-tech tracking-wider uppercase text-cyan-400/90 font-medium flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 shadow-[0_0_6px_#22d3ee] animate-pulse" />
            {transcriptRole === 'user' ? 'User Speech' : 'Hinata Voice'}
          </span>

          {/* Small animated audio waveform icon */}
          <div className="flex items-center gap-0.5 h-3.5">
            {[0, 1, 2, 3].map((bar) => {
              const activeHeight = state === 'speaking'
                ? Math.max(3, Math.min(14, 4 + Math.sin(Date.now() / 150 + bar) * 6 + outputVolume * 12))
                : state === 'listening'
                ? Math.max(3, Math.min(12, 3 + Math.sin(Date.now() / 200 + bar) * 4 + inputVolume * 8))
                : 3;

              return (
                <div
                  key={bar}
                  className="w-1 bg-cyan-400 rounded-full transition-all duration-75"
                  style={{
                    height: `${activeHeight}px`,
                    opacity: isVoiceActive ? 0.9 : 0.35,
                  }}
                />
              );
            })}
          </div>
        </div>

        {/* Natural voice response quote */}
        <p className="text-sm text-neutral-100 font-normal leading-relaxed whitespace-pre-line tracking-wide">
          "{speechText}"
        </p>
      </motion.div>

      {/* Lower Floating Glassmorphism Voice Active Card */}
      <motion.div
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.6, delay: 0.15, ease: 'easeOut' }}
        className="glass-panel rounded-2xl px-4 py-3 border border-white/12 shadow-[0_8px_32px_rgba(0,0,0,0.5)] backdrop-blur-xl relative overflow-hidden flex items-center justify-between gap-3 hover:border-purple-400/30 transition-all duration-300"
      >
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-cyan-500/20 to-purple-500/20 border border-white/15 flex items-center justify-center">
            <Radio className={`w-4 h-4 ${isVoiceActive ? 'text-cyan-400 animate-pulse' : 'text-neutral-400'}`} />
          </div>
          <div>
            <h4 className="text-xs font-semibold text-white tracking-wide">
              Voice Active
            </h4>
            <div className="flex items-center gap-1.5 mt-0.5">
              <span className={`w-1.5 h-1.5 rounded-full ${isVoiceActive ? 'bg-emerald-400 shadow-[0_0_6px_#34d399]' : 'bg-neutral-500'}`} />
              <span className="text-[11px] text-neutral-400 font-mono-tech">
                Gemini Live
              </span>
            </div>
          </div>
        </div>

        {/* Dynamic audio waveform bars */}
        <div className="flex items-center gap-1 h-5 px-1">
          {[1, 2, 3, 4, 5].map((idx) => {
            const barH = isVoiceActive
              ? Math.max(4, Math.min(20, 6 + Math.sin((idx * 0.8) + (Date.now() / 140)) * 7 + effectiveVol * 14))
              : 4;

            return (
              <div
                key={idx}
                className="w-1 rounded-full bg-gradient-to-t from-cyan-400 to-purple-400 transition-all duration-75"
                style={{
                  height: `${barH}px`,
                  opacity: isVoiceActive ? 0.95 : 0.3,
                }}
              />
            );
          })}
        </div>
      </motion.div>
    </div>
  );
};
