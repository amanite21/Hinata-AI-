import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { PhoneCall, MessageSquare, AlertTriangle, Check, X, ShieldAlert } from 'lucide-react';
import { DeviceActionManager } from '../modules/device/DeviceActionManager';

interface SensitiveActionConfirmationToastProps {
  pendingAction: { id: string; target: string; action: string; prompt?: string } | null;
  onDismiss: () => void;
}

export const SensitiveActionConfirmationToast: React.FC<SensitiveActionConfirmationToastProps> = ({
  pendingAction,
  onDismiss,
}) => {
  const [timeLeft, setTimeLeft] = useState<number>(30);

  useEffect(() => {
    if (!pendingAction) return;
    setTimeLeft(30);
    const interval = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          clearInterval(interval);
          onDismiss();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [pendingAction, onDismiss]);

  if (!pendingAction) return null;

  const isCall = pendingAction.action === 'phone_call';
  const isMessage = pendingAction.action === 'send_message';

  const handleConfirm = async () => {
    await DeviceActionManager.getInstance().confirmAction(true, pendingAction.id);
    onDismiss();
  };

  const handleCancel = async () => {
    await DeviceActionManager.getInstance().confirmAction(false, pendingAction.id);
    onDismiss();
  };

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0, y: 50, scale: 0.95 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        exit={{ opacity: 0, y: 30, scale: 0.95 }}
        className="fixed bottom-24 left-1/2 -translate-x-1/2 z-50 w-[92%] max-w-md rounded-2xl border border-amber-500/40 bg-[#0c1024]/95 backdrop-blur-2xl p-4 shadow-[0_15px_40px_rgba(245,158,11,0.25)] text-white"
      >
        <div className="flex items-start gap-3">
          <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400 shrink-0">
            {isCall ? (
              <PhoneCall className="w-5 h-5" />
            ) : isMessage ? (
              <MessageSquare className="w-5 h-5" />
            ) : (
              <ShieldAlert className="w-5 h-5" />
            )}
          </div>

          <div className="flex-1 min-w-0">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold uppercase tracking-wider text-amber-400 flex items-center gap-1">
                <AlertTriangle className="w-3.5 h-3.5" />
                Confirmation Required
              </span>
              <span className="text-[11px] text-slate-400 font-mono">{timeLeft}s</span>
            </div>

            <h4 className="text-sm font-semibold text-white mt-1">
              {isCall
                ? `Place call to "${pendingAction.target}"?`
                : isMessage
                ? `Send message to "${pendingAction.target}"?`
                : `Execute ${pendingAction.action}?`}
            </h4>
            <p className="text-xs text-slate-300 mt-0.5">
              {pendingAction.prompt || 'Hinata asks for your explicit confirmation before executing sensitive device operations.'}
            </p>

            <div className="flex items-center gap-2 mt-3">
              <button
                id="btn-confirm-sensitive-action"
                onClick={handleConfirm}
                className="flex-1 flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-slate-950 font-semibold text-xs shadow-lg transition-all"
              >
                <Check className="w-4 h-4" />
                Confirm & Proceed
              </button>
              <button
                id="btn-cancel-sensitive-action"
                onClick={handleCancel}
                className="flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl bg-slate-800/80 hover:bg-slate-700/80 text-slate-300 font-medium text-xs border border-white/10 transition-all"
              >
                <X className="w-4 h-4" />
                Cancel
              </button>
            </div>
          </div>
        </div>
      </motion.div>
    </AnimatePresence>
  );
};
