import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Activity, Shield, Cpu, Sparkles, Volume2, Mic, Eye, Smartphone } from 'lucide-react';
import { LiveSessionState } from '../types';

interface MoreModalProps {
  isOpen: boolean;
  onClose: () => void;
  state: LiveSessionState;
  latencyMs: number;
  inputVolume: number;
  outputVolume: number;
  onOpenVision?: () => void;
  onOpenDeviceActions?: () => void;
}

export const MoreModal: React.FC<MoreModalProps> = ({
  isOpen,
  onClose,
  state,
  latencyMs,
  inputVolume,
  outputVolume,
  onOpenVision,
  onOpenDeviceActions,
}) => {
  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-md select-none">
          <motion.div
            initial={{ opacity: 0, scale: 0.94 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.94 }}
            className="w-full max-w-md glass-panel rounded-3xl p-6 border border-white/15 shadow-[0_16px_50px_rgba(0,0,0,0.8)] relative overflow-hidden"
          >
            {/* Header */}
            <div className="flex items-center justify-between pb-4 border-b border-white/10 mb-4">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-purple-500/20 border border-purple-400/30 flex items-center justify-center text-purple-400">
                  <Activity className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white font-mono-tech">
                    System Telemetry
                  </h3>
                  <p className="text-xs text-neutral-400">
                    Hinata Live Neural Core
                  </p>
                </div>
              </div>
              <button
                onClick={onClose}
                className="w-8 h-8 rounded-full glass-button flex items-center justify-center text-neutral-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Metrics Grid */}
            <div className="grid grid-cols-2 gap-3 mb-4">
              <div className="p-3.5 rounded-2xl bg-white/5 border border-white/8 flex flex-col gap-1">
                <span className="text-[11px] font-mono-tech text-neutral-400 uppercase tracking-wider">
                  Session State
                </span>
                <span className="text-sm font-bold text-cyan-300 capitalize">
                  {state}
                </span>
              </div>

              <div className="p-3.5 rounded-2xl bg-white/5 border border-white/8 flex flex-col gap-1">
                <span className="text-[11px] font-mono-tech text-neutral-400 uppercase tracking-wider">
                  Live Latency
                </span>
                <span className="text-sm font-bold text-emerald-300 font-mono">
                  {latencyMs > 0 ? `${latencyMs} ms` : 'Ultra-Low'}
                </span>
              </div>

              <div className="p-3.5 rounded-2xl bg-white/5 border border-white/8 flex flex-col gap-1">
                <div className="flex items-center justify-between text-[11px] font-mono-tech text-neutral-400 uppercase tracking-wider">
                  <span className="flex items-center gap-1">
                    <Mic className="w-3 h-3 text-cyan-400" /> Mic Input
                  </span>
                  <span>{Math.round(inputVolume * 100)}%</span>
                </div>
                <div className="w-full h-1.5 rounded-full bg-white/10 overflow-hidden mt-1">
                  <div
                    className="h-full bg-cyan-400 rounded-full transition-all duration-75"
                    style={{ width: `${Math.min(100, inputVolume * 100)}%` }}
                  />
                </div>
              </div>

              <div className="p-3.5 rounded-2xl bg-white/5 border border-white/8 flex flex-col gap-1">
                <div className="flex items-center justify-between text-[11px] font-mono-tech text-neutral-400 uppercase tracking-wider">
                  <span className="flex items-center gap-1">
                    <Volume2 className="w-3 h-3 text-purple-400" /> Audio Output
                  </span>
                  <span>{Math.round(outputVolume * 100)}%</span>
                </div>
                <div className="w-full h-1.5 rounded-full bg-white/10 overflow-hidden mt-1">
                  <div
                    className="h-full bg-purple-400 rounded-full transition-all duration-75"
                    style={{ width: `${Math.min(100, outputVolume * 100)}%` }}
                  />
                </div>
              </div>
            </div>

            {/* Core Capabilities */}
            <div className="p-4 rounded-2xl bg-gradient-to-tr from-cyan-950/30 to-purple-950/30 border border-white/10 flex flex-col gap-2 mb-4">
              <div className="flex items-center gap-2 text-xs font-semibold text-neutral-200">
                <Shield className="w-3.5 h-3.5 text-cyan-400" />
                Adaptive Emotional Engine
              </div>
              <p className="text-xs text-neutral-300 leading-relaxed">
                Hinata reacts dynamically to your voice, conversation context, and emotional nuance with seamless lip-sync, expressive gaze, and holographic visual state shifts.
              </p>
            </div>

            {onOpenDeviceActions && (
              <button
                id="btn-more-device-actions"
                onClick={() => {
                  onClose();
                  onOpenDeviceActions();
                }}
                className="w-full mb-2.5 py-2.5 px-4 rounded-xl bg-emerald-950/60 border border-emerald-500/40 text-emerald-300 font-medium text-xs flex items-center justify-center gap-2 hover:bg-emerald-900/60 transition-all shadow-[0_0_15px_rgba(16,185,129,0.2)]"
              >
                <Smartphone className="w-4 h-4 text-emerald-400" />
                <span>Device Control & Automation Hub</span>
              </button>
            )}

            {onOpenVision && (
              <button
                onClick={() => {
                  onClose();
                  onOpenVision();
                }}
                className="w-full mb-3 py-2.5 px-4 rounded-xl bg-cyan-950/60 border border-cyan-500/40 text-cyan-300 font-medium text-xs flex items-center justify-center gap-2 hover:bg-cyan-900/60 transition-all shadow-[0_0_15px_rgba(0,229,255,0.2)]"
              >
                <Eye className="w-4 h-4 text-cyan-300" />
                <span>Open Visual Design Studio</span>
              </button>
            )}

            {/* Close Button */}
            <button
              onClick={onClose}
              className="w-full py-2.5 rounded-xl bg-gradient-to-r from-cyan-600 to-purple-600 text-white font-medium text-xs tracking-wider uppercase hover:opacity-95 transition-opacity"
            >
              Done
            </button>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
