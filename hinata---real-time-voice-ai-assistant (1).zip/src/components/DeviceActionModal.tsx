import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Smartphone,
  X,
  Compass,
  ListOrdered,
  ShieldCheck,
  Send,
  ExternalLink,
  Youtube,
  MessageSquare,
  Camera,
  Image as ImageIcon,
  Settings,
  MapPin,
  Music,
  Wifi,
  Bluetooth,
  Clock,
  Navigation,
  CheckCircle2,
  AlertCircle,
  Loader2,
  Info,
  Flashlight,
  Volume2,
} from 'lucide-react';
import { DeviceActionManager } from '../modules/device/DeviceActionManager';
import { TaskPlanner } from '../modules/task/TaskPlanner';
import { PermissionManager } from '../modules/device/PermissionManager';
import { HinataBrain } from '../modules/HinataBrain';
import { TaskPlan, DeviceActionResult } from '../modules/device/types';

interface DeviceActionModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const DeviceActionModal: React.FC<DeviceActionModalProps> = ({ isOpen, onClose }) => {
  const [activeTab, setActiveTab] = useState<'actions' | 'planner' | 'security' | 'console'>('actions');
  const [naturalCommand, setNaturalCommand] = useState<string>('');
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [lastResult, setLastResult] = useState<DeviceActionResult | null>(null);
  const [activePlan, setActivePlan] = useState<TaskPlan | null>(() => TaskPlanner.getInstance().getActivePlan());

  const dam = DeviceActionManager.getInstance();
  const planner = TaskPlanner.getInstance();
  const pm = PermissionManager.getInstance();
  const brain = HinataBrain.getInstance();

  useEffect(() => {
    return planner.subscribe((plan) => {
      setActivePlan(plan);
    });
  }, [planner]);

  if (!isOpen) return null;

  const handleExecuteQuickAction = async (action: string, target?: string, extra?: any) => {
    setIsProcessing(true);
    try {
      const res = await dam.executeAction(action as any, { target, ...extra });
      setLastResult(res);
    } catch (err: any) {
      setLastResult({
        success: false,
        action: action as any,
        message: err.message,
        timestamp: Date.now(),
      });
    } finally {
      setIsProcessing(false);
    }
  };

  const handleRunCommand = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!naturalCommand.trim() || isProcessing) return;
    setIsProcessing(true);

    try {
      const res = await brain.processNaturalCommand(naturalCommand);
      if (res.result) {
        setLastResult(res.result);
      } else if (res.clarificationNeeded) {
        setLastResult({
          success: false,
          action: 'in_app_action',
          message: res.clarificationPrompt || 'Needs clarification.',
          timestamp: Date.now(),
        });
      } else {
        setLastResult({
          success: true,
          action: 'in_app_action',
          message: `Processed command: "${naturalCommand}"`,
          timestamp: Date.now(),
        });
      }
      setNaturalCommand('');
    } catch (err: any) {
      setLastResult({
        success: false,
        action: 'in_app_action',
        message: err.message,
        timestamp: Date.now(),
      });
    } finally {
      setIsProcessing(false);
    }
  };

  const handlePlanTask = async (taskText: string) => {
    setIsProcessing(true);
    try {
      planner.createPlan(taskText);
      const res = await planner.executeActivePlan();
      setLastResult(res);
      setActiveTab('planner');
    } catch (err: any) {
      setLastResult({
        success: false,
        action: 'task_plan',
        message: err.message,
        timestamp: Date.now(),
      });
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/80 backdrop-blur-md">
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          className="relative w-full max-w-2xl max-h-[90vh] bg-[#070b1c] border border-cyan-500/30 rounded-3xl shadow-[0_0_50px_rgba(0,229,255,0.15)] flex flex-col overflow-hidden text-slate-100"
        >
          {/* Header */}
          <div className="flex items-center justify-between px-6 py-4 border-b border-white/10 bg-white/[0.02]">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-cyan-500/20 border border-cyan-500/40 flex items-center justify-center text-cyan-400">
                <Smartphone className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-semibold text-white tracking-wide">
                  Device Control & Actions Hub
                </h3>
                <p className="text-xs text-slate-400">
                  Safe Android Intents, App Launching, Hardware & Task Planning
                </p>
              </div>
            </div>

            <button
              id="btn-close-device-modal"
              onClick={onClose}
              className="w-8 h-8 rounded-full bg-white/5 hover:bg-white/10 flex items-center justify-center text-slate-400 hover:text-white transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Navigation Tabs */}
          <div className="flex items-center px-6 pt-3 border-b border-white/5 gap-2 overflow-x-auto scrollbar-none">
            <button
              id="tab-device-actions"
              onClick={() => setActiveTab('actions')}
              className={`flex items-center gap-2 px-3.5 py-2 text-xs font-medium rounded-t-xl transition-all border-b-2 ${
                activeTab === 'actions'
                  ? 'border-cyan-400 text-cyan-300 bg-cyan-500/10'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              <Smartphone className="w-3.5 h-3.5" />
              Quick Actions
            </button>
            <button
              id="tab-device-planner"
              onClick={() => setActiveTab('planner')}
              className={`flex items-center gap-2 px-3.5 py-2 text-xs font-medium rounded-t-xl transition-all border-b-2 ${
                activeTab === 'planner'
                  ? 'border-cyan-400 text-cyan-300 bg-cyan-500/10'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              <ListOrdered className="w-3.5 h-3.5" />
              Task Planner
              {activePlan && (
                <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
              )}
            </button>
            <button
              id="tab-device-security"
              onClick={() => setActiveTab('security')}
              className={`flex items-center gap-2 px-3.5 py-2 text-xs font-medium rounded-t-xl transition-all border-b-2 ${
                activeTab === 'security'
                  ? 'border-cyan-400 text-cyan-300 bg-cyan-500/10'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              <ShieldCheck className="w-3.5 h-3.5" />
              Permissions & Safety
            </button>
            <button
              id="tab-device-console"
              onClick={() => setActiveTab('console')}
              className={`flex items-center gap-2 px-3.5 py-2 text-xs font-medium rounded-t-xl transition-all border-b-2 ${
                activeTab === 'console'
                  ? 'border-cyan-400 text-cyan-300 bg-cyan-500/10'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              <Send className="w-3.5 h-3.5" />
              Natural Command Test
            </button>
          </div>

          {/* Body Area */}
          <div className="flex-1 overflow-y-auto p-6 space-y-5">
            {/* Last Action Result Banner */}
            {lastResult && (
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                className={`p-3.5 rounded-2xl border flex items-start gap-3 ${
                  lastResult.success
                    ? 'border-emerald-500/30 bg-emerald-500/10 text-emerald-300'
                    : 'border-amber-500/30 bg-amber-500/10 text-amber-300'
                }`}
              >
                {lastResult.success ? (
                  <CheckCircle2 className="w-5 h-5 shrink-0 mt-0.5 text-emerald-400" />
                ) : (
                  <AlertCircle className="w-5 h-5 shrink-0 mt-0.5 text-amber-400" />
                )}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-semibold uppercase tracking-wider">
                      {lastResult.action.replace('_', ' ')}: {lastResult.target || 'Device'}
                    </span>
                    <span className="text-[10px] opacity-70">
                      {new Date(lastResult.timestamp).toLocaleTimeString()}
                    </span>
                  </div>
                  <p className="text-xs mt-0.5 text-slate-200">{lastResult.message}</p>
                </div>
              </motion.div>
            )}

            {/* TAB 1: Quick Actions */}
            {activeTab === 'actions' && (
              <div className="space-y-5">
                {/* Apps Section */}
                <div>
                  <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2.5 flex items-center gap-1.5">
                    <Smartphone className="w-3.5 h-3.5 text-cyan-400" />
                    Android App Launchers (Intent + Fallback)
                  </h4>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                    <button
                      id="action-app-youtube"
                      onClick={() => handleExecuteQuickAction('open_app', 'YouTube')}
                      className="p-3 rounded-2xl border border-white/10 bg-white/[0.03] hover:bg-white/[0.08] hover:border-red-500/40 flex items-center gap-2.5 transition-all text-left group"
                    >
                      <div className="w-8 h-8 rounded-xl bg-red-500/20 text-red-400 flex items-center justify-center shrink-0">
                        <Youtube className="w-4 h-4" />
                      </div>
                      <div className="min-w-0">
                        <div className="text-xs font-medium text-white group-hover:text-red-300 truncate">YouTube</div>
                        <div className="text-[10px] text-slate-400 truncate">Watch & Search</div>
                      </div>
                    </button>

                    <button
                      id="action-app-camera"
                      onClick={() => handleExecuteQuickAction('open_camera')}
                      className="p-3 rounded-2xl border border-white/10 bg-white/[0.03] hover:bg-white/[0.08] hover:border-cyan-500/40 flex items-center gap-2.5 transition-all text-left group"
                    >
                      <div className="w-8 h-8 rounded-xl bg-cyan-500/20 text-cyan-400 flex items-center justify-center shrink-0">
                        <Camera className="w-4 h-4" />
                      </div>
                      <div className="min-w-0">
                        <div className="text-xs font-medium text-white group-hover:text-cyan-300 truncate">Camera</div>
                        <div className="text-[10px] text-slate-400 truncate">Capture Photos</div>
                      </div>
                    </button>

                    <button
                      id="action-app-gallery"
                      onClick={() => handleExecuteQuickAction('open_gallery')}
                      className="p-3 rounded-2xl border border-white/10 bg-white/[0.03] hover:bg-white/[0.08] hover:border-purple-500/40 flex items-center gap-2.5 transition-all text-left group"
                    >
                      <div className="w-8 h-8 rounded-xl bg-purple-500/20 text-purple-400 flex items-center justify-center shrink-0">
                        <ImageIcon className="w-4 h-4" />
                      </div>
                      <div className="min-w-0">
                        <div className="text-xs font-medium text-white group-hover:text-purple-300 truncate">Gallery</div>
                        <div className="text-[10px] text-slate-400 truncate">Browse Media</div>
                      </div>
                    </button>

                    <button
                      id="action-app-maps"
                      onClick={() => handleExecuteQuickAction('open_maps', 'current_location')}
                      className="p-3 rounded-2xl border border-white/10 bg-white/[0.03] hover:bg-white/[0.08] hover:border-emerald-500/40 flex items-center gap-2.5 transition-all text-left group"
                    >
                      <div className="w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0">
                        <MapPin className="w-4 h-4" />
                      </div>
                      <div className="min-w-0">
                        <div className="text-xs font-medium text-white group-hover:text-emerald-300 truncate">Google Maps</div>
                        <div className="text-[10px] text-slate-400 truncate">GPS & Nearby</div>
                      </div>
                    </button>

                    <button
                      id="action-app-whatsapp"
                      onClick={() => handleExecuteQuickAction('open_app', 'WhatsApp')}
                      className="p-3 rounded-2xl border border-white/10 bg-white/[0.03] hover:bg-white/[0.08] hover:border-green-500/40 flex items-center gap-2.5 transition-all text-left group"
                    >
                      <div className="w-8 h-8 rounded-xl bg-green-500/20 text-green-400 flex items-center justify-center shrink-0">
                        <MessageSquare className="w-4 h-4" />
                      </div>
                      <div className="min-w-0">
                        <div className="text-xs font-medium text-white group-hover:text-green-300 truncate">WhatsApp</div>
                        <div className="text-[10px] text-slate-400 truncate">Chat & Audio</div>
                      </div>
                    </button>

                    <button
                      id="action-app-spotify"
                      onClick={() => handleExecuteQuickAction('open_app', 'Spotify')}
                      className="p-3 rounded-2xl border border-white/10 bg-white/[0.03] hover:bg-white/[0.08] hover:border-emerald-400/40 flex items-center gap-2.5 transition-all text-left group"
                    >
                      <div className="w-8 h-8 rounded-xl bg-emerald-400/20 text-emerald-400 flex items-center justify-center shrink-0">
                        <Music className="w-4 h-4" />
                      </div>
                      <div className="min-w-0">
                        <div className="text-xs font-medium text-white group-hover:text-emerald-300 truncate">Spotify</div>
                        <div className="text-[10px] text-slate-400 truncate">Playback</div>
                      </div>
                    </button>

                    <button
                      id="action-app-settings"
                      onClick={() => handleExecuteQuickAction('system_setting', 'settings')}
                      className="p-3 rounded-2xl border border-white/10 bg-white/[0.03] hover:bg-white/[0.08] hover:border-slate-400 flex items-center gap-2.5 transition-all text-left group"
                    >
                      <div className="w-8 h-8 rounded-xl bg-slate-500/20 text-slate-300 flex items-center justify-center shrink-0">
                        <Settings className="w-4 h-4" />
                      </div>
                      <div className="min-w-0">
                        <div className="text-xs font-medium text-white group-hover:text-slate-300 truncate">Settings</div>
                        <div className="text-[10px] text-slate-400 truncate">System Config</div>
                      </div>
                    </button>

                    <button
                      id="action-app-torch"
                      onClick={() => handleExecuteQuickAction('torch')}
                      className="p-3 rounded-2xl border border-white/10 bg-white/[0.03] hover:bg-white/[0.08] hover:border-amber-400 flex items-center gap-2.5 transition-all text-left group"
                    >
                      <div className="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center shrink-0">
                        <Flashlight className="w-4 h-4" />
                      </div>
                      <div className="min-w-0">
                        <div className="text-xs font-medium text-white group-hover:text-amber-300 truncate">Flashlight</div>
                        <div className="text-[10px] text-slate-400 truncate">Toggle Torch</div>
                      </div>
                    </button>
                  </div>
                </div>

                {/* System Settings & Hardware Controls */}
                <div>
                  <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2.5 flex items-center gap-1.5">
                    <Wifi className="w-3.5 h-3.5 text-cyan-400" />
                    Android System Controls
                  </h4>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                    <button
                      id="action-system-wifi"
                      onClick={() => handleExecuteQuickAction('system_setting', 'wifi')}
                      className="p-3 rounded-2xl border border-white/10 bg-white/[0.03] hover:bg-cyan-500/10 hover:border-cyan-500/30 flex items-center gap-2.5 transition-all text-left"
                    >
                      <Wifi className="w-4 h-4 text-cyan-400 shrink-0" />
                      <div className="min-w-0">
                        <div className="text-xs font-medium text-white">Wi-Fi Settings</div>
                        <div className="text-[10px] text-slate-400">android.settings.WIFI_SETTINGS</div>
                      </div>
                    </button>

                    <button
                      id="action-system-bluetooth"
                      onClick={() => handleExecuteQuickAction('system_setting', 'bluetooth')}
                      className="p-3 rounded-2xl border border-white/10 bg-white/[0.03] hover:bg-blue-500/10 hover:border-blue-500/30 flex items-center gap-2.5 transition-all text-left"
                    >
                      <Bluetooth className="w-4 h-4 text-blue-400 shrink-0" />
                      <div className="min-w-0">
                        <div className="text-xs font-medium text-white">Bluetooth</div>
                        <div className="text-[10px] text-slate-400">BLUETOOTH_SETTINGS</div>
                      </div>
                    </button>

                    <button
                      id="action-system-alarm"
                      onClick={() => handleExecuteQuickAction('set_alarm', undefined, { hours: 7, minutes: 0 })}
                      className="p-3 rounded-2xl border border-white/10 bg-white/[0.03] hover:bg-purple-500/10 hover:border-purple-500/30 flex items-center gap-2.5 transition-all text-left"
                    >
                      <Clock className="w-4 h-4 text-purple-400 shrink-0" />
                      <div className="min-w-0">
                        <div className="text-xs font-medium text-white">Set 7:00 AM Alarm</div>
                        <div className="text-[10px] text-slate-400">SET_ALARM Intent</div>
                      </div>
                    </button>
                  </div>
                </div>

                {/* Multi-step sample prompts */}
                <div className="p-4 rounded-2xl border border-cyan-500/20 bg-cyan-950/20">
                  <h4 className="text-xs font-semibold text-cyan-300 mb-2 flex items-center gap-1.5">
                    <Navigation className="w-3.5 h-3.5" />
                    Try Multi-Step Task Sequences
                  </h4>
                  <div className="flex flex-wrap gap-2">
                    <button
                      onClick={() => handlePlanTask('Open Maps and navigate to the nearest hospital')}
                      className="px-3 py-1.5 rounded-xl border border-cyan-500/30 bg-cyan-500/10 hover:bg-cyan-500/20 text-xs text-cyan-200 transition-colors"
                    >
                      "Open Maps & navigate to nearest hospital"
                    </button>
                    <button
                      onClick={() => handlePlanTask('Open YouTube and search Python tutorials')}
                      className="px-3 py-1.5 rounded-xl border border-cyan-500/30 bg-cyan-500/10 hover:bg-cyan-500/20 text-xs text-cyan-200 transition-colors"
                    >
                      "Open YouTube & search Python tutorials"
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* TAB 2: Task Planner */}
            {activeTab === 'planner' && (
              <div className="space-y-4">
                <div className="p-4 rounded-2xl border border-white/10 bg-white/[0.02]">
                  <h4 className="text-sm font-semibold text-white mb-1">
                    Multi-Step Task Execution
                  </h4>
                  <p className="text-xs text-slate-400">
                    Hinata breaks down multi-intent user instructions into sequential, verified steps.
                  </p>
                </div>

                {activePlan ? (
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-xl border border-cyan-500/30 bg-cyan-500/5">
                      <div>
                        <div className="text-xs font-semibold text-cyan-300">Active Task Plan</div>
                        <div className="text-sm font-medium text-white">{activePlan.summary}</div>
                      </div>
                      <span
                        className={`text-xs px-2.5 py-1 rounded-full font-semibold uppercase ${
                          activePlan.status === 'completed'
                            ? 'bg-emerald-500/20 text-emerald-400'
                            : activePlan.status === 'executing'
                            ? 'bg-cyan-500/20 text-cyan-300 animate-pulse'
                            : activePlan.status === 'failed'
                            ? 'bg-rose-500/20 text-rose-400'
                            : 'bg-slate-500/20 text-slate-300'
                        }`}
                      >
                        {activePlan.status}
                      </span>
                    </div>

                    <div className="space-y-2">
                      {activePlan.steps.map((step, idx) => (
                        <div
                          key={step.id}
                          className={`p-3 rounded-xl border flex items-center justify-between gap-3 ${
                            step.status === 'completed'
                              ? 'border-emerald-500/20 bg-emerald-500/[0.03]'
                              : step.status === 'executing'
                              ? 'border-cyan-500/40 bg-cyan-500/10'
                              : 'border-white/5 bg-white/[0.01]'
                          }`}
                        >
                          <div className="flex items-center gap-3">
                            <span className="w-6 h-6 rounded-full bg-white/10 flex items-center justify-center text-xs font-mono text-slate-300">
                              {idx + 1}
                            </span>
                            <div>
                              <div className="text-xs font-medium text-white">{step.title}</div>
                              <div className="text-[11px] text-slate-400">{step.description}</div>
                            </div>
                          </div>

                          <div>
                            {step.status === 'completed' && (
                              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                            )}
                            {step.status === 'executing' && (
                              <Loader2 className="w-4 h-4 text-cyan-400 animate-spin" />
                            )}
                            {step.status === 'failed' && (
                              <AlertCircle className="w-4 h-4 text-rose-400" />
                            )}
                            {step.status === 'pending' && (
                              <span className="text-[10px] text-slate-500">Pending</span>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                ) : (
                  <div className="p-8 text-center border border-dashed border-white/10 rounded-2xl text-slate-400">
                    <ListOrdered className="w-8 h-8 mx-auto mb-2 text-slate-600" />
                    <p className="text-xs">No active task plan running.</p>
                    <p className="text-[11px] text-slate-500 mt-1">
                      Give Hinata a compound command like "Open Maps and navigate to nearest hospital" to generate a plan.
                    </p>
                  </div>
                )}
              </div>
            )}

            {/* TAB 3: Permissions & Security */}
            {activeTab === 'security' && (
              <div className="space-y-4">
                <div className="p-4 rounded-2xl border border-emerald-500/30 bg-emerald-500/10">
                  <div className="flex items-center gap-2 text-emerald-400 font-semibold text-xs mb-1">
                    <ShieldCheck className="w-4 h-4" />
                    Safe Android Architecture & Privacy Directives
                  </div>
                  <ul className="text-xs text-slate-300 space-y-1 mt-2 list-disc list-inside">
                    <li>Explicit confirmation required for all phone calls and text messages.</li>
                    <li>No financial, bank-account, or password actions are ever performed automatically.</li>
                    <li>Action Verification: No hallucinated execution. Exact real-world results are reported.</li>
                    <li>Never silently records microphone or monitors unrelated applications.</li>
                  </ul>
                </div>

                <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-400">
                  Device Permission Status
                </h4>

                <div className="space-y-2.5">
                  {(
                    [
                      { key: 'microphone', name: 'Microphone Access', icon: Volume2 },
                      { key: 'camera', name: 'Camera Access', icon: Camera },
                      { key: 'geolocation', name: 'GPS Location', icon: MapPin },
                      { key: 'notifications', name: 'System Notifications', icon: AlertCircle },
                      { key: 'accessibility', name: 'In-App Automation Sandbox', icon: Smartphone },
                    ] as const
                  ).map((perm) => {
                    const status = pm.getPermissionStatus(perm.key as any);
                    const explanation = pm.getPermissionExplanation(perm.key as any);
                    const Icon = perm.icon;

                    return (
                      <div
                        key={perm.key}
                        className="p-3.5 rounded-2xl border border-white/5 bg-white/[0.02] flex items-start justify-between gap-3"
                      >
                        <div className="flex items-start gap-3">
                          <div className="w-8 h-8 rounded-xl bg-white/5 flex items-center justify-center text-cyan-300 shrink-0">
                            <Icon className="w-4 h-4" />
                          </div>
                          <div>
                            <div className="text-xs font-semibold text-white">{perm.name}</div>
                            <div className="text-[11px] text-slate-400 mt-0.5">{explanation}</div>
                          </div>
                        </div>

                        <span
                          className={`text-[10px] font-semibold px-2 py-0.5 rounded-full shrink-0 uppercase tracking-wider ${
                            status === 'granted'
                              ? 'bg-emerald-500/20 text-emerald-400'
                              : 'bg-slate-700/50 text-slate-400'
                          }`}
                        >
                          {status}
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* TAB 4: Natural Command Console */}
            {activeTab === 'console' && (
              <div className="space-y-4">
                <p className="text-xs text-slate-300">
                  Test Hinata's Smart Conversational Intelligence directly with natural language commands.
                </p>

                <form onSubmit={handleRunCommand} className="space-y-3">
                  <div className="relative">
                    <input
                      id="input-natural-command"
                      type="text"
                      value={naturalCommand}
                      onChange={(e) => setNaturalCommand(e.target.value)}
                      placeholder='e.g. "Open YouTube", "Call Mom", "Turn on Wi-Fi", "Open it"'
                      className="w-full px-4 py-3 rounded-2xl bg-white/5 border border-cyan-500/30 text-white placeholder-slate-500 text-xs focus:outline-none focus:border-cyan-400 pr-10"
                    />
                    <button
                      id="btn-submit-command"
                      type="submit"
                      disabled={isProcessing || !naturalCommand.trim()}
                      className="absolute right-2 top-1/2 -translate-y-1/2 p-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 disabled:opacity-40 transition-all"
                    >
                      {isProcessing ? (
                        <Loader2 className="w-4 h-4 animate-spin" />
                      ) : (
                        <Send className="w-4 h-4" />
                      )}
                    </button>
                  </div>

                  <div className="flex flex-wrap gap-1.5 text-[11px]">
                    <span className="text-slate-500">Quick tests:</span>
                    <button
                      type="button"
                      onClick={() => setNaturalCommand('Open YouTube')}
                      className="text-cyan-400 hover:underline"
                    >
                      "Open YouTube"
                    </button>
                    <span className="text-slate-600">•</span>
                    <button
                      type="button"
                      onClick={() => setNaturalCommand('Call Mom')}
                      className="text-cyan-400 hover:underline"
                    >
                      "Call Mom"
                    </button>
                    <span className="text-slate-600">•</span>
                    <button
                      type="button"
                      onClick={() => setNaturalCommand('Set an alarm for 7 AM')}
                      className="text-cyan-400 hover:underline"
                    >
                      "Set an alarm for 7 AM"
                    </button>
                    <span className="text-slate-600">•</span>
                    <button
                      type="button"
                      onClick={() => setNaturalCommand('Open it')}
                      className="text-cyan-400 hover:underline"
                    >
                      "Open it" (Pronoun Resolution)
                    </button>
                  </div>
                </form>
              </div>
            )}
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
