import React, { useEffect, useRef } from 'react';
import { LiveSessionState, EmotionalState } from '../types';
import { EMOTION_CONFIGS } from '../modules/EmotionManager';

interface WaveformVisualizerProps {
  state: LiveSessionState;
  mood: EmotionalState;
  getFrequencyData?: () => Uint8Array;
  getTimeDomainData?: () => Uint8Array;
  inputVolume?: number;
  outputVolume?: number;
  className?: string;
}

export const WaveformVisualizer: React.FC<WaveformVisualizerProps> = ({
  state,
  mood,
  getFrequencyData,
  getTimeDomainData,
  inputVolume = 0,
  outputVolume = 0,
  className = '',
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const animFrameIdRef = useRef<number | null>(null);
  const phaseRef = useRef<number>(0);

  const emotionConfig = EMOTION_CONFIGS[mood] || EMOTION_CONFIGS.neutral;

  // Determine color palette based on emotion and voice state
  const getColors = () => {
    if (state === 'disconnected') {
      return {
        primary: 'rgba(148, 163, 184, 0.35)',
        secondary: 'rgba(100, 116, 139, 0.12)',
        glow: 'rgba(148, 163, 184, 0.1)',
      };
    }
    if (state === 'connecting') {
      return {
        primary: 'rgba(192, 132, 252, 0.85)',
        secondary: 'rgba(147, 51, 234, 0.35)',
        glow: 'rgba(168, 85, 247, 0.45)',
      };
    }

    switch (mood) {
      case 'happy':
        return {
          primary: 'rgba(251, 191, 36, 0.95)',
          secondary: 'rgba(244, 114, 182, 0.4)',
          glow: 'rgba(251, 191, 36, 0.55)',
        };
      case 'excited':
        return {
          primary: 'rgba(244, 63, 94, 0.95)',
          secondary: 'rgba(56, 189, 248, 0.45)',
          glow: 'rgba(244, 63, 94, 0.6)',
        };
      case 'curious':
        return {
          primary: 'rgba(168, 85, 247, 0.95)',
          secondary: 'rgba(45, 212, 191, 0.4)',
          glow: 'rgba(168, 85, 247, 0.5)',
        };
      case 'amused':
        return {
          primary: 'rgba(236, 72, 153, 0.95)',
          secondary: 'rgba(251, 191, 36, 0.4)',
          glow: 'rgba(236, 72, 153, 0.55)',
        };
      case 'calm':
        return {
          primary: 'rgba(45, 212, 191, 0.9)',
          secondary: 'rgba(56, 189, 248, 0.3)',
          glow: 'rgba(45, 212, 191, 0.4)',
        };
      case 'confident':
        return {
          primary: 'rgba(14, 165, 233, 0.95)',
          secondary: 'rgba(16, 185, 129, 0.4)',
          glow: 'rgba(14, 165, 233, 0.5)',
        };
      case 'empathetic':
        return {
          primary: 'rgba(244, 114, 182, 0.9)',
          secondary: 'rgba(167, 139, 250, 0.35)',
          glow: 'rgba(244, 114, 182, 0.45)',
        };
      case 'concerned':
        return {
          primary: 'rgba(249, 115, 22, 0.9)',
          secondary: 'rgba(234, 179, 8, 0.35)',
          glow: 'rgba(249, 115, 22, 0.5)',
        };
      case 'serious':
        return {
          primary: 'rgba(100, 116, 139, 0.85)',
          secondary: 'rgba(59, 130, 246, 0.3)',
          glow: 'rgba(100, 116, 139, 0.35)',
        };
      case 'playful':
        return {
          primary: 'rgba(217, 70, 239, 0.95)',
          secondary: 'rgba(6, 182, 212, 0.4)',
          glow: 'rgba(217, 70, 239, 0.55)',
        };
      case 'affectionate':
        return {
          primary: 'rgba(251, 113, 133, 0.95)',
          secondary: 'rgba(251, 191, 36, 0.45)',
          glow: 'rgba(251, 113, 133, 0.58)',
        };
      case 'jealous':
        return {
          primary: 'rgba(192, 132, 252, 0.95)',
          secondary: 'rgba(244, 63, 94, 0.45)',
          glow: 'rgba(192, 132, 252, 0.55)',
        };
      case 'annoyed':
        return {
          primary: 'rgba(245, 158, 11, 0.95)',
          secondary: 'rgba(239, 68, 68, 0.4)',
          glow: 'rgba(245, 158, 11, 0.52)',
        };
      case 'angry':
        return {
          primary: 'rgba(239, 68, 68, 0.95)',
          secondary: 'rgba(185, 28, 28, 0.45)',
          glow: 'rgba(239, 68, 68, 0.65)',
        };
      case 'frustrated':
        return {
          primary: 'rgba(249, 115, 22, 0.95)',
          secondary: 'rgba(220, 38, 38, 0.4)',
          glow: 'rgba(249, 115, 22, 0.55)',
        };
      case 'surprised':
        return {
          primary: 'rgba(6, 182, 212, 0.95)',
          secondary: 'rgba(250, 204, 21, 0.45)',
          glow: 'rgba(6, 182, 212, 0.6)',
        };
      case 'embarrassed':
        return {
          primary: 'rgba(244, 114, 182, 0.95)',
          secondary: 'rgba(216, 180, 254, 0.4)',
          glow: 'rgba(244, 114, 182, 0.52)',
        };
      case 'proud':
        return {
          primary: 'rgba(167, 139, 250, 0.95)',
          secondary: 'rgba(251, 191, 36, 0.45)',
          glow: 'rgba(167, 139, 250, 0.58)',
        };
      case 'disappointed':
        return {
          primary: 'rgba(148, 163, 184, 0.85)',
          secondary: 'rgba(71, 85, 105, 0.35)',
          glow: 'rgba(148, 163, 184, 0.35)',
        };
      case 'relieved':
        return {
          primary: 'rgba(52, 211, 153, 0.95)',
          secondary: 'rgba(45, 212, 191, 0.4)',
          glow: 'rgba(52, 211, 153, 0.5)',
        };
      case 'neutral':
      default:
        return {
          primary: 'rgba(129, 140, 248, 0.9)',
          secondary: 'rgba(56, 189, 248, 0.35)',
          glow: 'rgba(129, 140, 248, 0.45)',
        };
    }
  };

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let dpr = window.devicePixelRatio || 1;

    const updateSize = () => {
      const rect = canvas.getBoundingClientRect();
      canvas.width = rect.width * dpr;
      canvas.height = rect.height * dpr;
      ctx.scale(dpr, dpr);
    };

    updateSize();
    const resizeObserver = new ResizeObserver(() => updateSize());
    resizeObserver.observe(canvas);

    const render = () => {
      const rect = canvas.getBoundingClientRect();
      const width = rect.width;
      const height = rect.height;

      ctx.clearRect(0, 0, width, height);

      const colors = getColors();
      const speed = 0.035 * (emotionConfig.waveformSpeed || 1.0);
      phaseRef.current += speed;

      const activeVol =
        state === 'speaking'
          ? Math.max(0.1, outputVolume)
          : state === 'listening'
          ? Math.max(0.08, inputVolume)
          : 0.04;

      // Draw mirrored harmonic multi-layer wave
      const centerY = height / 2;
      const points = 48;
      const step = width / points;

      const freqData = getFrequencyData ? getFrequencyData() : null;
      const hasRealAudio = freqData && freqData.length > 0 && activeVol > 0.05;

      // Draw background harmonic wave
      ctx.beginPath();
      for (let i = 0; i <= points; i++) {
        const x = i * step;
        let audioFactor = 0;
        if (hasRealAudio && freqData) {
          const sampleIdx = Math.floor((i / points) * (freqData.length / 2));
          audioFactor = (freqData[sampleIdx] / 255) * 35;
        }

        // Emotion-tuned waveform geometry
        const waveScale = mood === 'serious' ? 0.6 : mood === 'excited' ? 1.4 : 1.0;
        const wave1 = Math.sin(i * 0.25 + phaseRef.current) * (8 + activeVol * 25) * waveScale;
        const wave2 = Math.cos(i * 0.15 - phaseRef.current * 0.8) * (5 + activeVol * 15) * waveScale;
        const y = centerY + (wave1 + wave2 + audioFactor) * 0.8;

        if (i === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }

      ctx.strokeStyle = colors.secondary;
      ctx.lineWidth = 4;
      ctx.lineCap = 'round';
      ctx.shadowColor = colors.glow;
      ctx.shadowBlur = 12;
      ctx.stroke();

      // Draw primary foreground wave
      ctx.beginPath();
      for (let i = 0; i <= points; i++) {
        const x = i * step;
        let audioFactor = 0;
        if (hasRealAudio && freqData) {
          const sampleIdx = Math.floor((i / points) * (freqData.length / 3));
          audioFactor = (freqData[sampleIdx] / 255) * 45;
        }

        const waveScale = mood === 'serious' ? 0.55 : mood === 'excited' ? 1.35 : 1.0;
        const wave1 = Math.sin(i * 0.35 + phaseRef.current * 1.2) * (10 + activeVol * 40) * waveScale;
        const wave2 = Math.sin(i * 0.18 + phaseRef.current * 0.5) * (6 + activeVol * 20) * waveScale;
        const y = centerY + (wave1 + wave2 + (i % 2 === 0 ? audioFactor : -audioFactor * 0.5));

        if (i === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }

      ctx.strokeStyle = colors.primary;
      ctx.lineWidth = 2.5;
      ctx.shadowColor = colors.primary;
      ctx.shadowBlur = 8;
      ctx.stroke();

      // Draw baseline glow line
      ctx.beginPath();
      ctx.moveTo(0, centerY);
      ctx.lineTo(width, centerY);
      ctx.strokeStyle = colors.secondary;
      ctx.lineWidth = 1;
      ctx.shadowBlur = 0;
      ctx.stroke();

      animFrameIdRef.current = requestAnimationFrame(render);
    };

    render();

    return () => {
      if (animFrameIdRef.current) {
        cancelAnimationFrame(animFrameIdRef.current);
      }
      resizeObserver.disconnect();
    };
  }, [state, mood, inputVolume, outputVolume, emotionConfig]);

  return (
    <div className={`relative w-full h-24 overflow-hidden pointer-events-none ${className}`}>
      <canvas ref={canvasRef} className="w-full h-full" />
    </div>
  );
};
