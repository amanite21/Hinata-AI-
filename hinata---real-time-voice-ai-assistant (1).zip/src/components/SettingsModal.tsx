import React, { useState, useEffect } from 'react';
import {
  X,
  Volume2,
  Radio,
  Check,
  Sliders,
  Mic,
  MicOff,
  ShieldCheck,
  User,
  Bot,
  Globe,
  Settings as SettingsIcon,
  RefreshCw,
  ExternalLink,
  CheckCircle2,
  AlertCircle,
  Loader2,
  Key,
  Sparkles,
  Eye,
  EyeOff,
  Lock,
  Cpu,
} from 'lucide-react';
import { MicrophoneManager, MicPermissionStatus, MicrophoneState } from '../modules/audio/MicrophoneManager';
import { OwnerManager } from '../modules/OwnerManager';
import { BackendConfig, BackendStatusType, BackendHealthResult } from '../config/backendConfig';
import { ClientAIProvider, AIProviderStatus, AIStatusState } from '../modules/ai/AIProvider';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedVoice: string;
  onSelectVoice: (voice: string) => void;
  outputVolume: number;
  onVolumeChange: (vol: number) => void;
  onOpenHandsFreeSetup?: () => void;
  initialTab?: 'voice' | 'permissions' | 'identity' | 'backend' | 'ai';
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  selectedVoice,
  onSelectVoice,
  outputVolume,
  onVolumeChange,
  onOpenHandsFreeSetup,
  initialTab = 'voice',
}) => {
  const micManager = MicrophoneManager.getInstance();
  const ownerManager = OwnerManager.getInstance();
  const aiProvider = ClientAIProvider.getInstance();

  // Microphone & Permissions state
  const [micStatus, setMicStatus] = useState<MicPermissionStatus>(() => micManager.getPermissionStatus());
  const [micState, setMicState] = useState<MicrophoneState>(() => micManager.getState());
  const [isRequestingMic, setIsRequestingMic] = useState<boolean>(false);

  // Identity Customization state
  const [assistantName, setAssistantNameInput] = useState<string>(() => ownerManager.getAssistantName());
  const [userName, setUserNameInput] = useState<string>(() => ownerManager.getOwnerName());
  const [identitySaved, setIdentitySaved] = useState<boolean>(false);

  // Backend URL configuration state
  const [backendUrlInput, setBackendUrlInput] = useState<string>(() => BackendConfig.getBackendUrl());
  const [backendStatus, setBackendStatus] = useState<BackendStatusType>(() => BackendConfig.getStatus());
  const [backendHealth, setBackendHealth] = useState<{ testing: boolean; ok?: boolean; latencyMs?: number; error?: string }>({
    testing: false,
    ok: BackendConfig.getLastHealthResult()?.ok,
    latencyMs: BackendConfig.getLastHealthResult()?.latencyMs,
    error: BackendConfig.getLastHealthResult()?.error,
  });
  const [backendSaved, setBackendSaved] = useState<boolean>(false);

  // AI Service & Key Configuration state
  const [aiStatus, setAiStatus] = useState<AIProviderStatus>(() => aiProvider.getStatus());
  const [isTestingKey, setIsTestingKey] = useState<boolean>(false);
  const [testFeedback, setTestFeedback] = useState<{ status: AIStatusState; message: string; latencyMs?: number } | null>(null);
  const [isChangeKeyOpen, setIsChangeKeyOpen] = useState<boolean>(false);
  const [candidateKeyInput, setCandidateKeyInput] = useState<string>('');
  const [showCandidateKey, setShowCandidateKey] = useState<boolean>(false);
  const [isVerifyingAndSaving, setIsVerifyingAndSaving] = useState<boolean>(false);
  const [changeKeyError, setChangeKeyError] = useState<string | null>(null);
  const [changeKeySuccess, setChangeKeySuccess] = useState<boolean>(false);

  // Active settings tab for clean organization
  const [activeTab, setActiveTab] = useState<'voice' | 'permissions' | 'identity' | 'backend' | 'ai'>(initialTab);

  useEffect(() => {
    setActiveTab(initialTab);
  }, [initialTab]);

  useEffect(() => {
    const unsub = BackendConfig.subscribe(() => {
      setBackendStatus(BackendConfig.getStatus());
      setBackendUrlInput(BackendConfig.getBackendUrl());
      const last = BackendConfig.getLastHealthResult();
      if (last) {
        setBackendHealth((prev) => ({
          ...prev,
          ok: last.ok,
          latencyMs: last.latencyMs,
          error: last.error,
        }));
      }
    });
    return unsub;
  }, []);

  useEffect(() => {
    const unsubAi = aiProvider.subscribe((status) => {
      setAiStatus(status);
    });
    // Fetch latest status on open
    aiProvider.fetchStatus().catch(() => {});
    return unsubAi;
  }, [aiProvider]);

  useEffect(() => {
    const unPerm = micManager.onPermissionChange((status) => {
      setMicStatus(status);
    });
    const unState = micManager.onStateChange((state) => {
      setMicState(state);
    });

    // Check permission status non-intrusively
    micManager.checkPermission().then(setMicStatus).catch(() => {});

    return () => {
      unPerm();
      unState();
    };
  }, [micManager]);

  const voices = [
    { id: 'Kore', name: 'Kore (Default)', desc: 'Warm, witty, charming & confident' },
    { id: 'Aoede', name: 'Aoede', desc: 'Expressive, dynamic & conversational' },
    { id: 'Zephyr', name: 'Zephyr', desc: 'Calm, soothing & friendly' },
    { id: 'Puck', name: 'Puck', desc: 'Playful, bright & energetic' },
    { id: 'Fenrir', name: 'Fenrir', desc: 'Grounded, warm & resonant' },
  ];

  const handleToggleUseMic = async () => {
    if (micManager.isBusy()) return;
    setIsRequestingMic(true);
    try {
      if (micState === 'LISTENING') {
        // Stop audio capture (Android permission remains GRANTED!)
        await micManager.stopListening('settings_test');
      } else {
        await micManager.startListening('settings_test', {
          echoCancellation: true,
          noiseSuppression: true,
        });
      }
    } catch (e) {
      console.warn('[SettingsModal] Mic toggle error:', e);
    } finally {
      setIsRequestingMic(false);
    }
  };

  const handleRequestPermission = async () => {
    setIsRequestingMic(true);
    try {
      const res = await micManager.requestPermission();
      setMicStatus(res.status);
    } finally {
      setIsRequestingMic(false);
    }
  };

  const handleOpenSettings = () => {
    micManager.openAppSettings();
  };

  const handleSaveIdentity = (e: React.FormEvent) => {
    e.preventDefault();
    ownerManager.setAssistantName(assistantName);
    ownerManager.setOwnerName(userName);
    setIdentitySaved(true);
    setTimeout(() => setIdentitySaved(false), 2500);
  };

  const handleSaveBackendUrl = (e: React.FormEvent) => {
    e.preventDefault();
    BackendConfig.setBackendUrl(backendUrlInput.trim() || null);
    setBackendSaved(true);
    setTimeout(() => setBackendSaved(false), 2500);
  };

  const handleTestBackend = async () => {
    setBackendHealth({ testing: true });
    try {
      const res = await BackendConfig.checkBackendHealth();
      setBackendHealth({
        testing: false,
        ok: res.ok,
        latencyMs: res.latencyMs,
        error: res.error,
      });
    } catch (err: any) {
      setBackendHealth({
        testing: false,
        ok: false,
        error: err?.message || 'Connection unavailable',
      });
    }
  };

  const handleTestConnection = async () => {
    setIsTestingKey(true);
    setTestFeedback(null);
    try {
      const res = await aiProvider.testConnection();
      setTestFeedback({
        status: res.status,
        message: res.message,
        latencyMs: res.latencyMs,
      });
    } catch (err: any) {
      setTestFeedback({
        status: 'NETWORK_ERROR',
        message: err?.message || 'Network error reaching test service.',
        latencyMs: 0,
      });
    } finally {
      setIsTestingKey(false);
    }
  };

  const handleVerifyAndSaveKey = async () => {
    if (!candidateKeyInput.trim()) {
      setChangeKeyError('Please paste a valid Gemini API key.');
      return;
    }

    setIsVerifyingAndSaving(true);
    setChangeKeyError(null);
    try {
      const res = await aiProvider.rotateKey(candidateKeyInput.trim());
      if (res.success) {
        setChangeKeySuccess(true);
        setIsChangeKeyOpen(false);
        setCandidateKeyInput('');
        setTestFeedback({
          status: 'CONNECTED',
          message: 'Key verified and connected successfully.',
        });
        setTimeout(() => setChangeKeySuccess(false), 3000);
      } else {
        // Did not save: preserve previous key and display specific error
        if (res.status === 'INVALID_KEY') {
          setChangeKeyError('Invalid API Key. Please check the key and try again.');
        } else if (res.status === 'EXPIRED_OR_REVOKED') {
          setChangeKeyError('API Key Expired or Revoked. Please provide an active key.');
        } else if (res.status === 'QUOTA_EXCEEDED') {
          setChangeKeyError('Quota Exceeded on this API Key.');
        } else {
          setChangeKeyError(res.message || 'Invalid API Key. Please check the key and try again.');
        }
      }
    } catch (err: any) {
      setChangeKeyError(err?.message || 'Verification failed. Could not reach server.');
    } finally {
      setIsVerifyingAndSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
      <div
        className="w-full max-w-lg glass-panel-glow rounded-3xl border border-white/15 p-6 flex flex-col gap-4 max-h-[90vh] overflow-y-auto text-neutral-100 shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between border-b border-white/10 pb-3">
          <div className="flex items-center gap-2">
            <Radio className="w-5 h-5 text-cyan-400" />
            <h2 className="text-lg font-bold tracking-wide font-mono-tech text-white">Hinata Settings</h2>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full glass-button flex items-center justify-center text-neutral-400 hover:text-white"
            aria-label="Close settings"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center gap-1 p-1 rounded-2xl bg-black/40 border border-white/10 overflow-x-auto text-xs">
          <button
            onClick={() => setActiveTab('voice')}
            className={`flex-1 min-w-[70px] py-1.5 px-2.5 rounded-xl font-medium transition-all flex items-center justify-center gap-1.5 ${
              activeTab === 'voice'
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm'
                : 'text-neutral-400 hover:text-neutral-200'
            }`}
          >
            <Volume2 className="w-3.5 h-3.5" />
            <span>Voice</span>
          </button>
          <button
            onClick={() => setActiveTab('permissions')}
            className={`flex-1 min-w-[90px] py-1.5 px-2.5 rounded-xl font-medium transition-all flex items-center justify-center gap-1.5 ${
              activeTab === 'permissions'
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm'
                : 'text-neutral-400 hover:text-neutral-200'
            }`}
          >
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>Permissions</span>
          </button>
          <button
            onClick={() => setActiveTab('identity')}
            className={`flex-1 min-w-[80px] py-1.5 px-2.5 rounded-xl font-medium transition-all flex items-center justify-center gap-1.5 ${
              activeTab === 'identity'
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm'
                : 'text-neutral-400 hover:text-neutral-200'
            }`}
          >
            <User className="w-3.5 h-3.5" />
            <span>Identity</span>
          </button>
          <button
            onClick={() => setActiveTab('backend')}
            className={`flex-1 min-w-[80px] py-1.5 px-2.5 rounded-xl font-medium transition-all flex items-center justify-center gap-1.5 ${
              activeTab === 'backend'
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm'
                : 'text-neutral-400 hover:text-neutral-200'
            }`}
          >
            <Globe className="w-3.5 h-3.5" />
            <span>Backend</span>
          </button>
          <button
            onClick={() => setActiveTab('ai')}
            className={`flex-1 min-w-[85px] py-1.5 px-2.5 rounded-xl font-medium transition-all flex items-center justify-center gap-1.5 ${
              activeTab === 'ai'
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm'
                : 'text-neutral-400 hover:text-neutral-200'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>AI Service</span>
          </button>
        </div>

        {/* TAB 1: VOICE & AUDIO */}
        {activeTab === 'voice' && (
          <div className="flex flex-col gap-4">
            {/* Voice Selection */}
            <div className="flex flex-col gap-2.5">
              <label className="text-xs font-semibold text-neutral-300 uppercase tracking-wider font-mono-tech flex items-center gap-1.5">
                <Volume2 className="w-3.5 h-3.5 text-cyan-400" />
                <span>Assistant Vocal Profile</span>
              </label>
              <div className="grid grid-cols-1 gap-2">
                {voices.map((v) => (
                  <button
                    key={v.id}
                    onClick={() => onSelectVoice(v.id)}
                    className={`flex items-center justify-between p-3 rounded-xl border text-left transition-all ${
                      selectedVoice === v.id
                        ? 'bg-cyan-500/20 border-cyan-500/50 text-white shadow-sm'
                        : 'bg-white/5 border-white/10 text-neutral-300 hover:bg-white/10'
                    }`}
                  >
                    <div>
                      <p className="font-semibold text-sm">{v.name}</p>
                      <p className="text-xs text-neutral-400 mt-0.5">{v.desc}</p>
                    </div>
                    {selectedVoice === v.id && <Check className="w-4 h-4 text-cyan-400 flex-shrink-0" />}
                  </button>
                ))}
              </div>
            </div>

            {/* Master Output Volume */}
            <div className="flex flex-col gap-2">
              <div className="flex items-center justify-between text-xs text-neutral-300">
                <span className="font-mono-tech uppercase font-semibold flex items-center gap-1.5">
                  <Sliders className="w-3.5 h-3.5 text-purple-400" />
                  Speech Playback Gain
                </span>
                <span className="font-mono-tech">{Math.round(outputVolume * 100)}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="1.5"
                step="0.05"
                value={outputVolume}
                onChange={(e) => onVolumeChange(parseFloat(e.target.value))}
                className="w-full h-1.5 bg-neutral-800 rounded-lg appearance-none cursor-pointer accent-cyan-400"
              />
            </div>

            {/* Hands-Free Setup */}
            {onOpenHandsFreeSetup && (
              <div className="p-3.5 rounded-2xl bg-cyan-950/40 border border-cyan-500/30 flex items-center justify-between gap-2">
                <div className="flex items-center gap-2 text-xs font-semibold text-white">
                  <Radio className="w-3.5 h-3.5 text-cyan-400 animate-pulse" />
                  <span>Hands-Free "Hey Hinata"</span>
                </div>
                <button
                  onClick={onOpenHandsFreeSetup}
                  className="px-2.5 py-1 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-[11px] transition-all shadow-[0_0_10px_rgba(0,229,255,0.3)]"
                >
                  Configure Setup ↗
                </button>
              </div>
            )}
          </div>
        )}

        {/* TAB 2: PERMISSIONS & MICROPHONE */}
        {activeTab === 'permissions' && (
          <div className="flex flex-col gap-4">
            <div className="p-4 rounded-2xl bg-[#09102b] border border-cyan-500/30 flex flex-col gap-3">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <Mic className="w-4 h-4 text-cyan-400" />
                  <span className="font-bold text-sm text-white">Microphone (RECORD_AUDIO)</span>
                </div>
                <div className="flex items-center gap-2 flex-wrap">
                  {/* Permission badge */}
                  <span
                    className={`px-2.5 py-0.5 rounded-full text-[10px] font-semibold border ${
                      micStatus === 'granted'
                        ? 'bg-emerald-950/80 border-emerald-500/40 text-emerald-300'
                        : 'bg-rose-950/80 border-rose-500/40 text-rose-300'
                    }`}
                  >
                    Permission: {micStatus === 'granted' ? 'GRANTED' : 'NOT GRANTED'}
                  </span>
                  {/* Hardware Capture badge */}
                  <span
                    className={`px-2.5 py-0.5 rounded-full text-[10px] font-semibold border ${
                      micState === 'LISTENING'
                        ? 'bg-cyan-950/80 border-cyan-500/40 text-cyan-300 animate-pulse'
                        : micState === 'STARTING' || micState === 'STOPPING' || micState === 'REQUESTING_PERMISSION'
                        ? 'bg-amber-950/80 border-amber-500/40 text-amber-300'
                        : 'bg-slate-900 border-slate-700 text-slate-400'
                    }`}
                  >
                    Capture: {micState}
                  </span>
                </div>
              </div>

              <p className="text-xs text-neutral-300 leading-relaxed">
                Hinata requires microphone access for Voice Chat, "Likho" Dictation Mode, and Hands-Free Wake Word.
              </p>

              {/* Action Buttons */}
              <div className="pt-2 border-t border-white/10 flex flex-wrap items-center gap-2">
                {micStatus === 'granted' ? (
                  <>
                    <button
                      type="button"
                      onClick={handleToggleUseMic}
                      disabled={
                        isRequestingMic ||
                        micManager.isBusy() ||
                        micState === 'STARTING' ||
                        micState === 'STOPPING' ||
                        micState === 'REQUESTING_PERMISSION'
                      }
                      className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold transition-all ${
                        micState === 'LISTENING'
                          ? 'bg-rose-600 hover:bg-rose-500 text-white shadow-[0_0_12px_rgba(244,63,94,0.4)]'
                          : 'bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 shadow-[0_0_12px_rgba(0,229,255,0.3)]'
                      }`}
                    >
                      {isRequestingMic ||
                      micState === 'STARTING' ||
                      micState === 'STOPPING' ||
                      micState === 'REQUESTING_PERMISSION' ? (
                        <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      ) : micState === 'LISTENING' ? (
                        <MicOff className="w-3.5 h-3.5" />
                      ) : (
                        <Mic className="w-3.5 h-3.5" />
                      )}
                      <span>
                        {micState === 'LISTENING' ? 'Stop Microphone Capture' : 'Use Microphone (Test)'}
                      </span>
                    </button>
                    <span className="text-[11px] text-emerald-400/80 flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      Permission permanently granted
                    </span>
                  </>
                ) : micStatus === 'permanently_denied' ? (
                  <div className="w-full flex flex-col gap-2">
                    <p className="text-xs text-amber-300 bg-amber-950/40 border border-amber-500/30 p-2.5 rounded-xl flex items-start gap-1.5">
                      <AlertCircle className="w-4 h-4 text-amber-400 flex-shrink-0 mt-0.5" />
                      <span>
                        Microphone permission is disabled in Android system settings. Open Settings to enable microphone access.
                      </span>
                    </p>
                    <button
                      type="button"
                      onClick={handleOpenSettings}
                      className="flex items-center justify-center gap-1.5 px-3.5 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 text-xs font-bold transition-all shadow-[0_0_12px_rgba(0,229,255,0.3)]"
                    >
                      <SettingsIcon className="w-3.5 h-3.5" />
                      <span>Open Android App Settings</span>
                    </button>
                  </div>
                ) : (
                  <div className="w-full flex flex-col gap-2">
                    <button
                      type="button"
                      onClick={handleRequestPermission}
                      disabled={isRequestingMic}
                      className="flex items-center justify-center gap-1.5 px-3.5 py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 text-xs font-bold transition-all shadow-[0_0_12px_rgba(0,229,255,0.3)]"
                    >
                      {isRequestingMic ? (
                        <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      ) : (
                        <ShieldCheck className="w-3.5 h-3.5" />
                      )}
                      <span>Grant Microphone Permission</span>
                    </button>
                  </div>
                )}
              </div>
            </div>

            {/* Architectural Rule Info */}
            <div className="p-3 rounded-xl bg-white/5 border border-white/10 text-[11px] text-neutral-400 space-y-1 leading-relaxed">
              <p className="font-semibold text-neutral-300 flex items-center gap-1">
                <CheckCircle2 className="w-3 h-3 text-cyan-400" />
                <span>Centralized Microphone Manager Architecture:</span>
              </p>
              <ul className="list-disc list-inside space-y-0.5 text-neutral-400 pl-1">
                <li>Permission state is strictly separated from audio capture sessions.</li>
                <li>Turning microphone OFF never revokes or re-prompts for Android permission.</li>
                <li>Single audio hardware pipeline eliminates audio source conflicts.</li>
              </ul>
            </div>
          </div>
        )}

        {/* TAB 3: IDENTITY & CUSTOMIZATION */}
        {activeTab === 'identity' && (
          <form onSubmit={handleSaveIdentity} className="flex flex-col gap-4">
            <div className="p-4 rounded-2xl bg-[#09102b] border border-cyan-500/30 flex flex-col gap-3">
              <div className="flex items-center gap-2 text-sm font-bold text-white">
                <Bot className="w-4 h-4 text-cyan-400" />
                <span>AI Assistant & User Customization</span>
              </div>
              <p className="text-xs text-neutral-400">
                Personalize what Hinata calls you and what name you use for your AI companion.
              </p>

              <div className="flex flex-col gap-3 pt-1">
                <div className="flex flex-col gap-1">
                  <label className="text-xs font-semibold text-neutral-300 flex items-center gap-1.5">
                    <Bot className="w-3.5 h-3.5 text-cyan-400" />
                    <span>AI Assistant Name</span>
                  </label>
                  <input
                    type="text"
                    value={assistantName}
                    onChange={(e) => setAssistantNameInput(e.target.value)}
                    placeholder="Hinata"
                    className="w-full px-3 py-2 rounded-xl bg-black/50 border border-white/15 text-white text-xs focus:outline-none focus:border-cyan-400"
                  />
                  <span className="text-[10px] text-neutral-400">Default: Hinata</span>
                </div>

                <div className="flex flex-col gap-1">
                  <label className="text-xs font-semibold text-neutral-300 flex items-center gap-1.5">
                    <User className="w-3.5 h-3.5 text-purple-400" />
                    <span>Your Name (Owner)</span>
                  </label>
                  <input
                    type="text"
                    value={userName}
                    onChange={(e) => setUserNameInput(e.target.value)}
                    placeholder="Aman"
                    className="w-full px-3 py-2 rounded-xl bg-black/50 border border-white/15 text-white text-xs focus:outline-none focus:border-purple-400"
                  />
                  <span className="text-[10px] text-neutral-400">Default: Aman</span>
                </div>
              </div>

              <div className="pt-2 border-t border-white/10 flex items-center justify-between">
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-bold text-xs shadow-[0_0_12px_rgba(0,229,255,0.3)] transition-all"
                >
                  Save Names
                </button>
                {identitySaved && (
                  <span className="text-xs text-emerald-400 flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    Saved successfully!
                  </span>
                )}
              </div>
            </div>
          </form>
        )}

        {/* TAB 4: BACKEND CONFIGURATION */}
        {activeTab === 'backend' && (
          <form onSubmit={handleSaveBackendUrl} className="flex flex-col gap-4">
            <div className="p-4 rounded-2xl bg-[#09102b] border border-cyan-500/30 flex flex-col gap-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-sm font-bold text-white">
                  <Globe className="w-4 h-4 text-cyan-400" />
                  <span>Backend Cloud Service</span>
                </div>
                <span
                  className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold border ${
                    backendStatus === 'connected'
                      ? 'bg-emerald-950/80 border-emerald-500/40 text-emerald-300'
                      : backendStatus === 'not_configured'
                      ? 'bg-cyan-950/80 border-cyan-500/40 text-cyan-300'
                      : 'bg-rose-950/80 border-rose-500/40 text-rose-300'
                  }`}
                >
                  {backendStatus === 'connected'
                    ? 'Connected ✓'
                    : backendStatus === 'not_configured'
                    ? 'Connecting...'
                    : 'Connection failed'}
                </span>
              </div>

              {/* Status Explanation Card */}
              {backendStatus === 'connected' && (
                <div className="p-3 rounded-xl bg-emerald-950/40 border border-emerald-500/30 text-xs text-slate-300 space-y-1">
                  <div className="font-bold text-emerald-300 flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    <span>Backend Status: CONNECTED</span>
                  </div>
                  <p className="text-[11px] text-emerald-200/90 font-medium">
                    Backend: {BackendConfig.getBackendDisplayName()}
                  </p>
                  <p className="text-[11px] text-slate-300 leading-relaxed">
                    Connected to this project's server via same-origin API routes. Full-duplex Gemini Live voice, streaming AI chat, and Cloud Memory synchronization are active.
                  </p>
                </div>
              )}

              {backendStatus === 'not_configured' && (
                <div className="p-3 rounded-xl bg-[#080e29] border border-cyan-500/30 text-xs text-slate-300 space-y-1">
                  <div className="font-bold text-cyan-300 flex items-center gap-1.5">
                    <Loader2 className="w-4 h-4 text-cyan-400 animate-spin" />
                    <span>Backend Status: CONNECTING...</span>
                  </div>
                  <p className="text-[11px] text-slate-300">
                    Connecting to AI Studio Server...
                  </p>
                </div>
              )}

              {backendStatus === 'connection_failed' && (
                <div className="p-3 rounded-xl bg-rose-950/40 border border-rose-500/30 text-xs text-slate-300 space-y-1">
                  <div className="font-bold text-rose-300 flex items-center gap-1.5">
                    <AlertCircle className="w-4 h-4 text-rose-400" />
                    <span>Backend Connection failed</span>
                  </div>
                  <p className="text-[11px] text-slate-300">
                    {backendHealth.error || 'Server unreachable or offline. Verify server is running and check URL.'}
                  </p>
                  <button
                    type="button"
                    onClick={() => {
                      BackendConfig.clearCustomBackendUrl();
                      setBackendUrlInput('');
                      handleTestBackend();
                    }}
                    className="text-xs text-cyan-400 hover:underline pt-1 inline-block"
                  >
                    Reset to AI Studio Server
                  </button>
                </div>
              )}

              <div className="flex flex-col gap-1.5 pt-1">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-semibold text-neutral-300">
                    External Backend URL (Optional Override):
                  </label>
                  <span className="text-[10px] text-cyan-400/80 font-mono">
                    Not required in AI Studio
                  </span>
                </div>
                <input
                  type="text"
                  value={backendUrlInput}
                  onChange={(e) => setBackendUrlInput(e.target.value)}
                  placeholder="Using AI Studio Server (Default)"
                  className="w-full px-3 py-2 rounded-xl bg-black/50 border border-white/15 text-white text-xs font-mono focus:outline-none focus:border-cyan-400"
                />
                <p className="text-[10px] text-neutral-400 leading-normal">
                  The frontend automatically connects to this project's internal server. An external URL is only needed if deploying to a separate external cloud host or physical Android APK.
                </p>
                <div className="flex items-center justify-between text-[10px] text-neutral-400 pt-0.5">
                  <span>
                    WebSocket: <code className="text-cyan-300 font-mono">{BackendConfig.getWsBackendUrl() ? `${BackendConfig.getWsBackendUrl()}/api/live` : '(same-origin)'}</code>
                  </span>
                  {BackendConfig.isCustomUrlActive() && (
                    <button
                      type="button"
                      onClick={() => {
                        BackendConfig.clearCustomBackendUrl();
                        setBackendUrlInput('');
                        handleTestBackend();
                      }}
                      className="text-cyan-400 hover:underline"
                    >
                      Use AI Studio Server
                    </button>
                  )}
                </div>
              </div>

              {/* Health Test */}
              <div className="pt-2 border-t border-white/10 flex flex-col gap-2">
                <div className="flex flex-wrap items-center gap-2">
                  <button
                    type="button"
                    onClick={handleTestBackend}
                    disabled={backendHealth.testing}
                    className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 disabled:opacity-60 text-slate-950 font-bold text-xs shadow-[0_0_10px_rgba(0,229,255,0.3)] flex items-center gap-1.5 transition-all"
                  >
                    {backendHealth.testing ? (
                      <Loader2 className="w-3.5 h-3.5 animate-spin text-slate-950" />
                    ) : (
                      <RefreshCw className="w-3.5 h-3.5 text-slate-950" />
                    )}
                    <span>Test Connection</span>
                  </button>

                  <button
                    type="submit"
                    className="px-4 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-semibold text-xs border border-white/15 transition-all"
                  >
                    Save URL
                  </button>

                  {BackendConfig.isCustomUrlActive() && (
                    <button
                      type="button"
                      onClick={() => {
                        BackendConfig.clearCustomBackendUrl();
                        setBackendUrlInput('');
                        handleTestBackend();
                      }}
                      className="px-3 py-1.5 rounded-xl bg-rose-950/40 hover:bg-rose-900/60 text-rose-300 text-xs border border-rose-500/30 transition-all"
                    >
                      Reset to AI Studio Server
                    </button>
                  )}

                  {backendSaved && (
                    <span className="text-xs text-emerald-400 flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      Saved!
                    </span>
                  )}
                </div>

                {backendHealth.ok !== undefined && (
                  <div
                    className={`p-2.5 rounded-xl border text-xs flex items-center gap-2 ${
                      backendHealth.ok
                        ? 'bg-emerald-950/40 border-emerald-500/40 text-emerald-300'
                        : 'bg-rose-950/40 border-rose-500/40 text-rose-300'
                    }`}
                  >
                    {backendHealth.ok ? (
                      <CheckCircle2 className="w-4 h-4 flex-shrink-0" />
                    ) : (
                      <AlertCircle className="w-4 h-4 flex-shrink-0" />
                    )}
                    <span>
                      {backendHealth.ok
                        ? `Backend connected successfully (${BackendConfig.getBackendDisplayName()} • ${backendHealth.latencyMs}ms latency).`
                        : `Connection failed: ${backendHealth.error || 'Connection unavailable.'}`}
                    </span>
                  </div>
                )}
              </div>

              {/* Architecture Guarantee */}
              <div className="p-3 rounded-xl bg-black/40 border border-white/10 flex items-start gap-2 text-[11px] text-slate-400">
                <ShieldCheck className="w-4 h-4 text-emerald-400 flex-shrink-0 mt-0.5" />
                <span>
                  <strong>Server-Side Security:</strong> The Gemini API key is securely loaded only on your backend server. The frontend client and Android APK connect purely via proxy and never hold secrets.
                </span>
              </div>
            </div>
          </form>
        )}

        {/* TAB 5: AI SERVICE */}
        {activeTab === 'ai' && (
          <div className="flex flex-col gap-4">
            {/* Section Header */}
            <div className="border-b border-white/10 pb-2.5">
              <h3 className="text-xs font-semibold text-neutral-300 uppercase tracking-wider font-mono-tech flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
                <span>AI SERVICE</span>
              </h3>
              <p className="text-[11px] text-neutral-400 mt-0.5">
                Centralized intelligence provider status, secure credential verification, and live key rotation.
              </p>
            </div>

            {/* AI Service Panel */}
            <div className="p-4 rounded-2xl bg-black/40 border border-white/10 space-y-4">
              {/* Provider */}
              <div className="flex items-center justify-between">
                <div>
                  <span className="text-xs font-semibold text-neutral-300 block font-mono-tech">Provider</span>
                  <span className="text-[11px] text-neutral-400">Google Gemini LLM & Multimodal Live</span>
                </div>
                <div className="px-3 py-1 rounded-xl bg-cyan-500/10 border border-cyan-500/30 text-cyan-300 text-xs font-semibold">
                  Gemini
                </div>
              </div>

              <div className="h-px bg-white/5" />

              {/* API Status */}
              <div className="flex items-center justify-between">
                <div>
                  <span className="text-xs font-semibold text-neutral-300 block font-mono-tech">API Status</span>
                  <span className="text-[11px] text-neutral-400">Live operational state</span>
                </div>
                <div>
                  {isTestingKey ? (
                    <div className="flex items-center gap-1.5 text-xs text-cyan-300 font-medium">
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      <span>Testing connection...</span>
                    </div>
                  ) : (() => {
                    const st = testFeedback ? testFeedback.status : aiStatus.status;
                    const lat = testFeedback?.latencyMs;

                    switch (st) {
                      case 'CONNECTED':
                        return (
                          <div className="flex items-center gap-1.5 text-xs text-emerald-400 font-semibold">
                            <span className="w-2 h-2 rounded-full bg-emerald-400 shadow-[0_0_8px_#34d399]" />
                            <span>Connected {lat !== undefined && lat > 0 ? `(${lat} ms)` : ''}</span>
                          </div>
                        );
                      case 'EXPIRED_OR_REVOKED':
                        return (
                          <div className="flex items-center gap-1.5 text-xs text-rose-400 font-semibold">
                            <span className="w-2 h-2 rounded-full bg-rose-400 shadow-[0_0_8px_#f43f5e]" />
                            <span>API Key Expired or Revoked</span>
                          </div>
                        );
                      case 'QUOTA_EXCEEDED':
                        return (
                          <div className="flex items-center gap-1.5 text-xs text-amber-400 font-semibold">
                            <span className="w-2 h-2 rounded-full bg-amber-400 shadow-[0_0_8px_#f59e0b]" />
                            <span>Quota Exceeded</span>
                          </div>
                        );
                      case 'INVALID_KEY':
                        return (
                          <div className="flex items-center gap-1.5 text-xs text-rose-400 font-semibold">
                            <span className="w-2 h-2 rounded-full bg-rose-400 shadow-[0_0_8px_#f43f5e]" />
                            <span>Invalid API Key</span>
                          </div>
                        );
                      case 'NETWORK_ERROR':
                        return (
                          <div className="flex items-center gap-1.5 text-xs text-amber-300 font-semibold">
                            <span className="w-2 h-2 rounded-full bg-amber-400" />
                            <span>Network Error</span>
                          </div>
                        );
                      case 'RATE_LIMITED':
                        return (
                          <div className="flex items-center gap-1.5 text-xs text-amber-400 font-semibold">
                            <span className="w-2 h-2 rounded-full bg-amber-400" />
                            <span>Rate Limited</span>
                          </div>
                        );
                      case 'NOT_CONFIGURED':
                      default:
                        return (
                          <div className="flex items-center gap-1.5 text-xs text-slate-400 font-medium">
                            <span className="w-2 h-2 rounded-full bg-slate-500" />
                            <span>Not Configured</span>
                          </div>
                        );
                    }
                  })()}
                </div>
              </div>

              <div className="h-px bg-white/5" />

              {/* API Key (Masked - NEVER shows complete key) */}
              <div className="flex items-center justify-between">
                <div>
                  <span className="text-xs font-semibold text-neutral-300 block font-mono-tech">API Key</span>
                  <span className="text-[11px] text-neutral-400">Server-side credential mask</span>
                </div>
                <div className="font-mono text-xs text-neutral-200 tracking-wider bg-black/50 px-3 py-1 rounded-lg border border-white/10 flex items-center gap-1.5">
                  <Lock className="w-3 h-3 text-neutral-400" />
                  <span>
                    {aiStatus.maskedKeySuffix || (aiStatus.isConfigured ? '••••••••••••••••' : 'Not configured')}
                  </span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => {
                    setIsChangeKeyOpen(true);
                    setCandidateKeyInput('');
                    setChangeKeyError(null);
                  }}
                  className="flex-1 py-2 px-3 rounded-xl bg-cyan-500/15 hover:bg-cyan-500/25 border border-cyan-500/40 text-cyan-300 font-semibold text-xs transition-all flex items-center justify-center gap-1.5"
                >
                  <Key className="w-3.5 h-3.5" />
                  <span>Change API Key</span>
                </button>
                <button
                  type="button"
                  disabled={isTestingKey}
                  onClick={handleTestConnection}
                  className="flex-1 py-2 px-3 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-neutral-200 font-semibold text-xs transition-all flex items-center justify-center gap-1.5 disabled:opacity-50"
                >
                  {isTestingKey ? (
                    <>
                      <Loader2 className="w-3.5 h-3.5 animate-spin text-cyan-400" />
                      <span>Testing connection...</span>
                    </>
                  ) : (
                    <>
                      <RefreshCw className="w-3.5 h-3.5 text-neutral-400" />
                      <span>Test Connection</span>
                    </>
                  )}
                </button>
              </div>

              {/* Test Feedback Notice */}
              {testFeedback && (
                <div
                  className={`p-2.5 rounded-xl border text-xs flex items-center gap-2 ${
                    testFeedback.status === 'CONNECTED'
                      ? 'bg-emerald-950/40 border-emerald-500/40 text-emerald-300'
                      : 'bg-rose-950/40 border-rose-500/40 text-rose-300'
                  }`}
                >
                  {testFeedback.status === 'CONNECTED' ? (
                    <CheckCircle2 className="w-4 h-4 flex-shrink-0" />
                  ) : (
                    <AlertCircle className="w-4 h-4 flex-shrink-0" />
                  )}
                  <span>{testFeedback.message}</span>
                </div>
              )}

              {/* Key Rotation Success Toast */}
              {changeKeySuccess && (
                <div className="p-2.5 rounded-xl border border-emerald-500/40 bg-emerald-950/40 text-emerald-300 text-xs flex items-center gap-2 animate-fadeIn">
                  <CheckCircle2 className="w-4 h-4 flex-shrink-0 text-emerald-400" />
                  <span>API Key verified and updated successfully!</span>
                </div>
              )}
            </div>

            {/* Change API Key Modal Dialog */}
            {isChangeKeyOpen && (
              <div className="p-4 rounded-2xl bg-[#090e24] border border-cyan-400/50 shadow-[0_10px_30px_rgba(0,0,0,0.8),0_0_20px_rgba(0,229,255,0.2)] space-y-3.5 animate-fadeIn">
                <div className="flex items-center justify-between pb-2 border-b border-white/10">
                  <div className="flex items-center gap-2">
                    <Key className="w-4 h-4 text-cyan-400" />
                    <h4 className="text-xs font-bold text-white tracking-wide font-mono-tech uppercase">Change API Key</h4>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      setIsChangeKeyOpen(false);
                      setCandidateKeyInput('');
                      setChangeKeyError(null);
                    }}
                    className="text-neutral-400 hover:text-white p-1"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>

                <p className="text-xs text-neutral-300 leading-relaxed">
                  Enter your replacement Gemini API key. Hinata will test connection with Google Gemini first. If valid, the new key will be applied immediately in server memory without rebuilding the app.
                </p>

                <div>
                  <label className="text-xs font-semibold text-neutral-300 block mb-1.5 font-mono-tech">
                    API Key
                  </label>
                  <div className="relative">
                    <input
                      type={showCandidateKey ? 'text' : 'password'}
                      value={candidateKeyInput}
                      onChange={(e) => {
                        setCandidateKeyInput(e.target.value);
                        setChangeKeyError(null);
                      }}
                      placeholder="Paste new Gemini API key here"
                      className="w-full px-3.5 py-2.5 pr-10 rounded-xl bg-black/60 border border-white/15 text-white placeholder-neutral-500 text-xs focus:outline-none focus:border-cyan-400 font-mono"
                    />
                    <button
                      type="button"
                      onClick={() => setShowCandidateKey(!showCandidateKey)}
                      className="absolute right-2.5 top-1/2 -translate-y-1/2 text-neutral-400 hover:text-white p-1 text-xs"
                      title={showCandidateKey ? 'Hide key' : 'Show key'}
                    >
                      {showCandidateKey ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                    </button>
                  </div>
                </div>

                {changeKeyError && (
                  <div className="p-2.5 rounded-xl bg-rose-950/50 border border-rose-500/50 text-rose-300 text-xs flex items-start gap-2">
                    <AlertCircle className="w-4 h-4 text-rose-400 flex-shrink-0 mt-0.5" />
                    <span>{changeKeyError}</span>
                  </div>
                )}

                <div className="flex items-center justify-end gap-2 pt-1">
                  <button
                    type="button"
                    disabled={isVerifyingAndSaving}
                    onClick={() => {
                      setIsChangeKeyOpen(false);
                      setCandidateKeyInput('');
                      setChangeKeyError(null);
                    }}
                    className="px-3.5 py-1.5 rounded-xl bg-white/5 hover:bg-white/10 text-neutral-300 text-xs font-semibold transition-all"
                  >
                    Cancel
                  </button>
                  <button
                    type="button"
                    disabled={isVerifyingAndSaving || !candidateKeyInput.trim()}
                    onClick={handleVerifyAndSaveKey}
                    className="px-4 py-1.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-black text-xs font-bold transition-all shadow-[0_0_12px_rgba(0,229,255,0.4)] flex items-center gap-1.5 disabled:opacity-50"
                  >
                    {isVerifyingAndSaving ? (
                      <>
                        <Loader2 className="w-3.5 h-3.5 animate-spin" />
                        <span>Testing key...</span>
                      </>
                    ) : (
                      <span>Verify & Save</span>
                    )}
                  </button>
                </div>
              </div>
            )}

            {/* Architecture Safety Rules Notice */}
            <div className="p-3.5 rounded-xl bg-black/40 border border-white/10 space-y-2 text-[11px] text-slate-400 leading-relaxed">
              <div className="flex items-center gap-2 text-cyan-300 font-semibold font-mono-tech">
                <Cpu className="w-4 h-4 text-cyan-400" />
                <span>ENVIRONMENT & KEY LIFECYCLE</span>
              </div>
              <div>
                <strong className="text-slate-200">AI Studio Development:</strong> Runtime rotation updates the active backend in memory instantly without rebuilding. To persist default keys across container restarts, set the <code className="text-cyan-300">GEMINI_API_KEY</code> environment variable in AI Studio Settings.
              </div>
              <div>
                <strong className="text-slate-200">Android Client / APK:</strong> The mobile APK connects purely via secure backend proxy and never stores raw API credentials. Rotating keys here allows you to replace expired or revoked keys without building or distributing a new APK.
              </div>
            </div>
          </div>
        )}

        {/* Footer Technical Architecture Info */}
        <div className="border-t border-white/10 pt-3 text-[11px] text-neutral-400 font-mono-tech space-y-1">
          <div className="flex justify-between">
            <span>AI Assistant</span>
            <span className="text-neutral-200">{ownerManager.getAssistantName()}</span>
          </div>
          <div className="flex justify-between">
            <span>Device Owner</span>
            <span className="text-neutral-200">{ownerManager.getOwnerName()}</span>
          </div>
          <div className="flex justify-between">
            <span>Microphone State</span>
            <span className="text-cyan-300 font-bold">{micState}</span>
          </div>
          <div className="flex justify-between">
            <span>RECORD_AUDIO Permission</span>
            <span className={micStatus === 'granted' ? 'text-emerald-400 font-bold' : 'text-amber-400'}>
              {micStatus === 'granted' ? 'GRANTED' : micStatus.toUpperCase()}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
