/**
 * VisualDesignModal - Advanced Visual Design Understanding Studio for Hinata AI.
 *
 * Allows users to:
 * - Upload UI screenshots, websites, posters, logos, color palettes, illustrations, and mascots
 * - Assign roles to multiple references (Layout, Colors, Mascot, Typography, Components)
 * - Deeply inspect Layout, Color Swatches, Typography Hierarchy, UI Components, and Visual Style
 * - Apply extracted palettes and themes directly to Hinata's interface in real-time
 * - Combine multiple references (e.g. Ref 1 Layout + Ref 2 Colors)
 * - Save design preferences permanently to Hinata's Long-Term Memory
 * - Reconstruct & export Tailwind CSS / React component specifications
 */

import React, { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  X,
  Eye,
  Upload,
  Camera,
  Layers,
  Palette,
  Type as TypeIcon,
  Sparkles,
  Sliders,
  Check,
  Copy,
  Trash2,
  RefreshCw,
  BookmarkPlus,
  Code2,
  Shuffle,
  Compass,
  ArrowRight,
  Scale,
  ShieldCheck,
  Wand2,
} from 'lucide-react';
import { useVisualDesign } from '../modules/visualDesign/useVisualDesign';
import { ReferenceRole } from '../types/visualDesign';
import { DesignMakerStudio } from './design/DesignMakerStudio';
import { DesignReviewStudio } from './design/DesignReviewStudio';
import { HonestDecisionStudio } from './design/HonestDecisionStudio';

interface VisualDesignModalProps {
  isOpen: boolean;
  onClose: () => void;
  onTriggerVoiceInstruction?: (instruction: string) => void;
}

type StudioTab = 'maker' | 'references' | 'analysis' | 'critic' | 'honest' | 'transform' | 'code' | 'memory';

export const VisualDesignModal: React.FC<VisualDesignModalProps> = ({
  isOpen,
  onClose,
  onTriggerVoiceInstruction,
}) => {
  const {
    references,
    activeReference,
    activeTheme,
    isBusy,
    addReference,
    updateRole,
    removeReference,
    clearAllReferences,
    applyReferenceToUI,
    resetTheme,
    combineReferences,
    rememberPreference,
    triggerAnalysis,
  } = useVisualDesign();

  const [activeTab, setActiveTab] = useState<StudioTab>('references');
  const [selectedRefId, setSelectedRefId] = useState<string | null>(null);
  const [copiedHex, setCopiedHex] = useState<string | null>(null);
  const [copiedCode, setCopiedCode] = useState<boolean>(false);
  const [feedbackNotice, setFeedbackNotice] = useState<string | null>(null);
  const [combineLayoutId, setCombineLayoutId] = useState<string>('');
  const [combineColorId, setCombineColorId] = useState<string>('');

  const fileInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);

  const currentRef = references.find((r) => r.id === (selectedRefId || activeReference?.id)) || activeReference;

  const showNotice = (msg: string) => {
    setFeedbackNotice(msg);
    setTimeout(() => setFeedbackNotice(null), 3500);
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      try {
        const newRef = await addReference(file, file.name.replace(/\.[^/.]+$/, ''));
        setSelectedRefId(newRef.id);
        showNotice(`Analyzed visual reference: ${file.name}`);
      } catch (err: any) {
        showNotice(`Failed to process image: ${err.message}`);
      }
    }
    if (fileInputRef.current) fileInputRef.current.value = '';
    if (cameraInputRef.current) cameraInputRef.current.value = '';
  };

  const copyToClipboard = (text: string, label: string = 'Copied') => {
    navigator.clipboard?.writeText(text);
    if (label.startsWith('#')) {
      setCopiedHex(label);
      setTimeout(() => setCopiedHex(null), 1800);
    } else {
      setCopiedCode(true);
      setTimeout(() => setCopiedCode(false), 2000);
    }
  };

  const roleOptions: { value: ReferenceRole; label: string; desc: string }[] = [
    { value: 'general', label: 'General', desc: 'Full holistic design reference' },
    { value: 'layout', label: 'Layout', desc: 'Composition, spacing & structure' },
    { value: 'color', label: 'Colors', desc: 'Palette, glowing accents & lighting' },
    { value: 'mascot', label: 'Mascot', desc: 'Avatar, character & cybernetic visor' },
    { value: 'typography', label: 'Typography', desc: 'Font style, weights & tracking' },
    { value: 'components', label: 'Components', desc: 'Dock, cards, buttons & widgets' },
  ];

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-md">
        <motion.div
          initial={{ opacity: 0, scale: 0.94, y: 15 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.94, y: 15 }}
          transition={{ duration: 0.2 }}
          className="relative w-full max-w-3xl max-h-[92vh] flex flex-col rounded-3xl bg-[#060a1d] border border-cyan-500/40 shadow-[0_0_40px_rgba(0,229,255,0.25)] overflow-hidden text-slate-200"
        >
          {/* Ambient header glow */}
          <div className="absolute top-0 inset-x-0 h-32 bg-gradient-to-b from-cyan-500/15 via-blue-600/10 to-transparent pointer-events-none" />

          {/* Top Bar */}
          <div className="relative px-5 pt-4 pb-3 flex items-center justify-between border-b border-cyan-500/20 z-10">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-[#0d163a] border border-cyan-400/50 flex items-center justify-center shadow-[0_0_12px_rgba(0,229,255,0.3)]">
                <Eye className="w-5 h-5 text-cyan-300" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h2 className="text-base font-bold text-white tracking-wide">
                    Visual Design Intelligence
                  </h2>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-cyan-950/80 border border-cyan-400/40 text-cyan-300 uppercase tracking-wider">
                    Omni Vision
                  </span>
                </div>
                <p className="text-xs text-slate-400 mt-0.5">
                  Analyze layouts, extract color palettes, transform Hinata UI, and recreate designs.
                </p>
              </div>
            </div>

            <button
              onClick={onClose}
              className="w-8 h-8 rounded-full bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white flex items-center justify-center transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Toast / Notification Banner */}
          {feedbackNotice && (
            <motion.div
              initial={{ opacity: 0, y: -8 }}
              animate={{ opacity: 1, y: 0 }}
              className="mx-5 mt-2 px-3.5 py-1.5 rounded-xl bg-cyan-950/90 border border-cyan-400/50 text-cyan-200 text-xs flex items-center gap-2 shadow-[0_0_15px_rgba(0,229,255,0.2)]"
            >
              <Sparkles className="w-3.5 h-3.5 text-cyan-300 flex-shrink-0 animate-pulse" />
              <span>{feedbackNotice}</span>
            </motion.div>
          )}

          {/* Navigation Tabs */}
          <div className="px-5 pt-3 pb-2 flex items-center gap-1.5 overflow-x-auto border-b border-slate-800/80 select-none scrollbar-none">
            {[
              { id: 'maker', label: 'Design Maker', icon: Wand2 },
              { id: 'references', label: 'References', icon: Layers, badge: references.length },
              { id: 'analysis', label: 'Breakdown', icon: Compass, disabled: !currentRef },
              { id: 'critic', label: 'Self-Review & Critique', icon: ShieldCheck, disabled: !currentRef },
              { id: 'honest', label: 'Honest Decision', icon: Scale },
              { id: 'transform', label: 'Apply Theme', icon: Sliders, disabled: !currentRef },
              { id: 'code', label: 'Recreate Spec', icon: Code2, disabled: !currentRef },
              { id: 'memory', label: 'Style Memory', icon: BookmarkPlus },
            ].map((tab) => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  disabled={tab.disabled}
                  onClick={() => setActiveTab(tab.id as StudioTab)}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold tracking-wide transition-all whitespace-nowrap ${
                    isActive
                      ? 'bg-cyan-500/20 text-cyan-200 border border-cyan-400/50 shadow-[0_0_12px_rgba(0,229,255,0.2)]'
                      : tab.disabled
                      ? 'text-slate-600 cursor-not-allowed opacity-50'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  <span>{tab.label}</span>
                  {tab.badge !== undefined && tab.badge > 0 && (
                    <span className="px-1.5 py-0.2 rounded-full text-[10px] font-bold bg-cyan-400 text-[#060a1d]">
                      {tab.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </div>

          {/* Body Content */}
          <div className="flex-1 overflow-y-auto px-5 py-4 space-y-4 min-h-[380px]">
            {/* Hidden File Inputs */}
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              multiple
              className="hidden"
              onChange={handleFileUpload}
            />
            <input
              ref={cameraInputRef}
              type="file"
              accept="image/*"
              capture="environment"
              className="hidden"
              onChange={handleFileUpload}
            />

            {/* TAB: DESIGN MAKER */}
            {activeTab === 'maker' && (
              <DesignMakerStudio
                onShowNotice={showNotice}
                onApplyStyle={(styleName) => {
                  showNotice(`Applied style: ${styleName}`);
                }}
              />
            )}

            {/* TAB: SELF-REVIEW & CRITIQUE */}
            {activeTab === 'critic' && (
              <DesignReviewStudio
                activeRef={currentRef || null}
                onShowNotice={showNotice}
              />
            )}

            {/* TAB: HONEST DECISION */}
            {activeTab === 'honest' && (
              <HonestDecisionStudio />
            )}

            {/* TAB 1: REFERENCES */}
            {activeTab === 'references' && (
              <div className="space-y-4">
                {/* Upload & Capture Bar */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                  <button
                    onClick={() => fileInputRef.current?.click()}
                    className="flex items-center justify-center gap-2 p-3 rounded-2xl bg-[#0e1738] border border-cyan-500/30 hover:border-cyan-400/60 hover:bg-[#13204d] text-cyan-200 transition-all group"
                  >
                    <Upload className="w-4 h-4 text-cyan-400 group-hover:scale-110 transition-transform" />
                    <span className="text-xs font-semibold">Upload Image / UI</span>
                  </button>

                  <button
                    onClick={() => cameraInputRef.current?.click()}
                    className="flex items-center justify-center gap-2 p-3 rounded-2xl bg-[#0e1738] border border-purple-500/30 hover:border-purple-400/60 hover:bg-[#13204d] text-purple-200 transition-all group"
                  >
                    <Camera className="w-4 h-4 text-purple-400 group-hover:scale-110 transition-transform" />
                    <span className="text-xs font-semibold">Capture Photo / Screen</span>
                  </button>

                  <button
                    onClick={() => {
                      if (activeTheme.isCustomApplied) {
                        resetTheme();
                        showNotice('Reset Hinata UI back to default Cyber Hologram aesthetic');
                      } else {
                        showNotice('Already using default Cyber Hologram aesthetic');
                      }
                    }}
                    className="flex items-center justify-center gap-2 p-3 rounded-2xl bg-[#0e1738] border border-slate-700 hover:border-slate-500 hover:bg-[#13204d] text-slate-300 transition-all"
                  >
                    <RefreshCw className="w-4 h-4 text-slate-400" />
                    <span className="text-xs font-semibold">
                      {activeTheme.isCustomApplied ? 'Reset Active Theme' : 'Theme: Default'}
                    </span>
                  </button>
                </div>

                {/* Reference Gallery */}
                {references.length === 0 ? (
                  <div className="flex flex-col items-center justify-center p-8 rounded-3xl bg-[#090f28]/60 border border-dashed border-cyan-500/30 text-center space-y-3">
                    <div className="w-14 h-14 rounded-full bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center shadow-[0_0_20px_rgba(0,229,255,0.15)]">
                      <Layers className="w-7 h-7 text-cyan-400" />
                    </div>
                    <div>
                      <h3 className="text-sm font-semibold text-white">No Visual References Added Yet</h3>
                      <p className="text-xs text-slate-400 max-w-md mt-1">
                        Upload UI screenshots, mobile app mockups, websites, color palettes, or mascots. Hinata will inspect their layout, colors, typography, and components.
                      </p>
                    </div>
                    <div className="flex items-center gap-2 pt-1">
                      <button
                        onClick={() => fileInputRef.current?.click()}
                        className="px-4 py-2 rounded-full bg-cyan-500 text-[#060a1d] font-bold text-xs hover:bg-cyan-400 shadow-[0_0_15px_rgba(0,229,255,0.4)] transition-all"
                      >
                        Select Image to Analyze
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-3">
                    <div className="flex items-center justify-between text-xs text-slate-400 px-1">
                      <span>Active Reference Images ({references.length})</span>
                      {references.length > 1 && (
                        <button
                          onClick={clearAllReferences}
                          className="text-rose-400 hover:text-rose-300 flex items-center gap-1 transition-colors"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                          <span>Clear All</span>
                        </button>
                      )}
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      {references.map((ref) => {
                        const isSelected = (selectedRefId || activeReference?.id) === ref.id;
                        return (
                          <div
                            key={ref.id}
                            onClick={() => setSelectedRefId(ref.id)}
                            className={`relative p-3 rounded-2xl transition-all cursor-pointer border ${
                              isSelected
                                ? 'bg-[#0f1b40] border-cyan-400 shadow-[0_0_20px_rgba(0,229,255,0.25)]'
                                : 'bg-[#0a102b] border-slate-800 hover:border-slate-700'
                            }`}
                          >
                            <div className="flex gap-3">
                              {/* Thumbnail preview */}
                              <div className="w-20 h-20 rounded-xl overflow-hidden bg-black/40 border border-slate-800 flex-shrink-0 relative">
                                <img
                                  src={ref.dataUrl}
                                  alt={ref.name}
                                  className="w-full h-full object-cover"
                                />
                                {ref.status === 'analyzing' && (
                                  <div className="absolute inset-0 bg-black/60 flex items-center justify-center">
                                    <RefreshCw className="w-4 h-4 text-cyan-400 animate-spin" />
                                  </div>
                                )}
                              </div>

                              {/* Details */}
                              <div className="flex-1 min-w-0">
                                <div className="flex items-center justify-between gap-1">
                                  <h4 className="text-xs font-bold text-white truncate">{ref.name}</h4>
                                  <button
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      removeReference(ref.id);
                                    }}
                                    className="text-slate-500 hover:text-rose-400 transition-colors p-1"
                                    title="Delete reference"
                                  >
                                    <Trash2 className="w-3.5 h-3.5" />
                                  </button>
                                </div>

                                <div className="mt-1 flex items-center gap-1.5 flex-wrap">
                                  <select
                                    value={ref.role}
                                    onClick={(e) => e.stopPropagation()}
                                    onChange={(e) => updateRole(ref.id, e.target.value as ReferenceRole)}
                                    className="bg-[#05081c] border border-cyan-500/30 text-cyan-300 rounded-lg px-2 py-0.5 text-[10px] font-semibold focus:outline-none"
                                  >
                                    {roleOptions.map((opt) => (
                                      <option key={opt.value} value={opt.value}>
                                        Role: {opt.label}
                                      </option>
                                    ))}
                                  </select>
                                </div>

                                {/* Color preview dots */}
                                {ref.analysis?.colors.rawSwatches && (
                                  <div className="flex items-center gap-1 mt-2">
                                    {ref.analysis.colors.rawSwatches.slice(0, 5).map((hex, idx) => (
                                      <span
                                        key={idx}
                                        className="w-3.5 h-3.5 rounded-full border border-black/40"
                                        style={{ backgroundColor: hex }}
                                        title={hex}
                                      />
                                    ))}
                                  </div>
                                )}
                              </div>
                            </div>

                            {/* Quick Action Footer */}
                            <div className="mt-3 pt-2 border-t border-slate-800/80 flex items-center justify-between gap-2">
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setSelectedRefId(ref.id);
                                  setActiveTab('analysis');
                                }}
                                className="text-[11px] font-semibold text-cyan-400 hover:text-cyan-300 flex items-center gap-1"
                              >
                                <Compass className="w-3 h-3" />
                                <span>Inspect Breakdown</span>
                              </button>

                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  applyReferenceToUI(ref.id);
                                  showNotice(`Applied ${ref.name} styling directly to Hinata UI!`);
                                }}
                                className="px-2.5 py-1 rounded-lg bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 border border-cyan-400/40 text-[11px] font-semibold flex items-center gap-1"
                              >
                                <Sparkles className="w-3 h-3 text-cyan-400" />
                                <span>Apply to UI</span>
                              </button>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}

                {/* Voice Prompts Helper */}
                <div className="p-3.5 rounded-2xl bg-[#090f28]/80 border border-slate-800/80 space-y-1.5">
                  <div className="flex items-center gap-2 text-xs font-bold text-cyan-300">
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>Voice Commands Supported</span>
                  </div>
                  <p className="text-[11.5px] text-slate-400 leading-relaxed">
                    With any reference uploaded, speak naturally into the mic:
                    <br />
                    <span className="text-slate-300 font-mono text-[11px]">
                      &quot;Hinata, make my UI look like this.&quot;
                    </span>{' '}
                    •{' '}
                    <span className="text-slate-300 font-mono text-[11px]">
                      &quot;Use the layout from reference 1 and colors from reference 2.&quot;
                    </span>{' '}
                    •{' '}
                    <span className="text-slate-300 font-mono text-[11px]">
                      &quot;Make this more futuristic.&quot;
                    </span>
                  </p>
                </div>
              </div>
            )}

            {/* TAB 2: ANALYSIS & BREAKDOWN */}
            {activeTab === 'analysis' && currentRef && (
              <div className="space-y-4">
                {/* Header overview */}
                <div className="p-4 rounded-2xl bg-[#0d163a] border border-cyan-500/30 flex flex-col sm:flex-row gap-4 items-start">
                  <div className="w-24 h-24 rounded-xl overflow-hidden bg-black/40 border border-cyan-400/30 flex-shrink-0">
                    <img
                      src={currentRef.dataUrl}
                      alt={currentRef.name}
                      className="w-full h-full object-cover"
                    />
                  </div>

                  <div className="flex-1 space-y-1.5">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <h3 className="text-sm font-bold text-white">{currentRef.name}</h3>
                        <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-cyan-400/20 text-cyan-300 uppercase">
                          {currentRef.role}
                        </span>
                      </div>
                      <button
                        onClick={() => {
                          triggerAnalysis(currentRef.id);
                          showNotice('Refreshing deep visual analysis...');
                        }}
                        className="text-xs text-cyan-400 hover:text-cyan-300 flex items-center gap-1"
                      >
                        <RefreshCw className="w-3 h-3" />
                        <span>Re-analyze</span>
                      </button>
                    </div>

                    <p className="text-xs text-slate-300 leading-relaxed">
                      {currentRef.analysis?.summary || 'Analyzing composition and aesthetic properties...'}
                    </p>

                    <div className="flex items-center gap-1.5 flex-wrap pt-1">
                      {currentRef.analysis?.visualStyle.moodKeywords.map((kw, i) => (
                        <span
                          key={i}
                          className="px-2 py-0.5 rounded-full text-[10px] font-medium bg-slate-800 text-slate-300 border border-slate-700"
                        >
                          #{kw}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>

                {/* 1. COLOR PALETTE */}
                {currentRef.analysis?.colors && (
                  <div className="p-4 rounded-2xl bg-[#090f28] border border-slate-800 space-y-2.5">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2 text-xs font-bold text-white">
                        <Palette className="w-4 h-4 text-cyan-400" />
                        <span>Extracted Color Palette</span>
                      </div>
                      <span className="text-[11px] text-slate-400">Click swatch to copy hex</span>
                    </div>

                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                      {[
                        { label: 'Primary', hex: currentRef.analysis.colors.primary },
                        { label: 'Secondary', hex: currentRef.analysis.colors.secondary },
                        { label: 'Accent Glow', hex: currentRef.analysis.colors.accent },
                        { label: 'Background', hex: currentRef.analysis.colors.background },
                      ].map((c, idx) => (
                        <button
                          key={idx}
                          onClick={() => copyToClipboard(c.hex, c.hex)}
                          className="flex items-center gap-2 p-2 rounded-xl bg-[#0e1635] border border-slate-800 hover:border-cyan-400/50 transition-all text-left group"
                        >
                          <span
                            className="w-6 h-6 rounded-lg border border-black/40 flex-shrink-0 shadow-sm"
                            style={{ backgroundColor: c.hex }}
                          />
                          <div className="min-w-0">
                            <p className="text-[10px] text-slate-400 uppercase tracking-wider">{c.label}</p>
                            <p className="text-xs font-mono font-semibold text-slate-200 group-hover:text-cyan-300">
                              {copiedHex === c.hex ? 'COPIED!' : c.hex}
                            </p>
                          </div>
                        </button>
                      ))}
                    </div>

                    {currentRef.analysis.colors.rawSwatches && currentRef.analysis.colors.rawSwatches.length > 0 && (
                      <div className="pt-2 flex items-center gap-1.5 flex-wrap">
                        <span className="text-[11px] text-slate-400 mr-1">Harmonies:</span>
                        {currentRef.analysis.colors.rawSwatches.map((hex, i) => (
                          <button
                            key={i}
                            onClick={() => copyToClipboard(hex, hex)}
                            className="flex items-center gap-1 px-2 py-0.5 rounded-md bg-[#0e1635] border border-slate-700 hover:border-cyan-400 text-[10px] font-mono"
                          >
                            <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: hex }} />
                            <span>{hex}</span>
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                )}

                {/* 2. LAYOUT & SPACING */}
                {currentRef.analysis?.layout && (
                  <div className="p-4 rounded-2xl bg-[#090f28] border border-slate-800 space-y-2">
                    <div className="flex items-center gap-2 text-xs font-bold text-white">
                      <Compass className="w-4 h-4 text-purple-400" />
                      <span>Layout & Composition Breakdown</span>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs text-slate-300">
                      <div className="p-2.5 rounded-xl bg-[#0e1635] space-y-1">
                        <span className="text-[10px] font-bold text-cyan-400 uppercase tracking-wider">
                          Composition
                        </span>
                        <p className="leading-relaxed">{currentRef.analysis.layout.composition}</p>
                      </div>

                      <div className="p-2.5 rounded-xl bg-[#0e1635] space-y-1">
                        <span className="text-[10px] font-bold text-purple-400 uppercase tracking-wider">
                          Positioning & Spacing
                        </span>
                        <p className="leading-relaxed">{currentRef.analysis.layout.positioning}</p>
                        <p className="text-slate-400 text-[11px]">Spacing: {currentRef.analysis.layout.spacing}</p>
                      </div>
                    </div>

                    {currentRef.analysis.layout.hierarchy && (
                      <div className="pt-1">
                        <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
                          Visual Hierarchy
                        </span>
                        <div className="flex items-center gap-2 flex-wrap text-xs">
                          {currentRef.analysis.layout.hierarchy.map((step, idx) => (
                            <React.Fragment key={idx}>
                              <span className="px-2 py-1 rounded-lg bg-[#0e1635] text-slate-200 border border-slate-700 font-medium">
                                {idx + 1}. {step}
                              </span>
                              {idx < currentRef.analysis!.layout.hierarchy.length - 1 && (
                                <ArrowRight className="w-3 h-3 text-slate-500" />
                              )}
                            </React.Fragment>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                )}

                {/* 3. TYPOGRAPHY */}
                {currentRef.analysis?.typography && (
                  <div className="p-4 rounded-2xl bg-[#090f28] border border-slate-800 space-y-2">
                    <div className="flex items-center gap-2 text-xs font-bold text-white">
                      <TypeIcon className="w-4 h-4 text-emerald-400" />
                      <span>Typography Hierarchy</span>
                    </div>

                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
                      {Object.entries(currentRef.analysis.typography.approximateSizes || {}).map(
                        ([level, size]) => (
                          <div key={level} className="p-2 rounded-xl bg-[#0e1635]">
                            <span className="text-[10px] uppercase font-bold text-emerald-400">{level}</span>
                            <p className="text-white font-mono font-semibold">{size}</p>
                          </div>
                        )
                      )}
                    </div>

                    <p className="text-xs text-slate-400">
                      Style: <span className="text-slate-200">{currentRef.analysis.typography.fontStyle}</span> •{' '}
                      Tracking:{' '}
                      <span className="text-slate-200">{currentRef.analysis.typography.letterSpacing}</span>
                    </p>
                  </div>
                )}

                {/* 4. UI COMPONENTS */}
                {currentRef.analysis?.components && (
                  <div className="p-4 rounded-2xl bg-[#090f28] border border-slate-800 space-y-2">
                    <div className="flex items-center gap-2 text-xs font-bold text-white">
                      <Layers className="w-4 h-4 text-amber-400" />
                      <span>UI Component Analysis</span>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-slate-300">
                      <div className="p-2.5 rounded-xl bg-[#0e1635]">
                        <span className="text-[10px] font-bold text-amber-400 uppercase">Controls & Buttons</span>
                        <p className="mt-0.5">{currentRef.analysis.components.buttons}</p>
                      </div>
                      <div className="p-2.5 rounded-xl bg-[#0e1635]">
                        <span className="text-[10px] font-bold text-amber-400 uppercase">Cards & Containers</span>
                        <p className="mt-0.5">{currentRef.analysis.components.cards}</p>
                      </div>
                      <div className="p-2.5 rounded-xl bg-[#0e1635]">
                        <span className="text-[10px] font-bold text-amber-400 uppercase">Navigation Dock</span>
                        <p className="mt-0.5">{currentRef.analysis.components.navigation}</p>
                      </div>
                      <div className="p-2.5 rounded-xl bg-[#0e1635]">
                        <span className="text-[10px] font-bold text-amber-400 uppercase">Avatar & Mascot</span>
                        <p className="mt-0.5">{currentRef.analysis.components.avatars}</p>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* TAB 3: APPLY & TRANSFORM */}
            {activeTab === 'transform' && currentRef && (
              <div className="space-y-4">
                {/* 1-Click Apply to Live UI */}
                <div className="p-4 rounded-3xl bg-gradient-to-r from-cyan-950/60 to-blue-950/60 border border-cyan-500/50 shadow-[0_0_30px_rgba(0,229,255,0.2)] space-y-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-sm font-bold text-white flex items-center gap-1.5">
                        <Sparkles className="w-4 h-4 text-cyan-300" />
                        <span>Live Theme Transformation</span>
                      </h3>
                      <p className="text-xs text-cyan-200/80 mt-0.5">
                        Safely adopts this reference&apos;s glowing neon accents, mascot aura, and ambient reflections.
                      </p>
                    </div>

                    <button
                      onClick={() => {
                        applyReferenceToUI(currentRef.id);
                        showNotice(`Applied ${currentRef.name} styling directly to Hinata!`);
                      }}
                      className="px-4 py-2 rounded-2xl bg-cyan-400 hover:bg-cyan-300 text-[#060a1d] font-bold text-xs shadow-[0_0_15px_rgba(0,229,255,0.5)] transition-all flex items-center gap-1.5"
                    >
                      <Sparkles className="w-3.5 h-3.5 text-[#060a1d]" />
                      <span>Apply to Hinata UI</span>
                    </button>
                  </div>

                  <div className="p-3 rounded-xl bg-[#060a1d]/80 border border-cyan-500/30 flex items-center justify-between text-xs">
                    <span className="text-slate-300">Active Theme Status:</span>
                    <span className="font-semibold text-cyan-300">
                      {activeTheme.isCustomApplied ? activeTheme.name : 'Hinata Cyber Hologram (Default)'}
                    </span>
                  </div>
                </div>

                {/* Combine References */}
                {references.length >= 2 && (
                  <div className="p-4 rounded-2xl bg-[#090f28] border border-slate-800 space-y-3">
                    <div className="flex items-center gap-2 text-xs font-bold text-white">
                      <Shuffle className="w-4 h-4 text-purple-400" />
                      <span>Combine Multiple References</span>
                    </div>
                    <p className="text-xs text-slate-400">
                      Synthesize two references together (e.g. Layout from Reference 1 and Colors from Reference 2).
                    </p>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                      <div>
                        <label className="text-[10px] font-bold text-slate-400 uppercase block mb-1">
                          Layout Reference
                        </label>
                        <select
                          value={combineLayoutId || references[0].id}
                          onChange={(e) => setCombineLayoutId(e.target.value)}
                          className="w-full bg-[#0e1635] border border-slate-700 rounded-xl px-3 py-2 text-white text-xs focus:outline-none"
                        >
                          {references.map((r) => (
                            <option key={r.id} value={r.id}>
                              {r.name} ({r.role})
                            </option>
                          ))}
                        </select>
                      </div>

                      <div>
                        <label className="text-[10px] font-bold text-slate-400 uppercase block mb-1">
                          Colors Reference
                        </label>
                        <select
                          value={combineColorId || references[1]?.id || references[0].id}
                          onChange={(e) => setCombineColorId(e.target.value)}
                          className="w-full bg-[#0e1635] border border-slate-700 rounded-xl px-3 py-2 text-white text-xs focus:outline-none"
                        >
                          {references.map((r) => (
                            <option key={r.id} value={r.id}>
                              {r.name} ({r.role})
                            </option>
                          ))}
                        </select>
                      </div>
                    </div>

                    <button
                      onClick={() => {
                        const lId = combineLayoutId || references[0].id;
                        const cId = combineColorId || references[1].id;
                        combineReferences(lId, cId);
                        showNotice('Synthesized hybrid design theme successfully!');
                      }}
                      className="w-full py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs shadow-[0_0_15px_rgba(168,85,247,0.4)] transition-all flex items-center justify-center gap-1.5"
                    >
                      <Shuffle className="w-3.5 h-3.5" />
                      <span>Combine & Apply Hybrid Theme</span>
                    </button>
                  </div>
                )}

                {/* Preset Transformation Prompts */}
                <div className="p-4 rounded-2xl bg-[#090f28] border border-slate-800 space-y-2.5">
                  <span className="text-xs font-bold text-white block">Preset Transformations</span>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {[
                      {
                        title: 'Make More Futuristic',
                        desc: 'Intensifies cyan/purple neon glow & energy rings',
                        instruction: 'Make this design more futuristic with glowing neon and orbital aura',
                      },
                      {
                        title: 'Make Mobile Friendly',
                        desc: 'Optimizes touch targets and compact dock',
                        instruction: 'Optimize this design for compact mobile screens and 48px touch targets',
                      },
                      {
                        title: 'Minimalist Clean',
                        desc: 'Reduces heavy borders, increases negative space',
                        instruction: 'Make this design more minimal, spacious, and subtle',
                      },
                      {
                        title: 'Neon Cyberpunk',
                        desc: 'Applies dual-tone cyan and magenta glow',
                        instruction: 'Apply vibrant high-contrast cyberpunk neon glow',
                      },
                    ].map((item, idx) => (
                      <button
                        key={idx}
                        onClick={() => {
                          triggerAnalysis(currentRef.id, item.instruction);
                          showNotice(`Applying transformation: ${item.title}`);
                        }}
                        className="p-2.5 rounded-xl bg-[#0e1635] border border-slate-800 hover:border-cyan-400/40 text-left transition-all group"
                      >
                        <p className="text-xs font-bold text-slate-200 group-hover:text-cyan-300">
                          {item.title}
                        </p>
                        <p className="text-[11px] text-slate-400 mt-0.5">{item.desc}</p>
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* TAB 4: RECREATE & EXPORT CODE */}
            {activeTab === 'code' && currentRef && (
              <div className="space-y-4">
                <div className="p-4 rounded-2xl bg-[#090f28] border border-slate-800 space-y-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-xs font-bold text-white">Suggested Tailwind Utility Classes</h3>
                      <p className="text-[11px] text-slate-400">Reconstruct this design aesthetic in React</p>
                    </div>

                    <button
                      onClick={() =>
                        copyToClipboard(
                          currentRef.analysis?.reconstructionPlan.suggestedTailwindClasses.join(' ') || '',
                          'Classes'
                        )
                      }
                      className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs text-cyan-300 flex items-center gap-1"
                    >
                      <Copy className="w-3.5 h-3.5" />
                      <span>{copiedCode ? 'Copied' : 'Copy Classes'}</span>
                    </button>
                  </div>

                  <div className="p-3 rounded-xl bg-[#060a1d] font-mono text-xs text-cyan-300/90 border border-slate-800 break-words leading-relaxed">
                    {currentRef.analysis?.reconstructionPlan.suggestedTailwindClasses.join(' ')}
                  </div>
                </div>

                {/* CSS Variables */}
                {currentRef.analysis?.reconstructionPlan.cssVariables && (
                  <div className="p-4 rounded-2xl bg-[#090f28] border border-slate-800 space-y-2">
                    <h3 className="text-xs font-bold text-white">Design Token CSS Variables</h3>
                    <pre className="p-3 rounded-xl bg-[#060a1d] font-mono text-xs text-slate-300 border border-slate-800 overflow-x-auto">
                      {Object.entries(currentRef.analysis.reconstructionPlan.cssVariables)
                        .map(([k, v]) => `${k}: ${v};`)
                        .join('\n')}
                    </pre>
                  </div>
                )}

                {/* Recommendations */}
                {currentRef.analysis?.reconstructionPlan.keyRecommendations && (
                  <div className="p-4 rounded-2xl bg-[#090f28] border border-slate-800 space-y-2">
                    <h3 className="text-xs font-bold text-white">Reconstruction Blueprint Advice</h3>
                    <ul className="space-y-1 text-xs text-slate-300 list-disc list-inside">
                      {currentRef.analysis.reconstructionPlan.keyRecommendations.map((rec, i) => (
                        <li key={i}>{rec}</li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            )}

            {/* TAB 5: DESIGN MEMORY */}
            {activeTab === 'memory' && (
              <div className="space-y-4">
                <div className="p-4 rounded-3xl bg-gradient-to-r from-purple-950/60 to-blue-950/60 border border-purple-500/40 space-y-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-sm font-bold text-white flex items-center gap-1.5">
                        <BookmarkPlus className="w-4 h-4 text-purple-300" />
                        <span>Save Design Preference to Long-Term Memory</span>
                      </h3>
                      <p className="text-xs text-purple-200/80 mt-0.5">
                        Hinata will remember your preferred visual aesthetics across sessions and in voice discussions.
                      </p>
                    </div>

                    <button
                      onClick={() => {
                        rememberPreference();
                        showNotice('Saved design style preference to Hinata Long-Term Memory!');
                      }}
                      className="px-4 py-2 rounded-2xl bg-purple-500 hover:bg-purple-400 text-white font-bold text-xs shadow-[0_0_15px_rgba(168,85,247,0.4)] transition-all flex items-center gap-1.5"
                    >
                      <Check className="w-3.5 h-3.5" />
                      <span>Remember This Style</span>
                    </button>
                  </div>

                  <div className="p-3 rounded-xl bg-[#060a1d]/80 border border-purple-500/30 text-xs text-slate-300">
                    Currently saved aesthetic: <span className="text-purple-300 font-semibold">{activeTheme.name}</span>{' '}
                    (Glow: {activeTheme.mascotGlowColor})
                  </div>
                </div>

                <div className="p-4 rounded-2xl bg-[#090f28] border border-slate-800 space-y-2">
                  <h4 className="text-xs font-bold text-white">How Memory Integration Works</h4>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    When you speak with Hinata (e.g. &quot;Hinata, remember that I like this style&quot; or click Remember
                    above), it is stored with importance 9/10 in Hinata&apos;s verified Memory Manager under{' '}
                    <span className="text-cyan-300 font-mono">preference</span>. Hinata will use these color choices and
                    layout tastes when answering your future design queries.
                  </p>
                </div>
              </div>
            )}
          </div>

          {/* Footer Bar */}
          <div className="px-5 py-3 border-t border-slate-800/80 bg-[#060a1d] flex items-center justify-between text-xs text-slate-400">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-cyan-400 shadow-[0_0_6px_#00e5ff]" />
              <span>Vision Engine: Gemini 3.8 Flash Multimodal</span>
            </div>

            <button
              onClick={onClose}
              className="px-4 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs transition-colors"
            >
              Close
            </button>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
