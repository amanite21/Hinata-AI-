/**
 * MemoryModal - User Control & Privacy Center for Hinata AI Memory System.
 * Enables users to:
 * - View, search, and filter stored memories across categories
 * - Add, edit, and delete specific memories
 * - View & update Hinata's structured understanding of the user (profile)
 * - Inspect past conversation summaries
 * - Toggle memory system on/off (disable memory)
 * - Clear all memories with confirmation
 * - Export and Import memory vaults
 */

import React, { useState, useEffect } from 'react';
import {
  X,
  Brain,
  Search,
  Plus,
  Trash2,
  Edit2,
  Check,
  Download,
  Upload,
  User,
  History,
  Shield,
  Tag,
  AlertTriangle,
  RotateCcw,
} from 'lucide-react';
import { MemoryManager } from '../modules/memory/MemoryManager';
import { MemoryItem, UserProfile, ConversationSummary, MemoryCategory } from '../modules/memory/MemoryTypes';

interface MemoryModalProps {
  isOpen: boolean;
  onClose: () => void;
}

type TabType = 'memories' | 'profile' | 'conversations' | 'settings';

export const MemoryModal: React.FC<MemoryModalProps> = ({ isOpen, onClose }) => {
  const [activeTab, setActiveTab] = useState<TabType>('memories');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  // State loaded from MemoryManager
  const [memories, setMemories] = useState<MemoryItem[]>([]);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [summaries, setSummaries] = useState<ConversationSummary[]>([]);
  const [isMemoryEnabled, setIsMemoryEnabled] = useState(true);
  const [autoExtractEnabled, setAutoExtractEnabled] = useState(true);

  // Add memory form state
  const [isAddingMemory, setIsAddingMemory] = useState(false);
  const [newContent, setNewContent] = useState('');
  const [newCategory, setNewCategory] = useState<MemoryCategory>('important');
  const [newImportance, setNewImportance] = useState<number>(8);

  // Edit memory inline state
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editContent, setEditContent] = useState('');

  // Confirmation state for clearing
  const [showClearConfirm, setShowClearConfirm] = useState(false);

  // Refresh data from MemoryManager
  const refreshData = () => {
    const mm = MemoryManager.getInstance();
    setMemories(mm.longTerm.getAll({ includeExpired: false }));
    setProfile(mm.getUserProfile());
    setSummaries(mm.conversations.getSummaries());
    const config = mm.getConfig();
    setIsMemoryEnabled(config.enabled);
    setAutoExtractEnabled(config.autoExtract);
  };

  useEffect(() => {
    if (!isOpen) return;
    refreshData();
    const mm = MemoryManager.getInstance();
    const unsubscribe = mm.subscribe(() => {
      refreshData();
    });
    return unsubscribe;
  }, [isOpen]);

  if (!isOpen) return null;

  const mm = MemoryManager.getInstance();

  // Handlers for Memories Tab
  const handleSaveNewMemory = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newContent.trim()) return;
    mm.saveMemory({
      content: newContent.trim(),
      category: newCategory,
      importance: newImportance,
      source: 'explicit_user',
    });
    setNewContent('');
    setIsAddingMemory(false);
  };

  const handleDeleteMemory = (id: string) => {
    mm.deleteMemory(id);
  };

  const handleStartEdit = (item: MemoryItem) => {
    setEditingId(item.id);
    setEditContent(item.content);
  };

  const handleSaveEdit = (id: string) => {
    if (editContent.trim()) {
      mm.updateMemory(id, { content: editContent.trim() });
    }
    setEditingId(null);
  };

  // Handlers for Profile Tab
  const handleProfileFieldChange = (field: keyof UserProfile, value: string) => {
    mm.manageUserProfile(field, value, 'set');
  };

  // Handlers for Settings Tab
  const handleToggleEnable = () => {
    const nextState = !isMemoryEnabled;
    setIsMemoryEnabled(nextState);
    mm.updateConfig({ enabled: nextState });
  };

  const handleToggleAutoExtract = () => {
    const nextState = !autoExtractEnabled;
    setAutoExtractEnabled(nextState);
    mm.updateConfig({ autoExtract: nextState });
  };

  const handleClearAll = () => {
    mm.clearAllMemories();
    setShowClearConfirm(false);
  };

  const handleExportVault = () => {
    const jsonStr = mm.exportVault();
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `hinata-memory-vault-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleImportVault = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string;
      if (text) {
        const success = mm.importVault(text);
        if (success) {
          alert('Memory vault imported successfully!');
        } else {
          alert('Failed to import memory vault. Invalid file format.');
        }
      }
    };
    reader.readAsText(file);
  };

  // Filtering
  const filteredMemories = memories.filter((m) => {
    const matchesCategory = selectedCategory === 'all' || m.category === selectedCategory;
    const matchesQuery =
      !searchQuery.trim() ||
      m.content.toLowerCase().includes(searchQuery.toLowerCase()) ||
      m.tags.some((t) => t.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesCategory && matchesQuery;
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/75 backdrop-blur-md">
      <div
        className="w-full max-w-2xl glass-panel-glow rounded-3xl border border-white/15 p-5 sm:p-6 flex flex-col gap-4 max-h-[88vh] overflow-hidden text-neutral-100 shadow-2xl bg-[#090a12]/95"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Top Header */}
        <div className="flex items-center justify-between border-b border-white/10 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-purple-500/20 border border-purple-500/30 flex items-center justify-center text-purple-300 shadow-[0_0_12px_rgba(168,85,247,0.3)]">
              <Brain className="w-4 h-4" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-bold tracking-wide font-mono-tech">
                  Hinata Memory Vault
                </h2>
                <span
                  className={`text-[10px] px-2 py-0.5 rounded-full font-mono-tech ${
                    isMemoryEnabled
                      ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                      : 'bg-neutral-700/50 text-neutral-400 border border-white/10'
                  }`}
                >
                  {isMemoryEnabled ? 'Active' : 'Disabled'}
                </span>
              </div>
              <p className="text-[11px] text-neutral-400 font-mono-tech">
                Cross-Session Long-Term Context & Privacy Controls
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full glass-button flex items-center justify-center text-neutral-400 hover:text-white"
            aria-label="Close memory modal"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center gap-1 border-b border-white/10 pb-2">
          <button
            onClick={() => setActiveTab('memories')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium transition-all ${
              activeTab === 'memories'
                ? 'bg-purple-500/25 text-white border border-purple-500/40 shadow-sm'
                : 'text-neutral-400 hover:text-neutral-200 hover:bg-white/5'
            }`}
          >
            <Brain className="w-3.5 h-3.5" />
            <span>Memories ({memories.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('profile')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium transition-all ${
              activeTab === 'profile'
                ? 'bg-purple-500/25 text-white border border-purple-500/40 shadow-sm'
                : 'text-neutral-400 hover:text-neutral-200 hover:bg-white/5'
            }`}
          >
            <User className="w-3.5 h-3.5" />
            <span>Profile & Persona</span>
          </button>

          <button
            onClick={() => setActiveTab('conversations')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium transition-all ${
              activeTab === 'conversations'
                ? 'bg-purple-500/25 text-white border border-purple-500/40 shadow-sm'
                : 'text-neutral-400 hover:text-neutral-200 hover:bg-white/5'
            }`}
          >
            <History className="w-3.5 h-3.5" />
            <span>Past Sessions ({summaries.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('settings')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium transition-all ${
              activeTab === 'settings'
                ? 'bg-purple-500/25 text-white border border-purple-500/40 shadow-sm'
                : 'text-neutral-400 hover:text-neutral-200 hover:bg-white/5'
            }`}
          >
            <Shield className="w-3.5 h-3.5" />
            <span>Privacy & Vault</span>
          </button>
        </div>

        {/* Tab 1: Memories List & Search */}
        {activeTab === 'memories' && (
          <div className="flex-1 flex flex-col gap-3 overflow-hidden">
            {/* Search and Category Filter Toolbar */}
            <div className="flex flex-wrap sm:flex-nowrap items-center gap-2">
              <div className="relative flex-1 min-w-[180px]">
                <Search className="w-3.5 h-3.5 text-neutral-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search memories, preferences, projects..."
                  className="w-full bg-white/5 border border-white/10 rounded-xl pl-9 pr-3 py-1.5 text-xs text-neutral-100 placeholder-neutral-500 focus:outline-none focus:border-purple-400/50"
                />
              </div>

              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="bg-neutral-900 border border-white/10 rounded-xl px-2.5 py-1.5 text-xs text-neutral-300 focus:outline-none focus:border-purple-400/50"
              >
                <option value="all">All Categories</option>
                <option value="PREFERENCES">Preferences</option>
                <option value="PROJECTS">Projects</option>
                <option value="GOALS">Goals</option>
                <option value="SKILLS">Skills</option>
                <option value="LEARNING">Learning</option>
                <option value="WORKFLOW">Workflow</option>
                <option value="IMPORTANT_FACTS">Important Facts</option>
                <option value="PROFILE">Profile Facts</option>
                <option value="preference">Preferences (Legacy)</option>
                <option value="project">Projects (Legacy)</option>
                <option value="goal">Goals (Legacy)</option>
                <option value="instruction">Instructions</option>
                <option value="important">Important</option>
              </select>

              <button
                onClick={() => setIsAddingMemory(!isAddingMemory)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-semibold shadow-md transition-colors"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Memory</span>
              </button>
            </div>

            {/* Quick Add Form */}
            {isAddingMemory && (
              <form
                onSubmit={handleSaveNewMemory}
                className="glass-panel p-3 rounded-2xl border border-purple-500/30 flex flex-col gap-2.5 bg-purple-950/20"
              >
                <div className="flex items-center justify-between text-xs font-medium text-purple-200">
                  <span>Store New Explicit Memory</span>
                  <button
                    type="button"
                    onClick={() => setIsAddingMemory(false)}
                    className="text-neutral-400 hover:text-white"
                  >
                    Cancel
                  </button>
                </div>
                <textarea
                  value={newContent}
                  onChange={(e) => setNewContent(e.target.value)}
                  placeholder="e.g., User is building a mobile productivity app called Horizon; prefers dark theme and concise explanations."
                  rows={2}
                  className="w-full bg-black/40 border border-white/10 rounded-xl p-2 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-purple-400/50"
                />
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <select
                      value={newCategory}
                      onChange={(e) => setNewCategory(e.target.value as MemoryCategory)}
                      className="bg-neutral-900 border border-white/10 rounded-lg px-2 py-1 text-xs text-neutral-200"
                    >
                      <option value="PREFERENCES">Preference</option>
                      <option value="PROJECTS">Project</option>
                      <option value="GOALS">Goal</option>
                      <option value="SKILLS">Skill</option>
                      <option value="LEARNING">Learning</option>
                      <option value="WORKFLOW">Workflow</option>
                      <option value="IMPORTANT_FACTS">Important Fact</option>
                      <option value="PROFILE">Profile</option>
                      <option value="instruction">Instruction</option>
                    </select>
                    <div className="flex items-center gap-1 text-[11px] text-neutral-400">
                      <span>Importance:</span>
                      <input
                        type="range"
                        min="1"
                        max="10"
                        value={newImportance}
                        onChange={(e) => setNewImportance(Number(e.target.value))}
                        className="w-16 accent-purple-500"
                      />
                      <span className="text-purple-300 font-mono">{newImportance}/10</span>
                    </div>
                  </div>
                  <button
                    type="submit"
                    className="px-3 py-1 rounded-lg bg-purple-600 hover:bg-purple-500 text-white text-xs font-semibold"
                  >
                    Save Memory
                  </button>
                </div>
              </form>
            )}

            {/* Memories Scrollable List */}
            <div className="flex-1 overflow-y-auto space-y-2 pr-1">
              {filteredMemories.length === 0 ? (
                <div className="py-12 flex flex-col items-center justify-center text-center text-neutral-500">
                  <Brain className="w-8 h-8 mb-2 opacity-30 text-purple-400" />
                  <p className="text-xs">No memories found matching your criteria.</p>
                  <p className="text-[11px] text-neutral-600 mt-0.5">
                    Hinata automatically remembers facts during conversation, or you can add one above.
                  </p>
                </div>
              ) : (
                filteredMemories.map((m) => {
                  const isEditing = editingId === m.id;
                  return (
                    <div
                      key={m.id}
                      className="glass-panel p-3 rounded-xl border border-white/10 hover:border-white/20 transition-all flex flex-col gap-2 group"
                    >
                      <div className="flex items-start justify-between gap-2">
                        {isEditing ? (
                          <div className="flex-1 flex items-center gap-2">
                            <input
                              type="text"
                              value={editContent}
                              onChange={(e) => setEditContent(e.target.value)}
                              className="flex-1 bg-black/50 border border-purple-500/50 rounded-lg px-2.5 py-1 text-xs text-white"
                              autoFocus
                            />
                            <button
                              onClick={() => handleSaveEdit(m.id)}
                              className="p-1 rounded bg-purple-600 hover:bg-purple-500 text-white"
                              title="Save Edit"
                            >
                              <Check className="w-3.5 h-3.5" />
                            </button>
                            <button
                              onClick={() => setEditingId(null)}
                              className="p-1 text-neutral-400 hover:text-white"
                              title="Cancel"
                            >
                              <X className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        ) : (
                          <p className="text-xs text-neutral-200 leading-relaxed flex-1">
                            {m.content}
                          </p>
                        )}

                        <div className="flex items-center gap-1 opacity-80 group-hover:opacity-100 flex-shrink-0">
                          {!isEditing && (
                            <button
                              onClick={() => handleStartEdit(m)}
                              className="p-1 rounded text-neutral-400 hover:text-neutral-200 hover:bg-white/10 transition-colors"
                              title="Edit memory"
                            >
                              <Edit2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                          <button
                            onClick={() => handleDeleteMemory(m.id)}
                            className="p-1 rounded text-neutral-400 hover:text-rose-400 hover:bg-rose-500/10 transition-colors"
                            title="Delete memory"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>

                      {/* Tags & Metadata Footer */}
                      <div className="flex items-center justify-between text-[10px] text-neutral-400 pt-1 border-t border-white/5">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <span className="px-1.5 py-0.5 rounded bg-white/10 text-neutral-300 uppercase font-mono-tech">
                            {m.category}
                          </span>
                          <span className="text-neutral-500">•</span>
                          <span className="font-mono-tech text-purple-300">
                            Score: {m.importance}/10
                          </span>
                          {m.tags.map((tag) => (
                            <span
                              key={tag}
                              className="px-1 py-0.2 rounded bg-purple-950/30 text-purple-300/80 text-[9px] flex items-center gap-0.5"
                            >
                              <Tag className="w-2.5 h-2.5" />
                              {tag}
                            </span>
                          ))}
                        </div>
                        <span className="text-neutral-500 font-mono-tech">
                          {new Date(m.updatedAt).toLocaleDateString()}
                        </span>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        )}

        {/* Tab 2: Structured User Profile */}
        {activeTab === 'profile' && profile && (
          <div className="flex-1 overflow-y-auto space-y-3.5 pr-1">
            <div className="p-3 rounded-2xl bg-purple-950/30 border border-purple-500/20 text-xs text-neutral-300">
              <p className="font-semibold text-purple-200 mb-0.5">
                Hinata's Understanding of You
              </p>
              <p className="text-[11px] text-neutral-400">
                This structured profile helps Hinata calibrate her communication style, language, and context. You can modify any field below.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {/* Name */}
              <div className="glass-panel p-3 rounded-xl border border-white/10 flex flex-col gap-1">
                <label className="text-[10px] font-mono-tech uppercase text-neutral-400">
                  Your Name / Preferred Title
                </label>
                <input
                  type="text"
                  value={profile.name}
                  onChange={(e) => handleProfileFieldChange('name', e.target.value)}
                  placeholder="e.g. Alex"
                  className="bg-black/40 border border-white/10 rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-purple-400/50"
                />
              </div>

              {/* Preferred Language */}
              <div className="glass-panel p-3 rounded-xl border border-white/10 flex flex-col gap-1">
                <label className="text-[10px] font-mono-tech uppercase text-neutral-400">
                  Preferred Language
                </label>
                <input
                  type="text"
                  value={profile.preferredLanguage}
                  onChange={(e) => handleProfileFieldChange('preferredLanguage', e.target.value)}
                  placeholder="e.g. English, Hindi, Japanese"
                  className="bg-black/40 border border-white/10 rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-purple-400/50"
                />
              </div>

              {/* Communication Style */}
              <div className="sm:col-span-2 glass-panel p-3 rounded-xl border border-white/10 flex flex-col gap-1">
                <label className="text-[10px] font-mono-tech uppercase text-neutral-400">
                  Hinata Communication Tone with You
                </label>
                <input
                  type="text"
                  value={profile.communicationStyle}
                  onChange={(e) => handleProfileFieldChange('communicationStyle', e.target.value)}
                  placeholder="e.g. Natural, conversational, witty & supportive"
                  className="bg-black/40 border border-white/10 rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-purple-400/50"
                />
              </div>

              {/* Active Projects */}
              <div className="glass-panel p-3 rounded-xl border border-white/10 flex flex-col gap-1">
                <label className="text-[10px] font-mono-tech uppercase text-neutral-400">
                  Active Projects (comma separated)
                </label>
                <input
                  type="text"
                  value={profile.projects.join(', ')}
                  onChange={(e) =>
                    mm.manageUserProfile('projects', e.target.value.split(',').map((s) => s.trim()).filter(Boolean), 'set')
                  }
                  placeholder="e.g. Hinata Voice, React Dashboard"
                  className="bg-black/40 border border-white/10 rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-purple-400/50"
                />
              </div>

              {/* Long-term Goals */}
              <div className="glass-panel p-3 rounded-xl border border-white/10 flex flex-col gap-1">
                <label className="text-[10px] font-mono-tech uppercase text-neutral-400">
                  Long-Term Goals (comma separated)
                </label>
                <input
                  type="text"
                  value={profile.goals.join(', ')}
                  onChange={(e) =>
                    mm.manageUserProfile('goals', e.target.value.split(',').map((s) => s.trim()).filter(Boolean), 'set')
                  }
                  placeholder="e.g. Master TypeScript, Launch product"
                  className="bg-black/40 border border-white/10 rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-purple-400/50"
                />
              </div>
            </div>

            {/* Known Preferences */}
            <div className="glass-panel p-3 rounded-xl border border-white/10 flex flex-col gap-2">
              <span className="text-[10px] font-mono-tech uppercase text-neutral-400">
                Known Personal Preferences
              </span>
              <div className="flex flex-wrap gap-2">
                {Object.entries(profile.preferences).length === 0 ? (
                  <p className="text-xs text-neutral-500">No custom preferences registered yet.</p>
                ) : (
                  Object.entries(profile.preferences).map(([k, v]) => (
                    <span
                      key={k}
                      className="px-2.5 py-1 rounded-lg bg-white/5 border border-white/10 text-xs flex items-center gap-1.5"
                    >
                      <span className="font-semibold text-purple-300">{k}:</span>
                      <span className="text-neutral-200">{String(v)}</span>
                    </span>
                  ))
                )}
              </div>
            </div>
          </div>
        )}

        {/* Tab 3: Past Conversation Summaries */}
        {activeTab === 'conversations' && (
          <div className="flex-1 overflow-y-auto space-y-2.5 pr-1">
            <div className="p-3 rounded-2xl bg-cyan-950/20 border border-cyan-500/20 text-xs text-neutral-300">
              <p className="font-semibold text-cyan-200 mb-0.5">
                Session Summaries
              </p>
              <p className="text-[11px] text-neutral-400">
                Hinata stores compact semantic summaries instead of raw audio/message bloat, keeping response times ultra-fast.
              </p>
            </div>

            {summaries.length === 0 ? (
              <div className="py-12 flex flex-col items-center justify-center text-center text-neutral-500">
                <History className="w-8 h-8 mb-2 opacity-30 text-cyan-400" />
                <p className="text-xs">No previous conversation sessions recorded yet.</p>
                <p className="text-[11px] text-neutral-600 mt-0.5">
                  Summaries are automatically created when live sessions end.
                </p>
              </div>
            ) : (
              summaries.map((s) => (
                <div
                  key={s.id}
                  className="glass-panel p-3.5 rounded-2xl border border-white/10 hover:border-white/20 transition-all flex flex-col gap-2"
                >
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-xs text-cyan-200 font-mono-tech">
                      {s.mainTopic}
                    </span>
                    <span className="text-[10px] text-neutral-500 font-mono-tech">
                      {new Date(s.timestamp).toLocaleString(undefined, {
                        month: 'short',
                        day: 'numeric',
                        hour: '2-digit',
                        minute: '2-digit',
                      })}
                    </span>
                  </div>

                  {s.importantDecisions.length > 0 && (
                    <div className="text-[11px] text-neutral-300">
                      <span className="text-purple-300 font-medium">Decisions: </span>
                      {s.importantDecisions.join(' • ')}
                    </div>
                  )}

                  {s.unfinishedTasks.length > 0 && (
                    <div className="text-[11px] text-neutral-300">
                      <span className="text-amber-300 font-medium">Tasks / Follow-ups: </span>
                      {s.unfinishedTasks.join(' • ')}
                    </div>
                  )}

                  <div className="flex items-center justify-between text-[10px] text-neutral-500 pt-1 border-t border-white/5">
                    <span>{s.turnsCount} conversational turns</span>
                    <button
                      onClick={() => mm.conversations.deleteSummary(s.id)}
                      className="text-neutral-500 hover:text-rose-400"
                    >
                      Delete summary
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        )}

        {/* Tab 4: Privacy & Vault Settings */}
        {activeTab === 'settings' && (
          <div className="flex-1 overflow-y-auto space-y-4 pr-1">
            {/* System Enable / Disable */}
            <div className="glass-panel p-4 rounded-2xl border border-white/10 flex items-center justify-between">
              <div>
                <p className="font-semibold text-xs text-white">Enable Long-Term Memory</p>
                <p className="text-[11px] text-neutral-400 mt-0.5">
                  When enabled, Hinata remembers preferences, projects, and context across conversations.
                </p>
              </div>
              <button
                onClick={handleToggleEnable}
                className={`relative w-12 h-6 rounded-full transition-colors ${
                  isMemoryEnabled ? 'bg-purple-600' : 'bg-neutral-700'
                }`}
              >
                <span
                  className={`absolute top-1 left-1 w-4 h-4 rounded-full bg-white transition-transform ${
                    isMemoryEnabled ? 'translate-x-6' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>

            {/* Auto-Extract from Speech */}
            <div className="glass-panel p-4 rounded-2xl border border-white/10 flex items-center justify-between">
              <div>
                <p className="font-semibold text-xs text-white">Auto-Detect Preferences & Facts</p>
                <p className="text-[11px] text-neutral-400 mt-0.5">
                  Intelligently classifies important goals and preferences without requiring explicit "Remember this" commands.
                </p>
              </div>
              <button
                onClick={handleToggleAutoExtract}
                className={`relative w-12 h-6 rounded-full transition-colors ${
                  autoExtractEnabled ? 'bg-purple-600' : 'bg-neutral-700'
                }`}
              >
                <span
                  className={`absolute top-1 left-1 w-4 h-4 rounded-full bg-white transition-transform ${
                    autoExtractEnabled ? 'translate-x-6' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>

            {/* Consolidate Memories */}
            <div className="glass-panel p-4 rounded-2xl border border-white/10 flex items-center justify-between">
              <div>
                <p className="font-semibold text-xs text-white">Consolidate & Deduplicate Vault</p>
                <p className="text-[11px] text-neutral-400 mt-0.5">
                  Merges redundant entries and purges expired temporary notes.
                </p>
              </div>
              <button
                onClick={() => {
                  const res = mm.consolidateMemories();
                  alert(`Consolidation complete. Merged: ${res.merged}, Removed duplicates: ${res.removedDuplicates}`);
                }}
                className="px-3 py-1.5 rounded-xl glass-button text-xs text-purple-300 hover:text-white flex items-center gap-1.5"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Consolidate</span>
              </button>
            </div>

            {/* Export & Import Backup */}
            <div className="glass-panel p-4 rounded-2xl border border-white/10 flex flex-col gap-3">
              <div>
                <p className="font-semibold text-xs text-white">Backup & Portability</p>
                <p className="text-[11px] text-neutral-400 mt-0.5">
                  Download an encrypted local JSON copy of your memory vault or import on another device.
                </p>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={handleExportVault}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl glass-button text-xs text-neutral-200 hover:text-white"
                >
                  <Download className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Export Vault (JSON)</span>
                </button>
                <label className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl glass-button text-xs text-neutral-200 hover:text-white cursor-pointer">
                  <Upload className="w-3.5 h-3.5 text-purple-400" />
                  <span>Import Vault</span>
                  <input
                    type="file"
                    accept=".json"
                    onChange={handleImportVault}
                    className="hidden"
                  />
                </label>
              </div>
            </div>

            {/* Clear All Memories Zone */}
            <div className="glass-panel p-4 rounded-2xl border border-rose-500/30 bg-rose-950/20 flex flex-col gap-3">
              <div className="flex items-center gap-2 text-rose-300">
                <AlertTriangle className="w-4 h-4" />
                <p className="font-semibold text-xs">Danger Zone: Forget Everything</p>
              </div>
              <p className="text-[11px] text-neutral-400">
                Permanently wipes all memories, profile details, and conversation histories from Hinata. This cannot be undone.
              </p>

              {showClearConfirm ? (
                <div className="flex items-center gap-2 pt-1">
                  <button
                    onClick={handleClearAll}
                    className="px-3 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-semibold"
                  >
                    Yes, Wipe All Data
                  </button>
                  <button
                    onClick={() => setShowClearConfirm(false)}
                    className="px-3 py-1.5 rounded-xl glass-button text-xs text-neutral-300"
                  >
                    Cancel
                  </button>
                </div>
              ) : (
                <button
                  onClick={() => setShowClearConfirm(true)}
                  className="w-fit flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/40 text-xs font-semibold"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Clear All Memory Records</span>
                </button>
              )}
            </div>
          </div>
        )}

        {/* Modal Footer */}
        <div className="border-t border-white/10 pt-3 flex items-center justify-between text-[11px] text-neutral-400">
          <span className="font-mono-tech">
            {memories.length} item(s) in active vault
          </span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-semibold transition-colors"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
