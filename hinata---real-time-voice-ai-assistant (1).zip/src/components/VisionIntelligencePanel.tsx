import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Sparkles,
  Eye,
  Monitor,
  CheckCircle2,
  AlertTriangle,
  Code2,
  Copy,
  Check,
  Volume2,
  X,
  ChevronDown,
  ChevronUp,
  FileText,
  Sliders,
  Palette,
  Terminal,
  Zap,
} from 'lucide-react';
import { VisionManager } from '../modules/VisionManager';
import { StructuredVisionAnalysis } from '../types';

interface VisionIntelligencePanelProps {
  onTriggerPrompt?: (promptText: string) => void;
}

export const VisionIntelligencePanel: React.FC<VisionIntelligencePanelProps> = ({
  onTriggerPrompt,
}) => {
  const [visionState, setVisionState] = useState(() => VisionManager.getInstance().getCurrentState());
  const [isExpanded, setIsExpanded] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<'summary' | 'ui' | 'design' | 'code'>('summary');
  const [copiedCode, setCopiedCode] = useState<boolean>(false);
  const [selectedFramework, setSelectedFramework] = useState<'react-tailwind' | 'jetpack-compose' | 'html-css'>('react-tailwind');

  useEffect(() => {
    const vm = VisionManager.getInstance();
    const unsubscribe = vm.subscribe((st) => {
      setVisionState(st);
      if (st.lastAnalysis) {
        setIsExpanded(true);
      }
    });
    return unsubscribe;
  }, []);

  const vm = VisionManager.getInstance();
  const isScreenActive = visionState.screenShareState.isActive;
  const hasImage = !!visionState.selectedImage;
  const isAnalyzing = visionState.isAnalyzing;
  const analysis = visionState.lastAnalysis;

  if (!isScreenActive && !hasImage && !analysis) {
    return null;
  }

  const handleRunQuestion = async (question: string) => {
    if (onTriggerPrompt) {
      onTriggerPrompt(question);
    }
    await vm.analyzeVisual(question);
    setIsExpanded(true);
  };

  const handleImproveDesign = async () => {
    await vm.improveActiveDesign('Critique visual hierarchy, contrast, balance, and modern UI tokens.');
    setActiveTab('design');
    setIsExpanded(true);
  };

  const handleConvertToCode = async (framework: 'react-tailwind' | 'jetpack-compose' | 'html-css') => {
    setSelectedFramework(framework);
    await vm.convertActiveDesignToCode(framework);
    setActiveTab('code');
    setIsExpanded(true);
  };

  const handleCopyCode = () => {
    const code = analysis?.designAnalysis?.codeImplementation?.snippet || '';
    if (!code) return;
    navigator.clipboard.writeText(code);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  const handleSpeakAgain = () => {
    if (analysis?.summary) {
      vm.speakVoiceExplanation(analysis.summary);
    }
  };

  return (
    <aside aria-label="Visual Intelligence Panel" className="w-full max-w-md mx-auto px-4 z-30 pointer-events-auto">
      {/* 1. Quick Action Chips Header */}
      <div className="flex items-center gap-1.5 overflow-x-auto py-1.5 scrollbar-none">
        {isScreenActive && (
          <button
            type="button"
            id="vision-chip-screen-summary"
            onClick={() => handleRunQuestion('What is on my screen?')}
            disabled={isAnalyzing}
            className="flex-shrink-0 flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-semibold bg-emerald-950/80 border border-emerald-400/50 text-emerald-200 hover:bg-emerald-900/80 shadow-[0_0_10px_rgba(16,185,129,0.25)] transition-all disabled:opacity-50"
          >
            <Monitor className="w-3 h-3 text-emerald-400" />
            <span>What's on screen?</span>
          </button>
        )}

        <button
          type="button"
          id="vision-chip-read-text"
          onClick={() => handleRunQuestion('Read all visible text, error messages, and labels on this visual.')}
          disabled={isAnalyzing}
          className="flex-shrink-0 flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-semibold bg-[#0a1438]/85 border border-cyan-500/40 text-cyan-200 hover:bg-cyan-900/40 shadow-[0_0_10px_rgba(0,229,255,0.2)] transition-all disabled:opacity-50"
        >
          <FileText className="w-3 h-3 text-cyan-400" />
          <span>Read text</span>
        </button>

        <button
          type="button"
          id="vision-chip-error-check"
          onClick={() => handleRunQuestion('Is there an error message, bug, or warning visible? What does it mean?')}
          disabled={isAnalyzing}
          className="flex-shrink-0 flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-semibold bg-[#0a1438]/85 border border-purple-500/40 text-purple-200 hover:bg-purple-900/40 shadow-[0_0_10px_rgba(168,85,247,0.2)] transition-all disabled:opacity-50"
        >
          <AlertTriangle className="w-3 h-3 text-purple-400" />
          <span>Explain error</span>
        </button>

        <button
          type="button"
          id="vision-chip-improve-design"
          onClick={handleImproveDesign}
          disabled={isAnalyzing}
          className="flex-shrink-0 flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-semibold bg-gradient-to-r from-blue-950/80 to-purple-950/80 border border-purple-400/50 text-purple-200 hover:brightness-110 shadow-[0_0_10px_rgba(192,132,252,0.25)] transition-all disabled:opacity-50"
        >
          <Sparkles className="w-3 h-3 text-pink-400" />
          <span>Improve design</span>
        </button>

        <button
          type="button"
          id="vision-chip-to-code"
          onClick={() => handleConvertToCode('react-tailwind')}
          disabled={isAnalyzing}
          className="flex-shrink-0 flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-semibold bg-[#0a1438]/85 border border-cyan-400/50 text-cyan-200 hover:bg-cyan-900/40 shadow-[0_0_10px_rgba(0,229,255,0.2)] transition-all disabled:opacity-50"
        >
          <Code2 className="w-3 h-3 text-cyan-300" />
          <span>Convert to code</span>
        </button>
      </div>

      {/* 2. Structured Analysis Result Drawer */}
      <AnimatePresence>
        {analysis && (
          <motion.div
            initial={{ opacity: 0, y: 15, scale: 0.98 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 10, scale: 0.98 }}
            transition={{ duration: 0.25 }}
            className="mt-1 rounded-2xl bg-[#080d24]/95 backdrop-blur-2xl border border-cyan-500/40 shadow-[0_12px_40px_rgba(0,0,0,0.85),0_0_25px_rgba(0,229,255,0.18)] overflow-hidden"
          >
            {/* Header / Summary Bar */}
            <div className="flex items-center justify-between px-3.5 py-2.5 bg-gradient-to-r from-cyan-950/40 via-[#0a1538] to-purple-950/40 border-b border-cyan-500/20">
              <div className="flex items-center gap-2 min-w-0">
                <span className="w-2 h-2 rounded-full bg-cyan-400 shadow-[0_0_8px_#00e5ff] animate-pulse" />
                <span className="text-xs font-bold text-cyan-300 tracking-wide">
                  HINATA VISION INTELLIGENCE
                </span>
                {analysis.confidence !== undefined && (
                  <span
                    className={`text-[10px] px-1.5 py-0.5 rounded font-mono ${
                      analysis.confidence >= 0.8
                        ? 'bg-emerald-950 border border-emerald-500/40 text-emerald-300'
                        : 'bg-amber-950 border border-amber-500/40 text-amber-300'
                    }`}
                  >
                    {Math.round(analysis.confidence * 100)}% conf
                  </span>
                )}
              </div>

              <div className="flex items-center gap-1 flex-shrink-0">
                <button
                  type="button"
                  id="vision-btn-speak-again"
                  onClick={handleSpeakAgain}
                  title="Speak explanation aloud"
                  className="p-1 rounded-lg text-slate-300 hover:text-cyan-300 hover:bg-cyan-500/10 transition-colors"
                >
                  <Volume2 className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  id="vision-btn-toggle-expand"
                  onClick={() => setIsExpanded(!isExpanded)}
                  title={isExpanded ? 'Collapse' : 'Expand details'}
                  className="p-1 rounded-lg text-slate-300 hover:text-cyan-300 hover:bg-cyan-500/10 transition-colors"
                >
                  {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                </button>
                <button
                  type="button"
                  id="vision-btn-dismiss"
                  onClick={() => setIsExpanded(false)}
                  title="Dismiss drawer"
                  className="p-1 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 transition-colors"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Always visible concise summary */}
            <div className="px-3.5 py-2 text-xs text-slate-200 leading-relaxed">
              <p className="line-clamp-3">{analysis.summary}</p>
            </div>

            {/* Collapsible Deep Inspection Tabs */}
            {isExpanded && (
              <div className="border-t border-slate-800/80">
                {/* Tab Switcher */}
                <div className="flex items-center justify-around px-2 pt-1 border-b border-slate-800/60 text-[11px] font-medium bg-[#05091b]">
                  <button
                    type="button"
                    id="vision-tab-summary"
                    onClick={() => setActiveTab('summary')}
                    className={`py-1.5 px-2 border-b-2 transition-all ${
                      activeTab === 'summary'
                        ? 'border-cyan-400 text-cyan-300 font-semibold'
                        : 'border-transparent text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    Details & Text
                  </button>
                  <button
                    type="button"
                    id="vision-tab-ui"
                    onClick={() => setActiveTab('ui')}
                    className={`py-1.5 px-2 border-b-2 transition-all ${
                      activeTab === 'ui'
                        ? 'border-cyan-400 text-cyan-300 font-semibold'
                        : 'border-transparent text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    UI Elements ({analysis.uiElements?.length || 0})
                  </button>
                  <button
                    type="button"
                    id="vision-tab-design"
                    onClick={() => setActiveTab('design')}
                    className={`py-1.5 px-2 border-b-2 transition-all ${
                      activeTab === 'design'
                        ? 'border-cyan-400 text-cyan-300 font-semibold'
                        : 'border-transparent text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    Design & UX
                  </button>
                  <button
                    type="button"
                    id="vision-tab-code"
                    onClick={() => setActiveTab('code')}
                    className={`py-1.5 px-2 border-b-2 transition-all ${
                      activeTab === 'code'
                        ? 'border-cyan-400 text-cyan-300 font-semibold'
                        : 'border-transparent text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    Code Export
                  </button>
                </div>

                {/* Tab Body */}
                <div className="p-3 max-h-60 overflow-y-auto text-xs space-y-2.5">
                  {/* TAB 1: SUMMARY & EXTRACTED TEXT */}
                  {activeTab === 'summary' && (
                    <div className="space-y-2">
                      {analysis.text && analysis.text.length > 0 && (
                        <div>
                          <span className="text-[10px] font-bold tracking-wider text-cyan-400 uppercase">
                            Extracted Visible Text
                          </span>
                          <div className="mt-1 p-2 rounded-xl bg-slate-950/80 border border-slate-800 text-[11px] font-mono text-slate-300 max-h-28 overflow-y-auto whitespace-pre-wrap">
                            {analysis.text.join('\n')}
                          </div>
                        </div>
                      )}

                      {analysis.objects && analysis.objects.length > 0 && (
                        <div>
                          <span className="text-[10px] font-bold tracking-wider text-cyan-400 uppercase">
                            Detected Objects
                          </span>
                          <div className="mt-1 flex flex-wrap gap-1">
                            {analysis.objects.map((obj, i) => (
                              <span
                                key={i}
                                className="px-2 py-0.5 rounded-md bg-slate-900 border border-slate-700 text-[10.5px] text-slate-300"
                              >
                                {obj.name}
                                {obj.confidence ? ` (${Math.round(obj.confidence * 100)}%)` : ''}
                              </span>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  )}

                  {/* TAB 2: UI ELEMENTS */}
                  {activeTab === 'ui' && (
                    <div className="space-y-1.5">
                      {analysis.uiElements && analysis.uiElements.length > 0 ? (
                        analysis.uiElements.map((el, i) => (
                          <div
                            key={i}
                            className="p-2 rounded-xl bg-slate-900/80 border border-slate-800 flex items-start justify-between gap-2"
                          >
                            <div>
                              <div className="font-semibold text-cyan-200 text-[11.5px]">
                                {el.label || el.type}
                              </div>
                              <span className="text-[10px] text-slate-400 capitalize">
                                Type: {el.type}
                              </span>
                            </div>
                            {el.state && (
                              <span className="text-[10px] px-1.5 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-800">
                                {el.state}
                              </span>
                            )}
                          </div>
                        ))
                      ) : (
                        <p className="text-slate-400 italic text-center py-3">
                          No distinct UI buttons/inputs mapped.
                        </p>
                      )}
                    </div>
                  )}

                  {/* TAB 3: DESIGN & UX INTELLIGENCE */}
                  {activeTab === 'design' && (
                    <div className="space-y-2.5">
                      {analysis.designAnalysis?.layout && (
                        <div className="p-2 rounded-xl bg-slate-900/60 border border-slate-800">
                          <span className="text-[10px] font-bold text-purple-300 uppercase">Layout Assessment</span>
                          <p className="text-[11px] text-slate-300 mt-0.5">
                            {analysis.designAnalysis.layout.responsiveStructure || analysis.designAnalysis.layout.composition || 'Modular composition'}
                          </p>
                          <p className="text-[10.5px] text-slate-400 mt-0.5">Spacing: {analysis.designAnalysis.layout.spacing}</p>
                        </div>
                      )}

                      {analysis.designAnalysis?.colors && (
                        <div className="p-2 rounded-xl bg-slate-900/60 border border-slate-800">
                          <span className="text-[10px] font-bold text-cyan-300 uppercase">Extracted Palette</span>
                          <div className="flex items-center gap-1.5 mt-1.5">
                            {analysis.designAnalysis.colors.palette?.map((hex, i) => (
                              <div key={i} className="flex flex-col items-center gap-1">
                                <div
                                  className="w-5 h-5 rounded-full border border-white/20 shadow-sm"
                                  style={{ backgroundColor: hex }}
                                />
                                <span className="text-[8.5px] font-mono text-slate-400">{hex}</span>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}

                      {analysis.designAnalysis?.improvements && analysis.designAnalysis.improvements.length > 0 && (
                        <div>
                          <span className="text-[10px] font-bold text-pink-300 uppercase">Suggested Improvements</span>
                          <div className="mt-1 space-y-1">
                            {analysis.designAnalysis.improvements.map((imp, i) => (
                              <div key={i} className="p-2 rounded-lg bg-pink-950/30 border border-pink-500/20 text-[11px]">
                                <span className="font-semibold text-pink-200">
                                  {imp.area}: {imp.suggestion}
                                </span>
                                {imp.rationale && <p className="text-[10px] text-pink-300/80 mt-0.5">{imp.rationale}</p>}
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  )}

                  {/* TAB 4: CODE GENERATION & EXPORT */}
                  {activeTab === 'code' && (
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-1">
                          <button
                            type="button"
                            id="vision-fw-react-tailwind"
                            onClick={() => handleConvertToCode('react-tailwind')}
                            className={`px-2 py-0.5 rounded text-[10px] font-medium transition-colors ${
                              selectedFramework === 'react-tailwind'
                                ? 'bg-cyan-500 text-slate-950 font-bold'
                                : 'bg-slate-800 text-slate-300 hover:text-white'
                            }`}
                          >
                            React + Tailwind
                          </button>
                          <button
                            type="button"
                            id="vision-fw-jetpack-compose"
                            onClick={() => handleConvertToCode('jetpack-compose')}
                            className={`px-2 py-0.5 rounded text-[10px] font-medium transition-colors ${
                              selectedFramework === 'jetpack-compose'
                                ? 'bg-purple-500 text-white font-bold'
                                : 'bg-slate-800 text-slate-300 hover:text-white'
                            }`}
                          >
                            Compose
                          </button>
                          <button
                            type="button"
                            id="vision-fw-html-css"
                            onClick={() => handleConvertToCode('html-css')}
                            className={`px-2 py-0.5 rounded text-[10px] font-medium transition-colors ${
                              selectedFramework === 'html-css'
                                ? 'bg-emerald-500 text-slate-950 font-bold'
                                : 'bg-slate-800 text-slate-300 hover:text-white'
                            }`}
                          >
                            HTML/CSS
                          </button>
                        </div>

                        {analysis.designAnalysis?.codeImplementation?.snippet && (
                          <button
                            type="button"
                            id="vision-btn-copy-code"
                            onClick={handleCopyCode}
                            className="flex items-center gap-1 px-2 py-1 rounded bg-slate-800 hover:bg-slate-700 text-cyan-300 text-[10px] font-semibold transition-colors"
                          >
                            {copiedCode ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                            <span>{copiedCode ? 'Copied' : 'Copy'}</span>
                          </button>
                        )}
                      </div>

                      {analysis.designAnalysis?.codeImplementation?.snippet ? (
                        <pre className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 text-[11px] font-mono text-emerald-300 overflow-x-auto max-h-48 leading-relaxed whitespace-pre">
                          <code>{analysis.designAnalysis.codeImplementation.snippet}</code>
                        </pre>
                      ) : (
                        <div className="text-center py-4">
                          <button
                            type="button"
                            id="vision-btn-generate-code-now"
                            onClick={() => handleConvertToCode(selectedFramework)}
                            className="px-3 py-1.5 rounded-xl bg-cyan-500/20 border border-cyan-400/60 text-cyan-200 text-xs font-semibold hover:bg-cyan-500/30 transition-all"
                          >
                            Synthesize {selectedFramework} Code Now
                          </button>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </aside>
  );
};
