import React from 'react';
import { motion } from 'motion/react';
import { LiveSessionState, EmotionalState, EmotionalIntensity } from '../types';
import { EMOTION_CONFIGS } from '../modules/EmotionManager';

interface OrbVisualizerProps {
  state: LiveSessionState;
  mood: EmotionalState;
  intensity?: EmotionalIntensity;
  inputVolume?: number;
  outputVolume?: number;
  onOrbClick?: () => void;
}

export const OrbVisualizer: React.FC<OrbVisualizerProps> = ({
  state,
  mood,
  intensity = 2,
  inputVolume = 0,
  outputVolume = 0,
  onOrbClick,
}) => {
  const emotionConfig = EMOTION_CONFIGS[mood] || EMOTION_CONFIGS.neutral;

  // Determine theme gradient and glow styling combining voice state, emotion, and intensity
  const getTheme = () => {
    if (state === 'disconnected') {
      return {
        coreGradient: 'from-slate-700 via-indigo-950 to-neutral-900',
        ringColor: 'border-slate-600/30',
        outerGlow: 'rgba(148, 163, 184, 0.14)',
        dotColor: 'bg-slate-400',
        pulseDuration: 4.0,
      };
    }

    if (state === 'connecting') {
      return {
        coreGradient: 'from-purple-600 via-indigo-700 to-fuchsia-900',
        ringColor: 'border-purple-400/50',
        outerGlow: 'rgba(168, 85, 247, 0.5)',
        dotColor: 'bg-purple-300',
        pulseDuration: 1.5,
      };
    }

    // Active connection: derive from all 21 emotional states
    switch (mood) {
      case 'happy':
        return {
          coreGradient: 'from-amber-400 via-pink-500 to-rose-700',
          ringColor: 'border-amber-400/60',
          outerGlow: 'rgba(251, 191, 36, 0.65)',
          dotColor: 'bg-amber-100',
          pulseDuration: 1.4,
        };
      case 'excited':
        return {
          coreGradient: 'from-rose-400 via-fuchsia-600 to-sky-600',
          ringColor: 'border-rose-400/70',
          outerGlow: 'rgba(244, 63, 94, 0.72)',
          dotColor: 'bg-rose-100',
          pulseDuration: 1.0,
        };
      case 'curious':
        return {
          coreGradient: 'from-purple-400 via-indigo-600 to-teal-600',
          ringColor: 'border-purple-400/60',
          outerGlow: 'rgba(168, 85, 247, 0.6)',
          dotColor: 'bg-teal-200',
          pulseDuration: 2.0,
        };
      case 'amused':
        return {
          coreGradient: 'from-pink-400 via-fuchsia-500 to-amber-500',
          ringColor: 'border-pink-400/65',
          outerGlow: 'rgba(236, 72, 153, 0.65)',
          dotColor: 'bg-amber-100',
          pulseDuration: 1.4,
        };
      case 'calm':
        return {
          coreGradient: 'from-teal-300 via-cyan-600 to-blue-900',
          ringColor: 'border-teal-400/50',
          outerGlow: 'rgba(45, 212, 191, 0.5)',
          dotColor: 'bg-teal-100',
          pulseDuration: 3.4,
        };
      case 'confident':
        return {
          coreGradient: 'from-sky-400 via-blue-600 to-emerald-700',
          ringColor: 'border-sky-400/65',
          outerGlow: 'rgba(14, 165, 233, 0.65)',
          dotColor: 'bg-emerald-200',
          pulseDuration: 2.0,
        };
      case 'empathetic':
        return {
          coreGradient: 'from-pink-300 via-rose-500 to-violet-800',
          ringColor: 'border-pink-300/55',
          outerGlow: 'rgba(244, 114, 182, 0.55)',
          dotColor: 'bg-pink-100',
          pulseDuration: 2.8,
        };
      case 'concerned':
        return {
          coreGradient: 'from-orange-400 via-amber-600 to-rose-800',
          ringColor: 'border-orange-400/60',
          outerGlow: 'rgba(249, 115, 22, 0.6)',
          dotColor: 'bg-orange-100',
          pulseDuration: 2.4,
        };
      case 'serious':
        return {
          coreGradient: 'from-slate-400 via-slate-600 to-blue-950',
          ringColor: 'border-slate-400/40',
          outerGlow: 'rgba(100, 116, 139, 0.45)',
          dotColor: 'bg-slate-200',
          pulseDuration: 3.2,
        };
      case 'playful':
        return {
          coreGradient: 'from-fuchsia-400 via-purple-600 to-cyan-600',
          ringColor: 'border-fuchsia-400/65',
          outerGlow: 'rgba(217, 70, 239, 0.65)',
          dotColor: 'bg-cyan-200',
          pulseDuration: 1.6,
        };

      // --- New Emotional States Visual Themes ---
      case 'affectionate':
        return {
          coreGradient: 'from-rose-300 via-rose-500 to-amber-600',
          ringColor: 'border-rose-300/60',
          outerGlow: 'rgba(251, 113, 133, 0.68)',
          dotColor: 'bg-rose-100',
          pulseDuration: 2.2,
        };
      case 'jealous':
        return {
          coreGradient: 'from-purple-400 via-fuchsia-600 to-rose-600',
          ringColor: 'border-purple-400/65',
          outerGlow: 'rgba(192, 132, 252, 0.65)',
          dotColor: 'bg-pink-200',
          pulseDuration: 1.7,
        };
      case 'annoyed':
        return {
          coreGradient: 'from-amber-500 via-orange-600 to-red-700',
          ringColor: 'border-amber-400/60',
          outerGlow: 'rgba(245, 158, 11, 0.62)',
          dotColor: 'bg-amber-100',
          pulseDuration: 1.9,
        };
      case 'angry':
        return {
          coreGradient: 'from-red-500 via-red-700 to-stone-900',
          ringColor: 'border-red-500/70',
          outerGlow: 'rgba(220, 38, 38, 0.75)',
          dotColor: 'bg-red-200',
          pulseDuration: 2.1,
        };
      case 'frustrated':
        return {
          coreGradient: 'from-orange-500 via-amber-700 to-neutral-800',
          ringColor: 'border-orange-500/65',
          outerGlow: 'rgba(234, 88, 12, 0.68)',
          dotColor: 'bg-orange-200',
          pulseDuration: 2.1,
        };
      case 'surprised':
        return {
          coreGradient: 'from-cyan-300 via-yellow-400 to-sky-600',
          ringColor: 'border-cyan-300/75',
          outerGlow: 'rgba(6, 182, 212, 0.72)',
          dotColor: 'bg-yellow-100',
          pulseDuration: 1.1,
        };
      case 'embarrassed':
        return {
          coreGradient: 'from-pink-300 via-rose-400 to-purple-500',
          ringColor: 'border-pink-300/60',
          outerGlow: 'rgba(244, 114, 182, 0.62)',
          dotColor: 'bg-pink-100',
          pulseDuration: 2.0,
        };
      case 'proud':
        return {
          coreGradient: 'from-violet-400 via-purple-600 to-amber-500',
          ringColor: 'border-violet-400/70',
          outerGlow: 'rgba(139, 92, 246, 0.72)',
          dotColor: 'bg-amber-200',
          pulseDuration: 1.5,
        };
      case 'disappointed':
        return {
          coreGradient: 'from-slate-500 via-blue-800 to-neutral-900',
          ringColor: 'border-slate-500/45',
          outerGlow: 'rgba(100, 116, 139, 0.45)',
          dotColor: 'bg-slate-300',
          pulseDuration: 3.1,
        };
      case 'relieved':
        return {
          coreGradient: 'from-emerald-300 via-teal-500 to-cyan-700',
          ringColor: 'border-emerald-300/55',
          outerGlow: 'rgba(52, 211, 153, 0.58)',
          dotColor: 'bg-emerald-100',
          pulseDuration: 2.7,
        };

      case 'neutral':
      default:
        return {
          coreGradient: 'from-indigo-400 via-sky-600 to-purple-800',
          ringColor: 'border-indigo-400/55',
          outerGlow: 'rgba(99, 102, 241, 0.55)',
          dotColor: 'bg-sky-200',
          pulseDuration: 2.5,
        };
    }
  };

  const theme = getTheme();

  // Intensity factor (0 to 5 mapped to 0.7 - 1.35)
  const intensityFactor = 0.7 + (intensity / 5) * 0.65;

  // Dynamic scale calculation based on active voice volume, emotion, and intensity
  const dynamicScale =
    state === 'speaking'
      ? 1 + Math.min(0.42, outputVolume * 1.35) * emotionConfig.scaleMultiplier * intensityFactor
      : state === 'listening'
      ? 1 + Math.min(0.26, inputVolume * 0.95)
      : 1;

  // Emotion-specific breathing duration modulated by intensity
  const basePulse = theme.pulseDuration / (0.85 + (intensity * 0.08));
  const pulseTime = state === 'speaking' ? Math.max(0.65, basePulse * 0.55) : basePulse;

  return (
    <div
      className="relative flex items-center justify-center cursor-pointer select-none"
      onClick={onOrbClick}
      style={{
        width: '280px',
        height: '280px',
      }}
      title={`Hinata - Voice: ${state} | Emotion: ${emotionConfig.label} (${emotionConfig.emoji}) [Intensity: ${intensity}/5]`}
    >
      {/* Ambient background aura reacting to emotion & intensity */}
      <motion.div
        className="absolute inset-0 rounded-full filter blur-3xl pointer-events-none"
        animate={{
          scale: [1, 1.15 + (intensity * 0.03), 1],
          opacity: state === 'disconnected' ? 0.25 : [0.6, 0.85 + (intensity * 0.03), 0.6],
        }}
        transition={{
          duration: pulseTime * 1.5,
          repeat: Infinity,
          ease: 'easeInOut',
        }}
        style={{
          background: theme.outerGlow,
        }}
      />

      {/* Ripple ring 1 - outer sound wave */}
      {(state === 'speaking' || state === 'listening') && (
        <motion.div
          className="absolute inset-2 rounded-full border border-current pointer-events-none"
          style={{ color: theme.outerGlow }}
          animate={{
            scale: [1, 1.45, 1.65],
            opacity: [0.75, 0.35, 0],
          }}
          transition={{
            duration: state === 'speaking' ? Math.max(1.1, pulseTime) : 2.2,
            repeat: Infinity,
            ease: 'easeOut',
          }}
        />
      )}

      {/* Ripple ring 2 */}
      {state === 'speaking' && (
        <motion.div
          className="absolute inset-6 rounded-full border border-current pointer-events-none"
          style={{ color: theme.outerGlow }}
          animate={{
            scale: [1, 1.38, 1.58],
            opacity: [0.85, 0.4, 0],
          }}
          transition={{
            duration: Math.max(1.1, pulseTime),
            delay: 0.45,
            repeat: Infinity,
            ease: 'easeOut',
          }}
        />
      )}

      {/* Outer orbital ring with rotating node */}
      <div
        className={`absolute inset-4 rounded-full border ${theme.ringColor} ${
          state === 'connecting'
            ? 'animate-spin'
            : mood === 'excited' || mood === 'surprised'
            ? 'animate-spin-fast'
            : 'animate-spin-slow'
        } pointer-events-none transition-all duration-500`}
      >
        <div
          className={`absolute -top-1.5 left-1/2 -translate-x-1/2 w-3 h-3 rounded-full ${theme.dotColor} shadow-lg`}
        />
      </div>

      {/* Counter-rotating dashed inner orbital ring */}
      <div
        className={`absolute inset-10 rounded-full border border-dashed ${theme.ringColor} ${
          state === 'connecting' ? 'animate-reverse-spin-slow duration-1000' : 'animate-reverse-spin-slow'
        } pointer-events-none transition-all duration-500`}
      />

      {/* Holographic central orb */}
      <motion.div
        className={`relative w-44 h-44 rounded-full bg-gradient-to-tr ${theme.coreGradient} shadow-2xl flex items-center justify-center overflow-hidden border border-white/20`}
        animate={{
          scale: dynamicScale,
        }}
        transition={{
          type: 'spring',
          stiffness: 320,
          damping: 22,
        }}
        style={{
          boxShadow: `0 0 50px -10px ${theme.outerGlow}, inset 0 0 25px rgba(255,255,255,0.25)`,
        }}
      >
        {/* Specular highlight glass reflections */}
        <div className="absolute top-0 left-0 right-0 h-1/2 bg-gradient-to-b from-white/25 to-transparent rounded-t-full pointer-events-none" />
        <div className="absolute -bottom-4 -right-4 w-24 h-24 bg-white/10 rounded-full filter blur-md pointer-events-none" />

        {/* Animated energy core with emotion pulse */}
        <motion.div
          className="w-24 h-24 rounded-full bg-white/20 backdrop-blur-sm filter blur-[2px]"
          animate={{
            scale: state === 'speaking' ? [0.9, 1.28, 0.9] : [0.95, 1.1, 0.95],
            opacity: state === 'disconnected' ? 0.3 : [0.65, 0.95, 0.65],
          }}
          transition={{
            duration: pulseTime,
            repeat: Infinity,
            ease: 'easeInOut',
          }}
        />

        {/* Inner bright focal light */}
        <div className={`absolute w-8 h-8 rounded-full ${theme.dotColor} filter blur-sm opacity-90`} />
        <div className="absolute w-3 h-3 rounded-full bg-white shadow-sm" />
      </motion.div>
    </div>
  );
};
