import React, { useEffect, useRef } from 'react';
import { LiveSessionState, EmotionalState, EmotionalIntensity, MascotState } from '../types';
import { AudioPlayer } from '../modules/AudioPlayer';
import { FaceAnimator, HinataEmotion, HinataAIState, EmotionEngine } from '../modules/face';

interface HinataMascotAvatarProps {
  state: LiveSessionState;
  mascotState?: MascotState;
  mood: EmotionalState;
  intensity?: EmotionalIntensity;
  outputVolume?: number;
  inputVolume?: number;
  audioPlayer?: AudioPlayer | null;
  onAvatarClick?: () => void;
  size?: number;
}

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  alpha: number;
  color: string;
}

export const HinataMascotAvatar: React.FC<HinataMascotAvatarProps> = ({
  state,
  mascotState,
  mood,
  intensity = 2,
  outputVolume = 0,
  inputVolume = 0,
  audioPlayer = null,
  onAvatarClick,
  size = 420,
}) => {
  const effectiveMascotState: MascotState =
    mascotState ||
    (state === 'speaking'
      ? 'SPEAKING'
      : state === 'listening'
      ? 'LISTENING'
      : state === 'processing'
      ? 'THINKING'
      : state === 'error'
      ? 'ERROR'
      : 'IDLE');

  // Convert to face module AI State
  const aiState: HinataAIState =
    state === 'disconnected'
      ? 'STOPPED'
      : effectiveMascotState === 'SPEAKING'
      ? 'SPEAKING'
      : effectiveMascotState === 'LISTENING'
      ? 'LISTENING'
      : effectiveMascotState === 'THINKING'
      ? 'THINKING'
      : effectiveMascotState === 'VISION_ANALYZING' ||
        effectiveMascotState === 'SCREEN_SHARING' ||
        effectiveMascotState === 'SCREEN_ANALYZING'
      ? 'UNDERSTANDING'
      : effectiveMascotState === 'ERROR'
      ? 'ERROR'
      : 'IDLE';

  // Dedicated FaceAnimator coordinator instance
  const animatorRef = useRef<FaceAnimator | null>(null);
  if (!animatorRef.current) {
    animatorRef.current = new FaceAnimator();
  }
  const animator = animatorRef.current;

  // Animation frame and timing refs
  const animFrameRef = useRef<number | null>(null);
  const prevTimeRef = useRef<number>(performance.now());
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // SVG DOM Element Refs for low-overhead 60FPS updates
  const mascotContainerRef = useRef<HTMLDivElement | null>(null);
  const headGroupRef = useRef<SVGGElement | null>(null);
  const haloGroupRef = useRef<SVGGElement | null>(null);
  const orbitFrontRef = useRef<SVGGElement | null>(null);
  const orbitBackRef = useRef<SVGGElement | null>(null);
  const rippleGroupRef = useRef<SVGGElement | null>(null);
  const leftPupilRef = useRef<SVGCircleElement | null>(null);
  const rightPupilRef = useRef<SVGCircleElement | null>(null);
  const leftEyeLidRef = useRef<SVGPathElement | null>(null);
  const rightEyeLidRef = useRef<SVGPathElement | null>(null);
  const mouthPathRef = useRef<SVGPathElement | null>(null);
  const mouthFillRef = useRef<SVGPathElement | null>(null);
  const leftBlushRef = useRef<SVGEllipseElement | null>(null);
  const rightBlushRef = useRef<SVGEllipseElement | null>(null);
  const auraGlowRef = useRef<HTMLDivElement | null>(null);

  // Particles
  const particlesRef = useRef<Particle[]>([]);

  // Update audioPlayer reference in animator
  useEffect(() => {
    animator.setAudioPlayer(audioPlayer);
  }, [audioPlayer, animator]);

  // Update emotional state and intensity in animator
  useEffect(() => {
    const normEmotion = EmotionEngine.getInstance().normalizeEmotion(mood);
    const normIntensity = intensity > 1 ? intensity / 5 : intensity || 0.5;
    animator.setEmotion(normEmotion, normIntensity);
  }, [mood, intensity, animator]);

  // Reset mouth immediately when speech state ends
  useEffect(() => {
    if (state !== 'speaking' && effectiveMascotState !== 'SPEAKING') {
      animator.resetSpeech();
    }
  }, [state, effectiveMascotState, animator]);

  // Initialize atmospheric floating dust particles
  useEffect(() => {
    const particles: Particle[] = [];
    const colors = ['#00e5ff', '#38bdf8', '#c084fc', '#f43f5e', '#ffffff'];
    for (let i = 0; i < 26; i++) {
      particles.push({
        x: Math.random() * size,
        y: Math.random() * size,
        vx: (Math.random() - 0.5) * 0.45,
        vy: -0.25 - Math.random() * 0.45,
        size: 1.2 + Math.random() * 2.2,
        alpha: 0.15 + Math.random() * 0.55,
        color: colors[Math.floor(Math.random() * colors.length)],
      });
    }
    particlesRef.current = particles;
  }, [size]);

  // Main 60FPS High-Performance Animation Loop
  useEffect(() => {
    const isSpeaking = state === 'speaking' || effectiveMascotState === 'SPEAKING';
    const fallbackVol = isSpeaking ? outputVolume : inputVolume;

    const animate = (currentTime: number) => {
      const deltaMs = Math.min(100, currentTime - prevTimeRef.current);
      prevTimeRef.current = currentTime;
      const dtSec = deltaMs / 1000;

      // 1. FaceAnimator updates physics, visemes, gaze, and expression
      const params = animator.update(deltaMs, dtSec, aiState, isSpeaking, fallbackVol);

      // 2. Direct DOM mutation for rapid 60FPS execution on mobile devices
      animator.applyToDom(params, {
        headGroupRef,
        haloGroupRef,
        orbitFrontRef,
        orbitBackRef,
        rippleGroupRef,
        leftEyeLidRef,
        rightEyeLidRef,
        mouthPathRef,
        mouthFillRef,
        leftBlushRef,
        rightBlushRef,
        auraGlowRef,
        leftPupilRef,
        rightPupilRef,
      });

      // 3. Render floating dust particles on canvas
      const canvas = canvasRef.current;
      if (canvas) {
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.clearRect(0, 0, canvas.width, canvas.height);
          for (let i = 0; i < particlesRef.current.length; i++) {
            const p = particlesRef.current[i];
            p.x += p.vx;
            p.y += p.vy;
            if (p.y < -10) {
              p.y = canvas.height + 10;
              p.x = Math.random() * canvas.width;
            }
            if (p.x < -10) p.x = canvas.width + 10;
            if (p.x > canvas.width + 10) p.x = -10;

            ctx.beginPath();
            ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
            ctx.fillStyle = p.color;
            ctx.globalAlpha = p.alpha;
            ctx.shadowBlur = 6;
            ctx.shadowColor = p.color;
            ctx.fill();
          }
          ctx.globalAlpha = 1.0;
        }
      }

      animFrameRef.current = requestAnimationFrame(animate);
    };

    animFrameRef.current = requestAnimationFrame(animate);

    return () => {
      if (animFrameRef.current !== null) {
        cancelAnimationFrame(animFrameRef.current);
        animFrameRef.current = null;
      }
    };
  }, [state, effectiveMascotState, aiState, outputVolume, inputVolume, animator]);

  // Normalized emotion for initial render
  const currentNormEmotion: HinataEmotion = EmotionEngine.getInstance().normalizeEmotion(mood);
  const normIntensity = intensity > 1 ? intensity / 5 : intensity || 0.5;

  // Dynamic Aura Background style
  const getAuraBackground = () => {
    switch (currentNormEmotion) {
      case 'happy':
      case 'laughing':
        return 'radial-gradient(circle, rgba(0, 229, 255, 0.45) 0%, rgba(251, 191, 36, 0.25) 50%, transparent 75%)';
      case 'excited':
        return 'radial-gradient(circle, rgba(236, 72, 153, 0.5) 0%, rgba(0, 229, 255, 0.4) 50%, transparent 75%)';
      case 'thinking':
        return 'radial-gradient(circle, rgba(129, 140, 248, 0.45) 0%, rgba(168, 85, 247, 0.3) 50%, transparent 75%)';
      case 'curious':
        return 'radial-gradient(circle, rgba(168, 85, 247, 0.45) 0%, rgba(6, 182, 212, 0.3) 50%, transparent 75%)';
      case 'concerned':
      case 'worried':
        return 'radial-gradient(circle, rgba(234, 179, 8, 0.35) 0%, rgba(56, 189, 248, 0.2) 50%, transparent 75%)';
      case 'calm':
      case 'relieved':
        return 'radial-gradient(circle, rgba(45, 212, 191, 0.35) 0%, rgba(56, 189, 248, 0.2) 50%, transparent 75%)';
      case 'error':
        return 'radial-gradient(circle, rgba(239, 68, 68, 0.55) 0%, rgba(185, 28, 28, 0.35) 50%, transparent 75%)';
      case 'success':
        return 'radial-gradient(circle, rgba(16, 185, 129, 0.55) 0%, rgba(0, 229, 255, 0.35) 50%, transparent 75%)';
      case 'idle':
      default:
        return 'radial-gradient(circle, rgba(0, 229, 255, 0.3) 0%, rgba(168, 85, 247, 0.2) 50%, transparent 75%)';
    }
  };

  return (
    <div
      ref={mascotContainerRef}
      onClick={onAvatarClick}
      className="relative w-full max-w-[440px] h-[380px] sm:h-[420px] flex items-center justify-center select-none cursor-pointer transition-transform duration-300 active:scale-98 group"
      style={{ perspective: 1000 }}
    >
      {/* Background Floating Dust Particles */}
      <canvas
        ref={canvasRef}
        width={size}
        height={size}
        className="absolute inset-0 w-full h-full pointer-events-none z-0 opacity-80"
      />

      {/* Atmospheric Ambient Lighting Aura */}
      <div
        ref={auraGlowRef}
        className="absolute w-72 h-72 sm:w-80 sm:h-80 rounded-full pointer-events-none filter blur-3xl transition-all duration-700 -z-10"
        style={{
          background: getAuraBackground(),
          transform: state === 'speaking' || effectiveMascotState === 'VISION_ANALYZING' ? 'scale(1.25)' : 'scale(1.0)',
        }}
      />

      {/* Main Mascot Vector Graphic */}
      <svg
        viewBox="0 0 400 400"
        className="w-full h-full max-w-[420px] max-h-[420px] z-10 filter drop-shadow-[0_18px_40px_rgba(0,0,0,0.7)] overflow-visible"
      >
        <defs>
          {/* Luminous Glow Filters */}
          <filter id="mascot-glow" x="-50%" y="-50%" width="200%" height="200%">
            <feGaussianBlur stdDeviation="3.2" result="blur" />
            <feMerge>
              <feMergeNode in="blur" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>

          <filter id="halo-glow" x="-50%" y="-50%" width="200%" height="200%">
            <feGaussianBlur stdDeviation="7.5" result="blur" />
            <feMerge>
              <feMergeNode in="blur" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>

          {/* Spherical Glossy Dark Face Gradient */}
          <radialGradient id="sphere-face-gradient" cx="42%" cy="38%" r="62%">
            <stop offset="0%" stopColor="#1e293b" />
            <stop offset="45%" stopColor="#0f172a" />
            <stop offset="78%" stopColor="#080c16" />
            <stop offset="100%" stopColor="#04060b" />
          </radialGradient>

          {/* Luminous Cyan Halo Gradient */}
          <linearGradient id="halo-grad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#ffffff" />
            <stop offset="20%" stopColor="#00e5ff" />
            <stop offset="60%" stopColor="#38bdf8" />
            <stop offset="85%" stopColor="#a855f7" />
            <stop offset="100%" stopColor="#00e5ff" />
          </linearGradient>

          {/* Eye Iris Gradient */}
          <radialGradient id="eye-iris-gradient" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="#00e5ff" />
            <stop offset="45%" stopColor="#0284c7" />
            <stop offset="85%" stopColor="#075985" />
            <stop offset="100%" stopColor="#0c4a6e" />
          </radialGradient>

          {/* Cheeks Blush Soft Gradient */}
          <radialGradient id="blush-grad" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="#ff4fd8" stopOpacity="0.8" />
            <stop offset="65%" stopColor="#f43f5e" stopOpacity="0.35" />
            <stop offset="100%" stopColor="#f43f5e" stopOpacity="0" />
          </radialGradient>

          {/* Orbital Ring Neon Gradient */}
          <linearGradient id="orbit-grad-neon" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#00e5ff" stopOpacity="0.95" />
            <stop offset="30%" stopColor="#0284c7" stopOpacity="0.9" />
            <stop offset="65%" stopColor="#9333ea" stopOpacity="0.95" />
            <stop offset="100%" stopColor="#ec4899" stopOpacity="0.95" />
          </linearGradient>

          {/* Floor Ripple Radial Gradient */}
          <radialGradient id="floor-ripple-grad" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="#00e5ff" stopOpacity="0.6" />
            <stop offset="50%" stopColor="#3b82f6" stopOpacity="0.3" />
            <stop offset="85%" stopColor="#9333ea" stopOpacity="0.15" />
            <stop offset="100%" stopColor="#000000" stopOpacity="0" />
          </radialGradient>
        </defs>

        {/* ========================================================= */}
        {/* FLOOR CONCENTRIC HOLOGRAPHIC RIPPLES */}
        {/* ========================================================= */}
        <g id="floor-ripples" ref={rippleGroupRef} className="origin-center">
          <ellipse cx="200" cy="335" rx="130" ry="22" fill="url(#floor-ripple-grad)" />
          <ellipse cx="200" cy="335" rx="125" ry="20" fill="none" stroke="#00e5ff" strokeWidth="1.5" strokeOpacity="0.75" filter="url(#mascot-glow)" />
          <ellipse cx="200" cy="335" rx="90" ry="14" fill="none" stroke="#38bdf8" strokeWidth="1.8" strokeOpacity="0.85" />
          <ellipse cx="200" cy="335" rx="55" ry="9" fill="none" stroke="#c084fc" strokeWidth="1.5" strokeOpacity="0.65" />
        </g>

        {/* ========================================================= */}
        {/* 1. LUMINOUS CIRCULAR HALO (BEHIND HEAD) */}
        {/* ========================================================= */}
        <g ref={haloGroupRef} id="halo-ring-group" className="origin-center">
          {/* Outer Cyan Halo Glow */}
          <circle
            cx="200"
            cy="195"
            r="114"
            fill="none"
            stroke="url(#halo-grad)"
            strokeWidth="11"
            filter="url(#halo-glow)"
            opacity="0.85"
          />
          {/* Intense Pure White Inner Halo Core Line */}
          <circle
            cx="200"
            cy="195"
            r="114"
            fill="none"
            stroke="#ffffff"
            strokeWidth="4.5"
            filter="url(#mascot-glow)"
          />
        </g>

        {/* Animated Head & Mascot Group */}
        <g ref={headGroupRef} transform="translate(0, 0)">
          {/* ========================================================= */}
          {/* 2. DUAL HOLOGRAPHIC ORBITAL RING (BACK HALF - Passes Behind Head) */}
          {/* ========================================================= */}
          <g ref={orbitBackRef} id="orbit-ring-back">
            <g transform="rotate(-18 200 208)">
              {/* Outer track back */}
              <path
                d="M 44 208 A 156 38 0 0 1 356 208"
                fill="none"
                stroke="url(#orbit-grad-neon)"
                strokeWidth="3.2"
                strokeDasharray="8 4"
                filter="url(#mascot-glow)"
                opacity="0.75"
              />
              {/* Inner track back */}
              <path
                d="M 68 208 A 132 30 0 0 1 332 208"
                fill="none"
                stroke="#00e5ff"
                strokeWidth="1.5"
                opacity="0.6"
              />
              {/* Back Orbital Node */}
              <circle cx="120" cy="182" r="2.5" fill="#00e5ff" filter="url(#mascot-glow)" />
            </g>
          </g>

          {/* ========================================================= */}
          {/* 3. SMOOTH DARK GLOSSY SPHERICAL FACE VISOR */}
          {/* ========================================================= */}
          {/* Outer Sphere Soft Glow */}
          <circle
            cx="200"
            cy="200"
            r="98"
            fill="#00e5ff"
            opacity="0.12"
            filter="url(#mascot-glow)"
          />

          {/* Dark Glossy Sphere Body */}
          <circle
            cx="200"
            cy="200"
            r="94"
            fill="url(#sphere-face-gradient)"
            stroke="#00e5ff"
            strokeWidth="2.2"
            strokeOpacity="0.8"
          />

          {/* Specular Curved Gloss Reflection on Top of Visor */}
          <path
            d="M 134 164 Q 185 142 248 156 Q 185 148 134 164 Z"
            fill="#ffffff"
            opacity="0.32"
          />

          {/* Soft Bottom Cyan Bounce Light */}
          <path
            d="M 145 258 Q 200 274 255 258 Q 200 266 145 258 Z"
            fill="#00e5ff"
            opacity="0.25"
            filter="url(#mascot-glow)"
          />

          {/* Forehead Micro Cyber Node */}
          <circle
            cx="200"
            cy="148"
            r="2.5"
            fill={state === 'speaking' ? '#00e5ff' : state === 'listening' ? '#38bdf8' : '#c084fc'}
            filter="url(#mascot-glow)"
          />

          {/* ========================================================= */}
          {/* 4. CUTE CHEEK BLUSH OVERLAYS */}
          {/* ========================================================= */}
          <ellipse
            ref={leftBlushRef}
            cx="145"
            cy="216"
            rx="16"
            ry="8"
            fill="url(#blush-grad)"
            style={{ opacity: 0.65, transition: 'opacity 0.25s ease' }}
          />
          <ellipse
            ref={rightBlushRef}
            cx="255"
            cy="216"
            rx="16"
            ry="8"
            fill="url(#blush-grad)"
            style={{ opacity: 0.65, transition: 'opacity 0.25s ease' }}
          />

          {/* ========================================================= */}
          {/* 5. DIGITAL GLOWING EYES & EYELIDS */}
          {/* ========================================================= */}
          {/* Left Eye */}
          <g>
            {animator.eyeController.renderEyeGraphic(
              true,
              currentNormEmotion,
              normIntensity,
              { x: 0, y: 0, targetX: 0, targetY: 0, microSaccadeX: 0, microSaccadeY: 0 },
              0,
              leftPupilRef,
              rightPupilRef
            )}
          </g>
          {/* Right Eye */}
          <g>
            {animator.eyeController.renderEyeGraphic(
              false,
              currentNormEmotion,
              normIntensity,
              { x: 0, y: 0, targetX: 0, targetY: 0, microSaccadeX: 0, microSaccadeY: 0 },
              0,
              leftPupilRef,
              rightPupilRef
            )}
          </g>

          {/* Blinking Eyelids */}
          <path
            ref={leftEyeLidRef}
            d="M 146 186 Q 162 186 178 186 Q 162 182 146 186 Z"
            fill="#060914"
            stroke="#0284c7"
            strokeWidth="1.5"
            style={{ opacity: 0 }}
          />
          <path
            ref={rightEyeLidRef}
            d="M 222 186 Q 238 186 254 186 Q 238 182 222 186 Z"
            fill="#060914"
            stroke="#0284c7"
            strokeWidth="1.5"
            style={{ opacity: 0 }}
          />

          {/* ========================================================= */}
          {/* 6. ANIMATED LIP-SYNC MOUTH */}
          {/* ========================================================= */}
          {/* Mouth Dark Interior Cavity */}
          <path
            ref={mouthFillRef}
            d="M 188 230 Q 200 229 212 230 Q 200 235 188 230 Z"
            fill="#0369a1"
            stroke="#00e5ff"
            strokeWidth="1"
            style={{ opacity: 0 }}
          />
          {/* Mouth Glowing Outline Lip Line */}
          <path
            ref={mouthPathRef}
            d="M 188 230 Q 200 238 212 230"
            fill="none"
            stroke="#00e5ff"
            strokeWidth="3.2"
            strokeLinecap="round"
            filter="url(#mascot-glow)"
          />

          {/* ========================================================= */}
          {/* 7. DUAL HOLOGRAPHIC ORBITAL RING (FRONT HALF) */}
          {/* ========================================================= */}
          <g ref={orbitFrontRef} id="orbit-ring-front">
            <g transform="rotate(-18 200 208)">
              {/* Outer track front */}
              <path
                d="M 356 208 A 156 38 0 0 1 44 208"
                fill="none"
                stroke="url(#orbit-grad-neon)"
                strokeWidth="3.6"
                filter="url(#mascot-glow)"
                opacity="0.95"
              />
              {/* Inner track front */}
              <path
                d="M 332 208 A 132 30 0 0 1 68 208"
                fill="none"
                stroke="#00e5ff"
                strokeWidth="1.8"
                opacity="0.85"
              />
              {/* Front Orbiting Sparkle Nodes */}
              <circle cx="210" cy="246" r="3.2" fill="#00e5ff" filter="url(#mascot-glow)" />
              <circle cx="210" cy="246" r="1.6" fill="#ffffff" />
              <circle cx="295" cy="235" r="2.8" fill="#ec4899" filter="url(#mascot-glow)" />
              <circle cx="105" cy="226" r="2.5" fill="#38bdf8" filter="url(#mascot-glow)" />
            </g>
          </g>

          {/* ========================================================= */}
          {/* 8. DYNAMIC VISION & SCREEN SHARING HUD OVERLAYS */}
          {/* ========================================================= */}
          {effectiveMascotState === 'VISION_ANALYZING' && (
            <g id="vision-hud-overlay">
              <path d="M 125 155 L 125 140 L 140 140" fill="none" stroke="#00e5ff" strokeWidth="2.5" filter="url(#mascot-glow)" />
              <path d="M 275 155 L 275 140 L 260 140" fill="none" stroke="#00e5ff" strokeWidth="2.5" filter="url(#mascot-glow)" />
              <path d="M 125 245 L 125 260 L 140 260" fill="none" stroke="#c084fc" strokeWidth="2.5" filter="url(#mascot-glow)" />
              <path d="M 275 245 L 275 260 L 260 260" fill="none" stroke="#c084fc" strokeWidth="2.5" filter="url(#mascot-glow)" />
              <line x1="128" y1="200" x2="272" y2="200" stroke="#00e5ff" strokeWidth="2" filter="url(#mascot-glow)" opacity="0.85" className="animate-pulse" />
            </g>
          )}

          {effectiveMascotState === 'SCREEN_SHARING' && (
            <g id="screen-share-overlay">
              <circle cx="200" cy="200" r="98" fill="none" stroke="#10b981" strokeWidth="2.5" strokeDasharray="8 6" filter="url(#mascot-glow)" className="animate-spin origin-center" style={{ animationDuration: '8s' }} />
              <rect x="184" y="132" width="32" height="20" rx="3" fill="#042f2e" stroke="#10b981" strokeWidth="1.8" filter="url(#mascot-glow)" />
              <line x1="184" y1="146" x2="216" y2="146" stroke="#10b981" strokeWidth="1.2" />
            </g>
          )}

          {effectiveMascotState === 'SCREEN_ANALYZING' && (
            <g id="screen-analyzing-overlay">
              {/* Dual concentric scanning target rings */}
              <circle cx="200" cy="200" r="96" fill="none" stroke="#10b981" strokeWidth="2.2" strokeDasharray="6 4" filter="url(#mascot-glow)" className="animate-spin origin-center" style={{ animationDuration: '4s' }} />
              <circle cx="200" cy="200" r="76" fill="none" stroke="#00e5ff" strokeWidth="1.6" strokeDasharray="4 8" filter="url(#mascot-glow)" className="animate-spin origin-center" style={{ animationDuration: '6s', animationDirection: 'reverse' }} />
              
              {/* Active Radar Sweep Line */}
              <line x1="200" y1="200" x2="270" y2="150" stroke="#34d399" strokeWidth="2.4" filter="url(#mascot-glow)" strokeLinecap="round" className="origin-center animate-spin" style={{ animationDuration: '2.5s' }} />
              
              {/* Target Crosshairs */}
              <path d="M 120 150 L 120 135 L 135 135" fill="none" stroke="#34d399" strokeWidth="2.5" filter="url(#mascot-glow)" />
              <path d="M 280 150 L 280 135 L 265 135" fill="none" stroke="#34d399" strokeWidth="2.5" filter="url(#mascot-glow)" />
              <path d="M 120 250 L 120 265 L 135 265" fill="none" stroke="#34d399" strokeWidth="2.5" filter="url(#mascot-glow)" />
              <path d="M 280 250 L 280 265 L 265 265" fill="none" stroke="#34d399" strokeWidth="2.5" filter="url(#mascot-glow)" />
              
              {/* Screen Icon with Pulse Light */}
              <rect x="182" y="128" width="36" height="22" rx="4" fill="#022c22" stroke="#34d399" strokeWidth="2" filter="url(#mascot-glow)" />
              <circle cx="200" cy="139" r="3" fill="#00e5ff" className="animate-ping" />
            </g>
          )}
        </g>
      </svg>
    </div>
  );
};
