import React, { useEffect, useRef } from 'react';

interface Particle {
  x: number;
  y: number;
  vy: number;
  size: number;
  color: string;
  alpha: number;
  maxAlpha: number;
}

export const FuturisticBackground: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;
    let width = (canvas.width = window.innerWidth);
    let height = (canvas.height = window.innerHeight);

    const handleResize = () => {
      if (!canvas) return;
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
    };
    window.addEventListener('resize', handleResize);

    // Cyan and purple floating bokeh embers/particles matching reference
    const particles: Particle[] = [];
    const count = Math.min(36, Math.floor(width / 25));
    for (let i = 0; i < count; i++) {
      particles.push({
        x: Math.random() * width,
        y: Math.random() * height,
        vy: -0.3 - Math.random() * 0.6,
        size: 1.2 + Math.random() * 2.8,
        color: Math.random() > 0.45 ? '#00e5ff' : '#9b5cff',
        alpha: Math.random() * 0.7,
        maxAlpha: 0.3 + Math.random() * 0.6,
      });
    }

    const render = () => {
      ctx.clearRect(0, 0, width, height);

      for (let i = 0; i < particles.length; i++) {
        const p = particles[i];
        p.y += p.vy;
        if (p.y < -10) {
          p.y = height + 10;
          p.x = Math.random() * width;
        }

        ctx.save();
        ctx.shadowBlur = p.size * 4;
        ctx.shadowColor = p.color;
        ctx.fillStyle = p.color;
        ctx.globalAlpha = p.alpha;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      }

      animId = requestAnimationFrame(render);
    };

    render();

    return () => {
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(animId);
    };
  }, []);

  return (
    <div className="fixed inset-0 w-full h-full pointer-events-none overflow-hidden z-0 bg-[#050612]">
      {/* 1. Base Deep Navy to Obsidian Space Gradient */}
      <div className="absolute inset-0 bg-gradient-to-b from-[#060817] via-[#050612] to-[#04050d]" />

      {/* 2. Soft Center Atmospheric Blue/Cyan Ambient Radial Glow */}
      <div className="absolute top-[35%] left-1/2 -translate-x-1/2 -translate-y-1/2 w-[550px] sm:w-[650px] h-[550px] sm:h-[650px] rounded-full bg-[radial-gradient(ellipse_at_center,_rgba(40,123,255,0.18)_0%,_rgba(0,229,255,0.09)_35%,_rgba(155,92,255,0.05)_65%,_transparent_75%)] filter blur-3xl pointer-events-none" />

      {/* 3. Floating Bokeh Particles Canvas */}
      <canvas
        ref={canvasRef}
        className="absolute inset-0 w-full h-full pointer-events-none z-10"
      />

      {/* 4. Glowing Concentric Holographic Projection Platform (Bottom Third Under Avatar) */}
      <div className="absolute bottom-[80px] sm:bottom-[90px] left-1/2 -translate-x-1/2 w-full max-w-[520px] h-[240px] flex items-center justify-center pointer-events-none z-10">
        {/* Holographic Projection Vertical Light Pillar */}
        <div
          className="absolute bottom-16 w-52 h-44 bg-gradient-to-t from-cyan-400/25 via-blue-500/12 to-transparent filter blur-lg"
          style={{ clipPath: 'polygon(20% 100%, 80% 100%, 95% 0%, 5% 0%)' }}
        />

        {/* Floor Horizon Grid Reflection */}
        <div
          className="absolute bottom-0 inset-x-0 h-44 opacity-35"
          style={{
            perspective: '350px',
          }}
        >
          <div
            className="w-full h-full"
            style={{
              transform: 'rotateX(76deg)',
              transformOrigin: 'bottom center',
              backgroundImage:
                'linear-gradient(to right, rgba(0, 229, 255, 0.4) 1px, transparent 1px), linear-gradient(to bottom, rgba(40, 123, 255, 0.4) 1px, transparent 1px)',
              backgroundSize: '36px 36px',
              maskImage: 'radial-gradient(ellipse at center, black 40%, transparent 85%)',
              WebkitMaskImage: 'radial-gradient(ellipse at center, black 40%, transparent 85%)',
            }}
          />
        </div>

        {/* Concentric Glowing Neon Rings On Floor (Exact Match to Reference) */}
        {/* Outermost Cyber Ring */}
        <div
          className="absolute bottom-10 w-[380px] sm:w-[420px] h-[130px] sm:h-[145px] rounded-full border border-blue-500/30"
          style={{
            transform: 'rotateX(75deg)',
            boxShadow: '0 0 25px rgba(40, 123, 255, 0.25)',
          }}
        />

        {/* Outer Purple/Magenta Neon Ring */}
        <div
          className="absolute bottom-11 w-[320px] sm:w-[350px] h-[110px] sm:h-[120px] rounded-full border-2 border-[#9b5cff]/65"
          style={{
            transform: 'rotateX(75deg)',
            boxShadow: '0 0 20px rgba(155, 92, 255, 0.5), inset 0 0 15px rgba(155, 92, 255, 0.3)',
          }}
        />

        {/* Middle Electric Blue Ring */}
        <div
          className="absolute bottom-12 w-[240px] sm:w-[260px] h-[85px] sm:h-[95px] rounded-full border-2 border-[#287bff]/85"
          style={{
            transform: 'rotateX(75deg)',
            boxShadow: '0 0 25px rgba(40, 123, 255, 0.7), inset 0 0 15px rgba(40, 123, 255, 0.4)',
          }}
        />

        {/* Inner Cyan Bright Ring */}
        <div
          className="absolute bottom-13 w-[160px] sm:w-[175px] h-[60px] sm:h-[65px] rounded-full border-2 border-[#00e5ff]"
          style={{
            transform: 'rotateX(75deg)',
            boxShadow: '0 0 20px #00e5ff, inset 0 0 12px #00e5ff',
          }}
        />

        {/* Innermost Glowing Cyan Core Spot */}
        <div
          className="absolute bottom-14 w-[85px] h-[34px] rounded-full bg-[#00e5ff] filter blur-sm opacity-80"
          style={{ transform: 'rotateX(75deg)' }}
        />
        <div
          className="absolute bottom-14 w-[50px] h-[20px] rounded-full bg-white filter blur-xs"
          style={{ transform: 'rotateX(75deg)' }}
        />
      </div>

      {/* 5. Subtle Edge Vignette */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_transparent_60%,_rgba(2,3,8,0.7)_100%)] pointer-events-none" />
    </div>
  );
};
