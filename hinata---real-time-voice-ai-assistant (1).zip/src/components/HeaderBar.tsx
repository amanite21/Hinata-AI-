import React, { useState, useEffect } from 'react';
import { SlidersHorizontal, Mic, Volume2, Wifi, Eye, Smartphone, BatteryMedium, Sparkles, Heart, AlertTriangle, CheckCircle2, AlertCircle, Server } from 'lucide-react';
import { LiveSessionState } from '../types';
import { HandsFreeStatusPill } from './wake/HandsFreeStatusPill';
import { backendConfig, BackendStatusType } from '../config/backendConfig';

interface HeaderBarProps {
  state: LiveSessionState;
  onOpenSettings: () => void;
  onOpenVision?: () => void;
  onOpenDeviceActions?: () => void;
  onOpenHandsFree?: () => void;
  onOpenBackendStatus?: () => void;
  activeReferenceCount?: number;
  isVisionCustomApplied?: boolean;
}

export const HeaderBar: React.FC<HeaderBarProps> = ({
  state,
  onOpenSettings,
  onOpenVision,
  onOpenDeviceActions,
  onOpenHandsFree,
  onOpenBackendStatus,
  activeReferenceCount = 0,
  isVisionCustomApplied = false,
}) => {
  const [currentTime, setCurrentTime] = useState<string>('12:06');
  const [backendStatus, setBackendStatus] = useState<BackendStatusType>(() => backendConfig.getStatus());

  useEffect(() => {
    const updateTime = () => {
      const d = new Date();
      const hours = d.getHours();
      const mins = d.getMinutes().toString().padStart(2, '0');
      setCurrentTime(`${hours}:${mins}`);
    };
    updateTime();
    const interval = setInterval(updateTime, 30000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const updateBackendStatus = () => {
      setBackendStatus(backendConfig.getStatus());
    };
    updateBackendStatus();
    const unsub = backendConfig.subscribe(updateBackendStatus);
    return unsub;
  }, []);

  const getStatusInfo = () => {
    switch (state) {
      case 'listening':
        return {
          text: 'Listening...',
          pillBg: 'bg-[#0a122c]/85 border-cyan-400/50 text-[#00e5ff] shadow-[0_0_15px_rgba(0,229,255,0.25)]',
          dotBg: 'bg-[#00e5ff] shadow-[0_0_10px_#00e5ff] animate-pulse',
          icon: <Mic className="w-3.5 h-3.5 text-[#00e5ff]" />,
        };
      case 'speaking':
        return {
          text: 'Speaking...',
          pillBg: 'bg-[#130d2c]/85 border-purple-400/50 text-[#c084fc] shadow-[0_0_15px_rgba(192,132,252,0.25)]',
          dotBg: 'bg-[#c084fc] shadow-[0_0_10px_#c084fc] animate-ping',
          icon: <Volume2 className="w-3.5 h-3.5 text-[#c084fc]" />,
        };
      case 'connecting':
        return {
          text: 'Connecting...',
          pillBg: 'bg-[#0a122c]/85 border-cyan-400/40 text-cyan-300',
          dotBg: 'bg-[#00e5ff] shadow-[0_0_10px_#00e5ff] animate-spin',
          icon: <Wifi className="w-3.5 h-3.5 text-cyan-300" />,
        };
      case 'error':
        return {
          text: 'Notice',
          pillBg: 'bg-rose-950/80 border-rose-500/40 text-rose-300',
          dotBg: 'bg-rose-400 shadow-[0_0_8px_#f43f5e]',
          icon: null,
        };
      case 'disconnected':
      default:
        return {
          text: 'Listening...',
          pillBg: 'bg-[#0a122c]/85 border-cyan-400/40 text-[#00e5ff] shadow-[0_0_12px_rgba(0,229,255,0.15)]',
          dotBg: 'bg-[#00e5ff] shadow-[0_0_8px_#00e5ff]',
          icon: <Mic className="w-3.5 h-3.5 text-[#00e5ff]" />,
        };
    }
  };

  const status = getStatusInfo();

  return (
    <header className="w-full max-w-4xl mx-auto px-4 pt-2.5 pb-1 z-40 select-none flex flex-col gap-1.5">
      {/* 1. Mobile Status Bar Row (Time, Signals, Battery) */}
      <div className="w-full flex items-center justify-between text-[11px] text-slate-400 px-1">
        <span className="font-semibold text-slate-200 tracking-tight">{currentTime}</span>
        <div className="flex items-center gap-2">
          <Wifi className="w-3 h-3 text-cyan-400" />
          <BatteryMedium className="w-3.5 h-3.5 text-slate-300" />
        </div>
      </div>

      {/* 2. Main Header Bar Row */}
      <div className="w-full flex items-center justify-between gap-3">
        {/* Left branding matching reference image */}
        <div className="flex items-center gap-2.5">
          <div className="relative flex-shrink-0">
            <div className="w-10 h-10 rounded-full overflow-hidden border-2 border-cyan-400/60 shadow-[0_0_14px_rgba(0,229,255,0.4)] bg-[#0a122c] p-0.5">
              <img
                src="/hinata_icon.jpg"
                alt="Hinata"
                className="w-full h-full object-cover rounded-full"
              />
            </div>
            <span className="absolute bottom-0 right-0 w-3 h-3 rounded-full bg-[#10b981] border-2 border-[#050612] shadow-[0_0_6px_#10b981]" />
          </div>

          <div className="flex flex-col">
            <div className="flex items-center gap-1.5">
              <h1 className="font-bold text-[16px] tracking-wide text-white leading-tight flex items-center gap-1">
                <span>Hinata</span>
                <span className="text-cyan-400 text-sm">✦</span>
              </h1>
              <span className="text-[9px] font-semibold px-1.5 py-0.5 rounded bg-cyan-950/80 border border-cyan-400/50 text-cyan-300 uppercase tracking-wider">
                COMPANION
              </span>
            </div>
            <p className="text-[11px] text-slate-400 font-normal leading-tight mt-0.5 flex items-center gap-1">
              <span>Your Personal AI Companion</span>
            </p>
          </div>
        </div>

        {/* Right side: Hands-Free Wake Word pill, Live status & Action icons */}
        <div className="flex items-center gap-2">
          {/* Backend Status Pill */}
          {onOpenBackendStatus && (
            <button
              onClick={onOpenBackendStatus}
              className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full border text-[10px] sm:text-[11px] font-medium transition-all duration-200 active:scale-95 ${
                backendStatus === 'connected'
                  ? 'bg-emerald-950/80 border-emerald-500/40 text-emerald-300 shadow-[0_0_10px_rgba(16,185,129,0.2)]'
                  : backendStatus === 'not_configured'
                  ? 'bg-amber-950/80 border-amber-500/40 text-amber-300 hover:border-amber-400'
                  : 'bg-rose-950/80 border-rose-500/40 text-rose-300'
              }`}
              title="Click to view Backend Status & Connection Diagnostics"
            >
              {backendStatus === 'connected' ? (
                <CheckCircle2 className="w-3 h-3 text-emerald-400" />
              ) : backendStatus === 'not_configured' ? (
                <AlertTriangle className="w-3 h-3 text-amber-400" />
              ) : (
                <AlertCircle className="w-3 h-3 text-rose-400" />
              )}
              <span className="hidden xs:inline">
                {backendStatus === 'connected'
                  ? 'Connected ✓'
                  : backendStatus === 'not_configured'
                  ? 'Not configured'
                  : 'Connection failed'}
              </span>
            </button>
          )}

          {onOpenHandsFree && (
            <HandsFreeStatusPill onOpenSetup={onOpenHandsFree} />
          )}

          <div
            className={`flex items-center gap-2 px-3 py-1.5 rounded-full border backdrop-blur-xl text-xs font-medium transition-all duration-300 ${status.pillBg}`}
          >
            <span className={`w-2 h-2 rounded-full ${status.dotBg}`} />
            {status.icon}
            <span className="text-[11px] font-medium tracking-wide">{status.text}</span>
          </div>

          {onOpenDeviceActions && (
            <button
              id="btn-header-device-actions"
              onClick={onOpenDeviceActions}
              className="w-8 h-8 rounded-full bg-[#0a122c]/85 border border-cyan-400/35 hover:border-cyan-400 text-slate-200 hover:text-white flex items-center justify-center transition-all duration-200 shadow-[0_0_10px_rgba(0,229,255,0.15)] active:scale-95"
              title="Device Control Hub"
            >
              <Smartphone className="w-3.5 h-3.5 text-purple-400" />
            </button>
          )}

          {onOpenVision && (
            <button
              onClick={onOpenVision}
              className={`relative w-8 h-8 rounded-full bg-[#0a122c]/85 border flex items-center justify-center transition-all duration-200 active:scale-95 ${
                activeReferenceCount > 0 || isVisionCustomApplied
                  ? 'border-cyan-400 text-cyan-300 shadow-[0_0_15px_rgba(0,229,255,0.35)]'
                  : 'border-cyan-400/35 hover:border-cyan-400 text-slate-200 hover:text-white shadow-[0_0_10px_rgba(0,229,255,0.15)]'
              }`}
              title="Visual Design Studio"
            >
              <Eye className="w-3.5 h-3.5 text-cyan-300" />
              {activeReferenceCount > 0 && (
                <span className="absolute -top-1 -right-1 px-1 min-w-[14px] h-[14px] flex items-center justify-center text-[9px] font-bold rounded-full bg-cyan-400 text-[#060a1d] shadow-[0_0_6px_#00e5ff]">
                  {activeReferenceCount}
                </span>
              )}
            </button>
          )}

          <button
            onClick={onOpenSettings}
            className="w-8 h-8 rounded-full bg-[#0a122c]/85 border border-cyan-400/35 hover:border-cyan-400 text-slate-200 hover:text-white flex items-center justify-center transition-all duration-200 shadow-[0_0_10px_rgba(0,229,255,0.15)] active:scale-95"
            title="Settings"
          >
            <SlidersHorizontal className="w-3.5 h-3.5 text-cyan-300" />
          </button>
        </div>
      </div>

      {/* Quote line underneath branding: "Not just an assistant... I'm here, with you. Always." ♡ */}
      <div className="hidden sm:flex items-center gap-1.5 px-1 text-[11px] text-cyan-300/80 italic font-serif">
        <span>“Not just an assistant... I'm here, with you. Always.”</span>
        <Heart className="w-3 h-3 text-pink-400 fill-pink-400 inline" />
      </div>
    </header>
  );
};
