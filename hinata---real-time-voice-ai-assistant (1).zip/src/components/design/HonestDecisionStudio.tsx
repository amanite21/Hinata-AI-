import React, { useState } from 'react';
import { motion } from 'motion/react';
import {
  ShieldAlert,
  CheckCircle2,
  AlertTriangle,
  HelpCircle,
  Scale,
  Lock,
  ArrowRight,
  Send,
  Zap,
} from 'lucide-react';
import { HonestDecisionEngine, DecisionEvaluation } from '../../modules/reasoning/HonestDecisionEngine';

export const HonestDecisionStudio: React.FC = () => {
  const engine = HonestDecisionEngine.getInstance();

  const [inputQuery, setInputQuery] = useState('Make everything solid red and remove all button borders');
  const [evaluation, setEvaluation] = useState<DecisionEvaluation>(() => {
    return engine.evaluateRequest('Make everything solid red and remove all button borders');
  });

  const testCases = [
    { label: 'Usability Conflict', query: 'Make everything solid red and remove all button borders' },
    { label: 'Consequential Action', query: 'Delete this file and wipe database' },
    { label: 'Permission Boundary', query: 'Spy on background camera and read private messages' },
    { label: 'Phone Call Confirmation', query: 'Call Mom right now' },
    { label: 'Epistemic Uncertainty', query: 'What am I wearing right now?' },
    { label: 'Original Design Making', query: 'Design bana do mobile music player ka' },
  ];

  const handleEvaluate = (text?: string) => {
    const q = text || inputQuery;
    const res = engine.evaluateRequest(q);
    setEvaluation(res);
  };

  const getStatusBadge = () => {
    switch (evaluation.status) {
      case 'SUPPORTED':
        return { bg: 'bg-emerald-500/20', text: 'text-emerald-300', border: 'border-emerald-500/40', icon: CheckCircle2 };
      case 'PARTIALLY_SUPPORTED':
        return { bg: 'bg-cyan-500/20', text: 'text-cyan-300', border: 'border-cyan-500/40', icon: CheckCircle2 };
      case 'UNSAFE':
        return { bg: 'bg-rose-500/20', text: 'text-rose-300', border: 'border-rose-500/40', icon: ShieldAlert };
      case 'IMPOSSIBLE_WITH_CURRENT_PERMISSIONS':
        return { bg: 'bg-purple-500/20', text: 'text-purple-300', border: 'border-purple-500/40', icon: Lock };
      case 'UNSUPPORTED':
        return { bg: 'bg-amber-500/20', text: 'text-amber-300', border: 'border-amber-500/40', icon: AlertTriangle };
      default:
        return { bg: 'bg-slate-800', text: 'text-slate-300', border: 'border-slate-700', icon: HelpCircle };
    }
  };

  const badge = getStatusBadge();
  const BadgeIcon = badge.icon;

  return (
    <div className="space-y-4">
      {/* Header Banner */}
      <div className="p-4 rounded-2xl bg-[#090d24] border border-cyan-500/30 space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="w-8 h-8 rounded-xl bg-cyan-500/20 border border-cyan-400/40 flex items-center justify-center text-cyan-300">
              <Scale className="w-4 h-4" />
            </span>
            <div>
              <h3 className="text-sm font-bold text-white">Honest Decision &amp; Critical Thinking Engine</h3>
              <p className="text-xs text-slate-400">
                Removes blind agreeableness. Evaluates permission boundaries, usability impacts, and fact-vs-guess certainty.
              </p>
            </div>
          </div>

          <span className="text-[11px] font-mono px-2 py-0.5 rounded-full bg-cyan-950 border border-cyan-400/40 text-cyan-300">
            Truth-First Execution
          </span>
        </div>

        {/* Quick Test Chips */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
          {testCases.map((tc) => (
            <button
              key={tc.label}
              onClick={() => {
                setInputQuery(tc.query);
                handleEvaluate(tc.query);
              }}
              className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-all whitespace-nowrap ${
                inputQuery === tc.query
                  ? 'bg-cyan-500/25 border border-cyan-400/60 text-cyan-200'
                  : 'bg-slate-800/60 hover:bg-slate-700/60 border border-slate-700/50 text-slate-300'
              }`}
            >
              {tc.label}
            </button>
          ))}
        </div>

        {/* Input Bar */}
        <div className="flex gap-2">
          <input
            type="text"
            value={inputQuery}
            onChange={(e) => setInputQuery(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleEvaluate()}
            placeholder="Type any command to evaluate capability, safety, or design integrity..."
            className="flex-1 px-3.5 py-2 rounded-xl bg-slate-900/90 border border-slate-700 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400 transition-colors min-h-[44px]"
          />
          <button
            onClick={() => handleEvaluate()}
            className="px-4 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-black font-bold text-xs shadow-[0_0_15px_rgba(0,229,255,0.3)] transition-all flex items-center gap-1.5 min-h-[44px]"
          >
            <Zap className="w-3.5 h-3.5 fill-current" />
            <span>Evaluate</span>
          </button>
        </div>
      </div>

      {/* Result Status Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        {/* Left: Capability & Epistemic Calibration */}
        <div className="p-4 rounded-2xl bg-[#060a1d] border border-slate-800 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-400">Request Evaluation</span>
            <span
              className={`px-2.5 py-0.5 rounded-full text-[11px] font-bold border flex items-center gap-1.5 ${badge.bg} ${badge.text} ${badge.border}`}
            >
              <BadgeIcon className="w-3 h-3" />
              <span>{evaluation.status}</span>
            </span>
          </div>

          <div className="p-3 rounded-xl bg-white/5 border border-white/5 space-y-1.5 text-xs">
            <div className="flex items-center justify-between">
              <span className="text-slate-400">Epistemic Certainty:</span>
              <span className="font-mono text-cyan-300 font-bold">{evaluation.epistemicStatus}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-slate-400">Can Execute Directly:</span>
              <span className={evaluation.canExecute ? 'text-emerald-400 font-bold' : 'text-rose-400 font-bold'}>
                {evaluation.canExecute ? 'YES' : 'NO (Guarded)'}
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-slate-400">Requires Confirmation:</span>
              <span className={evaluation.requiresConfirmation ? 'text-amber-400 font-bold' : 'text-slate-400'}>
                {evaluation.requiresConfirmation ? 'REQUIRED' : 'NO'}
              </span>
            </div>
          </div>

          <div>
            <span className="text-xs font-semibold text-slate-300 block mb-1">Reasoning Analysis:</span>
            <p className="text-xs text-slate-400 leading-relaxed bg-black/40 p-3 rounded-xl border border-slate-800">
              {evaluation.reason}
            </p>
          </div>
        </div>

        {/* Right: Hinata's Recommended Honest Response */}
        <div className="p-4 rounded-2xl bg-[#060a1d] border border-slate-800 space-y-3 flex flex-col justify-between">
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-slate-400 block mb-2">
              Hinata Honest Response
            </span>
            <div className="p-3.5 rounded-xl bg-cyan-950/40 border border-cyan-500/30 text-xs text-cyan-100 leading-relaxed">
              &quot;{evaluation.recommendedResponse}&quot;
            </div>
          </div>

          {/* Decision Support Matrix (if available) */}
          {evaluation.decisionSupport && (
            <div className="space-y-2 pt-2 border-t border-slate-800 text-xs">
              <span className="text-xs font-bold text-white flex items-center gap-1">
                <Scale className="w-3.5 h-3.5 text-cyan-400" />
                <span>Decision Support Matrix</span>
              </span>

              <div className="grid grid-cols-2 gap-2 text-[11px]">
                <div className="p-2.5 rounded-lg bg-rose-950/20 border border-rose-500/20">
                  <span className="font-bold text-rose-300 block">{evaluation.decisionSupport.optionA.name}</span>
                  <span className="text-slate-400 block mt-0.5">Cons: {evaluation.decisionSupport.optionA.cons}</span>
                </div>
                <div className="p-2.5 rounded-lg bg-emerald-950/20 border border-emerald-500/20">
                  <span className="font-bold text-emerald-300 block">{evaluation.decisionSupport.optionB.name}</span>
                  <span className="text-emerald-200/80 block mt-0.5">Pros: {evaluation.decisionSupport.optionB.pros}</span>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
