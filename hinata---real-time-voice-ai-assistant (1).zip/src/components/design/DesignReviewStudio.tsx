import React, { useState } from 'react';
import { motion } from 'motion/react';
import {
  Sparkles,
  CheckCircle2,
  AlertTriangle,
  ArrowRight,
  ShieldCheck,
  Eye,
  Sliders,
  Maximize2,
  Check,
} from 'lucide-react';
import { VisualReferenceImage } from '../../types/visualDesign';
import { DesignReviewEngine } from '../../modules/design/DesignReviewEngine';
import { ScreenshotCritiqueResult } from '../../modules/design/DesignIntelligenceTypes';

interface DesignReviewStudioProps {
  activeRef: VisualReferenceImage | null;
  onShowNotice: (msg: string) => void;
}

export const DesignReviewStudio: React.FC<DesignReviewStudioProps> = ({ activeRef, onShowNotice }) => {
  const reviewer = DesignReviewEngine.getInstance();

  const [critiqueResult, setCritiqueResult] = useState<ScreenshotCritiqueResult | null>(() => {
    if (activeRef?.analysis) {
      return reviewer.critiqueScreenshot(activeRef.analysis, activeRef.dataUrl);
    }
    return null;
  });

  // Recompute when active reference changes
  React.useEffect(() => {
    if (activeRef?.analysis) {
      const res = reviewer.critiqueScreenshot(activeRef.analysis, activeRef.dataUrl);
      setCritiqueResult(res);
    }
  }, [activeRef]);

  if (!activeRef || !activeRef.analysis || !critiqueResult) {
    return (
      <div className="p-8 text-center rounded-2xl bg-slate-900/30 border border-slate-800 space-y-3">
        <Eye className="w-8 h-8 text-slate-500 mx-auto" />
        <h4 className="text-sm font-semibold text-white">No Analyzed Reference Selected</h4>
        <p className="text-xs text-slate-400 max-w-md mx-auto">
          Upload or select a screenshot in the References tab to trigger Hinata&apos;s deep design critique engine.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Header Banner */}
      <div className="p-4 rounded-2xl bg-[#090e24] border border-cyan-500/30 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <img
            src={activeRef.dataUrl}
            alt={activeRef.name}
            className="w-12 h-12 rounded-xl object-cover border border-cyan-400/40 shrink-0"
          />
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-sm font-bold text-white">{activeRef.name}</h3>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-cyan-950 border border-cyan-400/40 text-cyan-300">
                Score: {critiqueResult.overallScore}/100
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              Honest objective critique evaluating optical hierarchy, mobile ergonomics, and typography rhythm.
            </p>
          </div>
        </div>

        <div className="text-right">
          <span
            className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-xl text-xs font-semibold ${
              critiqueResult.isAlreadyStrong
                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                : 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
            }`}
          >
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>{critiqueResult.isAlreadyStrong ? 'Robust Architecture' : 'Refinement Recommended'}</span>
          </span>
        </div>
      </div>

      {/* Structured 3-Way Breakdown: What Works, What Could Improve, What I Would Change */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
        {/* 1. What Works */}
        <div className="p-3.5 rounded-2xl bg-emerald-950/20 border border-emerald-500/30 space-y-2">
          <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-400 uppercase tracking-wider">
            <CheckCircle2 className="w-4 h-4" />
            <span>What Works</span>
          </div>
          <ul className="space-y-1.5 text-xs text-emerald-200/90">
            {critiqueResult.whatWorks.map((item, i) => (
              <li key={i} className="flex items-start gap-1.5 leading-relaxed">
                <span className="text-emerald-400 font-bold">•</span>
                <span>{item}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* 2. What Could Improve */}
        <div className="p-3.5 rounded-2xl bg-amber-950/20 border border-amber-500/30 space-y-2">
          <div className="flex items-center gap-1.5 text-xs font-bold text-amber-400 uppercase tracking-wider">
            <AlertTriangle className="w-4 h-4" />
            <span>What Could Improve</span>
          </div>
          <ul className="space-y-1.5 text-xs text-amber-200/90">
            {critiqueResult.whatCouldImprove.map((item, i) => (
              <li key={i} className="flex items-start gap-1.5 leading-relaxed">
                <span className="text-amber-400 font-bold">•</span>
                <span>{item}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* 3. What I Would Change */}
        <div className="p-3.5 rounded-2xl bg-cyan-950/20 border border-cyan-500/30 space-y-2">
          <div className="flex items-center gap-1.5 text-xs font-bold text-cyan-400 uppercase tracking-wider">
            <Sparkles className="w-4 h-4" />
            <span>What I Would Change</span>
          </div>
          <ul className="space-y-1.5 text-xs text-cyan-200/90">
            {critiqueResult.whatIWouldChange.map((item, i) => (
              <li key={i} className="flex items-start gap-1.5 leading-relaxed">
                <span className="text-cyan-400 font-bold">•</span>
                <span>{item}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>

      {/* Deep Metric Evaluations */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-2.5 text-xs">
        <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800">
          <span className="text-[11px] text-slate-400 font-medium block">Contrast Ratio</span>
          <span className="text-xs font-bold text-white mt-1 block">{critiqueResult.contrastAssessment}</span>
        </div>
        <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800">
          <span className="text-[11px] text-slate-400 font-medium block">Typography Scaling</span>
          <span className="text-xs font-bold text-white mt-1 block">{critiqueResult.typographyAssessment}</span>
        </div>
        <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800">
          <span className="text-[11px] text-slate-400 font-medium block">Spacing &amp; Rhythm</span>
          <span className="text-xs font-bold text-white mt-1 block">{critiqueResult.spacingAssessment}</span>
        </div>
        <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800">
          <span className="text-[11px] text-slate-400 font-medium block">Mobile Touch Boundaries</span>
          <span className="text-xs font-bold text-white mt-1 block">{critiqueResult.mobileUsabilityAssessment}</span>
        </div>
      </div>
    </div>
  );
};
