import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ExternalLink, CheckCircle2, Clock, CloudSun, Calculator, Sparkles, Search, X } from 'lucide-react';
import { ToolCallItem } from '../types';

interface ToolExecutionBadgeProps {
  activeTools: ToolCallItem[];
  onDismiss: (id: string) => void;
}

export const ToolExecutionBadge: React.FC<ToolExecutionBadgeProps> = ({
  activeTools,
  onDismiss,
}) => {
  if (activeTools.length === 0) return null;

  const getToolIcon = (name: string) => {
    switch (name) {
      case 'openWebsite':
        return <ExternalLink className="w-4 h-4 text-emerald-400" />;
      case 'getCurrentTime':
        return <Clock className="w-4 h-4 text-sky-400" />;
      case 'getWeather':
        return <CloudSun className="w-4 h-4 text-amber-400" />;
      case 'calculate':
        return <Calculator className="w-4 h-4 text-purple-400" />;
      case 'setAssistantMood':
        return <Sparkles className="w-4 h-4 text-pink-400" />;
      case 'searchWebSummary':
      default:
        return <Search className="w-4 h-4 text-cyan-400" />;
    }
  };

  const getToolTitle = (name: string) => {
    switch (name) {
      case 'openWebsite':
        return 'Action: Opening Website';
      case 'getCurrentTime':
        return 'Queried: Local Time';
      case 'getWeather':
        return 'Queried: Weather Forecast';
      case 'calculate':
        return 'Executed: Computation';
      case 'setAssistantMood':
        return 'Vibe Shift';
      case 'searchWebSummary':
      default:
        return 'Knowledge Lookup';
    }
  };

  return (
    <div className="fixed top-20 left-1/2 -translate-x-1/2 z-40 w-full max-w-sm px-4 flex flex-col gap-2 pointer-events-none">
      <AnimatePresence>
        {activeTools.slice(-2).map((tool) => (
          <motion.div
            key={tool.id}
            initial={{ opacity: 0, y: -16, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -12, scale: 0.95 }}
            transition={{ duration: 0.25 }}
            className="pointer-events-auto w-full glass-panel-glow rounded-2xl p-3.5 border border-white/15 shadow-2xl flex items-start justify-between gap-3 text-sm"
          >
            <div className="flex items-start gap-3 flex-1 min-w-0">
              <div className="w-8 h-8 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center flex-shrink-0 mt-0.5">
                {getToolIcon(tool.name)}
              </div>

              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-1.5">
                  <span className="font-semibold text-neutral-100 text-xs tracking-wide uppercase font-mono-tech">
                    {getToolTitle(tool.name)}
                  </span>
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                </div>

                {tool.name === 'openWebsite' && (
                  <div className="mt-1">
                    <p className="text-xs text-neutral-300 truncate">
                      {tool.args.title || tool.args.url}
                    </p>
                    {tool.args.url && (
                      <a
                        href={tool.args.url.startsWith('http') ? tool.args.url : `https://${tool.args.url}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1 text-[11px] text-emerald-400 hover:text-emerald-300 mt-1 font-medium underline underline-offset-2"
                      >
                        <span>Open in new tab</span>
                        <ExternalLink className="w-3 h-3" />
                      </a>
                    )}
                  </div>
                )}

                {tool.name === 'getWeather' && tool.result && (
                  <p className="text-xs text-neutral-300 mt-0.5">
                    {tool.result.location}: {tool.result.condition} ({tool.result.temperatureC}°C / {tool.result.temperatureF}°F)
                  </p>
                )}

                {tool.name === 'getCurrentTime' && tool.result && (
                  <p className="text-xs text-neutral-300 mt-0.5">
                    {tool.result.currentTime} • {tool.result.currentDate}
                  </p>
                )}

                {tool.name === 'calculate' && tool.result && (
                  <p className="text-xs text-neutral-300 mt-0.5 font-mono-tech">
                    {tool.args.expression} = <span className="text-purple-300 font-bold">{tool.result.result}</span>
                  </p>
                )}

                {tool.name === 'setAssistantMood' && (
                  <p className="text-xs text-neutral-300 mt-0.5">
                    Mood set to <span className="capitalize text-pink-300 font-medium">{tool.args.mood}</span>
                  </p>
                )}

                {tool.name === 'searchWebSummary' && tool.result && (
                  <p className="text-xs text-neutral-300 mt-0.5 line-clamp-2">
                    {tool.result.summary}
                  </p>
                )}
              </div>
            </div>

            <button
              onClick={() => onDismiss(tool.id)}
              className="text-neutral-400 hover:text-neutral-200 p-1 rounded-lg hover:bg-white/5 transition-colors"
              aria-label="Dismiss tool result"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
};
