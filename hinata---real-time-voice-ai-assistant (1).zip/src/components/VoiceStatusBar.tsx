import React from 'react';
import { motion } from 'motion/react';
import { LiveSessionState, MascotState, WakeWordState } from '../types';
import { Heart, Sparkles, Radio } from 'lucide-react';

interface VoiceStatusBarProps {
  state: LiveSessionState;
  mascotState?: MascotState;
  wakeState?: WakeWordState;
  isScreenSharing?: boolean;
  hasImage?: boolean;
  lastTranscript?: string | null;
  transcriptRole?: 'user' | 'model' | 'assistant' | null;
  outputVolume?: number;
  inputVolume?: number;
}

export const VoiceStatusBar: React.FC<VoiceStatusBarProps> = ({
  state,
  mascotState,
  wakeState,
  isScreenSharing = false,
  hasImage = false,
  lastTranscript,
  transcriptRole,
  outputVolume = 0,
  inputVolume = 0,
}) => {
  const isSpeaking = state === 'speaking' || wakeState === 'SPEAKING';
  const isListening = state === 'listening' || wakeState === 'LISTENING';
  const isThinking = state === 'processing' || mascotState === 'THINKING' || wakeState === 'THINKING';
  const isWakeDetected = wakeState === 'WAKE_DETECTED';
  const isVoiceActive = isSpeaking || isListening || isWakeDetected;
  const currentVol = isSpeaking ? outputVolume : inputVolume;

  // Title & Subtitle according to reference image states
  let mainTitle = "I'm Hinata... Listening to you...";
  let subText = "Tap mic or say \"Hey Hinata\"...";

  if (isWakeDetected) {
    mainTitle = '✦ Wake Word Heard! ("Hey Hinata")';
    subText = 'Yes, how can I help? Speak your command now...';
  } else if (lastTranscript && lastTranscript.trim().length > 0) {
    if (transcriptRole === 'user') {
      mainTitle = `You: “${lastTranscript}”`;
      subText = "Hinata is processing your request...";
    } else {
      mainTitle = `Hinata: “${lastTranscript}”`;
      subText = "Speaking in real-time...";
    }
  } else if (wakeState === 'WAKE_IDLE' && state === 'disconnected') {
    mainTitle = 'Hands-Free Standby: Say "Hey Hinata"';
    subText = 'Microphone listening locally • Low-battery standby mode';
  } else if (mascotState === 'SCREEN_ANALYZING') {
    mainTitle = 'Analyzing Active Screen...';
    subText = 'Understanding visible UI, layout & text...';
  } else if (mascotState === 'VISION_ANALYZING') {
    mainTitle = 'Analyzing Selected Image...';
    subText = 'Extracting UI structure & design tokens...';
  } else if (isSpeaking) {
    mainTitle = 'Hinata is speaking...';
    subText = 'Explaining visual analysis...';
  } else if (isThinking) {
    mainTitle = 'Hinata is thinking...';
    subText = 'Analyzing your request...';
  } else if (isListening) {
    mainTitle = 'Hinata is listening...';
    subText = 'Speak now... I can see your screen';
  } else if (isScreenSharing) {
    mainTitle = 'SCREEN SHARING ON';
    subText = 'Hinata can see your screen • Ask anything via voice';
  } else if (hasImage) {
    mainTitle = 'Image Attached';
    subText = 'Ask Hinata questions about this image...';
  }

  return (
    <div className="w-full max-w-md mx-auto px-4 z-30 select-none">
      <motion.div
        initial={{ opacity: 0, y: -8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
        className="relative flex items-center justify-between gap-3 px-4 py-2 rounded-2xl bg-[#080d24]/90 backdrop-blur-xl border border-cyan-500/30 shadow-[0_0_25px_rgba(0,229,255,0.18)] overflow-hidden"
      >
        {/* Soft Ambient Inner Glow */}
        <div className="absolute inset-0 bg-gradient-to-r from-cyan-500/10 via-purple-500/10 to-blue-500/10 pointer-events-none" />

        {/* Left Indicator */}
        <div className="relative flex items-center justify-center flex-shrink-0">
          <span
            className={`w-2.5 h-2.5 rounded-full shadow-[0_0_10px_#00e5ff] transition-all duration-300 ${
              isSpeaking
                ? 'bg-[#c084fc] shadow-[0_0_10px_#c084fc] scale-110'
                : isListening
                ? 'bg-[#00e5ff] shadow-[0_0_10px_#00e5ff] scale-110 animate-pulse'
                : isThinking
                ? 'bg-[#eab308] shadow-[0_0_10px_#eab308] animate-spin'
                : 'bg-[#00e5ff] opacity-80'
            }`}
          />
          {isVoiceActive && (
            <span className="absolute w-4 h-4 rounded-full border border-cyan-400/50 animate-ping pointer-events-none" />
          )}
        </div>

        {/* Center Text Info */}
        <div className="flex-1 min-w-0 text-center px-1">
          <div className="flex items-center justify-center gap-1.5 text-[12.5px] font-semibold text-white truncate">
            <span>{mainTitle}</span>
            <Heart className="w-3 h-3 text-pink-400 fill-pink-400 inline flex-shrink-0" />
          </div>
          <p className="text-[10.5px] text-cyan-300/80 truncate mt-0.5">
            {subText}
          </p>
        </div>

        {/* Right Animated Waveform */}
        <div className="flex items-center gap-1 h-4 flex-shrink-0">
          {[0, 1, 2, 3, 4].map((i) => {
            const h = isVoiceActive
              ? Math.max(4, Math.min(18, 5 + Math.sin(Date.now() / 140 + i * 0.9) * 6 + currentVol * 14))
              : i === 2 ? 14 : i === 1 || i === 3 ? 9 : 5;

            return (
              <div
                key={`wave-bar-${i}`}
                className={`w-[2.2px] rounded-full transition-all duration-75 ${
                  isSpeaking ? 'bg-gradient-to-t from-purple-400 to-pink-400 shadow-[0_0_6px_#c084fc]' : 'bg-[#00e5ff] shadow-[0_0_6px_#00e5ff]'
                }`}
                style={{
                  height: `${h}px`,
                }}
              />
            );
          })}
        </div>
      </motion.div>
    </div>
  );
};
