import React, { useState } from 'react';
import {
  Briefcase,
  Plus,
  Search,
  FileCheck,
  Send,
  CheckCircle2,
  AlertTriangle,
  HelpCircle,
  Clock,
  Sparkles,
  ExternalLink,
  ChevronRight,
  ShieldCheck,
  X
} from 'lucide-react';
import { FreelanceManager, MAX_DAILY_OUTREACH } from '../../modules/work/FreelanceManager';
import { FreelanceOpportunity, Proposal, FreelancePipelineStage } from '../../modules/work/types';
import { ApprovalManager } from '../../modules/work/ApprovalManager';

export const FreelancePipelineTab: React.FC = () => {
  const manager = FreelanceManager.getInstance();
  const approvals = ApprovalManager.getInstance();

  const [opportunities, setOpportunities] = useState<FreelanceOpportunity[]>(() => manager.getOpportunities());
  const [proposals, setProposals] = useState<Proposal[]>(() => manager.getProposals());
  const [selectedOpp, setSelectedOpp] = useState<FreelanceOpportunity | null>(null);
  const [selectedProposal, setSelectedProposal] = useState<Proposal | null>(null);
  const [activeSubTab, setActiveSubTab] = useState<'opportunities' | 'proposals' | 'outreach'>('opportunities');

  // New Opportunity Modal
  const [isNewOppModalOpen, setIsNewOppModalOpen] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newCompany, setNewCompany] = useState('');
  const [newSource, setNewSource] = useState('Upwork');
  const [newSkills, setNewSkills] = useState('');
  const [newSummary, setNewSummary] = useState('');
  const [newBudget, setNewBudget] = useState('');

  // Outreach form
  const [outreachName, setOutreachName] = useState('');
  const [outreachHandle, setOutreachHandle] = useState('');
  const [outreachReason, setOutreachReason] = useState('');
  const [outreachFeedback, setOutreachFeedback] = useState<{ msg: string; ok: boolean } | null>(null);

  const refreshData = () => {
    setOpportunities(manager.getOpportunities());
    setProposals(manager.getProposals());
  };

  const handleCreateOpp = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim() || !newCompany.trim()) return;

    const skillsArr = newSkills.split(',').map((s) => s.trim()).filter(Boolean);
    const created = manager.createOpportunity({
      title: newTitle.trim(),
      clientOrCompany: newCompany.trim(),
      source: newSource,
      requiredSkills: skillsArr.length > 0 ? skillsArr : ['Full-Stack', 'TypeScript'],
      projectSummary: newSummary.trim() || 'Custom client project requirements.',
      apparentRequirements: ['Coordinate delivery milestones', 'Deliver responsive code'],
      budgetPublic: newBudget.trim() || undefined,
    });

    setIsNewOppModalOpen(false);
    setNewTitle('');
    setNewCompany('');
    setNewSkills('');
    setNewSummary('');
    setNewBudget('');
    refreshData();
    setSelectedOpp(created);
  };

  const handleGenerateProposal = (oppId: string) => {
    const prop = manager.generateProposal(oppId);
    refreshData();
    if (prop) {
      setSelectedProposal(prop);
      setActiveSubTab('proposals');
    }
  };

  const handleStageChange = (id: string, newStage: FreelancePipelineStage) => {
    manager.updateOpportunityStage(id, newStage);
    refreshData();
  };

  const handleSendOutreach = (e: React.FormEvent) => {
    e.preventDefault();
    if (!outreachName || !outreachHandle) return;

    const res = manager.prepareOutreach({
      recipientName: outreachName,
      recipientHandleOrEmail: outreachHandle,
      platform: 'email',
      reasonForContact: outreachReason || 'Product engineering expansion',
    });

    if (res.success && res.outreach) {
      approvals.requestApproval({
        actionType: 'send_outreach',
        title: `Cold Outreach: ${outreachName}`,
        description: `Outreach to ${outreachHandle} regarding ${outreachReason}`,
        recipientOrTarget: outreachHandle,
        previewContent: res.outreach.personalizedDraft,
      });

      setOutreachFeedback({
        ok: true,
        msg: `${res.message} Added to Approvals queue.`,
      });
      setOutreachName('');
      setOutreachHandle('');
      setOutreachReason('');
    } else {
      setOutreachFeedback({
        ok: false,
        msg: res.message,
      });
    }
  };

  return (
    <div className="space-y-5">
      {/* Sub-navigation bar */}
      <div className="flex items-center justify-between gap-2 border-b border-slate-800 pb-3 flex-wrap">
        <div className="flex items-center gap-1.5 p-1 rounded-xl bg-[#09102c] border border-slate-800">
          <button
            onClick={() => setActiveSubTab('opportunities')}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
              activeSubTab === 'opportunities'
                ? 'bg-purple-600/30 text-purple-200 border border-purple-500/40'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Opportunities ({opportunities.length})
          </button>
          <button
            onClick={() => setActiveSubTab('proposals')}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
              activeSubTab === 'proposals'
                ? 'bg-purple-600/30 text-purple-200 border border-purple-500/40'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Proposals ({proposals.length})
          </button>
          <button
            onClick={() => setActiveSubTab('outreach')}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
              activeSubTab === 'outreach'
                ? 'bg-purple-600/30 text-purple-200 border border-purple-500/40'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Direct Outreach
          </button>
        </div>

        {activeSubTab === 'opportunities' && (
          <button
            onClick={() => setIsNewOppModalOpen(true)}
            className="px-3 py-1.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-xs font-medium text-white transition-all flex items-center gap-1.5 shadow-md"
          >
            <Plus className="w-3.5 h-3.5" />
            Add Opportunity
          </button>
        )}
      </div>

      {/* 1. OPPORTUNITIES VIEW */}
      {activeSubTab === 'opportunities' && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {/* List Column */}
          <div className="md:col-span-1 space-y-2.5">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider block mb-1">
              Active Pipeline
            </span>
            {opportunities.map((opp) => (
              <div
                key={opp.id}
                onClick={() => setSelectedOpp(opp)}
                className={`p-3.5 rounded-xl cursor-pointer border transition-all ${
                  selectedOpp?.id === opp.id
                    ? 'bg-[#10193d] border-purple-400/60 shadow-[0_0_15px_rgba(168,85,247,0.2)]'
                    : 'bg-[#090f28]/80 border-slate-800 hover:border-slate-700'
                }`}
              >
                <div className="flex items-start justify-between gap-2">
                  <h4 className="text-xs font-semibold text-white leading-tight">{opp.title}</h4>
                  <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-purple-500/20 text-purple-300 flex-shrink-0">
                    {opp.matchScore}%
                  </span>
                </div>
                <div className="mt-1.5 flex items-center justify-between text-[11px] text-slate-400">
                  <span>{opp.clientOrCompany}</span>
                  <span className="text-purple-300 font-medium">{opp.stage}</span>
                </div>
                {opp.budgetPublic && (
                  <p className="mt-1 text-[10px] text-slate-500">{opp.budgetPublic}</p>
                )}
              </div>
            ))}
          </div>

          {/* Details & Match Inspector Column */}
          <div className="md:col-span-2">
            {selectedOpp ? (
              <div className="p-5 rounded-2xl bg-[#09102c] border border-slate-800 space-y-4">
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 font-mono">
                        Source: {selectedOpp.source}
                      </span>
                      <span className="text-xs text-purple-300 font-semibold">{selectedOpp.budgetPublic}</span>
                    </div>
                    <h3 className="text-base font-bold text-white mt-1.5">{selectedOpp.title}</h3>
                    <p className="text-xs text-slate-300 mt-0.5">{selectedOpp.clientOrCompany}</p>
                  </div>

                  <button
                    onClick={() => handleGenerateProposal(selectedOpp.id)}
                    className="px-3 py-1.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-xs font-medium text-white transition-all flex items-center gap-1.5 shadow-lg flex-shrink-0"
                  >
                    <Sparkles className="w-3.5 h-3.5" />
                    Draft Proposal
                  </button>
                </div>

                {/* Pipeline Stage Controller */}
                <div className="p-3 rounded-xl bg-[#070c22] border border-slate-800 flex items-center justify-between gap-2">
                  <span className="text-xs text-slate-400">Current Stage:</span>
                  <select
                    value={selectedOpp.stage}
                    onChange={(e) => handleStageChange(selectedOpp.id, e.target.value as FreelancePipelineStage)}
                    className="bg-[#0b1335] text-xs text-purple-200 border border-purple-500/30 rounded-lg px-2.5 py-1 focus:outline-none"
                  >
                    <option value="LEAD">LEAD</option>
                    <option value="RESEARCH">RESEARCH</option>
                    <option value="QUALIFIED">QUALIFIED</option>
                    <option value="DRAFT_PROPOSAL">DRAFT_PROPOSAL</option>
                    <option value="USER_REVIEW">USER_REVIEW</option>
                    <option value="SUBMITTED">SUBMITTED</option>
                    <option value="PROJECT">PROJECT (WON)</option>
                    <option value="COMPLETED">COMPLETED</option>
                  </select>
                </div>

                {/* Match Analysis */}
                <div className="space-y-2">
                  <span className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                    Match Reasons:
                  </span>
                  <ul className="list-disc list-inside text-xs text-slate-300 space-y-1">
                    {selectedOpp.matchReasons.map((r, i) => (
                      <li key={i}>{r}</li>
                    ))}
                  </ul>
                </div>

                {/* Questions to check */}
                {selectedOpp.questionsToCheck.length > 0 && (
                  <div className="p-3 rounded-xl bg-[#060a1d] border border-slate-800 space-y-1.5">
                    <span className="text-xs font-semibold text-amber-400 flex items-center gap-1.5">
                      <HelpCircle className="w-3.5 h-3.5" />
                      Clarification Questions to Ask Client:
                    </span>
                    <ul className="text-xs text-slate-400 space-y-1 pl-4 list-disc">
                      {selectedOpp.questionsToCheck.map((q, i) => (
                        <li key={i}>{q}</li>
                      ))}
                    </ul>
                  </div>
                )}

                <div className="text-xs text-slate-400 border-t border-slate-800 pt-3">
                  <p className="font-semibold text-slate-300 mb-1">Project Summary:</p>
                  <p>{selectedOpp.projectSummary}</p>
                </div>
              </div>
            ) : (
              <div className="p-8 rounded-2xl bg-[#09102c]/50 border border-dashed border-slate-800 text-center text-xs text-slate-400">
                Select an opportunity from the left or click "Add Opportunity" to evaluate.
              </div>
            )}
          </div>
        </div>
      )}

      {/* 2. PROPOSALS VIEW */}
      {activeSubTab === 'proposals' && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="md:col-span-1 space-y-2">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider block mb-1">
              Draft & Submitted Proposals
            </span>
            {proposals.length === 0 ? (
              <p className="text-xs text-slate-500 py-3">No proposals drafted yet.</p>
            ) : (
              proposals.map((prop) => (
                <div
                  key={prop.id}
                  onClick={() => setSelectedProposal(prop)}
                  className={`p-3 rounded-xl cursor-pointer border transition-all ${
                    selectedProposal?.id === prop.id
                      ? 'bg-[#10193d] border-purple-400/60'
                      : 'bg-[#090f28]/80 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <h4 className="text-xs font-semibold text-white">{prop.title}</h4>
                  <div className="mt-1 flex items-center justify-between text-[11px] text-slate-400">
                    <span>{prop.clientName}</span>
                    <span className="text-purple-300 font-mono">{prop.status}</span>
                  </div>
                </div>
              ))
            )}
          </div>

          <div className="md:col-span-2">
            {selectedProposal ? (
              <div className="p-5 rounded-2xl bg-[#09102c] border border-slate-800 space-y-4 text-xs">
                <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                  <div>
                    <h3 className="text-sm font-bold text-white">{selectedProposal.title}</h3>
                    <span className="text-slate-400">Client: {selectedProposal.clientName}</span>
                  </div>
                  <button
                    onClick={() => {
                      navigator.clipboard.writeText(
                        `${selectedProposal.personalizedOpening}\n\n${selectedProposal.projectUnderstanding}\n\n${selectedProposal.proposedApproach}\n\n${selectedProposal.conciseClosing}`
                      );
                      alert('Proposal copied to clipboard!');
                    }}
                    className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-medium flex items-center gap-1.5"
                  >
                    Copy Proposal
                  </button>
                </div>

                <div className="space-y-3 text-slate-200">
                  <div>
                    <span className="font-semibold text-purple-300 block mb-1">Personalized Opening:</span>
                    <p className="bg-[#060a1d] p-3 rounded-xl border border-slate-800 whitespace-pre-line font-mono text-[11px]">
                      {selectedProposal.personalizedOpening}
                    </p>
                  </div>

                  <div>
                    <span className="font-semibold text-purple-300 block mb-1">Project Understanding:</span>
                    <p className="bg-[#060a1d] p-3 rounded-xl border border-slate-800 whitespace-pre-line">
                      {selectedProposal.projectUnderstanding}
                    </p>
                  </div>

                  <div>
                    <span className="font-semibold text-purple-300 block mb-1">Proposed Approach:</span>
                    <p className="bg-[#060a1d] p-3 rounded-xl border border-slate-800 whitespace-pre-line">
                      {selectedProposal.proposedApproach}
                    </p>
                  </div>

                  <div>
                    <span className="font-semibold text-purple-300 block mb-1">Closing:</span>
                    <p className="bg-[#060a1d] p-3 rounded-xl border border-slate-800 whitespace-pre-line font-mono text-[11px]">
                      {selectedProposal.conciseClosing}
                    </p>
                  </div>
                </div>
              </div>
            ) : (
              <div className="p-8 rounded-2xl bg-[#09102c]/50 border border-dashed border-slate-800 text-center text-xs text-slate-400">
                Select a proposal to view full approach and copy text.
              </div>
            )}
          </div>
        </div>
      )}

      {/* 3. DIRECT OUTREACH VIEW */}
      {activeSubTab === 'outreach' && (
        <div className="max-w-2xl mx-auto p-5 rounded-2xl bg-[#09102c] border border-slate-800 space-y-4 text-xs">
          <div className="border-b border-slate-800 pb-3">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Send className="w-4 h-4 text-purple-400" />
                Personalized Client Outreach
              </h3>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 border border-slate-700">
                Limit: {MAX_DAILY_OUTREACH} messages / day
              </span>
            </div>
            <p className="text-slate-400 text-[11px] mt-1">
              Enforces human approval gates and respectful communication frequencies to prevent spam.
            </p>
          </div>

          {outreachFeedback && (
            <div
              className={`p-3 rounded-xl text-xs flex items-center gap-2 ${
                outreachFeedback.ok
                  ? 'bg-emerald-950/50 border border-emerald-500/40 text-emerald-200'
                  : 'bg-rose-950/50 border border-rose-500/40 text-rose-200'
              }`}
            >
              {outreachFeedback.ok ? <CheckCircle2 className="w-4 h-4" /> : <AlertTriangle className="w-4 h-4" />}
              <span>{outreachFeedback.msg}</span>
            </div>
          )}

          <form onSubmit={handleSendOutreach} className="space-y-3">
            <div>
              <label className="block text-slate-300 font-medium mb-1">Recipient Name</label>
              <input
                type="text"
                placeholder="e.g. Alex Rivera"
                value={outreachName}
                onChange={(e) => setOutreachName(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-[#060a1d] border border-slate-700 text-white focus:outline-none focus:border-purple-400"
                required
              />
            </div>

            <div>
              <label className="block text-slate-300 font-medium mb-1">Email or Handle</label>
              <input
                type="text"
                placeholder="e.g. alex@company.com or linkedin.com/in/alex"
                value={outreachHandle}
                onChange={(e) => setOutreachHandle(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-[#060a1d] border border-slate-700 text-white focus:outline-none focus:border-purple-400"
                required
              />
            </div>

            <div>
              <label className="block text-slate-300 font-medium mb-1">Context / Reason for Contact</label>
              <input
                type="text"
                placeholder="e.g. Scaling real-time streaming architectures"
                value={outreachReason}
                onChange={(e) => setOutreachReason(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-[#060a1d] border border-slate-700 text-white focus:outline-none focus:border-purple-400"
              />
            </div>

            <button
              type="submit"
              className="w-full py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 font-semibold text-white transition-all shadow-md mt-2 flex items-center justify-center gap-2"
            >
              <ShieldCheck className="w-4 h-4" />
              Prepare & Submit for Approval
            </button>
          </form>
        </div>
      )}

      {/* MODAL: ADD OPPORTUNITY */}
      {isNewOppModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-lg p-5 rounded-2xl bg-[#0a1130] border border-purple-500/40 shadow-2xl space-y-4 text-xs">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-sm font-bold text-white">Add Freelance Opportunity</h3>
              <button
                onClick={() => setIsNewOppModalOpen(false)}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreateOpp} className="space-y-3">
              <div>
                <label className="block text-slate-300 mb-1">Opportunity / Project Title</label>
                <input
                  type="text"
                  placeholder="e.g. React & Node AI System MVP"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-[#060a1d] border border-slate-700 text-white"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-slate-300 mb-1">Client / Company</label>
                  <input
                    type="text"
                    placeholder="e.g. NextGen Labs"
                    value={newCompany}
                    onChange={(e) => setNewCompany(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-[#060a1d] border border-slate-700 text-white"
                    required
                  />
                </div>
                <div>
                  <label className="block text-slate-300 mb-1">Source</label>
                  <input
                    type="text"
                    placeholder="e.g. Upwork, Referral"
                    value={newSource}
                    onChange={(e) => setNewSource(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-[#060a1d] border border-slate-700 text-white"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-300 mb-1">Required Skills (comma-separated)</label>
                <input
                  type="text"
                  placeholder="React, TypeScript, Node.js, AI"
                  value={newSkills}
                  onChange={(e) => setNewSkills(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-[#060a1d] border border-slate-700 text-white"
                />
              </div>

              <div>
                <label className="block text-slate-300 mb-1">Budget / Rate</label>
                <input
                  type="text"
                  placeholder="e.g. $4,000 Milestone or $85/hr"
                  value={newBudget}
                  onChange={(e) => setNewBudget(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-[#060a1d] border border-slate-700 text-white"
                />
              </div>

              <div>
                <label className="block text-slate-300 mb-1">Requirements / Summary</label>
                <textarea
                  rows={3}
                  placeholder="Paste client requirements or key milestones here..."
                  value={newSummary}
                  onChange={(e) => setNewSummary(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-[#060a1d] border border-slate-700 text-white"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsNewOppModalOpen(false)}
                  className="px-3 py-1.5 rounded-xl text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-xl bg-purple-600 hover:bg-purple-500 font-semibold text-white"
                >
                  Save & Evaluate
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
