import React, { useState } from 'react';
import {
  Share2,
  Calendar,
  Sparkles,
  Copy,
  Check,
  TrendingUp,
  Lightbulb,
  ExternalLink,
  Layers,
  FileText
} from 'lucide-react';
import { LinkedInContentManager } from '../../modules/work/LinkedInContentManager';
import { IntegrationManager } from '../../modules/work/IntegrationManager';
import { LinkedInContentType, LinkedInPost, ContentScheduleItem, BrandAnalysis } from '../../modules/work/types';

export const LinkedInContentTab: React.FC = () => {
  const contentMgr = LinkedInContentManager.getInstance();
  const intMgr = IntegrationManager.getInstance();

  const [posts, setPosts] = useState<LinkedInPost[]>(() => contentMgr.getPosts());
  const [schedule, setSchedule] = useState<ContentScheduleItem[]>(() => contentMgr.getSchedule());
  const [brandAnalysis, setBrandAnalysis] = useState<BrandAnalysis>(() => contentMgr.analyzePersonalBrand());
  const [selectedType, setSelectedType] = useState<LinkedInContentType>('educational');
  const [customTopic, setCustomTopic] = useState('');
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [activeView, setActiveView] = useState<'posts' | 'calendar' | 'brand'>('posts');

  const isLinkedInConnected = intMgr.isConnected('linkedin');

  const contentTypes: Array<{ type: LinkedInContentType; label: string; desc: string }> = [
    { type: 'educational', label: '1. Educational', desc: 'Actionable mental model or tutorial' },
    { type: 'project_showcase', label: '2. Project Showcase', desc: 'Real architecture and outcomes' },
    { type: 'case_study', label: '3. Case Study', desc: 'Problem -> Approach -> Result breakdown' },
    { type: 'behind_the_scenes', label: '4. Behind the Scenes', desc: 'Daily workflow and engineering habits' },
    { type: 'learning_update', label: '5. Learning Update', desc: 'Fresh insights from recent experiments' },
    { type: 'freelancing_insight', label: '6. Freelancing Insight', desc: 'Client communication and scoping lessons' },
    { type: 'technical_explanation', label: '7. Technical Deep Dive', desc: 'Browser standards, audio, or perf' },
    { type: 'portfolio_showcase', label: '8. Portfolio Showcase', desc: 'Interactive highlights and live demos' },
    { type: 'question_discussion', label: '9. Question / Discussion', desc: 'Engage peer developers in tech debate' },
    { type: 'milestone', label: '10. Milestone', desc: 'Delivered release or career celebration' },
  ];

  const handleGenerate = () => {
    const post = contentMgr.generatePostDraft(selectedType, customTopic.trim() || undefined);
    setPosts(contentMgr.getPosts());
    setCustomTopic('');
  };

  const handleCopyPost = (post: LinkedInPost) => {
    const fullText = `${post.hook}\n\n${post.content}\n\n${post.cta}\n\n${post.hashtags.join(' ')}`;
    navigator.clipboard.writeText(fullText);
    setCopiedId(post.id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleRefreshPlan = () => {
    const newPlan = contentMgr.generateWeeklyPlan();
    setSchedule(newPlan);
  };

  return (
    <div className="space-y-5">
      {/* Integration Notice */}
      {!isLinkedInConnected && (
        <div className="p-3.5 rounded-xl bg-slate-900/90 border border-cyan-500/30 text-xs flex items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <Share2 className="w-4 h-4 text-cyan-400 flex-shrink-0" />
            <span className="text-slate-300">
              <strong className="text-cyan-300">Draft & Publish Mode Active:</strong> All 10 content formats generate publication-ready drafts for one-click copy. Connect official LinkedIn in Integrations for automated schedule sync.
            </span>
          </div>
        </div>
      )}

      {/* Navigation sub-tabs */}
      <div className="flex items-center justify-between border-b border-slate-800 pb-3 flex-wrap gap-2">
        <div className="flex items-center gap-1.5 p-1 rounded-xl bg-[#09102c] border border-slate-800">
          <button
            onClick={() => setActiveView('posts')}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
              activeView === 'posts'
                ? 'bg-cyan-600/30 text-cyan-200 border border-cyan-500/40'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Post Generator & Drafts ({posts.length})
          </button>
          <button
            onClick={() => setActiveView('calendar')}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
              activeView === 'calendar'
                ? 'bg-cyan-600/30 text-cyan-200 border border-cyan-500/40'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Weekly Content Plan ({schedule.length})
          </button>
          <button
            onClick={() => setActiveView('brand')}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
              activeView === 'brand'
                ? 'bg-cyan-600/30 text-cyan-200 border border-cyan-500/40'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Brand Intelligence
          </button>
        </div>

        {activeView === 'calendar' && (
          <button
            onClick={handleRefreshPlan}
            className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-medium text-slate-200 transition-all flex items-center gap-1.5"
          >
            <Calendar className="w-3.5 h-3.5 text-cyan-400" />
            Regenerate Weekly Schedule
          </button>
        )}
      </div>

      {/* VIEW 1: GENERATOR & POSTS */}
      {activeView === 'posts' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
          {/* Generator Controls */}
          <div className="lg:col-span-1 p-4 rounded-2xl bg-[#09102c] border border-slate-800 space-y-4 text-xs">
            <span className="font-semibold text-white block">1. Select Post Category (10 Formats)</span>
            <div className="grid grid-cols-1 gap-1.5 max-h-56 overflow-y-auto pr-1">
              {contentTypes.map((item) => (
                <button
                  key={item.type}
                  onClick={() => setSelectedType(item.type)}
                  className={`text-left p-2 rounded-xl border transition-all ${
                    selectedType === item.type
                      ? 'bg-cyan-950/70 border-cyan-400/70 text-cyan-200'
                      : 'bg-[#060a1d] border-slate-800 text-slate-300 hover:border-slate-700'
                  }`}
                >
                  <p className="font-bold text-[11px]">{item.label}</p>
                  <p className="text-[10px] text-slate-400 leading-tight mt-0.5">{item.desc}</p>
                </button>
              ))}
            </div>

            <div>
              <label className="block text-slate-300 font-medium mb-1">Custom Topic or Specific Project (Optional)</label>
              <input
                type="text"
                placeholder="e.g. Real-time audio streaming architecture"
                value={customTopic}
                onChange={(e) => setCustomTopic(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-[#060a1d] border border-slate-700 text-white text-xs"
              />
            </div>

            <button
              onClick={handleGenerate}
              className="w-full py-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 font-semibold text-white transition-all shadow-lg flex items-center justify-center gap-2"
            >
              <Sparkles className="w-4 h-4" />
              Generate Grounded Post Draft
            </button>
          </div>

          {/* Posts List */}
          <div className="lg:col-span-2 space-y-4">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider block">
              Generated Drafts ({posts.length})
            </span>
            {posts.map((post) => (
              <div
                key={post.id}
                className="p-5 rounded-2xl bg-[#09102c] border border-slate-800 space-y-3 text-xs"
              >
                <div className="flex items-center justify-between border-b border-slate-800 pb-2.5">
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-cyan-500/20 text-cyan-300 uppercase">
                      {post.contentType.replace('_', ' ')}
                    </span>
                    <span className="text-slate-400 text-[11px]">{post.topic}</span>
                  </div>

                  <button
                    onClick={() => handleCopyPost(post)}
                    className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-[11px] font-medium transition-all flex items-center gap-1.5"
                  >
                    {copiedId === post.id ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                        <span className="text-emerald-400">Copied!</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5 text-cyan-400" />
                        <span>Copy Post</span>
                      </>
                    )}
                  </button>
                </div>

                <div className="p-3.5 rounded-xl bg-[#060a1d] border border-slate-800/80 space-y-2 whitespace-pre-line text-slate-200 font-sans text-xs leading-relaxed">
                  <p className="font-bold text-white text-[13px]">{post.hook}</p>
                  <p>{post.content.replace(post.hook, '').trim()}</p>
                  <p className="text-cyan-300 font-semibold pt-1">{post.cta}</p>
                  <p className="text-slate-500 text-[11px]">{post.hashtags.join(' ')}</p>
                </div>

                {/* Visual Concept Card */}
                <div className="p-2.5 rounded-xl bg-[#081133] border border-cyan-500/20 flex items-center gap-2 text-[11px] text-cyan-200">
                  <Lightbulb className="w-4 h-4 text-amber-400 flex-shrink-0" />
                  <span>
                    <strong>Visual Idea:</strong> {post.visualConceptIdea}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* VIEW 2: WEEKLY CALENDAR */}
      {activeView === 'calendar' && (
        <div className="space-y-3">
          <div className="p-4 rounded-2xl bg-[#09102c] border border-slate-800">
            <h3 className="text-sm font-bold text-white mb-1">Adaptive Weekly Content Strategy</h3>
            <p className="text-xs text-slate-400">
              Structured to highlight your actual engineering achievements, architectural lessons, and freelancing milestones.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {schedule.map((item) => (
              <div
                key={item.id}
                className="p-4 rounded-2xl bg-[#09102c] border border-slate-800 space-y-3 text-xs flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                    <span className="font-bold text-white text-sm">{item.dayOfWeek}</span>
                    <span className="text-[10px] px-2 py-0.5 rounded bg-purple-500/20 text-purple-300 font-medium uppercase">
                      {item.contentType.replace('_', ' ')}
                    </span>
                  </div>

                  <div className="mt-2.5 space-y-1.5">
                    <h4 className="font-semibold text-cyan-300 leading-snug">{item.topic}</h4>
                    <p className="text-[11px] text-slate-300 italic">"{item.hook}"</p>
                    <p className="text-[11px] text-slate-400">{item.mainIdea}</p>
                  </div>
                </div>

                <div className="pt-2 border-t border-slate-800/80 text-[11px] text-slate-400 flex items-center justify-between">
                  <span className="capitalize text-slate-500">Status: {item.status}</span>
                  <button
                    onClick={() => {
                      navigator.clipboard.writeText(`${item.hook}\n\n${item.draft}\n\n${item.cta}`);
                      alert('Draft copied to clipboard!');
                    }}
                    className="text-cyan-400 hover:text-cyan-200 font-medium"
                  >
                    Copy Draft
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* VIEW 3: BRAND INTELLIGENCE */}
      {activeView === 'brand' && (
        <div className="max-w-3xl mx-auto p-5 rounded-2xl bg-[#09102c] border border-slate-800 space-y-5 text-xs">
          <div className="flex items-start justify-between border-b border-slate-800 pb-3">
            <div>
              <h3 className="text-sm font-bold text-white">Personal Brand Positioning</h3>
              <p className="text-slate-400 mt-0.5">{brandAnalysis.positioningSummary}</p>
            </div>
            <div className="text-right">
              <span className="text-2xl font-black text-cyan-400">{brandAnalysis.consistencyScore}</span>
              <span className="text-[10px] text-slate-400 block">Consistency Score</span>
            </div>
          </div>

          <div className="grid sm:grid-cols-2 gap-4">
            <div className="p-3.5 rounded-xl bg-[#060a1d] border border-slate-800 space-y-2">
              <span className="font-semibold text-emerald-400 block">Confirmed Core Strengths:</span>
              <ul className="list-disc list-inside text-slate-300 space-y-1">
                {brandAnalysis.confirmedStrengths.map((s, i) => (
                  <li key={i}>{s}</li>
                ))}
              </ul>
            </div>

            <div className="p-3.5 rounded-xl bg-[#060a1d] border border-slate-800 space-y-2">
              <span className="font-semibold text-amber-400 block">Identified Portfolio Gaps:</span>
              {brandAnalysis.portfolioGaps.length === 0 ? (
                <p className="text-slate-400">No major gaps identified. Strong profile baseline.</p>
              ) : (
                <ul className="list-disc list-inside text-slate-300 space-y-1">
                  {brandAnalysis.portfolioGaps.map((g, i) => (
                    <li key={i}>{g}</li>
                  ))}
                </ul>
              )}
            </div>
          </div>

          <div className="p-3.5 rounded-xl bg-[#060a1d] border border-slate-800 space-y-2">
            <span className="font-semibold text-cyan-400 block">Recommended Upcoming High-Leverage Topics:</span>
            <ul className="list-disc list-inside text-slate-300 space-y-1">
              {brandAnalysis.recommendedNextTopics.map((t, i) => (
                <li key={i}>{t}</li>
              ))}
            </ul>
          </div>
        </div>
      )}
    </div>
  );
};
