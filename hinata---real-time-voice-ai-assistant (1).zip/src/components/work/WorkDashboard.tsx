import React, { useState } from 'react';
import {
  LayoutDashboard,
  Briefcase,
  Share2,
  Mail,
  FolderGit2,
  ShieldCheck,
  User,
  Sparkles,
  Search,
  ArrowRight,
  CheckCircle2,
  Send
} from 'lucide-react';
import { WorkOverviewTab } from './WorkOverviewTab';
import { FreelancePipelineTab } from './FreelancePipelineTab';
import { LinkedInContentTab } from './LinkedInContentTab';
import { EmailOutreachTab } from './EmailOutreachTab';
import { PortfolioCaseStudyTab } from './PortfolioCaseStudyTab';
import { ApprovalActivityTab } from './ApprovalActivityTab';
import { WorkProfileIntegrationsTab } from './WorkProfileIntegrationsTab';
import { WorkIntelligenceCoordinator } from '../../modules/work/WorkIntelligenceCoordinator';

export type WorkTab = 'overview' | 'freelance' | 'linkedin' | 'email' | 'portfolio' | 'approvals' | 'profile';

interface WorkDashboardProps {
  initialTab?: WorkTab;
  onOpenChat?: () => void;
}

export const WorkDashboard: React.FC<WorkDashboardProps> = ({ initialTab = 'overview', onOpenChat }) => {
  const [activeTab, setActiveTab] = useState<WorkTab>(initialTab);
  const [quickPrompt, setQuickPrompt] = useState('');
  const [promptResult, setPromptResult] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);

  const coordinator = WorkIntelligenceCoordinator.getInstance();
  const pendingApprovalsCount = coordinator.approvals.getPendingRequests().length;

  const handleRunCommand = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!quickPrompt.trim() || isProcessing) return;

    setIsProcessing(true);
    setPromptResult(null);

    try {
      const res = await coordinator.handleNaturalWorkCommand(quickPrompt.trim());
      setPromptResult(res.response);
      setQuickPrompt('');
    } catch (err: any) {
      setPromptResult(`Error executing work command: ${err.message}`);
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="w-full h-full flex flex-col overflow-y-auto px-4 py-3 max-w-6xl mx-auto space-y-4">
      {/* 1. TOP HEADER & QUICK COMMAND AGENT BAR */}
      <div className="p-4 rounded-2xl bg-[#080d26]/90 border border-slate-800 shadow-xl space-y-3">
        <div className="flex items-center justify-between flex-wrap gap-2">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-cyan-500 to-purple-600 flex items-center justify-center shadow-[0_0_15px_rgba(0,229,255,0.4)]">
              <Sparkles className="w-4 h-4 text-white" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-white tracking-tight flex items-center gap-2">
                Work Intelligence Hub
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 font-mono">
                  100x Personal Agent
                </span>
              </h2>
              <p className="text-[11px] text-slate-400">
                Email • LinkedIn • Freelancing • Proposals • Portfolio Case Studies
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {pendingApprovalsCount > 0 && (
              <button
                onClick={() => setActiveTab('approvals')}
                className="px-2.5 py-1 rounded-lg bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-xs font-semibold flex items-center gap-1.5 animate-pulse"
              >
                <ShieldCheck className="w-3.5 h-3.5" />
                {pendingApprovalsCount} Approval{pendingApprovalsCount > 1 ? 's' : ''} Pending
              </button>
            )}
          </div>
        </div>

        {/* Natural Language Work Prompt Command Bar */}
        <form onSubmit={handleRunCommand} className="relative flex items-center">
          <input
            type="text"
            placeholder="Ask Hinata: 'Plan my day', 'Draft proposal for client', 'Plan LinkedIn post', 'Check follow-ups'..."
            value={quickPrompt}
            onChange={(e) => setQuickPrompt(e.target.value)}
            disabled={isProcessing}
            className="w-full pl-9 pr-24 py-2 rounded-xl bg-[#050818] border border-cyan-500/30 focus:border-cyan-400 text-xs text-white placeholder-slate-500 focus:outline-none shadow-inner"
          />
          <Search className="w-4 h-4 text-slate-400 absolute left-3 pointer-events-none" />
          <button
            type="submit"
            disabled={!quickPrompt.trim() || isProcessing}
            className="absolute right-1.5 px-3 py-1 rounded-lg bg-cyan-600 hover:bg-cyan-500 disabled:opacity-40 text-[11px] font-semibold text-white transition-all flex items-center gap-1"
          >
            <Send className="w-3 h-3" />
            {isProcessing ? 'Thinking...' : 'Instruct'}
          </button>
        </form>

        {/* Command Response Callout */}
        {promptResult && (
          <div className="p-3 rounded-xl bg-[#060a1d] border border-cyan-500/40 text-xs space-y-1">
            <div className="flex items-center justify-between text-[11px] font-semibold text-cyan-300">
              <span className="flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5" /> Hinata Response:
              </span>
              <button
                onClick={() => setPromptResult(null)}
                className="text-slate-500 hover:text-white"
              >
                ✕
              </button>
            </div>
            <p className="text-slate-200 whitespace-pre-line leading-relaxed font-sans">{promptResult}</p>
          </div>
        )}
      </div>

      {/* 2. PRIMARY TAB SELECTOR */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs select-none">
        <button
          onClick={() => setActiveTab('overview')}
          className={`px-3.5 py-2 rounded-xl font-medium flex items-center gap-2 whitespace-nowrap transition-all ${
            activeTab === 'overview'
              ? 'bg-cyan-600/30 text-cyan-300 border border-cyan-400/50 shadow-[0_0_12px_rgba(0,229,255,0.15)]'
              : 'text-slate-400 hover:text-white bg-[#080d26]/80 border border-slate-800'
          }`}
        >
          <LayoutDashboard className="w-4 h-4" />
          Overview & Brief
        </button>

        <button
          onClick={() => setActiveTab('freelance')}
          className={`px-3.5 py-2 rounded-xl font-medium flex items-center gap-2 whitespace-nowrap transition-all ${
            activeTab === 'freelance'
              ? 'bg-purple-600/30 text-purple-300 border border-purple-400/50 shadow-[0_0_12px_rgba(168,85,247,0.15)]'
              : 'text-slate-400 hover:text-white bg-[#080d26]/80 border border-slate-800'
          }`}
        >
          <Briefcase className="w-4 h-4" />
          Freelance Pipeline
        </button>

        <button
          onClick={() => setActiveTab('linkedin')}
          className={`px-3.5 py-2 rounded-xl font-medium flex items-center gap-2 whitespace-nowrap transition-all ${
            activeTab === 'linkedin'
              ? 'bg-cyan-600/30 text-cyan-300 border border-cyan-400/50 shadow-[0_0_12px_rgba(0,229,255,0.15)]'
              : 'text-slate-400 hover:text-white bg-[#080d26]/80 border border-slate-800'
          }`}
        >
          <Share2 className="w-4 h-4" />
          LinkedIn Studio
        </button>

        <button
          onClick={() => setActiveTab('email')}
          className={`px-3.5 py-2 rounded-xl font-medium flex items-center gap-2 whitespace-nowrap transition-all ${
            activeTab === 'email'
              ? 'bg-cyan-600/30 text-cyan-300 border border-cyan-400/50 shadow-[0_0_12px_rgba(0,229,255,0.15)]'
              : 'text-slate-400 hover:text-white bg-[#080d26]/80 border border-slate-800'
          }`}
        >
          <Mail className="w-4 h-4" />
          Email Triage & Follow-Ups
        </button>

        <button
          onClick={() => setActiveTab('portfolio')}
          className={`px-3.5 py-2 rounded-xl font-medium flex items-center gap-2 whitespace-nowrap transition-all ${
            activeTab === 'portfolio'
              ? 'bg-cyan-600/30 text-cyan-300 border border-cyan-400/50 shadow-[0_0_12px_rgba(0,229,255,0.15)]'
              : 'text-slate-400 hover:text-white bg-[#080d26]/80 border border-slate-800'
          }`}
        >
          <FolderGit2 className="w-4 h-4" />
          Portfolio & Case Studies
        </button>

        <button
          onClick={() => setActiveTab('approvals')}
          className={`px-3.5 py-2 rounded-xl font-medium flex items-center gap-2 whitespace-nowrap transition-all ${
            activeTab === 'approvals'
              ? 'bg-emerald-600/30 text-emerald-300 border border-emerald-400/50 shadow-[0_0_12px_rgba(16,185,129,0.15)]'
              : 'text-slate-400 hover:text-white bg-[#080d26]/80 border border-slate-800'
          }`}
        >
          <ShieldCheck className="w-4 h-4" />
          Approvals & Audit
          {pendingApprovalsCount > 0 && (
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
          )}
        </button>

        <button
          onClick={() => setActiveTab('profile')}
          className={`px-3.5 py-2 rounded-xl font-medium flex items-center gap-2 whitespace-nowrap transition-all ${
            activeTab === 'profile'
              ? 'bg-cyan-600/30 text-cyan-300 border border-cyan-400/50 shadow-[0_0_12px_rgba(0,229,255,0.15)]'
              : 'text-slate-400 hover:text-white bg-[#080d26]/80 border border-slate-800'
          }`}
        >
          <User className="w-4 h-4" />
          Profile & Integrations
        </button>
      </div>

      {/* 3. ACTIVE TAB CONTENT BODY */}
      <div className="flex-1 pb-16">
        {activeTab === 'overview' && (
          <WorkOverviewTab onNavigateTab={(target) => setActiveTab(target)} />
        )}
        {activeTab === 'freelance' && <FreelancePipelineTab />}
        {activeTab === 'linkedin' && <LinkedInContentTab />}
        {activeTab === 'email' && <EmailOutreachTab />}
        {activeTab === 'portfolio' && <PortfolioCaseStudyTab />}
        {activeTab === 'approvals' && <ApprovalActivityTab />}
        {activeTab === 'profile' && <WorkProfileIntegrationsTab />}
      </div>
    </div>
  );
};
