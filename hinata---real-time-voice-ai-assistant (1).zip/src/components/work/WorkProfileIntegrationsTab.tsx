import React, { useState } from 'react';
import {
  User,
  Shield,
  Link,
  CheckCircle2,
  XCircle,
  RefreshCw,
  Plus,
  Trash2,
  Save,
  Globe,
  Github,
  Linkedin,
  Mail,
  Calendar,
  Cloud,
  Check
} from 'lucide-react';
import { WorkProfileManager } from '../../modules/work/WorkProfileManager';
import { IntegrationManager } from '../../modules/work/IntegrationManager';
import { WorkProfile, IntegrationStatus, IntegrationProvider } from '../../modules/work/types';

export const WorkProfileIntegrationsTab: React.FC = () => {
  const profileMgr = WorkProfileManager.getInstance();
  const intMgr = IntegrationManager.getInstance();

  const [profile, setProfile] = useState<WorkProfile>(() => profileMgr.getProfile());
  const [integrations, setIntegrations] = useState<IntegrationStatus[]>(() => intMgr.getAll());
  const [activeSubTab, setActiveSubTab] = useState<'profile' | 'integrations'>('profile');
  const [saveFeedback, setSaveFeedback] = useState(false);

  // Skill & service input buffers
  const [newSkillInput, setNewSkillInput] = useState('');
  const [newServiceInput, setNewServiceInput] = useState('');

  // Connect integration modal
  const [connectingProvider, setConnectingProvider] = useState<IntegrationStatus | null>(null);
  const [accountInput, setAccountInput] = useState('');
  const [testResult, setTestResult] = useState<{ provider: string; ok: boolean; msg: string } | null>(null);

  const refreshData = () => {
    setProfile(profileMgr.getProfile());
    setIntegrations(intMgr.getAll());
  };

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    profileMgr.updateProfile(profile);
    setSaveFeedback(true);
    setTimeout(() => setSaveFeedback(false), 2000);
  };

  const handleAddSkill = () => {
    if (newSkillInput.trim()) {
      profileMgr.addSkill(newSkillInput.trim());
      setNewSkillInput('');
      refreshData();
    }
  };

  const handleRemoveSkill = (skill: string) => {
    profileMgr.removeSkill(skill);
    refreshData();
  };

  const handleAddService = () => {
    if (newServiceInput.trim()) {
      profileMgr.addService(newServiceInput.trim());
      setNewServiceInput('');
      refreshData();
    }
  };

  const handleRemoveService = (service: string) => {
    profileMgr.removeService(service);
    refreshData();
  };

  const handleConnectIntegration = (e: React.FormEvent) => {
    e.preventDefault();
    if (!connectingProvider || !accountInput.trim()) return;

    intMgr.connect(connectingProvider.provider, accountInput.trim());
    setConnectingProvider(null);
    setAccountInput('');
    refreshData();
  };

  const handleDisconnect = (provider: IntegrationProvider) => {
    intMgr.disconnect(provider);
    refreshData();
  };

  const handleTestConnection = async (provider: IntegrationProvider) => {
    const res = await intMgr.testConnection(provider);
    setTestResult({ provider, ok: res.ok, msg: res.message });
    refreshData();
    setTimeout(() => setTestResult(null), 4000);
  };

  return (
    <div className="space-y-5">
      {/* Sub-tab Switcher */}
      <div className="flex items-center justify-between border-b border-slate-800 pb-3 flex-wrap gap-2">
        <div className="flex items-center gap-1.5 p-1 rounded-xl bg-[#09102c] border border-slate-800">
          <button
            onClick={() => setActiveSubTab('profile')}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
              activeSubTab === 'profile'
                ? 'bg-cyan-600/30 text-cyan-200 border border-cyan-500/40'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Professional Work Profile
          </button>
          <button
            onClick={() => setActiveSubTab('integrations')}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
              activeSubTab === 'integrations'
                ? 'bg-cyan-600/30 text-cyan-200 border border-cyan-500/40'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Official Integrations ({integrations.filter((i) => i.status === 'CONNECTED').length} connected)
          </button>
        </div>

        {/* Security Pledge Banner */}
        <div className="flex items-center gap-1.5 text-[11px] text-slate-400">
          <Shield className="w-3.5 h-3.5 text-emerald-400" />
          <span>Zero sensitive credentials stored. Strictly public & authorized metadata.</span>
        </div>
      </div>

      {/* VIEW 1: WORK PROFILE */}
      {activeSubTab === 'profile' && (
        <form onSubmit={handleSaveProfile} className="max-w-3xl mx-auto space-y-4 text-xs">
          <div className="p-5 rounded-2xl bg-[#09102c] border border-slate-800 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div>
                <h3 className="text-sm font-bold text-white">Professional Identity & Work Persona</h3>
                <p className="text-slate-400 mt-0.5">
                  Used by Hinata to ground proposals, draft replies, and calibrate content without hallucinating.
                </p>
              </div>

              <button
                type="submit"
                className="px-4 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-semibold transition-all shadow-md flex items-center gap-1.5"
              >
                {saveFeedback ? <Check className="w-4 h-4 text-emerald-300" /> : <Save className="w-4 h-4" />}
                <span>{saveFeedback ? 'Profile Saved!' : 'Save Changes'}</span>
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-slate-300 font-medium mb-1">Display Name</label>
                <input
                  type="text"
                  value={profile.displayName}
                  onChange={(e) => setProfile({ ...profile, displayName: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-[#060a1d] border border-slate-700 text-white"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">Professional Title</label>
                <input
                  type="text"
                  value={profile.title}
                  onChange={(e) => setProfile({ ...profile, title: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-[#060a1d] border border-slate-700 text-white"
                />
              </div>
            </div>

            <div>
              <label className="block text-slate-300 font-medium mb-1">Professional Bio</label>
              <textarea
                rows={3}
                value={profile.professionalBio}
                onChange={(e) => setProfile({ ...profile, professionalBio: e.target.value })}
                className="w-full px-3 py-2 rounded-xl bg-[#060a1d] border border-slate-700 text-white"
              />
            </div>

            {/* Skills manager */}
            <div>
              <label className="block text-slate-300 font-medium mb-1">Core Skills</label>
              <div className="flex flex-wrap gap-1.5 mb-2">
                {profile.skills.map((skill) => (
                  <span
                    key={skill}
                    className="px-2.5 py-1 rounded-lg bg-[#060a1d] border border-cyan-500/30 text-cyan-200 flex items-center gap-1.5"
                  >
                    {skill}
                    <button
                      type="button"
                      onClick={() => handleRemoveSkill(skill)}
                      className="text-slate-400 hover:text-rose-400"
                    >
                      ×
                    </button>
                  </span>
                ))}
              </div>
              <div className="flex gap-2">
                <input
                  type="text"
                  placeholder="Add skill (e.g. Next.js, Python)..."
                  value={newSkillInput}
                  onChange={(e) => setNewSkillInput(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      handleAddSkill();
                    }
                  }}
                  className="flex-1 px-3 py-1.5 rounded-xl bg-[#060a1d] border border-slate-700 text-white"
                />
                <button
                  type="button"
                  onClick={handleAddSkill}
                  className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white"
                >
                  Add
                </button>
              </div>
            </div>

            {/* Services manager */}
            <div>
              <label className="block text-slate-300 font-medium mb-1">Offered Freelance Services</label>
              <div className="flex flex-wrap gap-1.5 mb-2">
                {profile.services.map((service) => (
                  <span
                    key={service}
                    className="px-2.5 py-1 rounded-lg bg-[#060a1d] border border-purple-500/30 text-purple-200 flex items-center gap-1.5"
                  >
                    {service}
                    <button
                      type="button"
                      onClick={() => handleRemoveService(service)}
                      className="text-slate-400 hover:text-rose-400"
                    >
                      ×
                    </button>
                  </span>
                ))}
              </div>
              <div className="flex gap-2">
                <input
                  type="text"
                  placeholder="Add service (e.g. Mobile App Prototyping)..."
                  value={newServiceInput}
                  onChange={(e) => setNewServiceInput(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      handleAddService();
                    }
                  }}
                  className="flex-1 px-3 py-1.5 rounded-xl bg-[#060a1d] border border-slate-700 text-white"
                />
                <button
                  type="button"
                  onClick={handleAddService}
                  className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white"
                >
                  Add
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-slate-300 font-medium mb-1">Availability</label>
                <select
                  value={profile.availability}
                  onChange={(e) => setProfile({ ...profile, availability: e.target.value as any })}
                  className="w-full px-3 py-2 rounded-xl bg-[#060a1d] border border-slate-700 text-white"
                >
                  <option value="immediate">Immediate (Full availability)</option>
                  <option value="part_time">Part-Time (10-20 hrs/week)</option>
                  <option value="limited">Limited</option>
                  <option value="booked_out">Booked Out</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">Communication Style</label>
                <select
                  value={profile.preferredCommunicationStyle}
                  onChange={(e) => setProfile({ ...profile, preferredCommunicationStyle: e.target.value as any })}
                  className="w-full px-3 py-2 rounded-xl bg-[#060a1d] border border-slate-700 text-white"
                >
                  <option value="professional">Professional</option>
                  <option value="concise">Concise & Direct</option>
                  <option value="consultative">Consultative</option>
                  <option value="friendly">Friendly & Warm</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">Hourly Rate Estimate</label>
                <input
                  type="text"
                  placeholder="e.g. $75 - $120 / hr"
                  value={profile.hourlyRateEstimate || ''}
                  onChange={(e) => setProfile({ ...profile, hourlyRateEstimate: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-[#060a1d] border border-slate-700 text-white"
                />
              </div>
            </div>

            {/* Profile URLs */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-slate-300 font-medium mb-1">Website URL</label>
                <input
                  type="url"
                  placeholder="https://..."
                  value={profile.websiteUrl}
                  onChange={(e) => setProfile({ ...profile, websiteUrl: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-[#060a1d] border border-slate-700 text-white"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">LinkedIn Profile</label>
                <input
                  type="url"
                  placeholder="https://linkedin.com/in/..."
                  value={profile.linkedInUrl}
                  onChange={(e) => setProfile({ ...profile, linkedInUrl: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-[#060a1d] border border-slate-700 text-white"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">GitHub Profile</label>
                <input
                  type="url"
                  placeholder="https://github.com/..."
                  value={profile.gitHubUrl}
                  onChange={(e) => setProfile({ ...profile, gitHubUrl: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-[#060a1d] border border-slate-700 text-white"
                />
              </div>
            </div>
          </div>
        </form>
      )}

      {/* VIEW 2: INTEGRATIONS */}
      {activeSubTab === 'integrations' && (
        <div className="max-w-3xl mx-auto space-y-4 text-xs">
          {testResult && (
            <div
              className={`p-3.5 rounded-xl flex items-center gap-2.5 ${
                testResult.ok
                  ? 'bg-emerald-950/60 border border-emerald-500/40 text-emerald-200'
                  : 'bg-rose-950/60 border border-rose-500/40 text-rose-200'
              }`}
            >
              {testResult.ok ? <CheckCircle2 className="w-4 h-4" /> : <XCircle className="w-4 h-4" />}
              <span>{testResult.msg}</span>
            </div>
          )}

          <div className="grid gap-3">
            {integrations.map((intg) => {
              const isConn = intg.status === 'CONNECTED';
              return (
                <div
                  key={intg.provider}
                  className="p-4 rounded-2xl bg-[#09102c] border border-slate-800 flex items-start justify-between gap-4"
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-white text-sm">{intg.name}</span>
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          isConn
                            ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                            : 'bg-slate-800 text-slate-400'
                        }`}
                      >
                        {intg.status}
                      </span>
                    </div>

                    <p className="text-slate-300 text-[11px]">{intg.description}</p>

                    {isConn && intg.accountIdentifier && (
                      <p className="text-cyan-300 font-mono text-[10px] pt-1">
                        Linked Account: {intg.accountIdentifier}
                      </p>
                    )}

                    <div className="flex flex-wrap gap-1 pt-1.5">
                      {intg.capabilities.map((cap, i) => (
                        <span key={i} className="text-[10px] px-2 py-0.5 rounded bg-[#060a1d] text-slate-400">
                          ✓ {cap}
                        </span>
                      ))}
                    </div>
                  </div>

                  <div className="flex flex-col gap-2 flex-shrink-0">
                    {isConn ? (
                      <>
                        <button
                          onClick={() => handleTestConnection(intg.provider)}
                          className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium flex items-center gap-1.5 transition-all"
                        >
                          <RefreshCw className="w-3.5 h-3.5 text-cyan-400" />
                          Test
                        </button>
                        <button
                          onClick={() => handleDisconnect(intg.provider)}
                          className="px-3 py-1.5 rounded-xl bg-rose-950/40 hover:bg-rose-900/60 border border-rose-500/30 text-rose-300 text-xs font-medium transition-all"
                        >
                          Disconnect
                        </button>
                      </>
                    ) : (
                      <button
                        onClick={() => {
                          setConnectingProvider(intg);
                          setAccountInput('');
                        }}
                        className="px-4 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold shadow-md transition-all"
                      >
                        Connect
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* CONNECT INTEGRATION MODAL */}
      {connectingProvider && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-md p-5 rounded-2xl bg-[#0a1130] border border-cyan-500/40 shadow-2xl space-y-4 text-xs">
            <h3 className="text-sm font-bold text-white">Connect {connectingProvider.name}</h3>
            <p className="text-slate-300">
              Provide your authorized account identifier or email address to enable Hinata's verified capabilities.
            </p>

            <form onSubmit={handleConnectIntegration} className="space-y-3">
              <div>
                <label className="block text-slate-300 font-medium mb-1">
                  Account Identifier / Authorized Email
                </label>
                <input
                  type="text"
                  placeholder="e.g. user@domain.com or github-username"
                  value={accountInput}
                  onChange={(e) => setAccountInput(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-[#060a1d] border border-slate-700 text-white"
                  required
                />
              </div>

              <div className="p-3 rounded-xl bg-[#060a1d] border border-slate-800 text-[11px] text-slate-400">
                Hinata operates with strict honesty: No fake simulated data will be returned. All operations will reflect authorized parameters.
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setConnectingProvider(null)}
                  className="px-3 py-1.5 rounded-xl text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 font-semibold text-white"
                >
                  Confirm & Link
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
