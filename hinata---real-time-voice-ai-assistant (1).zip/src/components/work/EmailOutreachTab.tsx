import React, { useState } from 'react';
import {
  Mail,
  Send,
  Clock,
  CheckCircle2,
  AlertCircle,
  Plus,
  Trash2,
  CornerDownRight,
  ShieldCheck,
  Filter
} from 'lucide-react';
import { EmailIntelligenceManager } from '../../modules/work/EmailIntelligenceManager';
import { FollowUpManager } from '../../modules/work/FollowUpManager';
import { IntegrationManager } from '../../modules/work/IntegrationManager';
import { ApprovalManager } from '../../modules/work/ApprovalManager';
import { EmailItem, EmailDraft, ReplyTone, FollowUpItem } from '../../modules/work/types';

export const EmailOutreachTab: React.FC = () => {
  const emailMgr = EmailIntelligenceManager.getInstance();
  const followUpMgr = FollowUpManager.getInstance();
  const intMgr = IntegrationManager.getInstance();
  const approvals = ApprovalManager.getInstance();

  const [emails, setEmails] = useState<EmailItem[]>(() => emailMgr.getEmails());
  const [drafts, setDrafts] = useState<EmailDraft[]>(() => emailMgr.getDrafts());
  const [followUps, setFollowUps] = useState<FollowUpItem[]>(() => followUpMgr.getAll());
  const [selectedEmail, setSelectedEmail] = useState<EmailItem | null>(null);
  const [selectedDraft, setSelectedDraft] = useState<EmailDraft | null>(null);
  const [filterCategory, setFilterCategory] = useState<string>('ALL');

  // Sample email composer modal
  const [isComposeModalOpen, setIsComposeModalOpen] = useState(false);
  const [sampleSender, setSampleSender] = useState('Sarah Chen');
  const [sampleEmail, setSampleEmail] = useState('sarah.chen@innovate.co');
  const [sampleSubject, setSampleSubject] = useState('Freelance Project Inquiry: AI Dashboard Frontend');
  const [sampleBody, setSampleBody] = useState(
    'Hi, I came across your portfolio. We are building an AI operations dashboard in React and TypeScript and need an engineer to lead the frontend architecture. Are you available for a 3-week engagement? We have a $4,500 milestone budget.'
  );

  const refreshData = () => {
    setEmails(emailMgr.getEmails());
    setDrafts(emailMgr.getDrafts());
    setFollowUps(followUpMgr.getAll());
  };

  const isEmailConnected = intMgr.isConnected('email');

  const filteredEmails = emails.filter((e) => {
    if (filterCategory === 'ALL') return true;
    return e.category === filterCategory;
  });

  const handleSelectEmail = (email: EmailItem) => {
    setSelectedEmail(email);
    emailMgr.markEmailRead(email.id);
    let draft = drafts.find((d) => d.emailId === email.id);
    if (!draft) {
      draft = emailMgr.generateReplyDraft(email.id) || undefined;
      setDrafts(emailMgr.getDrafts());
    }
    setSelectedDraft(draft || null);
  };

  const handleAddSampleEmail = (e: React.FormEvent) => {
    e.preventDefault();
    const created = emailMgr.addEmail({
      sender: { name: sampleSender, email: sampleEmail },
      subject: sampleSubject,
      body: sampleBody,
    });
    setIsComposeModalOpen(false);
    refreshData();
    handleSelectEmail(created);
  };

  const handleSelectTone = (tone: ReplyTone) => {
    if (!selectedDraft) return;
    let newReply = selectedDraft.professionalReply;
    if (tone === 'short') newReply = selectedDraft.shortReply;
    if (tone === 'friendly') newReply = selectedDraft.friendlyReply;

    emailMgr.updateDraftReply(selectedDraft.id, newReply, tone);
    setSelectedDraft({
      ...selectedDraft,
      tone,
      selectedReply: newReply,
    });
    setDrafts(emailMgr.getDrafts());
  };

  const handleSubmitForApproval = () => {
    if (!selectedDraft || !selectedEmail) return;

    approvals.requestApproval({
      actionType: 'send_email',
      title: `Send Reply: "${selectedDraft.subject}"`,
      description: `Reply to ${selectedDraft.recipientName} (${selectedDraft.recipientEmail})`,
      recipientOrTarget: selectedDraft.recipientEmail,
      previewContent: selectedDraft.selectedReply,
    });

    // Also register a follow-up check for 3 days from now
    followUpMgr.addFollowUp({
      contactName: selectedDraft.recipientName,
      contactEmailOrHandle: selectedDraft.recipientEmail,
      topic: selectedDraft.subject,
      daysUntilFollowUp: 3,
      notes: `Sent reply via tone: ${selectedDraft.tone}`,
    });

    alert('Draft submitted to Human Approval queue! Also scheduled a 3-day follow-up check.');
    refreshData();
  };

  const handleDeleteEmail = (id: string) => {
    emailMgr.deleteEmail(id);
    if (selectedEmail?.id === id) {
      setSelectedEmail(null);
      setSelectedDraft(null);
    }
    refreshData();
  };

  return (
    <div className="space-y-5">
      {/* Status banner */}
      <div className="p-3.5 rounded-xl bg-slate-900/90 border border-slate-800 text-xs flex items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <Mail className="w-4 h-4 text-cyan-400" />
          <span className="text-slate-300">
            {isEmailConnected ? (
              <span className="text-emerald-400 font-medium">Email Integration Active: Messages synced.</span>
            ) : (
              <span>
                <strong className="text-white">Email Inbox Triage:</strong> Currently in client-side authorized triage mode. Connect provider in Integrations for live sync.
              </span>
            )}
          </span>
        </div>

        <button
          onClick={() => setIsComposeModalOpen(true)}
          className="px-3 py-1.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-xs font-medium text-white transition-all flex items-center gap-1.5 shadow-md flex-shrink-0"
        >
          <Plus className="w-3.5 h-3.5" />
          Receive / Import Message
        </button>
      </div>

      {/* Main Email & Draft Workspace */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Email list column */}
        <div className="md:col-span-1 space-y-2.5">
          {/* Category Filter */}
          <div className="flex items-center gap-1 overflow-x-auto pb-1 text-[11px]">
            {['ALL', 'LEAD', 'CLIENT', 'IMPORTANT', 'FOLLOW_UP'].map((cat) => (
              <button
                key={cat}
                onClick={() => setFilterCategory(cat)}
                className={`px-2 py-1 rounded-lg font-medium transition-all ${
                  filterCategory === cat
                    ? 'bg-cyan-600/30 text-cyan-300 border border-cyan-400/40'
                    : 'text-slate-400 hover:text-white bg-[#09102c]'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          {filteredEmails.length === 0 ? (
            <div className="p-6 rounded-2xl bg-[#09102c]/60 border border-dashed border-slate-800 text-center text-xs text-slate-400">
              No emails in this category. Click "Receive / Import Message" above to test triage!
            </div>
          ) : (
            <div className="space-y-2 max-h-[500px] overflow-y-auto pr-1">
              {filteredEmails.map((em) => (
                <div
                  key={em.id}
                  onClick={() => handleSelectEmail(em)}
                  className={`p-3 rounded-xl cursor-pointer border transition-all text-xs ${
                    selectedEmail?.id === em.id
                      ? 'bg-[#101a40] border-cyan-400/60 shadow-[0_0_12px_rgba(0,229,255,0.15)]'
                      : 'bg-[#090f28]/80 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center justify-between font-semibold text-white">
                    <span className="truncate pr-2">{em.sender.name}</span>
                    <span
                      className={`text-[9px] px-1.5 py-0.5 rounded font-bold uppercase flex-shrink-0 ${
                        em.category === 'LEAD'
                          ? 'bg-purple-500/20 text-purple-300'
                          : em.category === 'CLIENT'
                          ? 'bg-cyan-500/20 text-cyan-300'
                          : 'bg-slate-700 text-slate-300'
                      }`}
                    >
                      {em.category}
                    </span>
                  </div>
                  <p className="text-slate-200 font-medium truncate mt-1 text-[11px]">{em.subject}</p>
                  <p className="text-slate-400 truncate text-[10px] mt-0.5">{em.snippet}</p>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Selected Email & Multi-Tone Draft Workspace */}
        <div className="md:col-span-2">
          {selectedEmail ? (
            <div className="p-5 rounded-2xl bg-[#09102c] border border-slate-800 space-y-4 text-xs">
              {/* Header */}
              <div className="flex items-start justify-between border-b border-slate-800 pb-3 gap-2">
                <div>
                  <h3 className="text-sm font-bold text-white">{selectedEmail.subject}</h3>
                  <div className="mt-1 flex items-center gap-2 text-slate-400 text-[11px]">
                    <span>From: <strong>{selectedEmail.sender.name}</strong> ({selectedEmail.sender.email})</span>
                    <span>•</span>
                    <span className="text-cyan-300">Confidence: {Math.round(selectedEmail.confidence * 100)}%</span>
                  </div>
                </div>

                <button
                  onClick={() => handleDeleteEmail(selectedEmail.id)}
                  className="text-slate-400 hover:text-rose-400 p-1"
                  title="Delete email"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>

              {/* Body */}
              <div className="p-3.5 rounded-xl bg-[#060a1d] border border-slate-800 text-slate-200 whitespace-pre-line leading-relaxed text-xs">
                {selectedEmail.body}
              </div>

              {/* Action items extracted */}
              {selectedEmail.actionItems.length > 0 && (
                <div className="p-2.5 rounded-xl bg-[#081238] border border-cyan-500/30 text-[11px] space-y-1">
                  <span className="font-semibold text-cyan-300 flex items-center gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    Detected Action Items:
                  </span>
                  <ul className="list-disc list-inside text-slate-300 pl-2">
                    {selectedEmail.actionItems.map((item, idx) => (
                      <li key={idx}>{item}</li>
                    ))}
                  </ul>
                </div>
              )}

              {/* DRAFT REPLY BOX */}
              {selectedDraft && (
                <div className="p-4 rounded-xl bg-[#080d26] border border-cyan-500/40 space-y-3">
                  <div className="flex items-center justify-between flex-wrap gap-2">
                    <span className="font-bold text-white flex items-center gap-1.5">
                      <CornerDownRight className="w-4 h-4 text-cyan-400" />
                      Prepared Contextual Reply Draft
                    </span>

                    {/* Tone Selector */}
                    <div className="flex items-center gap-1 p-0.5 rounded-lg bg-[#060a1d] border border-slate-700 text-[11px]">
                      {(['short', 'professional', 'friendly'] as ReplyTone[]).map((tone) => (
                        <button
                          key={tone}
                          onClick={() => handleSelectTone(tone)}
                          className={`px-2 py-0.5 rounded capitalize transition-all ${
                            selectedDraft.tone === tone
                              ? 'bg-cyan-500/20 text-cyan-300 font-semibold'
                              : 'text-slate-400 hover:text-white'
                          }`}
                        >
                          {tone}
                        </button>
                      ))}
                    </div>
                  </div>

                  <textarea
                    rows={6}
                    value={selectedDraft.selectedReply}
                    onChange={(e) => {
                      emailMgr.updateDraftReply(selectedDraft.id, e.target.value, selectedDraft.tone);
                      setSelectedDraft({ ...selectedDraft, selectedReply: e.target.value });
                    }}
                    className="w-full px-3 py-2 rounded-xl bg-[#060a1d] border border-slate-700 text-white font-mono text-[11px] leading-relaxed focus:outline-none focus:border-cyan-400"
                  />

                  <div className="flex items-center justify-between pt-1">
                    <span className="text-[10px] text-slate-400">
                      Requires human approval before external dispatch.
                    </span>

                    <button
                      onClick={handleSubmitForApproval}
                      className="px-4 py-1.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-semibold flex items-center gap-1.5 shadow-md"
                    >
                      <ShieldCheck className="w-4 h-4" />
                      Submit for Human Approval
                    </button>
                  </div>
                </div>
              )}
            </div>
          ) : (
            <div className="p-12 rounded-2xl bg-[#09102c]/50 border border-dashed border-slate-800 text-center text-xs text-slate-400">
              Select an email from the left to read and review reply options.
            </div>
          )}
        </div>
      </div>

      {/* SAMPLE EMAIL IMPORT MODAL */}
      {isComposeModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-md p-5 rounded-2xl bg-[#0a1130] border border-cyan-500/40 shadow-2xl space-y-3 text-xs">
            <h3 className="text-sm font-bold text-white">Receive / Import Email Message</h3>
            <form onSubmit={handleAddSampleEmail} className="space-y-3">
              <div>
                <label className="block text-slate-300 mb-1">Sender Name</label>
                <input
                  type="text"
                  value={sampleSender}
                  onChange={(e) => setSampleSender(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-[#060a1d] border border-slate-700 text-white"
                  required
                />
              </div>

              <div>
                <label className="block text-slate-300 mb-1">Sender Email</label>
                <input
                  type="email"
                  value={sampleEmail}
                  onChange={(e) => setSampleEmail(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-[#060a1d] border border-slate-700 text-white"
                  required
                />
              </div>

              <div>
                <label className="block text-slate-300 mb-1">Subject</label>
                <input
                  type="text"
                  value={sampleSubject}
                  onChange={(e) => setSampleSubject(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-[#060a1d] border border-slate-700 text-white"
                  required
                />
              </div>

              <div>
                <label className="block text-slate-300 mb-1">Message Body</label>
                <textarea
                  rows={4}
                  value={sampleBody}
                  onChange={(e) => setSampleBody(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-[#060a1d] border border-slate-700 text-white"
                  required
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsComposeModalOpen(false)}
                  className="px-3 py-1.5 rounded-xl text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 font-semibold text-white"
                >
                  Import & Classify
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
