import React, { useState } from 'react';
import {
  Sparkles,
  Mail,
  Send,
  Briefcase,
  Share2,
  Clock,
  ShieldCheck,
  CheckCircle2,
  ArrowRight,
  TrendingUp,
  FileText,
  AlertCircle
} from 'lucide-react';
import { WorkIntelligenceCoordinator } from '../../modules/work/WorkIntelligenceCoordinator';
import { DailyBriefData, DailyReviewData } from '../../modules/work/types';

interface WorkOverviewTabProps {
  onNavigateTab: (tab: 'freelance' | 'linkedin' | 'email' | 'portfolio' | 'approvals' | 'profile') => void;
}

export const WorkOverviewTab: React.FC<WorkOverviewTabProps> = ({ onNavigateTab }) => {
  const coordinator = WorkIntelligenceCoordinator.getInstance();
  const [brief, setBrief] = useState<DailyBriefData>(() => coordinator.workflow.generateMorningBrief());
  const [review, setReview] = useState<DailyReviewData | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);

  const importantEmails = coordinator.email.getImportantEmails();
  const pendingFollowUps = coordinator.followUp.getPending();
  const opportunities = coordinator.freelance.getOpportunities();
  const pendingApprovals = coordinator.approvals.getPendingRequests();
  const projects = coordinator.portfolio.getProjects();

  const handleRefreshBrief = () => {
    setIsGenerating(true);
    setTimeout(() => {
      setBrief(coordinator.workflow.generateMorningBrief());
      setIsGenerating(false);
    }, 200);
  };

  const handleGenerateReview = () => {
    setIsGenerating(true);
    setTimeout(() => {
      setReview(coordinator.workflow.generateDailyReview());
      setIsGenerating(false);
    }, 250);
  };

  return (
    <div className="space-y-6">
      {/* 1. TOP STATS BAR */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div
          onClick={() => onNavigateTab('email')}
          className="cursor-pointer p-4 rounded-2xl bg-[#0b1333]/70 border border-cyan-500/20 hover:border-cyan-400/50 transition-all group"
        >
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Priority Mail</span>
            <Mail className="w-4 h-4 text-cyan-400 group-hover:scale-110 transition-transform" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-white tracking-tight">{importantEmails.length}</span>
            <span className="text-[11px] text-cyan-300">Needs review</span>
          </div>
        </div>

        <div
          onClick={() => onNavigateTab('freelance')}
          className="cursor-pointer p-4 rounded-2xl bg-[#0b1333]/70 border border-purple-500/20 hover:border-purple-400/50 transition-all group"
        >
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Active Leads</span>
            <Briefcase className="w-4 h-4 text-purple-400 group-hover:scale-110 transition-transform" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-white tracking-tight">{opportunities.length}</span>
            <span className="text-[11px] text-purple-300">In pipeline</span>
          </div>
        </div>

        <div
          onClick={() => onNavigateTab('email')}
          className="cursor-pointer p-4 rounded-2xl bg-[#0b1333]/70 border border-amber-500/20 hover:border-amber-400/50 transition-all group"
        >
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Follow-Ups</span>
            <Clock className="w-4 h-4 text-amber-400 group-hover:scale-110 transition-transform" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-white tracking-tight">{pendingFollowUps.length}</span>
            <span className="text-[11px] text-amber-300">Pending reply</span>
          </div>
        </div>

        <div
          onClick={() => onNavigateTab('approvals')}
          className="cursor-pointer p-4 rounded-2xl bg-[#0b1333]/70 border border-emerald-500/20 hover:border-emerald-400/50 transition-all group"
        >
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Approvals</span>
            <ShieldCheck className="w-4 h-4 text-emerald-400 group-hover:scale-110 transition-transform" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-white tracking-tight">{pendingApprovals.length}</span>
            <span className="text-[11px] text-emerald-300">Safety gates</span>
          </div>
        </div>
      </div>

      {/* 2. MORNING WORK BRIEF CARD */}
      <div className="p-5 rounded-2xl bg-gradient-to-br from-[#0c153b] to-[#080d26] border border-cyan-500/30 shadow-[0_4px_24px_rgba(0,229,255,0.08)]">
        <div className="flex items-start justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 text-[10px] font-semibold tracking-wider uppercase rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-400/30">
                Daily Work Brief
              </span>
              <span className="text-xs text-slate-400">{brief.dateStr}</span>
            </div>
            <h3 className="text-base font-semibold text-white mt-2 leading-snug">
              {brief.greeting}
            </h3>
          </div>
          <button
            onClick={handleRefreshBrief}
            disabled={isGenerating}
            className="px-3 py-1.5 text-xs font-medium rounded-xl bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-300 border border-cyan-400/30 transition-all flex items-center gap-1.5"
          >
            <Sparkles className="w-3.5 h-3.5" />
            Refresh
          </button>
        </div>

        {/* Focus items */}
        <div className="mt-4 space-y-2">
          <p className="text-xs font-medium text-slate-300">Recommended Priority Tasks:</p>
          <div className="grid gap-2 sm:grid-cols-2">
            {brief.topTasksToday.map((task, idx) => (
              <div
                key={idx}
                className="flex items-start gap-2.5 p-3 rounded-xl bg-[#070b20]/70 border border-slate-800 text-xs text-slate-200"
              >
                <CheckCircle2 className="w-4 h-4 text-cyan-400 flex-shrink-0 mt-0.5" />
                <span>{task}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Scheduled Content Highlight */}
        {brief.scheduledContentToday && (
          <div className="mt-4 p-3 rounded-xl bg-purple-950/30 border border-purple-500/30 flex items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-2">
              <Share2 className="w-4 h-4 text-purple-400 flex-shrink-0" />
              <div>
                <span className="text-purple-300 font-medium">Scheduled LinkedIn Post: </span>
                <span className="text-slate-300">{brief.scheduledContentToday.topic}</span>
              </div>
            </div>
            <button
              onClick={() => onNavigateTab('linkedin')}
              className="text-purple-400 hover:text-purple-200 flex items-center gap-1 font-medium text-[11px]"
            >
              Review <ArrowRight className="w-3 h-3" />
            </button>
          </div>
        )}
      </div>

      {/* 3. TWO COLUMN ACTION SECTIONS */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Urgent Follow-ups & Inquiries */}
        <div className="p-4 rounded-2xl bg-[#09102c]/80 border border-slate-800 space-y-3">
          <div className="flex items-center justify-between">
            <h4 className="text-xs font-semibold text-slate-200 flex items-center gap-2">
              <Clock className="w-4 h-4 text-amber-400" />
              Overdue & Pending Follow-Ups
            </h4>
            <button
              onClick={() => onNavigateTab('email')}
              className="text-[11px] text-cyan-400 hover:underline flex items-center gap-1"
            >
              Manage all <ArrowRight className="w-3 h-3" />
            </button>
          </div>

          {pendingFollowUps.length === 0 ? (
            <p className="text-xs text-slate-400 py-3 text-center">No pending follow-ups. All communications are up to date.</p>
          ) : (
            <div className="space-y-2">
              {pendingFollowUps.slice(0, 3).map((item) => (
                <div key={item.id} className="p-2.5 rounded-xl bg-[#070b20] border border-slate-800 text-xs flex flex-col gap-1">
                  <div className="flex items-center justify-between font-medium text-slate-200">
                    <span>{item.contactName}</span>
                    <span className="text-[10px] text-amber-400">{item.responseStatus}</span>
                  </div>
                  <p className="text-[11px] text-slate-400">{item.topic}</p>
                  <p className="text-[10px] text-cyan-300/90 font-mono mt-0.5">Next: {item.nextActionSuggestion}</p>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Active Freelancing Opportunities */}
        <div className="p-4 rounded-2xl bg-[#09102c]/80 border border-slate-800 space-y-3">
          <div className="flex items-center justify-between">
            <h4 className="text-xs font-semibold text-slate-200 flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-purple-400" />
              High-Match Freelance Leads
            </h4>
            <button
              onClick={() => onNavigateTab('freelance')}
              className="text-[11px] text-purple-400 hover:underline flex items-center gap-1"
            >
              Pipeline <ArrowRight className="w-3 h-3" />
            </button>
          </div>

          {opportunities.length === 0 ? (
            <p className="text-xs text-slate-400 py-3 text-center">No freelance leads recorded yet.</p>
          ) : (
            <div className="space-y-2">
              {opportunities.slice(0, 3).map((opp) => (
                <div key={opp.id} className="p-2.5 rounded-xl bg-[#070b20] border border-slate-800 text-xs flex flex-col gap-1">
                  <div className="flex items-center justify-between font-medium text-slate-200">
                    <span className="truncate pr-2">{opp.title}</span>
                    <span className="text-[10px] px-1.5 py-0.5 rounded bg-purple-500/20 text-purple-300 font-semibold flex-shrink-0">
                      {opp.matchScore}% Match
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-[11px] text-slate-400">
                    <span>{opp.clientOrCompany}</span>
                    <span className="text-slate-300">{opp.budgetPublic || 'Custom Quote'}</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* 4. END-OF-DAY REVIEW ACCORDION / DRAWER */}
      <div className="p-4 rounded-2xl bg-[#070d24] border border-slate-800/90">
        <div className="flex items-center justify-between">
          <div>
            <h4 className="text-xs font-semibold text-white">End-of-Day Retrospective & Review</h4>
            <p className="text-[11px] text-slate-400">Summarizes completed work, pending replies, and tomorrow's plan.</p>
          </div>
          <button
            onClick={handleGenerateReview}
            className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-medium text-slate-200 transition-all flex items-center gap-1.5"
          >
            <FileText className="w-3.5 h-3.5 text-cyan-400" />
            {review ? 'Update Review' : 'Run Daily Review'}
          </button>
        </div>

        {review && (
          <div className="mt-4 pt-3 border-t border-slate-800 space-y-3 text-xs">
            <div className="grid sm:grid-cols-2 gap-3">
              <div className="p-3 rounded-xl bg-[#060a1d] border border-slate-800">
                <span className="font-semibold text-emerald-400 block mb-1">Completed Today:</span>
                <ul className="list-disc list-inside text-slate-300 space-y-0.5 text-[11px]">
                  {review.completedTasks.map((t, idx) => (
                    <li key={idx}>{t}</li>
                  ))}
                </ul>
              </div>
              <div className="p-3 rounded-xl bg-[#060a1d] border border-slate-800">
                <span className="font-semibold text-cyan-400 block mb-1">Tomorrow's Focus:</span>
                <ul className="list-disc list-inside text-slate-300 space-y-0.5 text-[11px]">
                  {review.nextDayActionItems.map((a, idx) => (
                    <li key={idx}>{a}</li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
