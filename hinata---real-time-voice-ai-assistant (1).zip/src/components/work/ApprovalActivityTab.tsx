import React, { useState } from 'react';
import {
  ShieldCheck,
  CheckCircle2,
  XCircle,
  Clock,
  FileCheck,
  AlertTriangle,
  History,
  Trash2
} from 'lucide-react';
import { ApprovalManager } from '../../modules/work/ApprovalManager';
import { ApprovalRequest, ActivityLogEntry } from '../../modules/work/types';

export const ApprovalActivityTab: React.FC = () => {
  const approvalMgr = ApprovalManager.getInstance();

  const [requests, setRequests] = useState<ApprovalRequest[]>(() => approvalMgr.getPendingRequests());
  const [logs, setLogs] = useState<ActivityLogEntry[]>(() => approvalMgr.getActivityLogs());
  const [activeSubTab, setActiveSubTab] = useState<'pending' | 'logs'>('pending');

  const refreshData = () => {
    setRequests(approvalMgr.getPendingRequests());
    setLogs(approvalMgr.getActivityLogs());
  };

  const handleApprove = (id: string) => {
    approvalMgr.approve(id);
    refreshData();
  };

  const handleReject = (id: string) => {
    approvalMgr.reject(id, 'User rejected action');
    refreshData();
  };

  const handleClearLogs = () => {
    approvalMgr.clearActivityLogs();
    refreshData();
  };

  return (
    <div className="space-y-5">
      {/* Sub-tab navigation */}
      <div className="flex items-center justify-between border-b border-slate-800 pb-3 flex-wrap gap-2">
        <div className="flex items-center gap-1.5 p-1 rounded-xl bg-[#09102c] border border-slate-800">
          <button
            onClick={() => setActiveSubTab('pending')}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
              activeSubTab === 'pending'
                ? 'bg-emerald-600/30 text-emerald-200 border border-emerald-500/40'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Pending Safety Approvals ({requests.length})
          </button>
          <button
            onClick={() => setActiveSubTab('logs')}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
              activeSubTab === 'logs'
                ? 'bg-emerald-600/30 text-emerald-200 border border-emerald-500/40'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Activity Audit Trail ({logs.length})
          </button>
        </div>

        {activeSubTab === 'logs' && logs.length > 0 && (
          <button
            onClick={handleClearLogs}
            className="px-2.5 py-1 rounded-lg text-[11px] text-slate-400 hover:text-rose-300 hover:bg-rose-950/40 border border-transparent hover:border-rose-500/30 flex items-center gap-1"
          >
            <Trash2 className="w-3.5 h-3.5" />
            Clear Log History
          </button>
        )}
      </div>

      {/* VIEW 1: PENDING APPROVALS */}
      {activeSubTab === 'pending' && (
        <div className="space-y-4">
          {requests.length === 0 ? (
            <div className="p-8 rounded-2xl bg-[#09102c]/50 border border-dashed border-slate-800 text-center text-xs text-slate-400">
              <ShieldCheck className="w-8 h-8 text-emerald-400/60 mx-auto mb-2" />
              <p className="font-semibold text-slate-300">All Human Approval Gates Clear</p>
              <p className="mt-0.5">No pending emails, messages, or external proposals waiting for permission.</p>
            </div>
          ) : (
            <div className="grid gap-3">
              {requests.map((req) => (
                <div
                  key={req.id}
                  className="p-5 rounded-2xl bg-[#09102c] border border-emerald-500/30 space-y-3 text-xs"
                >
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-300 uppercase">
                          {req.actionType.replace('_', ' ')}
                        </span>
                        <span className="text-slate-400 text-[11px]">Level: {req.level}</span>
                      </div>
                      <h4 className="text-sm font-bold text-white mt-1.5">{req.title}</h4>
                      <p className="text-[11px] text-slate-300">{req.description}</p>
                    </div>

                    <div className="flex items-center gap-2 flex-shrink-0">
                      <button
                        onClick={() => handleReject(req.id)}
                        className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-rose-900/60 text-slate-300 hover:text-rose-200 border border-slate-700 flex items-center gap-1 font-medium transition-all"
                      >
                        <XCircle className="w-3.5 h-3.5" />
                        Reject
                      </button>
                      <button
                        onClick={() => handleApprove(req.id)}
                        className="px-4 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold flex items-center gap-1 shadow-md transition-all"
                      >
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        Approve & Execute
                      </button>
                    </div>
                  </div>

                  {/* Preview Content */}
                  <div className="p-3 rounded-xl bg-[#060a1d] border border-slate-800 space-y-1">
                    <span className="font-semibold text-slate-400 block text-[10px] uppercase">
                      Action Payload Preview:
                    </span>
                    <pre className="text-slate-200 whitespace-pre-line font-mono text-[11px] leading-relaxed max-h-48 overflow-y-auto">
                      {req.previewContent}
                    </pre>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* VIEW 2: ACTIVITY AUDIT LOG */}
      {activeSubTab === 'logs' && (
        <div className="space-y-3">
          <div className="p-3.5 rounded-xl bg-[#09102c] border border-slate-800 flex items-center justify-between text-xs">
            <span className="text-slate-300">
              Complete chronological audit trail of all agent actions, approvals, and verified outcomes.
            </span>
            <span className="text-slate-400 text-[11px] font-mono">{logs.length} entries</span>
          </div>

          {logs.length === 0 ? (
            <div className="p-8 rounded-2xl bg-[#09102c]/50 border border-dashed border-slate-800 text-center text-xs text-slate-400">
              Audit log is clean. Actions taken will appear here automatically.
            </div>
          ) : (
            <div className="space-y-2 max-h-[550px] overflow-y-auto pr-1">
              {logs.map((entry) => (
                <div
                  key={entry.id}
                  className="p-3 rounded-xl bg-[#080d26] border border-slate-800/90 text-xs flex items-start justify-between gap-3"
                >
                  <div className="space-y-0.5">
                    <div className="flex items-center gap-2">
                      <span className="font-semibold text-white">{entry.action}</span>
                      <span
                        className={`text-[9px] px-1.5 py-0.2 rounded uppercase font-bold ${
                          entry.status === 'SUCCESS'
                            ? 'bg-emerald-500/20 text-emerald-300'
                            : entry.status === 'CANCELLED'
                            ? 'bg-amber-500/20 text-amber-300'
                            : 'bg-rose-500/20 text-rose-300'
                        }`}
                      >
                        {entry.status}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-300">{entry.resultMessage}</p>
                    <div className="flex items-center gap-2 text-[10px] text-slate-500 pt-0.5">
                      <span>Target: {entry.target}</span>
                      <span>•</span>
                      <span>Source: {entry.source}</span>
                      <span>•</span>
                      <span>Approval: {entry.userApproval}</span>
                    </div>
                  </div>

                  <span className="text-[10px] text-slate-400 font-mono flex-shrink-0">
                    {new Date(entry.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
