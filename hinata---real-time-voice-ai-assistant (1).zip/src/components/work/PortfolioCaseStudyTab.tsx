import React, { useState } from 'react';
import {
  FolderGit2,
  Sparkles,
  Plus,
  ExternalLink,
  Github,
  Copy,
  Check,
  FileText,
  Trash2,
  X
} from 'lucide-react';
import { PortfolioManager } from '../../modules/work/PortfolioManager';
import { PortfolioProject, CaseStudy } from '../../modules/work/types';

export const PortfolioCaseStudyTab: React.FC = () => {
  const portfolioMgr = PortfolioManager.getInstance();

  const [projects, setProjects] = useState<PortfolioProject[]>(() => portfolioMgr.getProjects());
  const [caseStudies, setCaseStudies] = useState<CaseStudy[]>(() => portfolioMgr.getCaseStudies());
  const [selectedProject, setSelectedProject] = useState<PortfolioProject | null>(() => projects[0] || null);
  const [selectedCaseStudy, setSelectedCaseStudy] = useState<CaseStudy | null>(() => caseStudies[0] || null);
  const [copiedMd, setCopiedMd] = useState(false);

  // Add project modal
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [title, setTitle] = useState('');
  const [purpose, setPurpose] = useState('');
  const [tech, setTech] = useState('');
  const [contrib, setContrib] = useState('');
  const [features, setFeatures] = useState('');
  const [liveUrl, setLiveUrl] = useState('');
  const [githubUrl, setGithubUrl] = useState('');

  const refreshData = () => {
    const p = portfolioMgr.getProjects();
    const c = portfolioMgr.getCaseStudies();
    setProjects(p);
    setCaseStudies(c);
  };

  const handleSelectProject = (proj: PortfolioProject) => {
    setSelectedProject(proj);
    const cs = caseStudies.find((c) => c.projectId === proj.id) || null;
    setSelectedCaseStudy(cs);
  };

  const handleGenerateCaseStudy = (projectId: string) => {
    const cs = portfolioMgr.generateCaseStudy(projectId);
    refreshData();
    if (cs) setSelectedCaseStudy(cs);
  };

  const handleCopyMarkdown = () => {
    if (!selectedCaseStudy) return;
    navigator.clipboard.writeText(selectedCaseStudy.formattedArticleMarkdown);
    setCopiedMd(true);
    setTimeout(() => setCopiedMd(false), 2000);
  };

  const handleAddProject = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !purpose.trim()) return;

    const techArr = tech.split(',').map((t) => t.trim()).filter(Boolean);
    const featArr = features.split('\n').map((f) => f.trim()).filter(Boolean);

    const created = portfolioMgr.addProject({
      title: title.trim(),
      purpose: purpose.trim(),
      technologies: techArr.length > 0 ? techArr : ['TypeScript', 'React'],
      userContribution: contrib.trim() || 'Lead system architect and frontend developer',
      keyFeatures: featArr.length > 0 ? featArr : ['Responsive layout', 'High performance'],
      liveUrl: liveUrl.trim() || undefined,
      githubUrl: githubUrl.trim() || undefined,
    });

    setIsAddModalOpen(false);
    setTitle('');
    setPurpose('');
    setTech('');
    setContrib('');
    setFeatures('');
    setLiveUrl('');
    setGithubUrl('');
    refreshData();
    handleSelectProject(created);
  };

  const handleDeleteProject = (id: string) => {
    portfolioMgr.deleteProject(id);
    refreshData();
    const remaining = portfolioMgr.getProjects();
    setSelectedProject(remaining[0] || null);
  };

  return (
    <div className="space-y-5">
      {/* Header bar */}
      <div className="flex items-center justify-between border-b border-slate-800 pb-3 flex-wrap gap-2">
        <div>
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            <FolderGit2 className="w-4 h-4 text-cyan-400" />
            Portfolio & Deep Case Study Studio
          </h3>
          <p className="text-xs text-slate-400">
            Synthesize genuine architectural case studies from verified project implementations.
          </p>
        </div>

        <button
          onClick={() => setIsAddModalOpen(true)}
          className="px-3 py-1.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-xs font-medium text-white transition-all flex items-center gap-1.5 shadow-md"
        >
          <Plus className="w-3.5 h-3.5" />
          Add Project
        </button>
      </div>

      {/* Main Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        {/* Project List */}
        <div className="md:col-span-1 space-y-2.5">
          <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider block">
            Featured Projects ({projects.length})
          </span>

          {projects.map((proj) => (
            <div
              key={proj.id}
              onClick={() => handleSelectProject(proj)}
              className={`p-3.5 rounded-xl cursor-pointer border transition-all text-xs ${
                selectedProject?.id === proj.id
                  ? 'bg-[#101a40] border-cyan-400/60 shadow-[0_0_12px_rgba(0,229,255,0.15)]'
                  : 'bg-[#090f28]/80 border-slate-800 hover:border-slate-700'
              }`}
            >
              <div className="flex items-start justify-between gap-2">
                <h4 className="font-bold text-white leading-tight">{proj.title}</h4>
                {proj.hasCaseStudy && (
                  <span className="text-[9px] px-1.5 py-0.5 rounded bg-cyan-500/20 text-cyan-300 font-mono">
                    CASE STUDY
                  </span>
                )}
              </div>
              <p className="text-slate-400 text-[11px] line-clamp-2 mt-1">{proj.purpose}</p>
              <div className="flex flex-wrap gap-1 mt-2">
                {proj.technologies.slice(0, 3).map((t, idx) => (
                  <span key={idx} className="text-[9px] px-1.5 py-0.5 rounded bg-slate-800 text-slate-300">
                    {t}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* Selected Project & Case Study Viewer */}
        <div className="md:col-span-2">
          {selectedProject ? (
            <div className="p-5 rounded-2xl bg-[#09102c] border border-slate-800 space-y-4 text-xs">
              {/* Project Top Bar */}
              <div className="flex items-start justify-between border-b border-slate-800 pb-3 gap-2">
                <div>
                  <h3 className="text-base font-bold text-white">{selectedProject.title}</h3>
                  <p className="text-slate-400 text-xs mt-0.5">{selectedProject.purpose}</p>
                  <div className="flex items-center gap-3 mt-2">
                    {selectedProject.liveUrl && (
                      <a
                        href={selectedProject.liveUrl}
                        target="_blank"
                        rel="noreferrer"
                        className="text-cyan-400 hover:underline flex items-center gap-1 text-[11px]"
                      >
                        <ExternalLink className="w-3 h-3" /> Live Demo
                      </a>
                    )}
                    {selectedProject.githubUrl && (
                      <a
                        href={selectedProject.githubUrl}
                        target="_blank"
                        rel="noreferrer"
                        className="text-slate-300 hover:text-white flex items-center gap-1 text-[11px]"
                      >
                        <Github className="w-3 h-3" /> GitHub Repo
                      </a>
                    )}
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => handleGenerateCaseStudy(selectedProject.id)}
                    className="px-3 py-1.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-medium flex items-center gap-1.5 shadow-md flex-shrink-0"
                  >
                    <Sparkles className="w-3.5 h-3.5" />
                    {selectedCaseStudy ? 'Re-generate' : 'Generate Case Study'}
                  </button>
                  <button
                    onClick={() => handleDeleteProject(selectedProject.id)}
                    className="p-1.5 text-slate-500 hover:text-rose-400"
                    title="Delete project"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Technologies & Contributions */}
              <div className="grid sm:grid-cols-2 gap-3">
                <div className="p-3 rounded-xl bg-[#060a1d] border border-slate-800">
                  <span className="font-semibold text-slate-300 block mb-1">Tech Stack:</span>
                  <div className="flex flex-wrap gap-1">
                    {selectedProject.technologies.map((t, idx) => (
                      <span key={idx} className="px-2 py-0.5 rounded text-[10px] bg-cyan-950/60 text-cyan-300 border border-cyan-500/30">
                        {t}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-[#060a1d] border border-slate-800">
                  <span className="font-semibold text-slate-300 block mb-1">Your Contribution:</span>
                  <p className="text-slate-300 text-[11px]">{selectedProject.userContribution}</p>
                </div>
              </div>

              {/* Case Study Output */}
              {selectedCaseStudy ? (
                <div className="p-4 rounded-xl bg-[#070c26] border border-cyan-500/40 space-y-3">
                  <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                    <span className="font-bold text-white flex items-center gap-2">
                      <FileText className="w-4 h-4 text-cyan-400" />
                      Generated Case Study
                    </span>
                    <button
                      onClick={handleCopyMarkdown}
                      className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-[11px] font-medium flex items-center gap-1.5"
                    >
                      {copiedMd ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                      <span>{copiedMd ? 'Copied Markdown' : 'Copy Article Markdown'}</span>
                    </button>
                  </div>

                  <div className="space-y-3 text-slate-200">
                    <div>
                      <span className="font-semibold text-cyan-300 block mb-0.5">Problem Statement:</span>
                      <p className="text-[11px] text-slate-300">{selectedCaseStudy.problem}</p>
                    </div>

                    <div>
                      <span className="font-semibold text-cyan-300 block mb-0.5">Architectural Approach:</span>
                      <p className="text-[11px] text-slate-300">{selectedCaseStudy.approach}</p>
                    </div>

                    <div>
                      <span className="font-semibold text-cyan-300 block mb-0.5">Challenges Overcome:</span>
                      <p className="text-[11px] text-slate-300 whitespace-pre-line">{selectedCaseStudy.challengesOvercome}</p>
                    </div>

                    <div>
                      <span className="font-semibold text-cyan-300 block mb-0.5">Results & Impact:</span>
                      <p className="text-[11px] text-slate-300 whitespace-pre-line">{selectedCaseStudy.resultsAndImpact}</p>
                    </div>

                    <div>
                      <span className="font-semibold text-cyan-300 block mb-0.5">Key Lessons:</span>
                      <p className="text-[11px] text-slate-300">{selectedCaseStudy.lessonsLearned}</p>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="p-6 rounded-xl bg-[#070c26] border border-dashed border-slate-800 text-center text-slate-400">
                  Click "Generate Case Study" above to turn this project into a structured case study article.
                </div>
              )}
            </div>
          ) : (
            <div className="p-12 rounded-2xl bg-[#09102c]/50 border border-dashed border-slate-800 text-center text-xs text-slate-400">
              Select a project from the left or click "Add Project" to begin.
            </div>
          )}
        </div>
      </div>

      {/* MODAL: ADD PROJECT */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-lg p-5 rounded-2xl bg-[#0a1130] border border-cyan-500/40 shadow-2xl space-y-3 text-xs">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <h3 className="text-sm font-bold text-white">Add Portfolio Project</h3>
              <button onClick={() => setIsAddModalOpen(false)} className="text-slate-400 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleAddProject} className="space-y-3">
              <div>
                <label className="block text-slate-300 mb-1">Project Name</label>
                <input
                  type="text"
                  placeholder="e.g. Real-Time Vision Analytics"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-[#060a1d] border border-slate-700 text-white"
                  required
                />
              </div>

              <div>
                <label className="block text-slate-300 mb-1">Purpose & Description</label>
                <textarea
                  rows={2}
                  placeholder="What problem does this project solve?"
                  value={purpose}
                  onChange={(e) => setPurpose(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-[#060a1d] border border-slate-700 text-white"
                  required
                />
              </div>

              <div>
                <label className="block text-slate-300 mb-1">Technologies Used (comma-separated)</label>
                <input
                  type="text"
                  placeholder="React, TypeScript, Web Audio, Tailwind"
                  value={tech}
                  onChange={(e) => setTech(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-[#060a1d] border border-slate-700 text-white"
                />
              </div>

              <div>
                <label className="block text-slate-300 mb-1">Your Exact Contribution</label>
                <input
                  type="text"
                  placeholder="e.g. Designed WebSocket streaming pipeline and UI components"
                  value={contrib}
                  onChange={(e) => setContrib(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-[#060a1d] border border-slate-700 text-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-slate-300 mb-1">Live URL (Optional)</label>
                  <input
                    type="url"
                    placeholder="https://app.example.com"
                    value={liveUrl}
                    onChange={(e) => setLiveUrl(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-[#060a1d] border border-slate-700 text-white"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 mb-1">GitHub URL (Optional)</label>
                  <input
                    type="url"
                    placeholder="https://github.com/..."
                    value={githubUrl}
                    onChange={(e) => setGithubUrl(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-[#060a1d] border border-slate-700 text-white"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-3 py-1.5 rounded-xl text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 font-semibold text-white"
                >
                  Save Project
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
