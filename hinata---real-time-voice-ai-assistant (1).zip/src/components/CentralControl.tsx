import React from 'react';
import { motion } from 'motion/react';
import { Mic, MicOff, Power, Square, Loader2, Volume2, Sparkles } from 'lucide-react';
import { LiveSessionState } from '../types';

interface CentralControlProps {
  state: LiveSessionState;
  isMuted: boolean;
  onConnect: () => void;
  onDisconnect: () => void;
  onToggleMute: () => void;
  onInterrupt: () => void;
}

export const CentralControl: React.FC<CentralControlProps> = ({
  state,
  isMuted,
  onConnect,
  onDisconnect,
  onToggleMute,
  onInterrupt,
}) => {
  const isConnected = state === 'listening' || state === 'speaking';

  return (
    <div className="flex flex-col items-center gap-4 select-none">
      {/* Action controls row */}
      <div className="flex items-center gap-4">
        {/* Left auxiliary action: Mute / Unmute (when connected) */}
        {isConnected && (
          <motion.button
            id="myraa-mute-btn"
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.8 }}
            onClick={onToggleMute}
            className={`w-12 h-12 rounded-full glass-button flex items-center justify-center transition-colors ${
              isMuted
                ? 'bg-rose-500/20 text-rose-300 border-rose-500/40'
                : 'text-neutral-300 hover:text-white'
            }`}
            title={isMuted ? 'Unmute microphone' : 'Mute microphone'}
          >
            {isMuted ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
          </motion.button>
        )}

        {/* Central main action trigger */}
        <div className="relative">
          {/* Subtle outer glow ring */}
          {state === 'listening' && (
            <div className="absolute -inset-2 rounded-full bg-cyan-500/20 filter blur-md animate-pulse pointer-events-none" />
          )}
          {state === 'speaking' && (
            <div className="absolute -inset-2 rounded-full bg-pink-500/25 filter blur-md animate-pulse pointer-events-none" />
          )}
          {state === 'connecting' && (
            <div className="absolute -inset-2 rounded-full bg-purple-500/25 filter blur-md animate-pulse pointer-events-none" />
          )}

          {state === 'disconnected' ? (
            <motion.button
              id="hinata-connect-btn"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.94 }}
              onClick={onConnect}
              className="relative px-7 py-4 rounded-full bg-gradient-to-r from-purple-600 via-fuchsia-600 to-indigo-600 text-white font-semibold text-base shadow-lg shadow-purple-600/30 border border-white/20 flex items-center gap-3 transition-shadow hover:shadow-purple-500/50"
            >
              <Power className="w-5 h-5 text-white animate-pulse" />
              <span>Wake Hinata</span>
              <Sparkles className="w-4 h-4 text-purple-200" />
            </motion.button>
          ) : state === 'connecting' ? (
            <div className="px-6 py-3.5 rounded-full glass-panel-glow text-purple-300 text-sm font-medium flex items-center gap-3 border border-purple-500/30">
              <Loader2 className="w-5 h-5 animate-spin text-purple-400" />
              <span>Connecting neural link...</span>
            </div>
          ) : state === 'speaking' ? (
            <motion.button
              id="hinata-interrupt-btn"
              whileHover={{ scale: 1.04 }}
              whileTap={{ scale: 0.95 }}
              onClick={onInterrupt}
              className="px-6 py-3.5 rounded-full bg-pink-500/15 hover:bg-pink-500/25 text-pink-300 border border-pink-500/40 text-sm font-medium flex items-center gap-2.5 backdrop-blur-md shadow-lg shadow-pink-500/10 transition-all"
            >
              <Volume2 className="w-4 h-4 text-pink-400 animate-bounce" />
              <span>Hinata speaking • Tap to interrupt</span>
            </motion.button>
          ) : (
            <motion.div
              id="hinata-listening-badge"
              className="px-6 py-3.5 rounded-full bg-cyan-500/10 text-cyan-300 border border-cyan-500/30 text-sm font-medium flex items-center gap-2.5 backdrop-blur-md"
            >
              <div className="w-2.5 h-2.5 rounded-full bg-cyan-400 animate-ping" />
              <span>Listening to you...</span>
            </motion.div>
          )}
        </div>

        {/* Right auxiliary action: Disconnect / Hang up */}
        {isConnected && (
          <motion.button
            id="hinata-disconnect-btn"
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.8 }}
            onClick={onDisconnect}
            className="w-12 h-12 rounded-full glass-button text-neutral-400 hover:text-rose-400 hover:border-rose-500/30 flex items-center justify-center transition-colors"
            title="End session"
          >
            <Square className="w-4 h-4 fill-current" />
          </motion.button>
        )}
      </div>

      {/* Auxiliary micro status hint */}
      <div className="text-xs text-neutral-400 font-mono-tech tracking-wider uppercase text-center flex items-center gap-1.5">
        {state === 'disconnected' && (
          <span className="text-neutral-500">Live Voice-to-Voice AI • Audio Only</span>
        )}
        {state === 'connecting' && (
          <span className="text-purple-400">Negotiating 16kHz & 24kHz Web Audio</span>
        )}
        {state === 'listening' && (
          <span className="text-cyan-400/90">Say anything, or ask Hinata to open a site</span>
        )}
        {state === 'speaking' && (
          <span className="text-pink-400/90">Continuous active session • Interrupt anytime</span>
        )}
      </div>
    </div>
  );
};
