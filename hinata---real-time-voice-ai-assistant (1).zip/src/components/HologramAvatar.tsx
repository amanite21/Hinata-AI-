import React, { useEffect, useRef, useState } from 'react';
import { LiveSessionState, EmotionalState, EmotionalIntensity } from '../types';
import { AvatarController, AvatarFrameState } from '../modules/avatar/AvatarController';

interface HologramAvatarProps {
  state: LiveSessionState;
  mood: EmotionalState;
  intensity?: EmotionalIntensity;
  outputVolume?: number;
  inputVolume?: number;
  onAvatarClick?: () => void;
}

export const HologramAvatar: React.FC<HologramAvatarProps> = ({
  state,
  mood,
  intensity = 2,
  outputVolume = 0,
  inputVolume = 0,
  onAvatarClick,
}) => {
  const controllerRef = useRef<AvatarController>(new AvatarController());
  const prevTimeRef = useRef<number>(performance.now());
  const reqAnimRef = useRef<number | null>(null);

  // References to directly manipulated DOM nodes for high performance (zero React re-render overhead)
  const containerRef = useRef<HTMLDivElement>(null);
  const headTransformRef = useRef<HTMLDivElement>(null);
  const leftEyelidRef = useRef<SVGPathElement>(null);
  const rightEyelidRef = useRef<SVGPathElement>(null);
  const leftPupilRef = useRef<SVGCircleElement>(null);
  const rightPupilRef = useRef<SVGCircleElement>(null);
  const mouthPathRef = useRef<SVGPathElement>(null);
  const mouthFillRef = useRef<SVGPathElement>(null);
  const leftBlushRef = useRef<SVGEllipseElement>(null);
  const rightBlushRef = useRef<SVGEllipseElement>(null);
  const leftEyebrowRef = useRef<SVGPathElement>(null);
  const rightEyebrowRef = useRef<SVGPathElement>(null);
  const canvasParticlesRef = useRef<HTMLCanvasElement>(null);
  const platformGlowRef = useRef<HTMLDivElement>(null);

  // Trigger brief reaction glitch whenever mood changes
  useEffect(() => {
    controllerRef.current.triggerReactionGlitch();
  }, [mood]);

  useEffect(() => {
    let active = true;

    const animate = (now: number) => {
      if (!active) return;
      const deltaMs = Math.min(60, Math.max(1, now - prevTimeRef.current));
      prevTimeRef.current = now;

      const frame: AvatarFrameState = controllerRef.current.update(
        deltaMs,
        state,
        mood,
        intensity,
        outputVolume,
        inputVolume
      );

      // 1. Head movement and micro-breathing (3D transform on head container)
      if (headTransformRef.current) {
        const { roll, pitch, yaw, translateY, scale } = frame.headPose;
        headTransformRef.current.style.transform = `translate3d(0, ${translateY.toFixed(
          2
        )}px, 0) rotateZ(${roll.toFixed(2)}deg) rotateY(${yaw.toFixed(
          2
        )}deg) rotateX(${(-pitch).toFixed(2)}deg) scale(${scale.toFixed(4)})`;
      }

      // 2. Eye gaze (pupil position)
      const gazeOffsetX = frame.eyeState.gazeX * 4.5;
      const gazeOffsetY = frame.eyeState.gazeY * 3.5;
      if (leftPupilRef.current) {
        leftPupilRef.current.setAttribute('cx', (136 + gazeOffsetX).toFixed(1));
        leftPupilRef.current.setAttribute('cy', (188 + gazeOffsetY).toFixed(1));
        leftPupilRef.current.setAttribute('r', (7.5 * frame.eyeState.pupilDilation).toFixed(1));
      }
      if (rightPupilRef.current) {
        rightPupilRef.current.setAttribute('cx', (184 + gazeOffsetX).toFixed(1));
        rightPupilRef.current.setAttribute('cy', (188 + gazeOffsetY).toFixed(1));
        rightPupilRef.current.setAttribute('r', (7.5 * frame.eyeState.pupilDilation).toFixed(1));
      }

      // 3. Eyelids (blinking & squint)
      // Base eye center at y=188, eye height ~14px.
      // Eyelid closes downwards: blinkProgress 0 (fully open) to 1 (closed)
      const blink = Math.min(1, frame.blinkProgress + frame.eyeState.squint * 0.35);
      const lidY = 181 + blink * 14;

      if (leftEyelidRef.current) {
        // Eyelid path covering from top down to lidY
        leftEyelidRef.current.setAttribute(
          'd',
          `M 124 180 Q 136 ${lidY} 148 180 Q 136 177 124 180 Z`
        );
        leftEyelidRef.current.style.opacity = blink > 0.05 ? '0.95' : '0';
      }
      if (rightEyelidRef.current) {
        rightEyelidRef.current.setAttribute(
          'd',
          `M 172 180 Q 184 ${lidY} 196 180 Q 184 177 172 180 Z`
        );
        rightEyelidRef.current.style.opacity = blink > 0.05 ? '0.95' : '0';
      }

      // 4. Eyebrows
      const { eyebrowLeftY, eyebrowLeftAngle, eyebrowRightY, eyebrowRightAngle } = frame.facialPose;
      if (leftEyebrowRef.current) {
        const leftBaseY = 172 + eyebrowLeftY;
        leftEyebrowRef.current.setAttribute(
          'd',
          `M 124 ${leftBaseY + eyebrowLeftAngle} Q 136 ${leftBaseY - 3} 148 ${leftBaseY - eyebrowLeftAngle}`
        );
      }
      if (rightEyebrowRef.current) {
        const rightBaseY = 172 + eyebrowRightY;
        rightEyebrowRef.current.setAttribute(
          'd',
          `M 172 ${rightBaseY - eyebrowRightAngle} Q 184 ${rightBaseY - 3} 196 ${rightBaseY + eyebrowRightAngle}`
        );
      }

      // 5. Blush intensity
      const blushOp = frame.facialPose.blushOpacity.toFixed(2);
      if (leftBlushRef.current) {
        leftBlushRef.current.style.opacity = blushOp;
      }
      if (rightBlushRef.current) {
        rightBlushRef.current.style.opacity = blushOp;
      }

      // 6. Mouth / Lip Sync
      // Mouth center at x=160, y=228
      const { mouthOpen, mouthWidth, mouthCurve } = frame.mouthState;
      const mouthHalfW = 10 * mouthWidth;
      const leftX = 160 - mouthHalfW;
      const rightX = 160 + mouthHalfW;
      const topY = 227 - mouthCurve * 2;
      const bottomY = 227 + mouthCurve * 1.5 + mouthOpen * 14;

      if (mouthPathRef.current) {
        if (mouthOpen < 0.08) {
          // Closed resting smile line
          mouthPathRef.current.setAttribute(
            'd',
            `M ${leftX} ${topY} Q 160 ${topY + 3 + mouthCurve * 4} ${rightX} ${topY}`
          );
        } else {
          // Open speaking lip outline
          mouthPathRef.current.setAttribute(
            'd',
            `M ${leftX} ${topY} Q 160 ${topY - 1} ${rightX} ${topY} Q 160 ${bottomY} ${leftX} ${topY} Z`
          );
        }
      }
      if (mouthFillRef.current) {
        if (mouthOpen >= 0.08) {
          mouthFillRef.current.setAttribute(
            'd',
            `M ${leftX} ${topY} Q 160 ${topY - 1} ${rightX} ${topY} Q 160 ${bottomY} ${leftX} ${topY} Z`
          );
          mouthFillRef.current.style.opacity = '0.9';
        } else {
          mouthFillRef.current.style.opacity = '0';
        }
      }

      // 7. Render floating particles on the background canvas
      const canvas = canvasParticlesRef.current;
      if (canvas) {
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.clearRect(0, 0, canvas.width, canvas.height);
          const w = canvas.width;
          const h = canvas.height;

          for (const p of frame.particles) {
            const px = (p.x / 100) * w;
            const py = (p.y / 100) * h;
            ctx.beginPath();
            ctx.arc(px, py, p.size, 0, Math.PI * 2);
            ctx.fillStyle = `hsla(${p.hue}, 90%, 65%, ${p.opacity * (state === 'disconnected' ? 0.35 : 0.85)})`;
            ctx.shadowBlur = 6;
            ctx.shadowColor = p.hue === 190 ? '#00e5ff' : '#c084fc';
            ctx.fill();
          }
        }
      }

      // 8. Platform illumination
      if (platformGlowRef.current) {
        platformGlowRef.current.style.opacity = frame.hologramFx.platformBrightness.toFixed(2);
      }

      reqAnimRef.current = requestAnimationFrame(animate);
    };

    reqAnimRef.current = requestAnimationFrame(animate);

    return () => {
      active = false;
      if (reqAnimRef.current) {
        cancelAnimationFrame(reqAnimRef.current);
      }
    };
  }, [state, mood, intensity, outputVolume, inputVolume]);

  return (
    <div
      ref={containerRef}
      onClick={onAvatarClick}
      className="relative w-full h-full max-w-lg mx-auto flex flex-col items-center justify-end select-none cursor-pointer overflow-visible pointer-events-auto"
      style={{ minHeight: '440px' }}
      title={`Hinata Holographic AI Companion (${state}) - Tap to interact`}
    >
      {/* Background Volumetric Projection Beam */}
      <div
        className="absolute bottom-16 left-1/2 -translate-x-1/2 w-80 h-[520px] pointer-events-none transition-opacity duration-700"
        style={{
          background:
            state === 'speaking'
              ? 'conic-gradient(from 180deg at 50% 100%, rgba(168, 85, 247, 0.22) 0deg, rgba(6, 182, 212, 0.28) 25deg, transparent 50deg, transparent 310deg, rgba(6, 182, 212, 0.28) 335deg, rgba(168, 85, 247, 0.22) 360deg)'
              : 'conic-gradient(from 180deg at 50% 100%, rgba(79, 70, 229, 0.16) 0deg, rgba(6, 182, 212, 0.18) 25deg, transparent 45deg, transparent 315deg, rgba(6, 182, 212, 0.18) 335deg, rgba(79, 70, 229, 0.16) 360deg)',
          filter: 'blur(12px)',
          opacity: state === 'disconnected' ? 0.35 : 0.85,
        }}
      />

      {/* Floating Hologram Particle Canvas */}
      <canvas
        ref={canvasParticlesRef}
        width={380}
        height={540}
        className="absolute inset-0 w-full h-full pointer-events-none z-10"
      />

      {/* Floating Holographic Cyber Rings orbiting body */}
      <div className="absolute top-[38%] left-1/2 -translate-x-1/2 -translate-y-1/2 w-72 h-72 pointer-events-none z-10">
        {/* Ring 1 - Tilted cyan orbital */}
        <div
          className="absolute inset-2 rounded-full border border-cyan-400/25 animate-spin-slow"
          style={{
            transform: 'rotateX(72deg) rotateY(15deg)',
            boxShadow: '0 0 15px rgba(6, 182, 212, 0.25)',
          }}
        >
          <div className="absolute -top-1 left-1/2 w-2 h-2 rounded-full bg-cyan-300 shadow-[0_0_8px_#22d3ee]" />
        </div>

        {/* Ring 2 - Counter-rotating purple orbital */}
        <div
          className="absolute inset-10 rounded-full border border-dashed border-purple-400/30 animate-reverse-spin-slow"
          style={{
            transform: 'rotateX(68deg) rotateY(-20deg)',
          }}
        >
          <div className="absolute -top-1 left-1/3 w-1.5 h-1.5 rounded-full bg-purple-300 shadow-[0_0_6px_#c084fc]" />
        </div>
      </div>

      {/* Hinata Projected Avatar Body Container */}
      <div
        ref={headTransformRef}
        className="relative w-[320px] sm:w-[360px] h-[480px] flex items-end justify-center z-20 transition-transform duration-75 will-change-transform"
      >
        {/* Luminous Body Aura & Rim Light */}
        <div
          className="absolute inset-x-6 top-8 bottom-12 rounded-full pointer-events-none filter blur-2xl transition-all duration-700"
          style={{
            background:
              state === 'speaking'
                ? 'radial-gradient(ellipse at 50% 45%, rgba(168, 85, 247, 0.45), rgba(6, 182, 212, 0.35) 60%, transparent 80%)'
                : state === 'listening'
                ? 'radial-gradient(ellipse at 50% 45%, rgba(6, 182, 212, 0.4), rgba(59, 130, 246, 0.28) 60%, transparent 80%)'
                : 'radial-gradient(ellipse at 50% 45%, rgba(99, 102, 241, 0.25), rgba(6, 182, 212, 0.15) 60%, transparent 80%)',
          }}
        />

        {/* Base Hologram Anime Character Image with Hologram Dual-Tone Gradient */}
        <div className="relative w-full h-full overflow-hidden flex items-end justify-center">
          <img
            src="/hinata_avatar.jpg"
            alt="Hinata Holographic AI Companion"
            className="w-full h-auto max-h-[460px] object-contain object-bottom select-none filter contrast-105"
            style={{
              maskImage: 'linear-gradient(to bottom, black 82%, transparent 98%)',
              WebkitMaskImage: 'linear-gradient(to bottom, black 82%, transparent 98%)',
              opacity: state === 'disconnected' ? 0.78 : 0.96,
            }}
            draggable={false}
          />

          {/* Hologram Cyan & Purple Chromatic Overlay */}
          <div
            className="absolute inset-0 pointer-events-none mix-blend-color-dodge transition-opacity duration-500"
            style={{
              background:
                'linear-gradient(135deg, rgba(6, 182, 212, 0.18) 0%, rgba(168, 85, 247, 0.22) 50%, rgba(37, 99, 235, 0.15) 100%)',
              opacity: state === 'speaking' ? 0.75 : 0.45,
            }}
          />

          {/* Real-time Facial Morph Overlay (Eyes, Blinking, Pupils, Blush, Lip-Sync Mouth) */}
          <svg
            viewBox="0 0 320 480"
            className="absolute inset-0 w-full h-full pointer-events-none z-30"
          >
            <defs>
              {/* Eye Glow Filter */}
              <filter id="eye-glow" x="-50%" y="-50%" width="200%" height="200%">
                <feGaussianBlur stdDeviation="2.5" result="blur" />
                <feMerge>
                  <feMergeNode in="blur" />
                  <feMergeNode in="SourceGraphic" />
                </feMerge>
              </filter>

              {/* Blush Radial Gradients */}
              <radialGradient id="blush-grad-left" cx="50%" cy="50%" r="50%">
                <stop offset="0%" stopColor="rgba(251, 113, 133, 0.65)" />
                <stop offset="100%" stopColor="rgba(251, 113, 133, 0)" />
              </radialGradient>
              <radialGradient id="blush-grad-right" cx="50%" cy="50%" r="50%">
                <stop offset="0%" stopColor="rgba(251, 113, 133, 0.65)" />
                <stop offset="100%" stopColor="rgba(251, 113, 133, 0)" />
              </radialGradient>
            </defs>

            {/* Cheek Blush Overlays */}
            <ellipse
              ref={leftBlushRef}
              cx="128"
              cy="204"
              rx="16"
              ry="8"
              fill="url(#blush-grad-left)"
              style={{ opacity: 0.2, transition: 'opacity 0.2s ease' }}
            />
            <ellipse
              ref={rightBlushRef}
              cx="192"
              cy="204"
              rx="16"
              ry="8"
              fill="url(#blush-grad-right)"
              style={{ opacity: 0.2, transition: 'opacity 0.2s ease' }}
            />

            {/* Left Eye & Dynamic Pupil */}
            <g id="left-eye-group">
              {/* Luminous Iris Accent */}
              <circle
                ref={leftPupilRef}
                cx="136"
                cy="188"
                r="7.5"
                fill="#22d3ee"
                filter="url(#eye-glow)"
                opacity="0.85"
              />
              <circle cx="134.5" cy="186.5" r="2.2" fill="#ffffff" opacity="0.9" />

              {/* Blinking Eyelid Path */}
              <path
                ref={leftEyelidRef}
                d="M 124 180 Q 136 181 148 180 Z"
                fill="#0e1329"
                stroke="#38bdf8"
                strokeWidth="1.5"
                style={{ opacity: 0 }}
              />
            </g>

            {/* Right Eye & Dynamic Pupil */}
            <g id="right-eye-group">
              {/* Luminous Iris Accent */}
              <circle
                ref={rightPupilRef}
                cx="184"
                cy="188"
                r="7.5"
                fill="#22d3ee"
                filter="url(#eye-glow)"
                opacity="0.85"
              />
              <circle cx="182.5" cy="186.5" r="2.2" fill="#ffffff" opacity="0.9" />

              {/* Blinking Eyelid Path */}
              <path
                ref={rightEyelidRef}
                d="M 172 180 Q 184 181 196 180 Z"
                fill="#0e1329"
                stroke="#38bdf8"
                strokeWidth="1.5"
                style={{ opacity: 0 }}
              />
            </g>

            {/* Dynamic Eyebrows */}
            <path
              ref={leftEyebrowRef}
              d="M 124 172 Q 136 169 148 172"
              fill="none"
              stroke="#67e8f9"
              strokeWidth="2"
              strokeLinecap="round"
              opacity="0.8"
            />
            <path
              ref={rightEyebrowRef}
              d="M 172 172 Q 184 169 196 172"
              fill="none"
              stroke="#67e8f9"
              strokeWidth="2"
              strokeLinecap="round"
              opacity="0.8"
            />

            {/* Dynamic Real-time Lip-Sync Mouth */}
            <g id="mouth-group">
              {/* Inner mouth cavity when open */}
              <path
                ref={mouthFillRef}
                d="M 152 227 Q 160 226 168 227 Q 160 234 152 227 Z"
                fill="#2e1047"
                opacity="0"
              />
              {/* Teeth / Upper lip shine highlight */}
              {state === 'speaking' && (
                <path
                  d="M 154 227.5 Q 160 228.5 166 227.5"
                  fill="none"
                  stroke="#ffffff"
                  strokeWidth="1"
                  opacity="0.8"
                />
              )}
              {/* Primary lip contour */}
              <path
                ref={mouthPathRef}
                d="M 152 227 Q 160 230 168 227"
                fill="none"
                stroke="#f472b6"
                strokeWidth="1.8"
                strokeLinecap="round"
              />
            </g>
          </svg>

          {/* Subtle Horizontal Hologram Scanlines */}
          <div
            className="absolute inset-0 pointer-events-none opacity-20"
            style={{
              backgroundImage:
                'repeating-linear-gradient(0deg, transparent, transparent 3px, rgba(34, 211, 238, 0.4) 4px, transparent 5px)',
              backgroundSize: '100% 6px',
            }}
          />
        </div>
      </div>

      {/* Futuristic Circular Holographic Projection Platform (Beneath Feet) */}
      <div
        className="relative -mt-16 w-80 h-28 flex items-center justify-center pointer-events-none z-0"
        style={{
          perspective: '600px',
        }}
      >
        <div
          ref={platformGlowRef}
          className="relative w-full h-full flex items-center justify-center transition-opacity duration-500"
          style={{
            transform: 'rotateX(68deg)',
            transformStyle: 'preserve-3d',
          }}
        >
          {/* Base Ambient Neon Platform Glow */}
          <div className="absolute inset-0 rounded-full bg-gradient-to-r from-cyan-500/30 via-purple-500/40 to-blue-500/30 filter blur-xl shadow-[0_0_40px_rgba(6,182,212,0.6)]" />

          {/* Outermost Projector Ring with Tech Marks */}
          <div className="absolute inset-0 rounded-full border-2 border-cyan-400/50 shadow-[0_0_20px_rgba(34,211,238,0.7)] animate-spin-slow">
            <div className="absolute top-0 left-1/2 -translate-x-1/2 w-3 h-3 rounded-full bg-cyan-300 shadow-[0_0_10px_#22d3ee]" />
            <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-3 h-3 rounded-full bg-cyan-300 shadow-[0_0_10px_#22d3ee]" />
          </div>

          {/* Middle Dashed Counter-Rotating Tech Ring */}
          <div className="absolute inset-4 rounded-full border border-dashed border-purple-400/60 shadow-[0_0_15px_rgba(168,85,247,0.5)] animate-reverse-spin-slow">
            <div className="absolute top-1/2 -left-1 w-2 h-2 rounded-full bg-purple-300 shadow-[0_0_8px_#c084fc]" />
            <div className="absolute top-1/2 -right-1 w-2 h-2 rounded-full bg-purple-300 shadow-[0_0_8px_#c084fc]" />
          </div>

          {/* Inner Glowing Hologram Emitter Core */}
          <div className="absolute inset-10 rounded-full bg-gradient-to-tr from-cyan-400/50 via-purple-500/50 to-indigo-600/50 border border-white/40 shadow-[0_0_30px_rgba(6,182,212,0.8)] animate-pulse" />

          {/* Projector Center Node */}
          <div className="w-8 h-8 rounded-full bg-white shadow-[0_0_20px_#ffffff] filter blur-[1px]" />
        </div>
      </div>
    </div>
  );
};
