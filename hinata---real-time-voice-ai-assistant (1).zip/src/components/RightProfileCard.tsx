import React from 'react';
import { motion } from 'motion/react';
import {
  Mic,
  Image as ImageIcon,
  Monitor,
  Smartphone,
  Calendar,
  Brain,
  Sparkles,
} from 'lucide-react';

export const RightProfileCard: React.FC = () => {
  const capabilities = [
    { label: 'Voice Conversations', icon: <Mic className="w-3.5 h-3.5 text-purple-400" />, color: 'bg-purple-500/15 border-purple-500/30' },
    { label: 'Image Analysis', icon: <ImageIcon className="w-3.5 h-3.5 text-blue-400" />, color: 'bg-blue-500/15 border-blue-500/30' },
    { label: 'Screen Sharing', icon: <Monitor className="w-3.5 h-3.5 text-cyan-400" />, color: 'bg-cyan-500/15 border-cyan-500/30' },
    { label: 'Device Actions', icon: <Smartphone className="w-3.5 h-3.5 text-purple-400" />, color: 'bg-purple-500/15 border-purple-500/30' },
    { label: 'Smart Planning', icon: <Calendar className="w-3.5 h-3.5 text-blue-400" />, color: 'bg-blue-500/15 border-blue-500/30' },
    { label: 'Memory & Context', icon: <Brain className="w-3.5 h-3.5 text-pink-400" />, color: 'bg-pink-500/15 border-pink-500/30' },
  ];

  return (
    <motion.div
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.6, delay: 0.1, ease: 'easeOut' }}
      className="p-4 rounded-3xl bg-[#080d24]/90 border border-cyan-500/30 shadow-[0_8px_32px_rgba(0,0,0,0.6)] backdrop-blur-xl pointer-events-auto select-none z-30 w-[240px] flex flex-col justify-between hover:border-cyan-400/50 transition-all duration-300 relative overflow-hidden"
    >
      {/* Ambient background glow */}
      <div className="absolute -bottom-8 -left-8 w-24 h-24 bg-cyan-500/15 rounded-full filter blur-xl pointer-events-none" />

      <div>
        <div className="flex items-center gap-2 mb-3 pb-2.5 border-b border-slate-800">
          <Sparkles className="w-4 h-4 text-cyan-400" />
          <h3 className="text-xs font-bold text-white tracking-wide uppercase">
            I can help you with:
          </h3>
        </div>

        {/* Capabilities List matching reference image */}
        <div className="flex flex-col gap-2 mb-4">
          {capabilities.map((item, index) => (
            <div
              key={index}
              className="flex items-center gap-2.5 text-xs text-slate-200 hover:text-cyan-200 transition-colors"
            >
              <div className={`w-6 h-6 rounded-lg border flex items-center justify-center flex-shrink-0 ${item.color}`}>
                {item.icon}
              </div>
              <span className="font-medium text-[11.5px] leading-tight">
                {item.label}
              </span>
            </div>
          ))}
          <span className="text-[10px] text-cyan-400/80 italic pl-1">
            And much more...
          </span>
        </div>
      </div>

      {/* Languages Supported */}
      <div className="pt-2.5 border-t border-slate-800 flex flex-col gap-1.5">
        <span className="text-[10px] text-slate-400 font-medium">
          Supports Languages:
        </span>
        <div className="flex flex-wrap gap-1">
          <span className="text-[10px] px-1.5 py-0.5 rounded-md bg-slate-900 border border-slate-700 text-slate-300">
            🇮🇳 Hindi
          </span>
          <span className="text-[10px] px-1.5 py-0.5 rounded-md bg-slate-900 border border-slate-700 text-slate-300">
            🇬🇧 English
          </span>
          <span className="text-[10px] px-1.5 py-0.5 rounded-md bg-slate-900 border border-slate-700 text-slate-300">
            🇵🇰 Urdu
          </span>
          <span className="text-[10px] px-1.5 py-0.5 rounded-md bg-slate-900 border border-slate-700 text-slate-300">
            🕉️ Sanskrit
          </span>
        </div>
      </div>
    </motion.div>
  );
};
