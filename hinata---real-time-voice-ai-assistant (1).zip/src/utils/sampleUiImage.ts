/**
 * Generates a high-resolution dark-mode cybernetic dashboard screenshot data URL
 * for instant testing of Hinata's visual AI vision & comprehension engine.
 */
export function getSampleDashboardDataUrl(): string {
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="900" height="560" viewBox="0 0 900 560">
    <defs>
      <linearGradient id="bgGrad" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stop-color="#050814" />
        <stop offset="50%" stop-color="#0a1128" />
        <stop offset="100%" stop-color="#04060f" />
      </linearGradient>
      <linearGradient id="cyanCard" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stop-color="#00e5ff" stop-opacity="0.15" />
        <stop offset="100%" stop-color="#0284c7" stop-opacity="0.05" />
      </linearGradient>
      <linearGradient id="purpleCard" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stop-color="#a855f7" stop-opacity="0.15" />
        <stop offset="100%" stop-color="#6366f1" stop-opacity="0.05" />
      </linearGradient>
      <linearGradient id="chartGrad" x1="0%" y1="0%" x2="0%" y2="100%">
        <stop offset="0%" stop-color="#00e5ff" stop-opacity="0.4" />
        <stop offset="100%" stop-color="#00e5ff" stop-opacity="0.0" />
      </linearGradient>
    </defs>

    <!-- Canvas Background -->
    <rect width="900" height="560" fill="url(#bgGrad)" />

    <!-- Top Navigation Bar -->
    <rect x="24" y="20" width="852" height="56" rx="16" fill="#0b132b" stroke="#00e5ff" stroke-opacity="0.3" stroke-width="1.5" />
    <circle cx="56" cy="48" r="14" fill="#00e5ff" />
    <text x="80" y="53" fill="#ffffff" font-family="system-ui, sans-serif" font-size="16" font-weight="bold" letter-spacing="1">HINATA OS // NEURAL DASHBOARD</text>
    
    <rect x="680" y="34" width="80" height="28" rx="8" fill="#10b981" fill-opacity="0.2" stroke="#10b981" stroke-width="1" />
    <text x="696" y="52" fill="#34d399" font-family="system-ui, sans-serif" font-size="12" font-weight="bold">ONLINE</text>

    <rect x="772" y="34" width="88" height="28" rx="8" fill="#00e5ff" fill-opacity="0.2" stroke="#00e5ff" stroke-width="1" />
    <text x="786" y="52" fill="#38bdf8" font-family="system-ui, sans-serif" font-size="12" font-weight="bold">v3.8 FLASH</text>

    <!-- Metric Cards Row -->
    <!-- Card 1 -->
    <rect x="24" y="96" width="268" height="110" rx="16" fill="url(#cyanCard)" stroke="#00e5ff" stroke-opacity="0.3" stroke-width="1" />
    <text x="44" y="128" fill="#94a3b8" font-family="system-ui, sans-serif" font-size="12" font-weight="600" letter-spacing="0.5">NEURAL ACCURACY</text>
    <text x="44" y="168" fill="#00e5ff" font-family="system-ui, sans-serif" font-size="32" font-weight="800">99.84%</text>
    <text x="180" y="168" fill="#34d399" font-family="system-ui, sans-serif" font-size="13" font-weight="bold">+2.4% vs last hr</text>

    <!-- Card 2 -->
    <rect x="316" y="96" width="268" height="110" rx="16" fill="url(#purpleCard)" stroke="#a855f7" stroke-opacity="0.3" stroke-width="1" />
    <text x="336" y="128" fill="#94a3b8" font-family="system-ui, sans-serif" font-size="12" font-weight="600" letter-spacing="0.5">VOICE SYNTHESIS LATENCY</text>
    <text x="336" y="168" fill="#c084fc" font-family="system-ui, sans-serif" font-size="32" font-weight="800">18 ms</text>
    <text x="450" y="168" fill="#38bdf8" font-family="system-ui, sans-serif" font-size="13" font-weight="bold">Zero-jitter PCM</text>

    <!-- Card 3 -->
    <rect x="608" y="96" width="268" height="110" rx="16" fill="url(#cyanCard)" stroke="#00e5ff" stroke-opacity="0.3" stroke-width="1" />
    <text x="628" y="128" fill="#94a3b8" font-family="system-ui, sans-serif" font-size="12" font-weight="600" letter-spacing="0.5">ACTIVE TASKS COMPLETED</text>
    <text x="628" y="168" fill="#38bdf8" font-family="system-ui, sans-serif" font-size="32" font-weight="800">1,429</text>
    <text x="740" y="168" fill="#34d399" font-family="system-ui, sans-serif" font-size="13" font-weight="bold">100% Verified</text>

    <!-- Main Analytics Graph Section -->
    <rect x="24" y="226" width="560" height="300" rx="18" fill="#080e22" stroke="#1e293b" stroke-width="1.5" />
    <text x="48" y="260" fill="#f8fafc" font-family="system-ui, sans-serif" font-size="16" font-weight="bold">Visual Comprehension &amp; Audio Stream Bandwidth</text>
    <text x="48" y="280" fill="#64748b" font-family="system-ui, sans-serif" font-size="12">Real-time telemetric throughput across multi-modal pipeline</text>

    <!-- Chart Line & Gradient Area -->
    <path d="M 48 470 L 48 420 Q 120 360, 180 390 T 300 320 T 420 350 T 540 280 L 540 470 Z" fill="url(#chartGrad)" />
    <path d="M 48 420 Q 120 360, 180 390 T 300 320 T 420 350 T 540 280" fill="none" stroke="#00e5ff" stroke-width="3.5" />
    <circle cx="540" cy="280" r="5" fill="#00e5ff" stroke="#ffffff" stroke-width="2" />

    <!-- Side Control Panel -->
    <rect x="608" y="226" width="268" height="300" rx="18" fill="#080e22" stroke="#1e293b" stroke-width="1.5" />
    <text x="628" y="260" fill="#f8fafc" font-family="system-ui, sans-serif" font-size="15" font-weight="bold">System Modules</text>

    <!-- Module Items -->
    <rect x="628" y="280" width="228" height="46" rx="10" fill="#0e1738" stroke="#00e5ff" stroke-opacity="0.2" stroke-width="1" />
    <circle cx="648" cy="303" r="6" fill="#00e5ff" />
    <text x="664" y="308" fill="#e2e8f0" font-family="system-ui, sans-serif" font-size="13" font-weight="600">Gemini 3.8 Flash Vision</text>

    <rect x="628" y="336" width="228" height="46" rx="10" fill="#0e1738" stroke="#a855f7" stroke-opacity="0.2" stroke-width="1" />
    <circle cx="648" cy="359" r="6" fill="#a855f7" />
    <text x="664" y="364" fill="#e2e8f0" font-family="system-ui, sans-serif" font-size="13" font-weight="600">Audio Synth Engine</text>

    <rect x="628" y="392" width="228" height="46" rx="10" fill="#0e1738" stroke="#10b981" stroke-opacity="0.2" stroke-width="1" />
    <circle cx="648" cy="415" r="6" fill="#10b981" />
    <text x="664" y="420" fill="#e2e8f0" font-family="system-ui, sans-serif" font-size="13" font-weight="600">Device Controller V2</text>

    <rect x="628" y="448" width="228" height="46" rx="10" fill="#0e1738" stroke="#f59e0b" stroke-opacity="0.2" stroke-width="1" />
    <circle cx="648" cy="471" r="6" fill="#f59e0b" />
    <text x="664" y="476" fill="#e2e8f0" font-family="system-ui, sans-serif" font-size="13" font-weight="600">Long-term Memory Bank</text>
  </svg>`;

  return `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`;
}
