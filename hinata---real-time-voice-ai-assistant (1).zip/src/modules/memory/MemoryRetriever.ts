/**
 * MemoryRetriever - Context-aware semantic and relevance-based memory search.
 * Retrieves only the most useful memories for the active conversation,
 * avoiding context bloat and keeping voice streaming latency ultra-low.
 */

import { MemoryItem, ScoredMemoryItem, MemorySearchQuery } from './MemoryTypes';
import { LongTermMemory } from './LongTermMemory';

export class MemoryRetriever {
  private longTermMemory: LongTermMemory;

  constructor(longTermMemory: LongTermMemory) {
    this.longTermMemory = longTermMemory;
  }

  /**
   * Retrieves relevant memories scored by query match, importance, recency, and category relevance.
   */
  public search(params: MemorySearchQuery): ScoredMemoryItem[] {
    const all = this.longTermMemory.getAll({ includeExpired: params.includeExpired, category: params.category });
    const query = (params.query || '').trim().toLowerCase();
    const minImportance = params.minImportance || 1;
    const limit = params.limit || 5;

    // Filter by min importance
    const candidates = all.filter((m) => m.importance >= minImportance);

    if (!query) {
      // Return top memories by importance and recency
      return candidates
        .slice(0, limit)
        .map((m) => ({ ...m, relevanceScore: m.importance * 10 }));
    }

    const queryTokens = this.tokenize(query);
    const scored: ScoredMemoryItem[] = [];

    for (const memory of candidates) {
      const matchReasons: string[] = [];
      let score = 0;

      // 1. Importance weight (0 to 40 points)
      score += (memory.importance / 10) * 35;

      // 2. Token overlap score (0 to 60 points)
      const memoryText = `${memory.content} ${memory.tags.join(' ')} ${memory.category}`.toLowerCase();
      const memoryTokens = this.tokenize(memoryText);

      let matchedTokensCount = 0;
      for (const qToken of queryTokens) {
        if (memoryTokens.has(qToken)) {
          matchedTokensCount++;
        } else {
          // Check substring / prefix match
          for (const mToken of memoryTokens) {
            if (mToken.includes(qToken) || qToken.includes(mToken)) {
              matchedTokensCount += 0.5;
              break;
            }
          }
        }
      }

      if (queryTokens.size > 0) {
        const tokenOverlapRatio = Math.min(1, matchedTokensCount / queryTokens.size);
        const overlapPoints = tokenOverlapRatio * 50;
        score += overlapPoints;
        if (tokenOverlapRatio > 0.3) {
          matchReasons.push(`Content relevance (${Math.round(tokenOverlapRatio * 100)}%)`);
        }
      }

      // 3. Category match boost
      if (params.category && memory.category === params.category) {
        score += 15;
        matchReasons.push(`Category match (${memory.category})`);
      } else {
        // Boost if query mentions category keywords
        if (query.includes('project') && memory.category === 'project') {
          score += 15;
          matchReasons.push('Topic matches project');
        }
        if ((query.includes('prefer') || query.includes('like')) && memory.category === 'preference') {
          score += 15;
          matchReasons.push('Topic matches preference');
        }
        if (query.includes('goal') && memory.category === 'goal') {
          score += 15;
          matchReasons.push('Topic matches goal');
        }
      }

      // 4. Recency boost (up to 10 points for recently accessed/updated)
      const ageHours = (Date.now() - memory.updatedAt) / (1000 * 60 * 60);
      if (ageHours < 24) {
        score += 10;
        matchReasons.push('Recent update');
      } else if (ageHours < 168) {
        score += 5;
      }

      // Only include if there is some relevance or if query is general
      if (matchedTokensCount > 0 || memory.importance >= 8) {
        scored.push({
          ...memory,
          relevanceScore: Math.round(score),
          matchReasons,
        });
      }
    }

    // Sort descending by relevance score
    scored.sort((a, b) => b.relevanceScore - a.relevanceScore);

    const topResults = scored.slice(0, limit);

    // Update lastAccessedAt for top retrieved items
    for (const item of topResults) {
      this.longTermMemory.updateMemory(item.id, { lastAccessedAt: Date.now() });
    }

    return topResults;
  }

  /**
   * Formats relevant memories into a compact natural block for AI prompt injection.
   */
  public formatMemoriesForAI(memories: MemoryItem[]): string {
    if (!memories || memories.length === 0) return '';
    return memories.map((m) => `- [${m.category.toUpperCase()}] ${m.content}`).join('\n');
  }

  /**
   * Directly retrieves and formats relevant memories for a prompt query.
   */
  public getFormattedContext(query: string, limit: number = 3): string {
    const scored = this.search({ query, limit });
    return this.formatMemoriesForAI(scored);
  }

  private tokenize(text: string): Set<string> {
    const clean = text
      .toLowerCase()
      .replace(/[^a-z0-9 ]/g, ' ')
      .split(/\s+/)
      .filter((w) => w.length > 2 && !STOP_WORDS.has(w));
    return new Set(clean);
  }
}

// Common conversational stop words to ignore during token scoring
const STOP_WORDS = new Set([
  'the', 'and', 'for', 'with', 'about', 'from', 'what', 'when', 'where',
  'how', 'which', 'that', 'this', 'then', 'them', 'they', 'here', 'there',
  'will', 'would', 'could', 'should', 'can', 'are', 'was', 'were', 'been',
  'have', 'has', 'had', 'does', 'did', 'doing', 'into', 'just', 'more',
  'some', 'such', 'than', 'very', 'your', 'you',
]);
