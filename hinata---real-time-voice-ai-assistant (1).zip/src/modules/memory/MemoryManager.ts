/**
 * MemoryManager - Master coordinator for Hinata AI Advanced Long-Term Memory System.
 *
 * Implements:
 * - ShortTermMemory (active conversation continuity, turn tracking, topic)
 * - LongTermMemory (persistent cross-session memory with importance & deduplication)
 * - ProfileMemory (structured user profile with intelligent upsert)
 * - ConversationMemory (meaningful conversation summaries)
 * - MemoryRetriever (context-based ranking and relevance retrieval)
 * - MemoryExtractor (detects implicit and explicit user intents)
 * - Complete user privacy, export, clear, and control capabilities
 */

import {
  MemoryItem,
  UserProfile,
  ConversationSummary,
  MemoryCategory,
  MemorySource,
  ScoredMemoryItem,
  MemorySystemConfig,
  ConversationTurn,
} from './MemoryTypes';
import { MemoryStorage } from './MemoryStorage';
import { ShortTermMemory } from './ShortTermMemory';
import { LongTermMemory } from './LongTermMemory';
import { ProfileMemory } from './ProfileMemory';
import { ConversationMemory } from './ConversationMemory';
import { MemoryRetriever } from './MemoryRetriever';
import { MemoryExtractor } from './MemoryExtractor';
import { backendConfig } from '../../config/backendConfig';

export type MemoryChangeListener = (event: {
  type: 'memory_saved' | 'memory_updated' | 'memory_deleted' | 'profile_updated' | 'summary_created' | 'cleared';
  payload?: any;
}) => void;

export class MemoryManager {
  private static instance: MemoryManager | null = null;

  public readonly storage: MemoryStorage;
  public readonly shortTerm: ShortTermMemory;
  public readonly longTerm: LongTermMemory;
  public readonly profile: ProfileMemory;
  public readonly conversations: ConversationMemory;
  public readonly retriever: MemoryRetriever;
  public readonly extractor: MemoryExtractor;

  private config: MemorySystemConfig;
  private listeners: Set<MemoryChangeListener> = new Set();

  constructor() {
    this.storage = new MemoryStorage();
    this.shortTerm = new ShortTermMemory();
    this.longTerm = new LongTermMemory(this.storage);
    this.profile = new ProfileMemory(this.storage);
    this.conversations = new ConversationMemory(this.storage);
    this.retriever = new MemoryRetriever(this.longTerm);
    this.extractor = new MemoryExtractor();
    this.config = this.storage.loadConfig();
  }

  public static getInstance(): MemoryManager {
    if (!MemoryManager.instance) {
      MemoryManager.instance = new MemoryManager();
    }
    return MemoryManager.instance;
  }

  // Subscribe to memory updates for real-time UI synchronization
  public subscribe(listener: MemoryChangeListener): () => void {
    this.listeners.add(listener);
    return () => {
      this.listeners.delete(listener);
    };
  }

  private notify(type: Parameters<MemoryChangeListener>[0]['type'], payload?: any): void {
    for (const listener of this.listeners) {
      try {
        listener({ type, payload });
      } catch (err) {
        console.error('[MemoryManager] Listener error:', err);
      }
    }
  }

  // Configuration
  public getConfig(): Readonly<MemorySystemConfig> {
    return { ...this.config };
  }

  public updateConfig(updates: Partial<MemorySystemConfig>): void {
    this.config = { ...this.config, ...updates };
    this.storage.saveConfig(this.config);
    this.notify('profile_updated');
  }

  // 1. SAVE MEMORY
  public saveMemory(params: {
    content: string;
    category?: MemoryCategory;
    importance?: number;
    tags?: string[];
    source?: MemorySource;
    expiresInDays?: number;
  }): MemoryItem {
    if (!this.config.enabled) {
      console.log('[MemoryManager] Memory system is currently disabled by user.');
    }
    const item = this.longTerm.saveMemory(params);
    this.notify('memory_saved', item);

    // Sync to backend store asynchronously for multi-phone recall
    backendConfig
      .fetchWithHeaders('/api/memory', {
        method: 'POST',
        body: JSON.stringify({
          content: item.content,
          category: item.category,
          importance: item.importance,
          source: item.source,
          tags: item.tags,
          id: item.id,
        }),
      })
      .catch((e) => {
        console.warn('[MemoryManager] Async cloud memory save warning:', e);
      });

    return item;
  }

  // 2. RETRIEVE RELEVANT MEMORIES
  public retrieveRelevantMemories(
    queryOrTopic: string = '',
    options?: { limit?: number; category?: MemoryCategory; minImportance?: number }
  ): ScoredMemoryItem[] {
    if (!this.config.enabled) return [];
    return this.retriever.search({
      query: queryOrTopic,
      category: options?.category,
      minImportance: options?.minImportance,
      limit: options?.limit || this.config.maxContextMemories,
    });
  }

  // 3. UPDATE MEMORY
  public updateMemory(id: string, updates: Partial<Omit<MemoryItem, 'id' | 'createdAt'>>): MemoryItem | null {
    const updated = this.longTerm.updateMemory(id, updates);
    if (updated) {
      this.notify('memory_updated', updated);
      if (updated.content) {
        backendConfig
          .fetchWithHeaders('/api/memory', {
            method: 'POST',
            body: JSON.stringify(updated),
          })
          .catch(() => {});
      }
    }
    return updated;
  }

  // 4. DELETE MEMORY
  public deleteMemory(id: string): boolean {
    const deleted = this.longTerm.deleteMemory(id);
    if (deleted) {
      this.notify('memory_deleted', { id });
      backendConfig
        .fetchWithHeaders(`/api/memory/${encodeURIComponent(id)}`, {
          method: 'DELETE',
        })
        .catch(() => {});
    }
    return deleted;
  }

  // 5. FORGET MEMORY BY QUERY (e.g. "Forget that project" or "Don't remember this")
  public forgetMemoryByQuery(query: string): number {
    const count = this.longTerm.deleteByQuery(query);
    if (count > 0) {
      this.notify('memory_deleted', { query, count });
    }
    return count;
  }

  // 6. CONSOLIDATE MEMORIES (deduplicate & merge redundant entries)
  public consolidateMemories(): { merged: number; updated: number; removedDuplicates: number } {
    const result = this.longTerm.consolidateMemories();
    this.notify('memory_updated', result);
    return result;
  }

  // 7. CREATE CONVERSATION SUMMARY
  public createConversationSummary(topic?: string): ConversationSummary | null {
    const turns = this.shortTerm.getTurns();
    const duration = this.shortTerm.getSessionDuration();
    const summary = this.conversations.createSummaryFromTurns({
      turns,
      topic: topic || this.shortTerm.getCurrentTopic(),
      durationMs: duration,
    });

    if (summary) {
      this.notify('summary_created', summary);
    }
    return summary;
  }

  // 8. MANAGE USER PROFILE
  public manageUserProfile(
    field: keyof UserProfile,
    value: any,
    action: 'set' | 'append' | 'remove' = 'set'
  ): UserProfile {
    const updated = this.profile.updateField(field, value, action);
    this.notify('profile_updated', updated);
    return updated;
  }

  public getUserProfile(): Readonly<UserProfile> {
    return this.profile.getProfile();
  }

  public setEntireUserProfile(updates: Partial<UserProfile>): UserProfile {
    const updated = this.profile.setProfile(updates);
    this.notify('profile_updated', updated);
    return updated;
  }

  // 9. AUTOMATIC TEXT EXTRACTION
  public processUserInput(text: string): {
    extracted: boolean;
    memoriesSaved: number;
    profileUpdated: boolean;
    forgotCount: number;
  } {
    if (!this.config.enabled || !this.config.autoExtract) {
      return { extracted: false, memoriesSaved: 0, profileUpdated: false, forgotCount: 0 };
    }

    const extraction = this.extractor.extract(text);
    let memoriesSaved = 0;
    let profileUpdated = false;
    let forgotCount = 0;

    // Handle forget queries
    if (extraction.forgetQueries && extraction.forgetQueries.length > 0) {
      for (const fq of extraction.forgetQueries) {
        forgotCount += this.forgetMemoryByQuery(fq);
      }
    }

    // Handle memories to save
    if (extraction.memoriesToSave && extraction.memoriesToSave.length > 0) {
      for (const mem of extraction.memoriesToSave) {
        this.saveMemory(mem);
        memoriesSaved++;
      }
    }

    // Handle profile updates
    if (extraction.profileUpdates && Object.keys(extraction.profileUpdates).length > 0) {
      for (const [key, val] of Object.entries(extraction.profileUpdates)) {
        if (Array.isArray(val)) {
          this.manageUserProfile(key as keyof UserProfile, val, 'append');
        } else {
          this.manageUserProfile(key as keyof UserProfile, val, 'set');
        }
      }
      profileUpdated = true;
    }

    return {
      extracted: extraction.detected,
      memoriesSaved,
      profileUpdated,
      forgotCount,
    };
  }

  // 10. GENERATE AI SYSTEM INSTRUCTION MEMORY CONTEXT
  /**
   * Produces a clean, highly relevant, compact memory prompt block for Gemini Live.
   * Runs asynchronously and safely without delaying voice startup.
   */
  public getMemoryContextForLiveSession(currentTopic?: string): string {
    if (!this.config.enabled) {
      return '';
    }

    const blocks: string[] = [];

    // 1. Structured User Profile
    const profileText = this.profile.getFormattedProfileForAI();
    if (profileText) {
      blocks.push(`### User Profile\n${profileText}`);
    }

    // 2. High Priority Long-Term Memories & Active Topic Memories
    const relevantMemories = this.retrieveRelevantMemories(currentTopic || '', {
      limit: this.config.maxContextMemories,
      minImportance: 6,
    });

    if (relevantMemories.length > 0) {
      const memoryLines = relevantMemories.map((m) => `- [${m.category.toUpperCase()}] ${m.content}`);
      blocks.push(`### Long-Term Memories & Preferences\n${memoryLines.join('\n')}`);
    }

    // 3. Past Conversation Highlights
    const pastSummaries = this.conversations.getRecentSummariesForAI(2);
    if (pastSummaries) {
      blocks.push(`### Previous Conversation Summaries\n${pastSummaries}`);
    }

    if (blocks.length === 0) return '';

    return [
      `# Persistent Memory & Personal Context`,
      `Hinata has persistent memory across sessions. Use this information naturally to personalize the conversation:`,
      ...blocks,
      `Memory Usage Guidelines:`,
      `- Use these memories naturally without sounding robotic (do NOT say "According to my memory" or "You previously said" unless asked).`,
      `- When the user explicitly asks you to remember something, or shares a strong preference or project, invoke the "rememberInformation" tool.`,
      `- When the user asks you to forget or delete something, invoke the "forgetMemory" tool.`,
      `- When the user shares or updates their name, preferred language, or goals, invoke the "updateUserProfile" tool.`,
    ].join('\n\n');
  }

  // 11. PRIVACY & EXPORT / IMPORT
  public clearAllMemories(): void {
    this.storage.clearAll();
    this.longTerm.load();
    this.profile.resetProfile();
    this.conversations.load();
    this.shortTerm.resetSession();
    this.notify('cleared');
  }

  public exportVault(): string {
    return this.storage.exportBackup();
  }

  public importVault(jsonString: string): boolean {
    const success = this.storage.importBackup(jsonString);
    if (success) {
      this.longTerm.load();
      this.conversations.load();
      this.config = this.storage.loadConfig();
      this.notify('profile_updated');
    }
    return success;
  }

  /**
   * Syncs user-scoped memory across multiple Android phones and devices.
   */
  public async syncWithBackend(): Promise<void> {
    try {
      // 1. Pull backend memories for current user
      const res = await backendConfig.fetchWithHeaders('/api/memory', { method: 'GET' });
      if (!res.ok) return;
      const data = await res.json();
      if (!data.memories || !Array.isArray(data.memories)) return;

      const remoteMemories: any[] = data.memories;
      const localMemories = this.longTerm.getAll();
      let importedCount = 0;

      for (const remote of remoteMemories) {
        const exists = localMemories.some(
          (m) => m.id === remote.id || m.content.toLowerCase() === remote.content.toLowerCase()
        );
        if (!exists) {
          this.longTerm.saveMemory({
            content: remote.content,
            category: remote.category,
            importance: remote.importance,
            source: remote.source || 'cloud_sync',
            tags: remote.tags,
          });
          importedCount++;
        }
      }

      // 2. Push any local memories not yet on remote
      const missingOnRemote = localMemories.filter(
        (loc) => !remoteMemories.some((rem) => rem.id === loc.id || rem.content.toLowerCase() === loc.content.toLowerCase())
      );

      if (missingOnRemote.length > 0) {
        await backendConfig.fetchWithHeaders('/api/memory/sync', {
          method: 'POST',
          body: JSON.stringify({
            items: missingOnRemote.map((m) => ({
              id: m.id,
              content: m.content,
              category: m.category,
              importance: m.importance,
              source: m.source,
              tags: m.tags,
            })),
          }),
        });
      }

      if (importedCount > 0) {
        this.notify('memory_updated');
      }
    } catch (err) {
      console.warn('[MemoryManager] Backend memory sync offline or skipped:', err);
    }
  }
}
