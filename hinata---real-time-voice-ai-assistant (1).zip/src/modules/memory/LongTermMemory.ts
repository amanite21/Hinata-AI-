/**
 * LongTermMemory - Manages persistent memories across sessions.
 * Implements categorization, importance ranking (1-10), deduplication,
 * intelligent consolidation, and automatic expiration for low-importance items.
 */

import { MemoryItem, MemoryCategory, MemorySource } from './MemoryTypes';
import { MemoryStorage } from './MemoryStorage';

export class LongTermMemory {
  private storage: MemoryStorage;
  private memories: MemoryItem[] = [];

  constructor(storage: MemoryStorage) {
    this.storage = storage;
    this.load();
  }

  public load(): void {
    this.memories = this.storage.loadMemories();
    this.purgeExpired();
  }

  public getAll(options?: { includeExpired?: boolean; category?: MemoryCategory }): MemoryItem[] {
    let list = [...this.memories];
    if (!options?.includeExpired) {
      const now = Date.now();
      list = list.filter((m) => !m.expiresAt || m.expiresAt > now);
    }
    if (options?.category) {
      list = list.filter((m) => m.category === options.category);
    }
    // Sort primarily by importance descending, then lastUpdated descending
    return list.sort((a, b) => {
      if (b.importance !== a.importance) {
        return b.importance - a.importance;
      }
      return b.updatedAt - a.updatedAt;
    });
  }

  public getById(id: string): MemoryItem | null {
    const item = this.memories.find((m) => m.id === id);
    if (item) {
      item.lastAccessedAt = Date.now();
      this.persist();
      return { ...item };
    }
    return null;
  }

  /**
   * Saves a new memory item or updates an existing related one to prevent duplicates.
   */
  public saveMemory(params: {
    content: string;
    category?: MemoryCategory;
    importance?: number;
    tags?: string[];
    source?: MemorySource;
    expiresInDays?: number;
  }): MemoryItem {
    const trimmedContent = params.content.trim();
    const category: MemoryCategory = params.category || 'important';
    const importance = Math.min(10, Math.max(1, params.importance ?? 7));
    const tags = Array.isArray(params.tags) ? params.tags.map((t) => t.trim().toLowerCase()) : [];
    const source: MemorySource = params.source || 'explicit_user';

    // Calculate expiration if low importance or explicitly specified
    let expiresAt: number | null = null;
    if (params.expiresInDays && params.expiresInDays > 0) {
      expiresAt = Date.now() + params.expiresInDays * 86400000;
    } else if (category === 'temporary' || importance <= 3) {
      // Low importance or temporary expires in 7 days by default
      expiresAt = Date.now() + 7 * 86400000;
    }

    // Check if there is an existing memory that should be updated instead of duplicated
    const existing = this.findSimilarExistingMemory(trimmedContent, category);
    if (existing) {
      console.log(`[LongTermMemory] Consolidating and updating existing memory: "${existing.content}" -> "${trimmedContent}"`);
      existing.content = trimmedContent;
      existing.category = category;
      existing.importance = Math.max(existing.importance, importance);
      existing.updatedAt = Date.now();
      existing.lastAccessedAt = Date.now();
      if (expiresAt) existing.expiresAt = expiresAt;
      existing.tags = Array.from(new Set([...existing.tags, ...tags]));
      this.persist();
      return { ...existing };
    }

    const newItem: MemoryItem = {
      id: 'mem_' + Math.random().toString(36).substring(2, 9) + '_' + Date.now().toString(36),
      content: trimmedContent,
      category,
      importance,
      createdAt: Date.now(),
      updatedAt: Date.now(),
      lastAccessedAt: Date.now(),
      tags,
      expiresAt,
      source,
    };

    this.memories.unshift(newItem);
    this.persist();
    return newItem;
  }

  public updateMemory(id: string, updates: Partial<Omit<MemoryItem, 'id' | 'createdAt'>>): MemoryItem | null {
    const idx = this.memories.findIndex((m) => m.id === id);
    if (idx === -1) return null;

    const current = this.memories[idx];
    const updated: MemoryItem = {
      ...current,
      ...updates,
      updatedAt: Date.now(),
      lastAccessedAt: Date.now(),
    };

    if (updates.importance !== undefined) {
      updated.importance = Math.min(10, Math.max(1, updates.importance));
    }

    this.memories[idx] = updated;
    this.persist();
    return { ...updated };
  }

  public deleteMemory(id: string): boolean {
    const initialLen = this.memories.length;
    this.memories = this.memories.filter((m) => m.id !== id);
    if (this.memories.length !== initialLen) {
      this.persist();
      return true;
    }
    return false;
  }

  /**
   * Deletes memories that match a search query or keywords (e.g. when user says "Forget that project").
   */
  public deleteByQuery(query: string): number {
    const cleanQuery = query.toLowerCase().trim();
    if (!cleanQuery) return 0;

    const queryTokens = cleanQuery
      .replace(/[^a-z0-9 ]/g, '')
      .split(/\s+/)
      .filter((t) => t.length > 2);

    if (queryTokens.length === 0) return 0;

    const initialLen = this.memories.length;
    this.memories = this.memories.filter((item) => {
      const itemText = (item.content + ' ' + item.tags.join(' ')).toLowerCase();
      // If majority of query tokens are present, mark for deletion
      const matches = queryTokens.filter((token) => itemText.includes(token));
      const shouldDelete = matches.length >= Math.ceil(queryTokens.length * 0.6);
      return !shouldDelete;
    });

    const deletedCount = initialLen - this.memories.length;
    if (deletedCount > 0) {
      this.persist();
    }
    return deletedCount;
  }

  public clearAll(): void {
    this.memories = [];
    this.persist();
  }

  /**
   * Consolidate duplicate or redundant memories.
   * Merges highly overlapping items in the same category.
   */
  public consolidateMemories(): { merged: number; updated: number; removedDuplicates: number } {
    let merged = 0;
    let removedDuplicates = 0;
    const seenContents = new Map<string, MemoryItem>();
    const consolidatedList: MemoryItem[] = [];

    for (const item of this.memories) {
      const normalized = item.content.toLowerCase().trim().replace(/[^a-z0-9]/g, ' ');
      const existing = seenContents.get(normalized);

      if (existing) {
        // Duplicate exact content
        existing.importance = Math.max(existing.importance, item.importance);
        existing.tags = Array.from(new Set([...existing.tags, ...item.tags]));
        existing.updatedAt = Math.max(existing.updatedAt, item.updatedAt);
        removedDuplicates++;
      } else {
        seenContents.set(normalized, item);
        consolidatedList.push(item);
      }
    }

    this.memories = consolidatedList;
    this.persist();

    return {
      merged,
      updated: removedDuplicates,
      removedDuplicates,
    };
  }

  /**
   * Purge expired memories (e.g. low-importance items past TTL).
   */
  public purgeExpired(): number {
    const now = Date.now();
    const initialLen = this.memories.length;

    this.memories = this.memories.filter((item) => {
      if (item.expiresAt && item.expiresAt <= now) {
        // High importance memories (7-10) should not expire even if expiresAt was set
        if (item.importance >= 7) {
          item.expiresAt = null;
          return true;
        }
        return false;
      }
      return true;
    });

    const purged = initialLen - this.memories.length;
    if (purged > 0) {
      this.persist();
    }
    return purged;
  }

  private persist(): void {
    this.storage.saveMemories(this.memories);
  }

  /**
   * Compares candidate content with existing memories in the same or related category
   * to detect updates to the same subject (e.g. "favorite language", "project name").
   */
  private findSimilarExistingMemory(newContent: string, category: MemoryCategory): MemoryItem | null {
    const newNorm = newContent.toLowerCase();
    const newWords = newNorm
      .replace(/[^a-z0-9 ]/g, '')
      .split(/\s+/)
      .filter((w) => w.length > 3);

    if (newWords.length === 0) return null;

    // Prefixes that signal subject replacement
    const replacementPrefixes = [
      'favorite',
      'prefer',
      'work on',
      'working on',
      'project',
      'language',
      'living in',
      'live in',
      'job',
      'role',
      'hobby',
    ];

    for (const item of this.memories) {
      const itemNorm = item.content.toLowerCase();

      // If category matches and shares a key replacement subject
      for (const prefix of replacementPrefixes) {
        if (newNorm.includes(prefix) && itemNorm.includes(prefix)) {
          return item;
        }
      }

      // Word overlap heuristic: if > 70% of distinctive words match
      const matchingWords = newWords.filter((w) => itemNorm.includes(w));
      if (matchingWords.length >= Math.max(3, Math.floor(newWords.length * 0.75))) {
        return item;
      }
    }

    return null;
  }
}
