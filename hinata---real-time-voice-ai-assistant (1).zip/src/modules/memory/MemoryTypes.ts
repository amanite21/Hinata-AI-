/**
 * MemoryTypes - Core type definitions for Hinata AI Advanced Long-Term Memory System.
 */

export type MemoryCategory =
  | 'PROFILE'
  | 'PREFERENCES'
  | 'GOALS'
  | 'PROJECTS'
  | 'SKILLS'
  | 'LEARNING'
  | 'WORKFLOW'
  | 'IMPORTANT_FACTS'
  | 'CONVERSATION_CONTEXT'
  | 'temporary'
  | 'important'
  | 'long_term'
  | 'preference'
  | 'project'
  | 'goal'
  | 'instruction'
  | 'profile'
  | 'conversation_summary';

export type MemorySource = 'explicit_user' | 'assistant_detected' | 'manual_user' | 'system';

export interface MemoryItem {
  id: string;
  content: string;
  category: MemoryCategory;
  importance: number; // 0.0 to 1.0 or 1 to 10
  confidence?: number; // 0.0 to 1.0
  createdAt: number;
  updatedAt: number;
  lastAccessedAt: number;
  tags: string[];
  expiresAt?: number | null;
  source: MemorySource;
  metadata?: Record<string, any>;
}

export interface ScoredMemoryItem extends MemoryItem {
  relevanceScore: number;
  matchReasons?: string[];
}

export interface UserProfile {
  name: string;
  preferredLanguage: string;
  communicationStyle: string;
  interests: string[];
  skills: string[];
  projects: string[];
  goals: string[];
  preferences: Record<string, string>;
  lastUpdated: number;
}

export interface ConversationTurn {
  role: 'user' | 'assistant';
  text: string;
  timestamp: number;
  emotion?: string;
}

export interface ConversationSummary {
  id: string;
  timestamp: number;
  mainTopic: string;
  importantDecisions: string[];
  userPreferences: string[];
  importantFacts: string[];
  unfinishedTasks: string[];
  futureReferences: string[];
  turnsCount: number;
  durationMs: number;
}

export interface MemorySearchQuery {
  query: string;
  category?: MemoryCategory;
  minImportance?: number;
  limit?: number;
  includeExpired?: boolean;
}

export interface MemorySystemConfig {
  enabled: boolean;
  autoExtract: boolean;
  maxContextMemories: number;
  retentionDaysLowImportance: number; // e.g. 7 days
}

export interface MemoryExtractionResult {
  detected: boolean;
  memoriesToSave: Array<{
    content: string;
    category: MemoryCategory;
    importance: number;
    tags: string[];
    source: MemorySource;
  }>;
  profileUpdates?: Partial<UserProfile>;
  forgetQueries?: string[];
}
