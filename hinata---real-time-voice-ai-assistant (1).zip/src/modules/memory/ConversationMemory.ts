/**
 * ConversationMemory - Stores meaningful structured summaries of previous conversations.
 * Avoids storing every message verbatim by producing compact structured records containing:
 * mainTopic, importantDecisions, userPreferences, importantFacts, unfinishedTasks, futureReferences.
 */

import { ConversationSummary, ConversationTurn } from './MemoryTypes';
import { MemoryStorage } from './MemoryStorage';

export class ConversationMemory {
  private storage: MemoryStorage;
  private summaries: ConversationSummary[] = [];

  constructor(storage: MemoryStorage) {
    this.storage = storage;
    this.load();
  }

  public load(): void {
    this.summaries = this.storage.loadSummaries();
  }

  public getSummaries(): ConversationSummary[] {
    return [...this.summaries].sort((a, b) => b.timestamp - a.timestamp);
  }

  public getById(id: string): ConversationSummary | null {
    return this.summaries.find((s) => s.id === id) || null;
  }

  /**
   * Generates and stores a structured summary from active session turns.
   */
  public createSummaryFromTurns(params: {
    turns: ConversationTurn[];
    topic?: string;
    durationMs?: number;
  }): ConversationSummary | null {
    const { turns, topic, durationMs } = params;
    if (!turns || turns.length < 2) {
      // Don't save empty or single-greeting conversations
      return null;
    }

    const mainTopic = topic || this.inferMainTopic(turns);
    const importantDecisions = this.extractDecisions(turns);
    const userPreferences = this.extractPreferences(turns);
    const importantFacts = this.extractFacts(turns);
    const unfinishedTasks = this.extractUnfinishedTasks(turns);
    const futureReferences = this.extractFutureReferences(turns);

    const summary: ConversationSummary = {
      id: 'conv_' + Math.random().toString(36).substring(2, 9) + '_' + Date.now().toString(36),
      timestamp: Date.now(),
      mainTopic,
      importantDecisions,
      userPreferences,
      importantFacts,
      unfinishedTasks,
      futureReferences,
      turnsCount: turns.length,
      durationMs: durationMs || 0,
    };

    this.summaries.unshift(summary);
    // Keep max 25 recent summaries to prevent memory bloat
    if (this.summaries.length > 25) {
      this.summaries = this.summaries.slice(0, 25);
    }

    this.persist();
    return summary;
  }

  public saveSummaryDirect(summary: Omit<ConversationSummary, 'id' | 'timestamp'>): ConversationSummary {
    const newSummary: ConversationSummary = {
      ...summary,
      id: 'conv_' + Math.random().toString(36).substring(2, 9) + '_' + Date.now().toString(36),
      timestamp: Date.now(),
    };
    this.summaries.unshift(newSummary);
    this.persist();
    return newSummary;
  }

  public deleteSummary(id: string): boolean {
    const initialLen = this.summaries.length;
    this.summaries = this.summaries.filter((s) => s.id !== id);
    if (this.summaries.length !== initialLen) {
      this.persist();
      return true;
    }
    return false;
  }

  public clearAll(): void {
    this.summaries = [];
    this.persist();
  }

  /**
   * Formats past conversation highlights for AI context injection.
   */
  public getRecentSummariesForAI(limit: number = 3): string {
    const recents = this.getSummaries().slice(0, limit);
    if (recents.length === 0) return '';

    return recents
      .map((s) => {
        const dateStr = new Date(s.timestamp).toLocaleDateString('en-US', {
          month: 'short',
          day: 'numeric',
        });
        const details: string[] = [];
        if (s.importantDecisions.length > 0) details.push(`Decisions: ${s.importantDecisions.join('; ')}`);
        if (s.unfinishedTasks.length > 0) details.push(`Tasks: ${s.unfinishedTasks.join('; ')}`);
        if (s.importantFacts.length > 0) details.push(`Facts: ${s.importantFacts.join('; ')}`);
        const detailStr = details.length > 0 ? ` (${details.join(' | ')})` : '';
        return `- [${dateStr}] Topic: "${s.mainTopic}"${detailStr}`;
      })
      .join('\n');
  }

  private persist(): void {
    this.storage.saveSummaries(this.summaries);
  }

  private inferMainTopic(turns: ConversationTurn[]): string {
    const texts = turns.map((t) => t.text.toLowerCase()).join(' ');
    const candidates = [
      { kw: 'project', label: 'Project Planning & Development' },
      { kw: 'code', label: 'Software Architecture & Code' },
      { kw: 'weather', label: 'Weather & Travel' },
      { kw: 'calculate', label: 'Math & Financial Estimation' },
      { kw: 'music', label: 'Music & Audio Discussion' },
      { kw: 'movie', label: 'Films & Entertainment' },
      { kw: 'schedule', label: 'Schedule & Time Planning' },
      { kw: 'health', label: 'Fitness & Health' },
    ];
    for (const c of candidates) {
      if (texts.includes(c.kw)) return c.label;
    }
    // Fallback: use snippet of the first substantive user turn
    const firstUserTurn = turns.find((t) => t.role === 'user' && t.text.length > 8);
    if (firstUserTurn) {
      return firstUserTurn.text.slice(0, 48) + (firstUserTurn.text.length > 48 ? '...' : '');
    }
    return 'Voice Consultation & Discussion';
  }

  private extractDecisions(turns: ConversationTurn[]): string[] {
    const decisions: string[] = [];
    const decisionMarkers = ['decided to', 'agreed to', 'will go with', 'chosen', 'let us use', "let's use"];
    for (const turn of turns) {
      const lower = turn.text.toLowerCase();
      for (const marker of decisionMarkers) {
        if (lower.includes(marker)) {
          decisions.push(turn.text.slice(0, 80));
          break;
        }
      }
    }
    return Array.from(new Set(decisions)).slice(0, 3);
  }

  private extractPreferences(turns: ConversationTurn[]): string[] {
    const prefs: string[] = [];
    const prefMarkers = ['prefer', 'favorite', 'i like', 'i love', 'my preference'];
    for (const turn of turns) {
      if (turn.role === 'user') {
        const lower = turn.text.toLowerCase();
        for (const marker of prefMarkers) {
          if (lower.includes(marker)) {
            prefs.push(turn.text.slice(0, 80));
            break;
          }
        }
      }
    }
    return Array.from(new Set(prefs)).slice(0, 3);
  }

  private extractFacts(turns: ConversationTurn[]): string[] {
    const facts: string[] = [];
    for (const turn of turns) {
      if (turn.role === 'user') {
        const lower = turn.text.toLowerCase();
        if (lower.includes('my name is') || lower.includes('i am working on') || lower.includes('i live in')) {
          facts.push(turn.text.slice(0, 80));
        }
      }
    }
    return Array.from(new Set(facts)).slice(0, 3);
  }

  private extractUnfinishedTasks(turns: ConversationTurn[]): string[] {
    const tasks: string[] = [];
    const taskMarkers = ['need to finish', 'todo', 'still have to', 'next time', 'later'];
    for (const turn of turns) {
      const lower = turn.text.toLowerCase();
      for (const marker of taskMarkers) {
        if (lower.includes(marker)) {
          tasks.push(turn.text.slice(0, 80));
          break;
        }
      }
    }
    return Array.from(new Set(tasks)).slice(0, 3);
  }

  private extractFutureReferences(turns: ConversationTurn[]): string[] {
    const refs: string[] = [];
    const refMarkers = ['remind me', 'next meeting', 'follow up', 'tomorrow'];
    for (const turn of turns) {
      const lower = turn.text.toLowerCase();
      for (const marker of refMarkers) {
        if (lower.includes(marker)) {
          refs.push(turn.text.slice(0, 80));
          break;
        }
      }
    }
    return Array.from(new Set(refs)).slice(0, 3);
  }
}
