/**
 * ProfileMemory - Structured User Profile manager for Hinata AI.
 * Handles Name, Preferred Language, Communication Style, Interests, Skills,
 * Projects, Goals, and Preferences with intelligent upsert and deduplication.
 */

import { UserProfile } from './MemoryTypes';
import { MemoryStorage } from './MemoryStorage';

export class ProfileMemory {
  private storage: MemoryStorage;
  private profile: UserProfile;

  constructor(storage: MemoryStorage) {
    this.storage = storage;
    this.profile = this.storage.loadProfile();
  }

  public getProfile(): Readonly<UserProfile> {
    return { ...this.profile };
  }

  /**
   * Intelligently updates a field in the profile without creating duplicate or conflicting records.
   */
  public updateField(
    field: keyof UserProfile,
    value: any,
    action: 'set' | 'append' | 'remove' = 'set'
  ): UserProfile {
    switch (field) {
      case 'name':
      case 'preferredLanguage':
      case 'communicationStyle': {
        const strVal = String(value || '').trim();
        if (strVal) {
          this.profile[field] = strVal;
        }
        break;
      }

      case 'interests':
      case 'skills':
      case 'projects':
      case 'goals': {
        const existingList = Array.isArray(this.profile[field]) ? [...this.profile[field]] : [];
        const incomingItems: string[] = Array.isArray(value)
          ? value.map((v) => String(v).trim()).filter(Boolean)
          : String(value || '')
              .split(/[,;\n]/)
              .map((v) => v.trim())
              .filter(Boolean);

        if (action === 'set') {
          this.profile[field] = Array.from(new Set(incomingItems));
        } else if (action === 'append') {
          const merged = [...existingList, ...incomingItems];
          this.profile[field] = Array.from(new Set(merged));
        } else if (action === 'remove') {
          const toRemove = new Set(incomingItems.map((i) => i.toLowerCase()));
          this.profile[field] = existingList.filter((item) => !toRemove.has(item.toLowerCase()));
        }
        break;
      }

      case 'preferences': {
        if (typeof value === 'object' && value !== null) {
          if (action === 'set') {
            this.profile.preferences = { ...value };
          } else {
            // merge
            this.profile.preferences = { ...this.profile.preferences, ...value };
          }
        } else if (typeof value === 'string') {
          // Parse "key: value" or "key = value"
          const match = value.match(/^([^:=]+)[:=](.+)$/);
          if (match) {
            const k = match[1].trim();
            const v = match[2].trim();
            if (k && v) {
              this.profile.preferences[k] = v;
            }
          }
        }
        break;
      }
    }

    this.profile.lastUpdated = Date.now();
    this.persist();
    return { ...this.profile };
  }

  /**
   * Sets multiple profile fields at once.
   */
  public setProfile(updates: Partial<UserProfile>): UserProfile {
    for (const [key, val] of Object.entries(updates)) {
      if (key === 'lastUpdated') continue;
      this.updateField(key as keyof UserProfile, val, 'set');
    }
    return { ...this.profile };
  }

  public resetProfile(): void {
    this.profile = {
      name: '',
      preferredLanguage: 'English',
      communicationStyle: 'Natural, conversational, witty & supportive',
      interests: [],
      skills: [],
      projects: [],
      goals: [],
      preferences: {},
      lastUpdated: Date.now(),
    };
    this.persist();
  }

  /**
   * Compact text representation of user profile for injecting into AI prompt context.
   */
  public getFormattedProfileForAI(): string {
    const parts: string[] = [];

    if (this.profile.name) {
      parts.push(`- User's Name: ${this.profile.name}`);
    }
    if (this.profile.preferredLanguage && this.profile.preferredLanguage !== 'English') {
      parts.push(`- Preferred Language: ${this.profile.preferredLanguage}`);
    }
    if (this.profile.communicationStyle) {
      parts.push(`- Communication Style: ${this.profile.communicationStyle}`);
    }
    if (this.profile.projects.length > 0) {
      parts.push(`- Active Projects: ${this.profile.projects.join(', ')}`);
    }
    if (this.profile.goals.length > 0) {
      parts.push(`- Long-Term Goals: ${this.profile.goals.join(', ')}`);
    }
    if (this.profile.skills.length > 0) {
      parts.push(`- Skills & Expertise: ${this.profile.skills.join(', ')}`);
    }
    if (this.profile.interests.length > 0) {
      parts.push(`- Core Interests: ${this.profile.interests.join(', ')}`);
    }
    if (Object.keys(this.profile.preferences).length > 0) {
      const prefs = Object.entries(this.profile.preferences)
        .map(([k, v]) => `${k}: ${v}`)
        .join('; ');
      parts.push(`- Known Preferences: ${prefs}`);
    }

    return parts.join('\n');
  }

  private persist(): void {
    this.storage.saveProfile(this.profile);
  }
}
