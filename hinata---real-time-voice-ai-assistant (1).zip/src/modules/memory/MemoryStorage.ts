/**
 * MemoryStorage - Resilient persistent storage layer for Hinata AI Memory System.
 * Supports LocalStorage with safe in-memory fallback and JSON export/import.
 */

import { MemoryItem, UserProfile, ConversationSummary, MemorySystemConfig } from './MemoryTypes';

const STORAGE_KEYS = {
  MEMORIES: 'hinata_memories_v1',
  PROFILE: 'hinata_profile_v1',
  SUMMARIES: 'hinata_summaries_v1',
  CONFIG: 'hinata_memory_config_v1',
};

const DEFAULT_PROFILE: UserProfile = {
  name: 'Aman',
  preferredLanguage: 'English',
  communicationStyle: 'Natural, conversational, witty & supportive',
  interests: ['Technology', 'AI', 'Design'],
  skills: [],
  projects: [],
  goals: [],
  preferences: {},
  lastUpdated: Date.now(),
};

const DEFAULT_CONFIG: MemorySystemConfig = {
  enabled: true,
  autoExtract: true,
  maxContextMemories: 8,
  retentionDaysLowImportance: 7,
};

// Initial starter memories to give Hinata a natural baseline
const SEED_MEMORIES: MemoryItem[] = [
  {
    id: 'seed-1',
    content: 'Hinata is your personal real-time voice assistant with emotional intelligence, memory, and quick witty banter.',
    category: 'instruction',
    importance: 8,
    createdAt: Date.now() - 3600000,
    updatedAt: Date.now() - 3600000,
    lastAccessedAt: Date.now(),
    tags: ['system', 'hinata', 'personality'],
    source: 'system',
  },
];

export class MemoryStorage {
  private inMemoryFallback: Record<string, string> = {};

  private isLocalStorageAvailable(): boolean {
    try {
      if (typeof window === 'undefined' || !window.localStorage) return false;
      const testKey = '__hinata_test_storage__';
      window.localStorage.setItem(testKey, '1');
      window.localStorage.removeItem(testKey);
      return true;
    } catch {
      return false;
    }
  }

  private getItem(key: string): string | null {
    if (this.isLocalStorageAvailable()) {
      try {
        return window.localStorage.getItem(key);
      } catch (err) {
        console.warn(`[MemoryStorage] Read error for ${key}:`, err);
      }
    }
    return this.inMemoryFallback[key] || null;
  }

  private setItem(key: string, value: string): void {
    if (this.isLocalStorageAvailable()) {
      try {
        window.localStorage.setItem(key, value);
        return;
      } catch (err) {
        console.warn(`[MemoryStorage] Write error for ${key}:`, err);
      }
    }
    this.inMemoryFallback[key] = value;
  }

  private removeItem(key: string): void {
    if (this.isLocalStorageAvailable()) {
      try {
        window.localStorage.removeItem(key);
      } catch (err) {
        console.warn(`[MemoryStorage] Remove error for ${key}:`, err);
      }
    }
    delete this.inMemoryFallback[key];
  }

  // Load All Memories
  public loadMemories(): MemoryItem[] {
    const raw = this.getItem(STORAGE_KEYS.MEMORIES);
    if (!raw) {
      this.saveMemories(SEED_MEMORIES);
      return [...SEED_MEMORIES];
    }
    try {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) {
        return parsed;
      }
      return [...SEED_MEMORIES];
    } catch (err) {
      console.error('[MemoryStorage] Failed to parse memories:', err);
      return [...SEED_MEMORIES];
    }
  }

  // Save All Memories
  public saveMemories(memories: MemoryItem[]): void {
    try {
      this.setItem(STORAGE_KEYS.MEMORIES, JSON.stringify(memories));
    } catch (err) {
      console.error('[MemoryStorage] Failed to serialize memories:', err);
    }
  }

  // Load User Profile
  public loadProfile(): UserProfile {
    const raw = this.getItem(STORAGE_KEYS.PROFILE);
    if (!raw) {
      this.saveProfile(DEFAULT_PROFILE);
      return { ...DEFAULT_PROFILE };
    }
    try {
      const parsed = JSON.parse(raw);
      const merged = { ...DEFAULT_PROFILE, ...parsed };
      if (!merged.name || !merged.name.trim()) {
        merged.name = 'Aman';
      }
      return merged;
    } catch (err) {
      console.error('[MemoryStorage] Failed to parse profile:', err);
      return { ...DEFAULT_PROFILE };
    }
  }

  // Save User Profile
  public saveProfile(profile: UserProfile): void {
    try {
      this.setItem(STORAGE_KEYS.PROFILE, JSON.stringify(profile));
    } catch (err) {
      console.error('[MemoryStorage] Failed to serialize profile:', err);
    }
  }

  // Load Conversation Summaries
  public loadSummaries(): ConversationSummary[] {
    const raw = this.getItem(STORAGE_KEYS.SUMMARIES);
    if (!raw) return [];
    try {
      const parsed = JSON.parse(raw);
      return Array.isArray(parsed) ? parsed : [];
    } catch (err) {
      console.error('[MemoryStorage] Failed to parse summaries:', err);
      return [];
    }
  }

  // Save Conversation Summaries
  public saveSummaries(summaries: ConversationSummary[]): void {
    try {
      this.setItem(STORAGE_KEYS.SUMMARIES, JSON.stringify(summaries));
    } catch (err) {
      console.error('[MemoryStorage] Failed to serialize summaries:', err);
    }
  }

  // Load System Config
  public loadConfig(): MemorySystemConfig {
    const raw = this.getItem(STORAGE_KEYS.CONFIG);
    if (!raw) return { ...DEFAULT_CONFIG };
    try {
      const parsed = JSON.parse(raw);
      return { ...DEFAULT_CONFIG, ...parsed };
    } catch {
      return { ...DEFAULT_CONFIG };
    }
  }

  // Save System Config
  public saveConfig(config: MemorySystemConfig): void {
    try {
      this.setItem(STORAGE_KEYS.CONFIG, JSON.stringify(config));
    } catch (err) {
      console.error('[MemoryStorage] Failed to serialize config:', err);
    }
  }

  // Clear All Persistent Memory Data
  public clearAll(): void {
    this.removeItem(STORAGE_KEYS.MEMORIES);
    this.removeItem(STORAGE_KEYS.PROFILE);
    this.removeItem(STORAGE_KEYS.SUMMARIES);
    this.saveMemories(SEED_MEMORIES);
    this.saveProfile(DEFAULT_PROFILE);
  }

  // Export full memory backup as JSON string
  public exportBackup(): string {
    const data = {
      version: 1,
      timestamp: Date.now(),
      memories: this.loadMemories(),
      profile: this.loadProfile(),
      summaries: this.loadSummaries(),
      config: this.loadConfig(),
    };
    return JSON.stringify(data, null, 2);
  }

  // Import memory backup
  public importBackup(jsonString: string): boolean {
    try {
      const data = JSON.parse(jsonString);
      if (Array.isArray(data.memories)) {
        this.saveMemories(data.memories);
      }
      if (data.profile && typeof data.profile === 'object') {
        this.saveProfile({ ...DEFAULT_PROFILE, ...data.profile });
      }
      if (Array.isArray(data.summaries)) {
        this.saveSummaries(data.summaries);
      }
      if (data.config && typeof data.config === 'object') {
        this.saveConfig({ ...DEFAULT_CONFIG, ...data.config });
      }
      return true;
    } catch (err) {
      console.error('[MemoryStorage] Import failed:', err);
      return false;
    }
  }
}
