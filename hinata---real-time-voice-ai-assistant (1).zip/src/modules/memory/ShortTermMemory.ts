/**
 * ShortTermMemory - Manages information from the current active conversation.
 * Tracks current topic, recent messages, active task, user instructions,
 * recent questions, emotional context, and temporary session details.
 */

import { ConversationTurn } from './MemoryTypes';

export interface ShortTermSnapshot {
  currentTopic: string;
  recentTurns: ConversationTurn[];
  currentTask: string | null;
  activeInstructions: string[];
  recentQuestions: string[];
  emotionalContext: string | null;
  temporaryDetails: Record<string, any>;
  turnsCount: number;
  sessionStartTime: number;
}

export class ShortTermMemory {
  private currentTopic: string = 'General Conversation';
  private recentTurns: ConversationTurn[] = [];
  private currentTask: string | null = null;
  private activeInstructions: string[] = [];
  private recentQuestions: string[] = [];
  private emotionalContext: string | null = null;
  private temporaryDetails: Record<string, any> = {};
  private sessionStartTime: number = Date.now();
  private maxTurns: number = 30;

  constructor() {
    this.sessionStartTime = Date.now();
  }

  public recordTurn(role: 'user' | 'assistant', text: string, emotion?: string): void {
    if (!text || text.trim().length === 0) return;

    const turn: ConversationTurn = {
      role,
      text: text.trim(),
      timestamp: Date.now(),
      emotion,
    };

    this.recentTurns.push(turn);
    if (this.recentTurns.length > this.maxTurns) {
      this.recentTurns.shift();
    }

    // If user asked a question, track it in recentQuestions
    if (role === 'user' && text.includes('?')) {
      this.recentQuestions.push(text.trim());
      if (this.recentQuestions.length > 5) {
        this.recentQuestions.shift();
      }
    }

    // Auto-detect topic shift heuristics if keywords appear
    this.detectTopicShift(text);
  }

  public setCurrentTopic(topic: string): void {
    if (topic && topic.trim()) {
      this.currentTopic = topic.trim();
    }
  }

  public getCurrentTopic(): string {
    return this.currentTopic;
  }

  public setCurrentTask(task: string | null): void {
    this.currentTask = task ? task.trim() : null;
  }

  public getCurrentTask(): string | null {
    return this.currentTask;
  }

  public addInstruction(instruction: string): void {
    const trimmed = instruction.trim();
    if (trimmed && !this.activeInstructions.includes(trimmed)) {
      this.activeInstructions.push(trimmed);
      if (this.activeInstructions.length > 10) {
        this.activeInstructions.shift();
      }
    }
  }

  public removeInstruction(instruction: string): void {
    this.activeInstructions = this.activeInstructions.filter(
      (inst) => inst.toLowerCase() !== instruction.toLowerCase()
    );
  }

  public setEmotionalContext(emotion: string, reason?: string): void {
    this.emotionalContext = reason ? `${emotion} (${reason})` : emotion;
  }

  public setTemporaryDetail(key: string, value: any): void {
    this.temporaryDetails[key] = value;
  }

  public getTemporaryDetail(key: string): any {
    return this.temporaryDetails[key];
  }

  public getTurns(): ConversationTurn[] {
    return [...this.recentTurns];
  }

  public getSessionDuration(): number {
    return Date.now() - this.sessionStartTime;
  }

  public getSnapshot(): ShortTermSnapshot {
    return {
      currentTopic: this.currentTopic,
      recentTurns: [...this.recentTurns],
      currentTask: this.currentTask,
      activeInstructions: [...this.activeInstructions],
      recentQuestions: [...this.recentQuestions],
      emotionalContext: this.emotionalContext,
      temporaryDetails: { ...this.temporaryDetails },
      turnsCount: this.recentTurns.length,
      sessionStartTime: this.sessionStartTime,
    };
  }

  public resetSession(): void {
    this.currentTopic = 'General Conversation';
    this.recentTurns = [];
    this.currentTask = null;
    this.activeInstructions = [];
    this.recentQuestions = [];
    this.emotionalContext = null;
    this.temporaryDetails = {};
    this.sessionStartTime = Date.now();
  }

  private detectTopicShift(text: string): void {
    const lower = text.toLowerCase();
    const topicKeywords: Record<string, string> = {
      project: 'Active Project Discussion',
      code: 'Coding & Architecture',
      coding: 'Coding & Architecture',
      weather: 'Weather & Forecast',
      time: 'Time & Scheduling',
      math: 'Calculations & Numbers',
      movie: 'Entertainment & Cinema',
      music: 'Music & Audio',
      travel: 'Travel & Exploration',
      food: 'Culinary & Dining',
      coffee: 'Coffee & Drinks',
      work: 'Career & Work',
      design: 'Design & Visuals',
      ai: 'Artificial Intelligence',
    };

    for (const [kw, topicName] of Object.entries(topicKeywords)) {
      if (lower.includes(kw)) {
        this.currentTopic = topicName;
        break;
      }
    }
  }
}
