/**
 * MemoryExtractor - Intelligently detects and classifies important information
 * from conversational text and voice transcripts.
 *
 * Distinguishes between things worth remembering and temporary conversational filler.
 * Recognizes explicit triggers: "Remember that...", "From now on...", "My favorite...",
 * "I prefer...", "I am working on...", "My goal is...", "Always...", "Never...",
 * and explicit forgetting triggers: "Forget this", "Delete that memory".
 */

import { MemoryExtractionResult, MemoryCategory } from './MemoryTypes';

export class MemoryExtractor {
  // Ignored phrases that must never be stored as memory
  private ignoredPatterns = [
    /^(hi|hello|hey|good morning|good evening|good night|bye|goodbye|see ya|ok|okay|sure|thanks|thank you|yes|no|cool|alright|got it|nice)$/i,
    /^(what's up|how are you|how do you do|can you hear me|testing|test 1 2 3)$/i,
  ];

  /**
   * Evaluates text to extract new memories, profile updates, or forget requests.
   */
  public extract(text: string): MemoryExtractionResult {
    const result: MemoryExtractionResult = {
      detected: false,
      memoriesToSave: [],
      profileUpdates: {},
      forgetQueries: [],
    };

    if (!text || typeof text !== 'string') return result;
    const cleanText = text.trim();
    if (cleanText.length < 5) return result;

    // Strict Privacy & Security Rule: NEVER store passwords, secrets, api keys, pins, credit cards
    const sensitivePattern = /(password|pin code|secret key|api[ _-]?key|bearer token|auth token|cvv|credit card|private key)/i;
    if (sensitivePattern.test(cleanText)) {
      console.warn('[MemoryExtractor] Blocked sensitive information from being stored in memory vault.');
      return result;
    }

    // Check if whole text is generic conversational filler
    for (const pattern of this.ignoredPatterns) {
      if (pattern.test(cleanText)) {
        return result;
      }
    }

    const lower = cleanText.toLowerCase();

    // 1. Check for FORGET / DELETE triggers
    const forgetPatterns = [
      /forget (?:that|what i said|about|everything about|my) (.+)/i,
      /delete (?:that|the) memory(?: about)? (.+)/i,
      /don'?t remember (?:this|that|about)? (.+)/i,
      /remove (?:that|my) (.+) from (?:your )?memory/i,
    ];
    for (const fp of forgetPatterns) {
      const match = cleanText.match(fp);
      if (match && match[1]) {
        result.detected = true;
        result.forgetQueries?.push(match[1].trim());
      }
    }

    // 2. Check for EXPLICIT "Remember that..." or "Remember this..."
    const explicitPatterns = [
      /(?:please )?remember that (.+)/i,
      /(?:please )?remember this:? (.+)/i,
      /(?:make sure to )?remember (?:that )?(.+)/i,
    ];
    for (const ep of explicitPatterns) {
      const match = cleanText.match(ep);
      if (match && match[1]) {
        const memoryContent = match[1].trim();
        const { category, tags } = this.inferCategoryAndTags(memoryContent);
        result.detected = true;
        result.memoriesToSave.push({
          content: memoryContent,
          category: category || 'important',
          importance: 9, // Explicit requests get high importance
          tags: ['explicit', ...tags],
          source: 'explicit_user',
        });
      }
    }

    // 3. Check for BEHAVIORAL INSTRUCTIONS: "From now on...", "Always...", "Never..."
    const instructionPatterns = [
      /from now on[, ]+(.+)/i,
      /always (.+)/i,
      /never (.+)/i,
    ];
    for (const ip of instructionPatterns) {
      const match = cleanText.match(ip);
      if (match && match[1]) {
        result.detected = true;
        result.memoriesToSave.push({
          content: cleanText,
          category: 'instruction',
          importance: 9,
          tags: ['instruction', 'rule'],
          source: 'explicit_user',
        });
        break;
      }
    }

    // 4. Check for USER NAME / IDENTITY
    const nameMatch = cleanText.match(/(?:my name is|call me|i am|i'm) ([A-Z][a-z]+(?: [A-Z][a-z]+)?)/i);
    if (nameMatch && nameMatch[1] && !['Hinata', 'Assistant', 'Working', 'Going', 'Happy', 'Doing'].includes(nameMatch[1])) {
      result.detected = true;
      result.profileUpdates = result.profileUpdates || {};
      result.profileUpdates.name = nameMatch[1].trim();
      result.memoriesToSave.push({
        content: `User's name is ${nameMatch[1].trim()}`,
        category: 'profile',
        importance: 10,
        tags: ['name', 'identity', 'profile'],
        source: 'explicit_user',
      });
    }

    // 5. Check for PREFERENCES
    const prefPatterns = [
      /(?:my favorite|my favourite) (.+?) (?:is|are) (.+)/i,
      /i prefer (.+?)(?: over (.+))?$/i,
      /i (?:really )?(?:like|love|enjoy) (.+)/i,
      /i (?:hate|dislike|can't stand) (.+)/i,
    ];
    for (const pp of prefPatterns) {
      const match = cleanText.match(pp);
      if (match) {
        result.detected = true;
        result.memoriesToSave.push({
          content: cleanText,
          category: 'preference',
          importance: 8,
          tags: ['preference', 'user_taste'],
          source: 'assistant_detected',
        });
        break;
      }
    }

    // 6. Check for PROJECTS
    const projectPatterns = [
      /i am working on (?:a |an )?(.+)/i,
      /i'm working on (?:a |an )?(.+)/i,
      /my project is (?:called )?(.+)/i,
      /building (?:a |an )?(.+)/i,
    ];
    for (const proj of projectPatterns) {
      const match = cleanText.match(proj);
      if (match && match[1]) {
        result.detected = true;
        const projName = match[1].trim().slice(0, 50);
        result.memoriesToSave.push({
          content: cleanText,
          category: 'project',
          importance: 8,
          tags: ['project', 'work', projName.toLowerCase()],
          source: 'assistant_detected',
        });
        result.profileUpdates = result.profileUpdates || {};
        result.profileUpdates.projects = [projName];
        break;
      }
    }

    // 7. Check for GOALS
    const goalPatterns = [
      /my goal is (?:to )?(.+)/i,
      /i want to achieve (.+)/i,
      /i plan to (.+)/i,
      /my aim is (?:to )?(.+)/i,
    ];
    for (const gp of goalPatterns) {
      const match = cleanText.match(gp);
      if (match && match[1]) {
        result.detected = true;
        const goalText = match[1].trim().slice(0, 60);
        result.memoriesToSave.push({
          content: cleanText,
          category: 'goal',
          importance: 8,
          tags: ['goal', 'aspiration'],
          source: 'assistant_detected',
        });
        result.profileUpdates = result.profileUpdates || {};
        result.profileUpdates.goals = [goalText];
        break;
      }
    }

    // 8. Check for LANGUAGE PREFERENCE
    const langMatch = cleanText.match(/(?:i prefer to speak|speak in|my language is|switch to|prefer) (hindi|english|japanese|spanish|french|german|mandarin|italian|korean)/i);
    if (langMatch && langMatch[1]) {
      const lang = langMatch[1].charAt(0).toUpperCase() + langMatch[1].slice(1).toLowerCase();
      result.detected = true;
      result.profileUpdates = result.profileUpdates || {};
      result.profileUpdates.preferredLanguage = lang;
      result.memoriesToSave.push({
        content: `User prefers communicating in ${lang}`,
        category: 'preference',
        importance: 9,
        tags: ['language', 'preference', 'locale'],
        source: 'explicit_user',
      });
    }

    return result;
  }

  private inferCategoryAndTags(text: string): { category: MemoryCategory; tags: string[] } {
    const lower = text.toLowerCase();
    const tags: string[] = [];

    if (lower.includes('project') || lower.includes('app') || lower.includes('build') || lower.includes('code')) {
      tags.push('project');
      return { category: 'project', tags };
    }
    if (lower.includes('goal') || lower.includes('aim') || lower.includes('target') || lower.includes('plan')) {
      tags.push('goal');
      return { category: 'goal', tags };
    }
    if (lower.includes('prefer') || lower.includes('favorite') || lower.includes('like') || lower.includes('love')) {
      tags.push('preference');
      return { category: 'preference', tags };
    }
    if (lower.includes('always') || lower.includes('never') || lower.includes('rule') || lower.includes('don\'t')) {
      tags.push('instruction');
      return { category: 'instruction', tags };
    }
    if (lower.includes('name') || lower.includes('live in') || lower.includes('birthday') || lower.includes('job')) {
      tags.push('profile');
      return { category: 'profile', tags };
    }

    return { category: 'important', tags: ['general'] };
  }
}
