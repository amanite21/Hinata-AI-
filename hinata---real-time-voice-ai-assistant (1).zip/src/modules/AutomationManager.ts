export { AutomationActions as AutomationManager } from './device/AutomationActions';
