/**
 * MicrophoneManager - Master Centralized Android & Web Microphone Controller for Hinata AI.
 *
 * Enforces strict architectural separation:
 * 1. Android Permission State: GRANTED / DENIED / PROMPT / PERMANENTLY_DENIED
 *    - Handled via official runtime permission flow.
 *    - Never repeatedly requested once GRANTED.
 *    - App restart preserves GRANTED status without auto-prompting.
 *    - Mic OFF NEVER revokes or changes Android permission.
 *
 * 2. Microphone Capture State: IDLE / STARTING / LISTENING / STOPPING / ERROR
 *    - Single microphone owner with coordinated priority (LiveSession, ChatVoice, Dictation, WakeWord).
 *    - State machine protects against double-start and double-stop.
 *    - Rapid taps safely handled without duplicate streams or crashes.
 *
 * 3. Unified Audio Pipeline:
 *    - Coordinates single MediaStream, AudioContext, real-time volume metering, and PCM16 streaming.
 *    - Full Android lifecycle handling (background/resume/configuration changes).
 */

export type MicrophoneState = 'IDLE' | 'REQUESTING_PERMISSION' | 'STARTING' | 'LISTENING' | 'STOPPING' | 'ERROR';
export type MicrophoneOwner = 'live_session' | 'chat_voice' | 'dictation' | 'wake_word' | 'settings_test' | null;
export type MicPermissionStatus = 'granted' | 'denied' | 'requesting' | 'prompt' | 'permanently_denied';

export interface MicrophoneAudioOptions {
  sampleRate?: number;
  channelCount?: number;
  echoCancellation?: boolean;
  noiseSuppression?: boolean;
  autoGainControl?: boolean;
  streamPcm16?: boolean;
}

export type MicStateListener = (state: MicrophoneState, owner: MicrophoneOwner, error?: string | null) => void;
export type MicVolumeListener = (volume: number) => void;
export type MicPcmListener = (base64Pcm16: string) => void;
export type MicPermissionListener = (status: MicPermissionStatus) => void;

const PERM_STORAGE_KEY = 'hinata_mic_permission_status_v2';
const PERM_DENIED_COUNT_KEY = 'hinata_mic_denied_count';

export class MicrophoneManager {
  private static instance: MicrophoneManager | null = null;

  // States
  private state: MicrophoneState = 'IDLE';
  private currentOwner: MicrophoneOwner = null;
  private permissionStatus: MicPermissionStatus = 'prompt';
  private errorMessage: string | null = null;

  // Single shared audio pipeline
  private mediaStream: MediaStream | null = null;
  private audioContext: AudioContext | null = null;
  private sourceNode: MediaStreamAudioSourceNode | null = null;
  private analyserNode: AnalyserNode | null = null;
  private processorNode: ScriptProcessorNode | null = null;
  private silentGainNode: GainNode | null = null;

  // Audio metering
  private freqData: Uint8Array = new Uint8Array(128);
  private currentVolume: number = 0;
  private volumeInterval: any = null;

  // Options & listeners
  private options: MicrophoneAudioOptions = {
    sampleRate: 16000,
    channelCount: 1,
    echoCancellation: true,
    noiseSuppression: true,
    autoGainControl: true,
    streamPcm16: false,
  };

  private stateListeners: Set<MicStateListener> = new Set();
  private volumeListeners: Set<MicVolumeListener> = new Set();
  private pcmListeners: Set<MicPcmListener> = new Set();
  private permissionListeners: Set<MicPermissionListener> = new Set();
  private teardownCallbacks: Set<() => void> = new Set();

  // Concurrency & Transition locking
  private isTransitioning: boolean = false;
  private stopPromise: Promise<void> | null = null;
  private currentOpId: number = 0;

  // Background resume memory
  private resumeOwnerAfterBackground: MicrophoneOwner = null;

  private constructor() {
    this.initPermissionState();
    this.setupLifecycleListeners();
  }

  public static getInstance(): MicrophoneManager {
    if (!MicrophoneManager.instance) {
      MicrophoneManager.instance = new MicrophoneManager();
    }
    return MicrophoneManager.instance;
  }

  // ============================================================================
  // 1. PERMISSION MANAGEMENT (RECORD_AUDIO)
  // ============================================================================

  /**
   * Initializes permission status from storage and registers OS permission watchers.
   * Runs non-intrusively on startup — NEVER opens a dialog automatically.
   */
  private initPermissionState(): void {
    if (typeof window === 'undefined') return;

    try {
      const stored = localStorage.getItem(PERM_STORAGE_KEY) as MicPermissionStatus | null;
      if (stored === 'granted' || stored === 'denied' || stored === 'permanently_denied') {
        this.permissionStatus = stored;
      }
    } catch {}

    // Check system permission query if supported (without popping any prompt)
    if (typeof navigator !== 'undefined' && navigator.permissions?.query) {
      navigator.permissions
        .query({ name: 'microphone' as any })
        .then((permStatus) => {
          this.handlePermissionQueryChange(permStatus.state as PermissionState);
          permStatus.onchange = () => {
            this.handlePermissionQueryChange(permStatus.state as PermissionState);
          };
        })
        .catch(() => {
          // Permissions API query for microphone unsupported in some webviews
        });
    }
  }

  private handlePermissionQueryChange(state: PermissionState): void {
    let mapped: MicPermissionStatus = 'prompt';
    if (state === 'granted') {
      mapped = 'granted';
      try {
        localStorage.setItem(PERM_STORAGE_KEY, 'granted');
        localStorage.removeItem(PERM_DENIED_COUNT_KEY);
      } catch {}
    } else if (state === 'denied') {
      const count = parseInt(localStorage.getItem(PERM_DENIED_COUNT_KEY) || '1', 10);
      mapped = count >= 2 ? 'permanently_denied' : 'denied';
      try {
        localStorage.setItem(PERM_STORAGE_KEY, mapped);
      } catch {}
    } else {
      mapped = 'prompt';
      try {
        localStorage.setItem(PERM_STORAGE_KEY, 'prompt');
      } catch {}
    }

    if (this.permissionStatus !== mapped) {
      this.permissionStatus = mapped;
      this.notifyPermissionChange();
    }
  }

  /**
   * Checks current permission status without prompting.
   */
  public async checkPermission(): Promise<MicPermissionStatus> {
    if (typeof window === 'undefined') return 'prompt';

    // Native Android wrapper bridge check if provided
    if ((window as any).Android?.checkPermission) {
      try {
        const has = (window as any).Android.checkPermission('android.permission.RECORD_AUDIO');
        const st: MicPermissionStatus = has ? 'granted' : 'prompt';
        this.permissionStatus = st;
        return st;
      } catch (e) {
        console.warn('[MicrophoneManager] Android bridge check error:', e);
      }
    }

    if (navigator.permissions?.query) {
      try {
        const res = await navigator.permissions.query({ name: 'microphone' as any });
        this.handlePermissionQueryChange(res.state as PermissionState);
        return this.permissionStatus;
      } catch {}
    }

    return this.permissionStatus;
  }

  /**
   * Requests Android RECORD_AUDIO permission.
   * - If already GRANTED: immediately returns without prompt.
   * - If prompt/denied: requests once.
   */
  public async requestPermission(): Promise<{
    granted: boolean;
    status: MicPermissionStatus;
    message: string;
  }> {
    if (typeof window === 'undefined') {
      return { granted: false, status: 'prompt', message: 'Window not available' };
    }

    // 1. If already granted, NEVER re-prompt!
    if (this.permissionStatus === 'granted') {
      return {
        granted: true,
        status: 'granted',
        message: 'Microphone permission already granted.',
      };
    }

    // 2. If permanently denied, inform user to open settings
    if (this.permissionStatus === 'permanently_denied') {
      return {
        granted: false,
        status: 'permanently_denied',
        message: 'Microphone permission is disabled. Open Settings to enable microphone access.',
      };
    }

    // 3. Official Android native bridge request if present
    this.setPermissionStatus('requesting');

    if ((window as any).Android?.requestPermission) {
      try {
        const res = (window as any).Android.requestPermission('android.permission.RECORD_AUDIO');
        if (res) {
          this.setPermissionStatus('granted');
          return { granted: true, status: 'granted', message: 'Microphone permission granted.' };
        }
      } catch (e) {
        console.warn('[MicrophoneManager] Android bridge request error:', e);
      }
    }

    // 4. Standard WebRTC / WebView prompt request
    try {
      console.log('[MicrophoneManager] Requesting official RECORD_AUDIO permission...');
      const testStream = await navigator.mediaDevices.getUserMedia({ audio: true });
      // Cleanly release the test tracks immediately
      testStream.getTracks().forEach((track) => track.stop());

      this.setPermissionStatus('granted');
      try {
        localStorage.removeItem(PERM_DENIED_COUNT_KEY);
      } catch {}

      return {
        granted: true,
        status: 'granted',
        message: 'Microphone permission granted.',
      };
    } catch (err: any) {
      console.warn('[MicrophoneManager] Microphone permission denied or rejected:', err);
      const deniedCount = parseInt(localStorage.getItem(PERM_DENIED_COUNT_KEY) || '0', 10) + 1;
      try {
        localStorage.setItem(PERM_DENIED_COUNT_KEY, String(deniedCount));
      } catch {}

      const isPermanent = deniedCount >= 2 || err?.name === 'NotAllowedError';
      const status: MicPermissionStatus = isPermanent ? 'permanently_denied' : 'denied';
      this.setPermissionStatus(status);

      return {
        granted: false,
        status,
        message:
          status === 'permanently_denied'
            ? 'Microphone permission is disabled. Open Settings to enable microphone access.'
            : 'Microphone permission was denied.',
      };
    }
  }

  private setPermissionStatus(status: MicPermissionStatus): void {
    this.permissionStatus = status;
    try {
      localStorage.setItem(PERM_STORAGE_KEY, status);
    } catch {}
    this.notifyPermissionChange();
  }

  public getPermissionStatus(): MicPermissionStatus {
    return this.permissionStatus;
  }

  public isPermissionGranted(): boolean {
    return this.permissionStatus === 'granted';
  }

  /**
   * Opens Android Application Settings so user can enable permissions if permanently denied.
   */
  public openAppSettings(): void {
    if (typeof window === 'undefined') return;

    // 1. Android companion bridge if available
    if ((window as any).Android?.openAppSettings) {
      try {
        (window as any).Android.openAppSettings();
        return;
      } catch {}
    }

    // 2. Android Intent URI for Application Details Settings
    try {
      const intentUrl = 'intent:#Intent;action=android.settings.APPLICATION_DETAILS_SETTINGS;end';
      window.location.href = intentUrl;
    } catch {
      console.log('[MicrophoneManager] Intent redirect attempted.');
    }
  }

  // ============================================================================
  // 2. SINGLE MICROPHONE OWNER & STATE MACHINE
  // ============================================================================

  public getState(): MicrophoneState {
    return this.state;
  }

  public getOwner(): MicrophoneOwner {
    return this.currentOwner;
  }

  public isListening(): boolean {
    return this.state === 'LISTENING';
  }

  public getCurrentVolume(): number {
    return this.currentVolume;
  }

  /**
   * Starts microphone capture.
   * Strict state machine protection against double-start and concurrent ownership conflicts.
   */
  public async startListening(
    owner: MicrophoneOwner,
    options?: Partial<MicrophoneAudioOptions>
  ): Promise<boolean> {
    if (typeof window === 'undefined') return false;

    // If currently stopping, wait for the stop to cleanly finish before starting
    if (this.state === 'STOPPING' && this.stopPromise) {
      await this.stopPromise;
    }

    // Strict concurrency lock: If currently starting or requesting permission, reject redundant/conflicting requests!
    if (this.isTransitioning || this.state === 'STARTING' || this.state === 'REQUESTING_PERMISSION') {
      console.log(`[MicrophoneManager] Operation in progress (state=${this.state}). Concurrent start request ignored.`);
      return false;
    }

    if (this.state === 'LISTENING') {
      // Same owner -> redundant start ignored
      if (this.currentOwner === owner) {
        console.log('[MicrophoneManager] Already LISTENING for owner:', owner);
        return true;
      }

      // Priority coordination: Switch owner cleanly without killing the hardware stream
      console.log(`[MicrophoneManager] Switching owner from ${this.currentOwner} to ${owner}`);
      this.currentOwner = owner;
      if (options) {
        this.options = { ...this.options, ...options };
      }
      this.notifyStateChange();
      return true;
    }

    const opId = ++this.currentOpId;
    this.isTransitioning = true;

    // 1. Ensure Permission is GRANTED before touching audio hardware
    if (this.permissionStatus !== 'granted') {
      this.setState('REQUESTING_PERMISSION', owner, null);
      const permResult = await this.requestPermission();
      if (opId !== this.currentOpId) {
        this.isTransitioning = false;
        return false;
      }
      if (!permResult.granted) {
        this.isTransitioning = false;
        this.setState('ERROR', owner, permResult.message);
        return false;
      }
    }

    // 2. Begin STARTING transition
    this.setState('STARTING', owner, null);

    if (options) {
      this.options = { ...this.options, ...options };
    }

    try {
      // 3. Acquire MediaStream if not already open
      if (!this.mediaStream || !this.mediaStream.active || this.mediaStream.getAudioTracks().length === 0) {
        console.log('[MicrophoneManager] Opening audio hardware stream...');
        this.mediaStream = await navigator.mediaDevices.getUserMedia({
          audio: {
            channelCount: this.options.channelCount || 1,
            echoCancellation: this.options.echoCancellation !== false,
            noiseSuppression: this.options.noiseSuppression !== false,
            autoGainControl: this.options.autoGainControl !== false,
          },
        });
      }

      if (opId !== this.currentOpId) {
        this.teardownPipeline();
        this.isTransitioning = false;
        return false;
      }

      // 4. Setup Web Audio pipeline
      await this.setupAudioPipeline();

      if (opId !== this.currentOpId) {
        this.teardownPipeline();
        this.isTransitioning = false;
        return false;
      }

      // 5. Successfully active -> LISTENING
      this.isTransitioning = false;
      this.setState('LISTENING', owner, null);
      console.log(`[MicrophoneManager] Microphone capture started successfully for ${owner}`);
      return true;
    } catch (err: any) {
      this.isTransitioning = false;
      const humanError = this.resolveAudioErrorMessage(err);
      console.error('[MicrophoneManager] Microphone hardware start failed:', err);
      this.teardownPipeline();
      this.setState('ERROR', owner, humanError);
      return false;
    }
  }

  /**
   * Stops microphone capture.
   * Protects against double-stop and NEVER alters or revokes Android permission.
   */
  public async stopListening(owner?: MicrophoneOwner): Promise<void> {
    // If an owner is specified and does not match the active owner, ignore
    if (owner && this.currentOwner && owner !== this.currentOwner) {
      console.log(`[MicrophoneManager] Ignoring stop from non-active owner ${owner} (active: ${this.currentOwner})`);
      return;
    }

    // Double-stop protection: If already IDLE or STOPPING, safely do nothing!
    if (this.state === 'IDLE' || this.state === 'STOPPING') {
      return;
    }

    // If starting or requesting permission, increment opId so in-flight start aborts
    if (this.state === 'STARTING' || this.state === 'REQUESTING_PERMISSION') {
      this.currentOpId++;
    }

    this.isTransitioning = true;
    this.setState('STOPPING', this.currentOwner, null);

    this.stopPromise = (async () => {
      try {
        this.teardownPipeline();
      } catch (e) {
        console.warn('[MicrophoneManager] Error during stop teardown:', e);
      } finally {
        this.isTransitioning = false;
        this.currentOwner = null;
        // Permission remains GRANTED!
        this.setState('IDLE', null, null);
        this.stopPromise = null;
        console.log('[MicrophoneManager] Microphone capture stopped (Permission remains GRANTED).');
      }
    })();

    await this.stopPromise;
  }

  /**
   * Toggles microphone capture safely.
   * Protects against rapid double-taps: ignores calls if transitioning.
   */
  public async toggle(owner: MicrophoneOwner = 'chat_voice', options?: Partial<MicrophoneAudioOptions>): Promise<boolean> {
    if (this.isTransitioning || this.state === 'STARTING' || this.state === 'STOPPING' || this.state === 'REQUESTING_PERMISSION') {
      console.log(`[MicrophoneManager] Toggle ignored during transition (${this.state})`);
      return this.state === 'LISTENING';
    }

    if (this.state === 'LISTENING') {
      await this.stopListening();
      return false;
    } else {
      return await this.startListening(owner, options);
    }
  }

  public isBusy(): boolean {
    return this.isTransitioning || this.state === 'STARTING' || this.state === 'STOPPING' || this.state === 'REQUESTING_PERMISSION';
  }

  public onTeardown(cb: () => void): () => void {
    this.teardownCallbacks.add(cb);
    return () => {
      this.teardownCallbacks.delete(cb);
    };
  }

  /**
   * Releases all audio resources (called on app close or deep background).
   */
  public release(): void {
    this.teardownPipeline();
    if (this.mediaStream) {
      try {
        this.mediaStream.getTracks().forEach((t) => t.stop());
      } catch {}
      this.mediaStream = null;
    }
    this.currentOwner = null;
    this.state = 'IDLE';
    this.notifyStateChange();
  }

  // ============================================================================
  // 3. AUDIO PIPELINE & TELEMETRY
  // ============================================================================

  private async setupAudioPipeline(): Promise<void> {
    if (!this.mediaStream) return;

    const AudioCtxClass =
      window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;

    if (!this.audioContext || this.audioContext.state === 'closed') {
      try {
        this.audioContext = new AudioCtxClass({ sampleRate: 16000 });
      } catch {
        this.audioContext = new AudioCtxClass();
      }
    }

    if (this.audioContext.state === 'suspended') {
      await this.audioContext.resume();
    }

    // Source Node
    this.sourceNode = this.audioContext.createMediaStreamSource(this.mediaStream);

    // Analyser Node for Volume Metering
    this.analyserNode = this.audioContext.createAnalyser();
    this.analyserNode.fftSize = 256;
    this.analyserNode.smoothingTimeConstant = 0.4;
    this.freqData = new Uint8Array(this.analyserNode.frequencyBinCount);

    this.sourceNode.connect(this.analyserNode);

    // Continuous volume metering
    if (this.volumeInterval) clearInterval(this.volumeInterval);
    this.volumeInterval = setInterval(() => {
      if (!this.analyserNode || this.state !== 'LISTENING') return;
      this.analyserNode.getByteFrequencyData(this.freqData);
      let sum = 0;
      for (let i = 0; i < this.freqData.length; i++) {
        sum += this.freqData[i];
      }
      const rawAvg = sum / this.freqData.length / 255;
      this.currentVolume = Math.min(1, Math.max(0, rawAvg * 1.6));
      this.notifyVolume(this.currentVolume);
    }, 45);

    // PCM16 Streaming for Gemini Live if requested
    if (this.options.streamPcm16) {
      const bufferSize = 2048;
      this.processorNode = this.audioContext.createScriptProcessor(bufferSize, 1, 1);
      const targetSampleRate = 16000;
      const actualSampleRate = this.audioContext.sampleRate;

      this.processorNode.onaudioprocess = (e: AudioProcessingEvent) => {
        const out = e.outputBuffer.getChannelData(0);
        out.fill(0); // Zero speaker feedback

        if (this.state !== 'LISTENING') return;

        const inputChannelData = e.inputBuffer.getChannelData(0);
        let samples: Float32Array;
        if (actualSampleRate === targetSampleRate) {
          samples = inputChannelData;
        } else {
          samples = this.resample(inputChannelData, actualSampleRate, targetSampleRate);
        }

        const pcm16 = this.floatTo16BitPCM(samples);
        const base64 = this.arrayBufferToBase64(pcm16);
        this.notifyPcm(base64);
      };

      this.analyserNode.connect(this.processorNode);

      // Silent gain node to keep processor running without echo
      this.silentGainNode = this.audioContext.createGain();
      this.silentGainNode.gain.setValueAtTime(0, this.audioContext.currentTime);
      this.processorNode.connect(this.silentGainNode);
      this.silentGainNode.connect(this.audioContext.destination);
    }
  }

  private teardownPipeline(): void {
    // Notify all registered audio consumers (e.g. SpeechRecognition, WebRTC) to stop
    for (const cb of Array.from(this.teardownCallbacks)) {
      try {
        cb();
      } catch (e) {
        console.warn('[MicrophoneManager] Teardown callback error:', e);
      }
    }
    // Note: Do NOT clear this.teardownCallbacks here! Permanent component observers remain registered.

    if (this.volumeInterval) {
      clearInterval(this.volumeInterval);
      this.volumeInterval = null;
    }
    this.currentVolume = 0;
    this.notifyVolume(0);

    if (this.processorNode) {
      try {
        this.processorNode.disconnect();
        this.processorNode.onaudioprocess = null;
      } catch {}
      this.processorNode = null;
    }

    if (this.silentGainNode) {
      try {
        this.silentGainNode.disconnect();
      } catch {}
      this.silentGainNode = null;
    }

    if (this.sourceNode) {
      try {
        this.sourceNode.disconnect();
      } catch {}
      this.sourceNode = null;
    }

    if (this.analyserNode) {
      try {
        this.analyserNode.disconnect();
      } catch {}
      this.analyserNode = null;
    }

    if (this.audioContext && this.audioContext.state !== 'closed') {
      try {
        this.audioContext.close().catch(() => {});
      } catch {}
      this.audioContext = null;
    }

    if (this.mediaStream) {
      try {
        this.mediaStream.getTracks().forEach((track) => track.stop());
      } catch {}
      this.mediaStream = null;
    }
  }

  // ============================================================================
  // 4. ANDROID LIFECYCLE COORDINATION
  // ============================================================================

  private setupLifecycleListeners(): void {
    if (typeof document === 'undefined') return;

    document.addEventListener('visibilitychange', () => {
      if (document.hidden) {
        console.log('[MicrophoneManager] App backgrounded. Releasing active microphone capture...');
        if (this.state === 'LISTENING') {
          this.resumeOwnerAfterBackground = this.currentOwner;
          this.stopListening().catch(() => {});
        }
      } else {
        console.log('[MicrophoneManager] App resumed. Checking permission state without prompt...');
        this.checkPermission().catch(() => {});
        // Note: Do NOT automatically trigger microphone start or permission popups on resume!
      }
    });
  }

  // ============================================================================
  // 5. AUDIO HELPERS & ERROR RESOLVER
  // ============================================================================

  private resolveAudioErrorMessage(err: any): string {
    const name = err?.name || '';
    if (name === 'NotAllowedError' || name === 'PermissionDeniedError') {
      return 'Microphone permission was denied. Please allow microphone access.';
    }
    if (name === 'NotFoundError' || name === 'DevicesNotFoundError') {
      return 'No microphone found on this device.';
    }
    if (name === 'NotReadableError' || name === 'TrackStartError') {
      return 'Microphone is currently being used by another app.';
    }
    if (name === 'OverconstrainedError') {
      return 'Microphone constraints could not be satisfied.';
    }
    if (name === 'SecurityError') {
      return 'Microphone blocked by Android security policy.';
    }
    return err?.message || 'Microphone activation failed.';
  }

  private floatTo16BitPCM(input: Float32Array): ArrayBuffer {
    const buffer = new ArrayBuffer(input.length * 2);
    const view = new DataView(buffer);
    for (let i = 0; i < input.length; i++) {
      const s = Math.max(-1, Math.min(1, input[i]));
      view.setInt16(i * 2, s < 0 ? s * 0x8000 : s * 0x7fff, true);
    }
    return buffer;
  }

  private arrayBufferToBase64(buffer: ArrayBuffer): string {
    let binary = '';
    const bytes = new Uint8Array(buffer);
    const len = bytes.byteLength;
    for (let i = 0; i < len; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    return window.btoa(binary);
  }

  private resample(source: Float32Array, sourceRate: number, targetRate: number): Float32Array {
    if (sourceRate === targetRate) return source;
    const ratio = sourceRate / targetRate;
    const targetLength = Math.round(source.length / ratio);
    const result = new Float32Array(targetLength);
    for (let i = 0; i < targetLength; i++) {
      const srcIndex = i * ratio;
      const index0 = Math.floor(srcIndex);
      const index1 = Math.min(index0 + 1, source.length - 1);
      const weight = srcIndex - index0;
      result[i] = source[index0] * (1 - weight) + source[index1] * weight;
    }
    return result;
  }

  // ============================================================================
  // 6. SUBSCRIPTIONS
  // ============================================================================

  private setState(state: MicrophoneState, owner: MicrophoneOwner, error: string | null): void {
    this.state = state;
    this.currentOwner = owner;
    this.errorMessage = error;
    this.notifyStateChange();
  }

  public onStateChange(listener: MicStateListener): () => void {
    this.stateListeners.add(listener);
    listener(this.state, this.currentOwner, this.errorMessage);
    return () => {
      this.stateListeners.delete(listener);
    };
  }

  public onVolume(listener: MicVolumeListener): () => void {
    this.volumeListeners.add(listener);
    return () => {
      this.volumeListeners.delete(listener);
    };
  }

  public onPcmData(listener: MicPcmListener): () => void {
    this.pcmListeners.add(listener);
    return () => {
      this.pcmListeners.delete(listener);
    };
  }

  public onPermissionChange(listener: MicPermissionListener): () => void {
    this.permissionListeners.add(listener);
    listener(this.permissionStatus);
    return () => {
      this.permissionListeners.delete(listener);
    };
  }

  private notifyStateChange(): void {
    for (const listener of this.stateListeners) {
      try {
        listener(this.state, this.currentOwner, this.errorMessage);
      } catch (e) {
        console.error('[MicrophoneManager] State listener error:', e);
      }
    }
  }

  private notifyVolume(vol: number): void {
    for (const listener of this.volumeListeners) {
      try {
        listener(vol);
      } catch (e) {
        console.error('[MicrophoneManager] Volume listener error:', e);
      }
    }
  }

  private notifyPcm(base64: string): void {
    for (const listener of this.pcmListeners) {
      try {
        listener(base64);
      } catch (e) {
        console.error('[MicrophoneManager] PCM listener error:', e);
      }
    }
  }

  private notifyPermissionChange(): void {
    for (const listener of this.permissionListeners) {
      try {
        listener(this.permissionStatus);
      } catch (e) {
        console.error('[MicrophoneManager] Permission listener error:', e);
      }
    }
  }
}
