/**
 * imageProcessor - Fast client-side image downsampling, canvas color extraction,
 * and media capture utilities for Hinata Visual Design System.
 */

import { DesignPalette } from '../../types/visualDesign';

export interface ProcessedImageData {
  dataUrl: string;
  mimeType: string;
  width: number;
  height: number;
  extractedPalette: DesignPalette;
}

/**
 * Resizes and compresses an image to fit max dimensions while preserving aspect ratio.
 */
export async function processAndDownsampleImage(
  fileOrUrl: File | Blob | string,
  maxDimension: number = 1200,
  quality: number = 0.85
): Promise<ProcessedImageData> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';

    img.onload = () => {
      try {
        let width = img.naturalWidth || img.width;
        let height = img.naturalHeight || img.height;

        if (width > maxDimension || height > maxDimension) {
          if (width > height) {
            height = Math.round((height * maxDimension) / width);
            width = maxDimension;
          } else {
            width = Math.round((width * maxDimension) / height);
            height = maxDimension;
          }
        }

        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');

        if (!ctx) {
          throw new Error('Canvas 2D context unavailable');
        }

        ctx.drawImage(img, 0, 0, width, height);

        // Extract dominant colors from canvas
        const extractedPalette = extractPaletteFromCanvas(ctx, width, height);

        const mimeType = 'image/jpeg';
        const dataUrl = canvas.toDataURL(mimeType, quality);

        resolve({
          dataUrl,
          mimeType,
          width,
          height,
          extractedPalette,
        });
      } catch (err) {
        reject(err);
      }
    };

    img.onerror = (e) => reject(new Error('Failed to load image for visual analysis'));

    if (typeof fileOrUrl === 'string') {
      img.src = fileOrUrl;
    } else {
      const reader = new FileReader();
      reader.onload = (e) => {
        img.src = e.target?.result as string;
      };
      reader.onerror = () => reject(new Error('Failed to read file'));
      reader.readAsDataURL(fileOrUrl);
    }
  });
}

/**
 * Extracts a structured DesignPalette directly from canvas pixel data
 */
export function extractPaletteFromCanvas(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number
): DesignPalette {
  const step = Math.max(1, Math.floor(Math.min(width, height) / 40));
  const imageData = ctx.getImageData(0, 0, width, height);
  const data = imageData.data;

  const colorBuckets: Map<string, { r: number; g: number; b: number; count: number }> = new Map();
  let bgR = 0;
  let bgG = 0;
  let bgB = 0;
  let sampleCount = 0;

  for (let y = 0; y < height; y += step) {
    for (let x = 0; x < width; x += step) {
      const idx = (y * width + x) * 4;
      const a = data[idx + 3];
      if (a < 120) continue; // Skip transparent pixels

      const r = data[idx];
      const g = data[idx + 1];
      const b = data[idx + 2];

      bgR += r;
      bgG += g;
      bgB += b;
      sampleCount++;

      // Quantize to 32-step buckets
      const qr = Math.floor(r / 32) * 32;
      const qg = Math.floor(g / 32) * 32;
      const qb = Math.floor(b / 32) * 32;
      const key = `${qr},${qg},${qb}`;

      const existing = colorBuckets.get(key);
      if (existing) {
        existing.count++;
      } else {
        colorBuckets.set(key, { r: qr, g: qg, b: qb, count: 1 });
      }
    }
  }

  // Sort by frequency
  const sorted = Array.from(colorBuckets.values()).sort((a, b) => b.count - a.count);

  const toHex = (r: number, g: number, b: number) =>
    '#' + [r, g, b].map((x) => Math.min(255, Math.max(0, x)).toString(16).padStart(2, '0')).join('');

  const avgBgR = sampleCount > 0 ? Math.round(bgR / sampleCount) : 10;
  const avgBgG = sampleCount > 0 ? Math.round(bgG / sampleCount) : 12;
  const avgBgB = sampleCount > 0 ? Math.round(bgB / sampleCount) : 24;

  const rawSwatches = sorted.slice(0, 8).map((c) => toHex(c.r, c.g, c.b));

  // Find most vibrant accent color (highest color saturation)
  let bestAccent = '#00e5ff';
  let maxSat = -1;

  for (const c of sorted) {
    const max = Math.max(c.r, c.g, c.b);
    const min = Math.min(c.r, c.g, c.b);
    const sat = max === 0 ? 0 : (max - min) / max;
    const lum = (max + min) / 510;

    // Filter out very dark or washed out gray
    if (sat > 0.35 && lum > 0.25 && lum < 0.85 && sat > maxSat) {
      maxSat = sat;
      bestAccent = toHex(c.r, c.g, c.b);
    }
  }

  const primary = sorted[0] ? toHex(sorted[0].r, sorted[0].g, sorted[0].b) : '#080d24';
  const secondary = sorted[1] ? toHex(sorted[1].r, sorted[1].g, sorted[1].b) : '#287bff';
  const accent = bestAccent || (sorted[2] ? toHex(sorted[2].r, sorted[2].g, sorted[2].b) : '#00e5ff');
  const background = toHex(avgBgR, avgBgG, avgBgB);
  const surface = sorted[0] ? toHex(Math.min(255, sorted[0].r + 15), Math.min(255, sorted[0].g + 15), Math.min(255, sorted[0].b + 20)) : '#0e1635';

  return {
    primary,
    secondary,
    accent,
    background,
    surface,
    textPrimary: '#f8fafc',
    textSecondary: '#94a3b8',
    glowColor: accent,
    gradient: `linear-gradient(135deg, ${accent} 0%, ${secondary} 50%, #9b5cff 100%)`,
    rawSwatches,
  };
}
