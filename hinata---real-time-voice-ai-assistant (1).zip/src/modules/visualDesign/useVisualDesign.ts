/**
 * useVisualDesign - React hook providing reactive state and actions for
 * Hinata's Visual Design Understanding System.
 */

import { useState, useEffect, useCallback } from 'react';
import {
  VisualDesignManager,
  DEFAULT_HINATA_THEME,
} from './VisualDesignManager';
import {
  VisualReferenceImage,
  AppliedDesignTheme,
  ReferenceRole,
  VisualDesignAnalysis,
} from '../../types/visualDesign';

export function useVisualDesign() {
  const manager = VisualDesignManager.getInstance();
  const [references, setReferences] = useState<VisualReferenceImage[]>(() =>
    [...manager.getReferences()]
  );
  const [activeTheme, setActiveTheme] = useState<AppliedDesignTheme>(() =>
    manager.getActiveTheme()
  );
  const [isBusy, setIsBusy] = useState<boolean>(() => manager.isBusy());

  useEffect(() => {
    const unsubscribe = manager.subscribe((event) => {
      setReferences([...manager.getReferences()]);
      setActiveTheme(manager.getActiveTheme());
      setIsBusy(manager.isBusy());
    });
    return unsubscribe;
  }, [manager]);

  const addReference = useCallback(
    async (fileOrUrl: File | Blob | string, name?: string, role?: ReferenceRole) => {
      return manager.addReference(fileOrUrl, name, role);
    },
    [manager]
  );

  const updateRole = useCallback(
    (id: string, role: ReferenceRole) => {
      manager.updateReferenceRole(id, role);
    },
    [manager]
  );

  const removeReference = useCallback(
    (id: string) => {
      manager.removeReference(id);
    },
    [manager]
  );

  const clearAllReferences = useCallback(() => {
    manager.clearAllReferences();
  }, [manager]);

  const applyReferenceToUI = useCallback(
    (id: string) => {
      return manager.applyReferenceToUI(id);
    },
    [manager]
  );

  const resetTheme = useCallback(() => {
    return manager.resetToDefaultTheme();
  }, [manager]);

  const combineReferences = useCallback(
    (layoutId: string, colorId: string) => {
      return manager.combineReferences(layoutId, colorId);
    },
    [manager]
  );

  const rememberPreference = useCallback(
    (customNote?: string) => {
      manager.rememberDesignPreference(customNote);
    },
    [manager]
  );

  const triggerAnalysis = useCallback(
    async (id: string, instruction?: string) => {
      return manager.triggerDeepAnalysis(id, undefined, instruction);
    },
    [manager]
  );

  return {
    references,
    activeReference: references[0],
    activeTheme,
    isBusy,
    addReference,
    updateRole,
    removeReference,
    clearAllReferences,
    applyReferenceToUI,
    resetTheme,
    combineReferences,
    rememberPreference,
    triggerAnalysis,
  };
}
