/**
 * DesignGenerator - Code, Tailwind & Theme Synthesis Engine for Hinata AI.
 *
 * Implements:
 * - Design -> Code transformation (React, TypeScript, Tailwind CSS, Vite)
 * - Multi-reference synthesis (combining layout + colors + typography + mascot)
 * - Preset aesthetic modifications ("Make more futuristic", "Make premium", "Make mobile friendly")
 * - Component-specific styling updates (Avatar, Bottom Nav, Cards, Holograms)
 */

import {
  VisualReferenceImage,
  VisualDesignAnalysis,
  AppliedDesignTheme,
} from '../../types/visualDesign';

export interface GeneratedCodeOutput {
  componentName: string;
  tailwindClasses: string;
  reactJsxSnippet: string;
  cssVariables: Record<string, string>;
  designTokens: {
    primaryColor: string;
    accentGlow: string;
    surfaceBackground: string;
    borderRadius: string;
    typographyFamily: string;
  };
}

export class DesignGenerator {
  private static instance: DesignGenerator | null = null;

  private constructor() {}

  public static getInstance(): DesignGenerator {
    if (!DesignGenerator.instance) {
      DesignGenerator.instance = new DesignGenerator();
    }
    return DesignGenerator.instance;
  }

  /**
   * Generates a tailored React/Tailwind component snippet based on visual analysis.
   */
  public generateComponentFromDesign(
    analysis: VisualDesignAnalysis,
    componentType: 'card' | 'navbar' | 'avatar_container' | 'modal' = 'card'
  ): GeneratedCodeOutput {
    const primary = analysis.colors.primary;
    const accent = analysis.colors.accent;
    const bg = analysis.colors.background;
    const radius = '16px';

    let tailwindClasses = '';
    let reactJsxSnippet = '';

    switch (componentType) {
      case 'card': {
        tailwindClasses = `relative overflow-hidden rounded-[${radius}] border border-[${accent}]/30 bg-[${primary}]/80 p-5 backdrop-blur-xl shadow-[0_0_25px_${accent}25] transition-all hover:border-[${accent}]/60`;
        reactJsxSnippet = `
<div className="${tailwindClasses}">
  <div className="absolute top-0 right-0 w-24 h-24 bg-[${accent}]/10 rounded-full blur-2xl pointer-events-none" />
  <h3 className="text-base font-semibold text-white tracking-wide">Interface Module</h3>
  <p className="text-sm text-slate-300 mt-1">Generated from visual reference: ${analysis.visualStyle?.category || 'Custom'}</p>
</div>`.trim();
        break;
      }

      case 'navbar': {
        tailwindClasses = `fixed bottom-4 left-1/2 -translate-x-1/2 px-4 py-3 rounded-full border border-[${accent}]/30 bg-[${bg}]/85 backdrop-blur-2xl shadow-[0_10px_30px_rgba(0,0,0,0.5)] flex items-center gap-3`;
        reactJsxSnippet = `
<nav className="${tailwindClasses}">
  <button className="px-4 py-2 rounded-full bg-[${accent}] text-[${bg}] font-medium text-sm shadow-[0_0_15px_${accent}60]">Action</button>
  <button className="px-4 py-2 text-slate-300 hover:text-white text-sm">Status</button>
</nav>`.trim();
        break;
      }

      default: {
        tailwindClasses = `rounded-2xl border border-[${accent}]/40 bg-[${primary}]/90 p-4 text-white`;
        reactJsxSnippet = `<div className="${tailwindClasses}">Custom Module</div>`;
      }
    }

    return {
      componentName: `Hinata${componentType.charAt(0).toUpperCase() + componentType.slice(1)}`,
      tailwindClasses,
      reactJsxSnippet,
      cssVariables: {
        '--color-primary': primary,
        '--color-accent': accent,
        '--color-bg': bg,
        '--glow-color': analysis.colors.glowColor,
      },
      designTokens: {
        primaryColor: primary,
        accentGlow: analysis.colors.glowColor,
        surfaceBackground: analysis.colors.surface,
        borderRadius: radius,
        typographyFamily: analysis.typography?.fontStyle || 'Inter, sans-serif',
      },
    };
  }

  /**
   * Synthesizes multiple design references into a cohesive design theme.
   * e.g., Image 1 for layout, Image 2 for color palette, Image 3 for avatar glow.
   */
  public synthesizeMultipleDesigns(
    references: VisualReferenceImage[]
  ): AppliedDesignTheme {
    const layoutRef = references.find((r) => r.role === 'layout') || references[0];
    const colorRef = references.find((r) => r.role === 'color') || references[references.length > 1 ? 1 : 0];
    const mascotRef = references.find((r) => r.role === 'mascot') || references[0];

    const palette = colorRef?.analysis?.colors || {
      primary: '#080d24',
      secondary: '#287bff',
      accent: '#00e5ff',
      background: '#040714',
      surface: '#0a122c',
      textPrimary: '#ffffff',
      textSecondary: '#94a3b8',
      glowColor: '#00e5ff',
      gradient: 'linear-gradient(135deg, #00e5ff 0%, #287bff 100%)',
      rawSwatches: ['#00e5ff', '#287bff', '#080d24'],
    };

    const mascotGlow = mascotRef?.analysis?.colors?.glowColor || palette.accent;

    return {
      id: `synth_${Date.now()}`,
      name: `Synthesized: ${layoutRef?.name || 'Layout'} + ${colorRef?.name || 'Palette'}`,
      styleCategory: 'Multi-Reference Hybrid',
      palette,
      mascotGlowColor: mascotGlow,
      accentGlowColor: palette.secondary || '#9b5cff',
      bgAtmosphere: `radial-gradient(ellipse at 50% 30%, ${palette.accent}20 0%, ${palette.secondary}15 45%, transparent 75%)`,
      borderAccent: palette.secondary,
      isCustomApplied: true,
      sourceReferenceId: colorRef?.id,
    };
  }
}
