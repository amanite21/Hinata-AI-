/**
 * ImageInputManager - Coordinates Android/Gallery image picking, image optimization,
 * small non-intrusive preview tracking, and vision pipeline dispatch.
 */

import { SelectedImage } from '../types';

export type ImageInputListener = (image: SelectedImage | null) => void;

export class ImageInputManager {
  private static instance: ImageInputManager | null = null;
  private currentImage: SelectedImage | null = null;
  private listeners: ImageInputListener[] = [];
  private fileInput: HTMLInputElement | null = null;

  private readonly MAX_IMAGE_DIMENSION = 1600;
  private readonly JPEG_QUALITY = 0.85;

  private constructor() {
    // Hidden file input is created on demand during pickImage for optimal DOM security and compatibility
  }

  public static getInstance(): ImageInputManager {
    if (!ImageInputManager.instance) {
      ImageInputManager.instance = new ImageInputManager();
    }
    return ImageInputManager.instance;
  }

  public subscribe(listener: ImageInputListener): () => void {
    this.listeners.push(listener);
    listener(this.currentImage);
    return () => {
      this.listeners = this.listeners.filter((l) => l !== listener);
    };
  }

  private notifyListeners(): void {
    for (const listener of this.listeners) {
      try {
        listener(this.currentImage);
      } catch (err) {
        console.error('[ImageInputManager] Listener error:', err);
      }
    }
  }

  public getSelectedImage(): SelectedImage | null {
    return this.currentImage;
  }

  public hasImage(): boolean {
    return this.currentImage !== null;
  }

  /**
   * Prompts user via native Android / browser gallery photo picker.
   */
  public async pickImage(): Promise<SelectedImage | null> {
    if (typeof document === 'undefined') return null;

    return new Promise((resolve) => {
      const input = document.createElement('input');
      input.type = 'file';
      input.accept = 'image/*';
      input.style.position = 'fixed';
      input.style.top = '-10000px';
      input.style.left = '-10000px';
      input.style.opacity = '0';
      input.setAttribute('aria-hidden', 'true');
      document.body.appendChild(input);

      let isSettled = false;
      const cleanup = () => {
        if (isSettled) return;
        isSettled = true;
        try {
          if (document.body.contains(input)) {
            document.body.removeChild(input);
          }
        } catch {}
      };

      const handleChange = async () => {
        const file = input.files?.[0];
        cleanup();
        if (file) {
          try {
            const img = await this.setImageFromFile(file);
            resolve(img);
          } catch (err) {
            console.error('[ImageInputManager] Failed to load picked image:', err);
            resolve(null);
          }
        } else {
          resolve(null);
        }
      };

      const handleCancel = () => {
        cleanup();
        resolve(null);
      };

      input.addEventListener('change', handleChange, { once: true });
      input.addEventListener('cancel', handleCancel, { once: true });

      // Window focus fallback for browsers that don't trigger the cancel event when dialog is closed
      const onWindowFocus = () => {
        setTimeout(() => {
          if (!isSettled && (!input.files || input.files.length === 0)) {
            cleanup();
            resolve(null);
          }
        }, 500);
      };
      window.addEventListener('focus', onWindowFocus, { once: true });

      // Trigger native picker
      try {
        input.click();
      } catch (err) {
        console.error('[ImageInputManager] input.click() error:', err);
        cleanup();
        resolve(null);
      }
    });
  }

  /**
   * Processes, downscales if huge, and saves image from File.
   */
  public async setImageFromFile(file: File): Promise<SelectedImage> {
    const dataUrl = await this.readFileAsDataUrl(file);
    const optimized = await this.optimizeImage(dataUrl, file.type || 'image/jpeg');

    const item: SelectedImage = {
      id: Math.random().toString(36).substring(2, 10),
      dataUrl: optimized.dataUrl,
      base64: optimized.base64,
      mimeType: optimized.mimeType,
      name: file.name || 'Screenshot',
      timestamp: Date.now(),
      width: optimized.width,
      height: optimized.height,
    };

    this.currentImage = item;
    this.notifyListeners();
    return item;
  }

  /**
   * Directly sets image from Data URL.
   */
  public async setImageFromDataUrl(dataUrl: string, name: string = 'Reference Image'): Promise<SelectedImage> {
    const mimeMatch = dataUrl.match(/^data:([^;]+);base64,/);
    const mimeType = mimeMatch ? mimeMatch[1] : 'image/jpeg';
    const optimized = await this.optimizeImage(dataUrl, mimeType);

    const item: SelectedImage = {
      id: Math.random().toString(36).substring(2, 10),
      dataUrl: optimized.dataUrl,
      base64: optimized.base64,
      mimeType: optimized.mimeType,
      name,
      timestamp: Date.now(),
      width: optimized.width,
      height: optimized.height,
    };

    this.currentImage = item;
    this.notifyListeners();
    return item;
  }

  public clearImage(): void {
    this.currentImage = null;
    this.notifyListeners();
  }

  private readFileAsDataUrl(file: File): Promise<string> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = (e) => reject(e);
      reader.readAsDataURL(file);
    });
  }

  private optimizeImage(
    srcDataUrl: string,
    mimeType: string
  ): Promise<{ dataUrl: string; base64: string; mimeType: string; width: number; height: number }> {
    return new Promise((resolve) => {
      const img = new Image();
      img.onload = () => {
        const origW = img.naturalWidth || img.width;
        const origH = img.naturalHeight || img.height;

        let targetW = origW;
        let targetH = origH;

        if (origW > this.MAX_IMAGE_DIMENSION || origH > this.MAX_IMAGE_DIMENSION) {
          if (origW >= origH) {
            targetW = this.MAX_IMAGE_DIMENSION;
            targetH = Math.round((origH * this.MAX_IMAGE_DIMENSION) / origW);
          } else {
            targetH = this.MAX_IMAGE_DIMENSION;
            targetW = Math.round((origW * this.MAX_IMAGE_DIMENSION) / origH);
          }
        }

        const canvas = document.createElement('canvas');
        canvas.width = targetW;
        canvas.height = targetH;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          const rawBase64 = srcDataUrl.replace(/^data:[^;]+;base64,/, '');
          resolve({
            dataUrl: srcDataUrl,
            base64: rawBase64,
            mimeType,
            width: origW,
            height: origH,
          });
          return;
        }

        ctx.drawImage(img, 0, 0, targetW, targetH);
        const outMime = mimeType === 'image/png' ? 'image/png' : 'image/jpeg';
        const outDataUrl = canvas.toDataURL(outMime, this.JPEG_QUALITY);
        const outBase64 = outDataUrl.replace(/^data:[^;]+;base64,/, '');

        resolve({
          dataUrl: outDataUrl,
          base64: outBase64,
          mimeType: outMime,
          width: targetW,
          height: targetH,
        });
      };

      img.onerror = () => {
        const rawBase64 = srcDataUrl.replace(/^data:[^;]+;base64,/, '');
        resolve({
          dataUrl: srcDataUrl,
          base64: rawBase64,
          mimeType,
          width: 800,
          height: 600,
        });
      };

      img.src = srcDataUrl;
    });
  }
}
