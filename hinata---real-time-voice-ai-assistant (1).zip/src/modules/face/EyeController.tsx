import React from 'react';
import { HinataEmotion, HinataAIState, GazeState, EyeRenderParams } from './types';

export class EyeController {
  // Blinking Engine
  private blinkTimer: number = 0;
  private nextBlinkInterval: number = 3200 + Math.random() * 2400;
  private blinkProgress: number = 0; // 0 = open, 1 = fully closed
  private isBlinking: boolean = false;
  private blinkPhase: 'closing' | 'opening' | 'double_wait' | 'idle' = 'idle';
  private hasPendingDoubleBlink: boolean = false;
  private doubleBlinkTimer: number = 0;

  // Gaze & Saccades
  private gazeTimer: number = 0;
  private nextGazeInterval: number = 2000;
  private gazeX: number = 0;
  private gazeY: number = 0;
  private targetGazeX: number = 0;
  private targetGazeY: number = 0;
  private microSaccadeX: number = 0;
  private microSaccadeY: number = 0;

  constructor() {
    this.scheduleNextBlink();
  }

  private scheduleNextBlink(): void {
    this.blinkTimer = 0;
    // Natural human blink distribution: 2.8 to 5.4 seconds
    this.nextBlinkInterval = 2800 + Math.random() * 2600;
    // 22% chance of firing an occasional double-blink
    this.hasPendingDoubleBlink = Math.random() < 0.22;
  }

  /**
   * Updates blink kinematics and natural saccadic gaze.
   */
  public update(
    deltaMs: number,
    dtSec: number,
    emotion: HinataEmotion,
    aiState: HinataAIState,
    timeSec: number
  ): {
    leftEye: EyeRenderParams;
    rightEye: EyeRenderParams;
    gaze: GazeState;
  } {
    // 1. Blinking Logic
    if (aiState === 'STOPPED') {
      // Peaceful closed eyes when stopped
      this.blinkProgress = Math.min(1.0, this.blinkProgress + dtSec * 6.0);
    } else if (!this.isBlinking) {
      this.blinkTimer += deltaMs;
      if (this.blinkTimer >= this.nextBlinkInterval) {
        this.isBlinking = true;
        this.blinkPhase = 'closing';
        this.blinkTimer = 0;
      }
    } else {
      if (this.blinkPhase === 'closing') {
        // Fast realistic lid closure (takes ~60ms)
        this.blinkProgress += dtSec * 18.0;
        if (this.blinkProgress >= 1.0) {
          this.blinkProgress = 1.0;
          this.blinkPhase = 'opening';
        }
      } else if (this.blinkPhase === 'opening') {
        // Natural elastomeric lid opening
        this.blinkProgress -= dtSec * 11.0;
        if (this.blinkProgress <= 0.0) {
          this.blinkProgress = 0.0;
          if (this.hasPendingDoubleBlink) {
            // Trigger quick double blink sequence
            this.hasPendingDoubleBlink = false;
            this.blinkPhase = 'double_wait';
            this.doubleBlinkTimer = 0;
          } else {
            this.blinkPhase = 'idle';
            this.isBlinking = false;
            this.scheduleNextBlink();
          }
        }
      } else if (this.blinkPhase === 'double_wait') {
        this.doubleBlinkTimer += deltaMs;
        if (this.doubleBlinkTimer >= 80) {
          // Fire secondary flutter blink
          this.blinkPhase = 'closing';
        }
      }
    }

    // 2. Natural Gaze & Micro-saccades
    this.gazeTimer += deltaMs;
    if (this.gazeTimer >= this.nextGazeInterval) {
      this.gazeTimer = 0;
      this.nextGazeInterval = 1600 + Math.random() * 2200;

      // Determine gaze direction based on state and emotion
      if (aiState === 'LISTENING') {
        // Attentive forward focus with subtle conversational curiosity
        this.targetGazeX = (Math.random() - 0.5) * 1.8;
        this.targetGazeY = (Math.random() - 0.5) * 1.2;
      } else if (aiState === 'THINKING' || emotion === 'thinking') {
        // Looking upward and to the side (cognitive retrieval saccade)
        this.targetGazeX = Math.random() > 0.5 ? 4.5 : -4.5;
        this.targetGazeY = -4.0;
      } else if (aiState === 'SPEAKING') {
        // Conversational eye contact: mostly centered with organic reflective shifts
        const rand = Math.random();
        if (rand < 0.35) {
          this.targetGazeX = -2.5 + Math.random() * 1.5;
          this.targetGazeY = -1.5;
        } else if (rand < 0.65) {
          this.targetGazeX = 2.5 + Math.random() * 1.5;
          this.targetGazeY = -1.0;
        } else {
          this.targetGazeX = (Math.random() - 0.5) * 2.0;
          this.targetGazeY = (Math.random() - 0.5) * 1.5;
        }
      } else if (emotion === 'curious' || emotion === 'confused') {
        this.targetGazeX = 3.0;
        this.targetGazeY = -2.0;
      } else if (emotion === 'sad' || emotion === 'disappointed') {
        this.targetGazeX = (Math.random() - 0.5) * 1.5;
        this.targetGazeY = 3.5; // lowered gaze
      } else {
        // Subtle ambient wandering
        this.targetGazeX = Math.sin(timeSec * 0.7) * 2.2;
        this.targetGazeY = Math.cos(timeSec * 0.5) * 1.4;
      }
    }

    // Smooth saccadic interpolation (spring-damper feeling)
    const lerpSpeed = Math.min(1.0, 9.0 * dtSec);
    this.gazeX += (this.targetGazeX - this.gazeX) * lerpSpeed;
    this.gazeY += (this.targetGazeY - this.gazeY) * lerpSpeed;

    // Organic micro-saccade tremor (barely perceptible ocular jitter)
    this.microSaccadeX = Math.sin(timeSec * 24.0) * 0.25;
    this.microSaccadeY = Math.cos(timeSec * 19.0) * 0.2;

    const finalGaze: GazeState = {
      x: this.gazeX + this.microSaccadeX,
      y: this.gazeY + this.microSaccadeY,
      targetX: this.targetGazeX,
      targetY: this.targetGazeY,
      microSaccadeX: this.microSaccadeX,
      microSaccadeY: this.microSaccadeY,
    };

    const eyeParams: EyeRenderParams = {
      openness: 1.0 - this.blinkProgress,
      width: 1.0,
      arcCurvature: 0,
      pupilScale: 1.0,
      pupilGlow: 0.85,
      primaryColor: '#00e5ff',
      glowColor: 'rgba(0, 229, 255, 0.45)',
      irisColor: '#0284c7',
      eyebrowSlant: 0,
      eyebrowHeight: 0,
      isBlinking: this.isBlinking,
      blinkProgress: this.blinkProgress,
      showHighlights: true,
      sparkleType: 'glint',
    };

    return {
      leftEye: { ...eyeParams },
      rightEye: { ...eyeParams },
      gaze: finalGaze,
    };
  }

  /**
   * Renders the SVG representation of Hinata's expressive cyber eyes.
   * Handles all 19 emotions with clean SVG vector geometry.
   */
  public renderEyeGraphic(
    isLeft: boolean,
    emotion: HinataEmotion,
    intensity: number,
    gaze: GazeState,
    blinkProgress: number,
    leftPupilRef?: React.RefObject<SVGCircleElement | null>,
    rightPupilRef?: React.RefObject<SVGCircleElement | null>
  ): React.ReactNode {
    const cx = isLeft ? 162 : 238;
    const cy = 198;
    const pupilRef = isLeft ? leftPupilRef : rightPupilRef;

    // If completely closed (e.g. blink or stopped)
    if (blinkProgress >= 0.96) {
      const d = isLeft ? 'M 148 198 Q 162 201 176 198' : 'M 224 198 Q 238 201 252 198';
      return (
        <g>
          <path d={d} fill="none" stroke="#00e5ff" strokeWidth="3" strokeLinecap="round" filter="url(#mascot-glow)" />
          <path d={d} fill="none" stroke="#ffffff" strokeWidth="1.5" strokeLinecap="round" />
        </g>
      );
    }

    // 1. HAPPY: Gentle smiling upward curved arcs ^ ^ with bright cyan stroke
    if (emotion === 'happy') {
      const curveHeight = 18 + intensity * 6;
      const d = isLeft
        ? `M 148 202 Q 162 ${202 - curveHeight} 176 202`
        : `M 224 202 Q 238 ${202 - curveHeight} 252 202`;
      return (
        <g>
          <path d={d} fill="none" stroke="#00e5ff" strokeWidth="5.5" strokeLinecap="round" filter="url(#mascot-glow)" />
          <path d={d} fill="none" stroke="#ffffff" strokeWidth="2.8" strokeLinecap="round" />
          {/* Subtle lower eye shine */}
          <ellipse cx={cx + gaze.x * 0.4} cy={cy + 4} rx="4" ry="2" fill="#00e5ff" opacity="0.75" filter="url(#mascot-glow)" />
        </g>
      );
    }

    // 2. LAUGHING: Closed happy squinting joy wedges > < with energetic warmth
    if (emotion === 'laughing') {
      const d = isLeft ? 'M 146 198 L 164 186 L 176 198' : 'M 224 198 L 236 186 L 254 198';
      return (
        <g>
          <path d={d} fill="none" stroke="#00e5ff" strokeWidth="5" strokeLinecap="round" filter="url(#mascot-glow)" />
          <path d={d} fill="none" stroke="#ffffff" strokeWidth="2.5" strokeLinecap="round" />
          {/* Joyful cheek gleams */}
          <circle cx={isLeft ? 144 : 256} cy="204" r="2.2" fill="#ff4fd8" filter="url(#mascot-glow)" />
        </g>
      );
    }

    // 3. EXCITED: Huge wide eyes with sparkling star highlights & diamond sheen
    if (emotion === 'excited') {
      const rScale = 1.0 + intensity * 0.15;
      return (
        <g>
          <ellipse cx={cx} cy={cy} rx={17 * rScale} ry={19 * rScale} fill="url(#eye-iris-gradient)" filter="url(#mascot-glow)" />
          <ellipse cx={cx} cy={cy} rx={15 * rScale} ry={17 * rScale} fill="#082f49" />
          <circle ref={pupilRef} cx={cx + gaze.x} cy={cy + gaze.y} r="8.5" fill="#00e5ff" filter="url(#mascot-glow)" />
          <circle cx={cx + gaze.x} cy={cy + gaze.y} r="5" fill="#ffffff" />
          {/* 4-Point Star Glints */}
          <path
            d={`M ${cx - 5 + gaze.x} ${cy - 6 + gaze.y} L ${cx - 4 + gaze.x} ${cy - 8 + gaze.y} L ${cx - 3 + gaze.x} ${cy - 6 + gaze.y} L ${cx - 1 + gaze.x} ${cy - 5 + gaze.y} L ${cx - 3 + gaze.x} ${cy - 4 + gaze.y} L ${cx - 4 + gaze.x} ${cy - 2 + gaze.y} L ${cx - 5 + gaze.x} ${cy - 4 + gaze.y} L ${cx - 7 + gaze.x} ${cy - 5 + gaze.y} Z`}
            fill="#ffffff"
            filter="url(#mascot-glow)"
          />
          <circle cx={cx + 4 + gaze.x} cy={cy + 5 + gaze.y} r="2.5" fill="#ffffff" />
        </g>
      );
    }

    // 4. CURIOUS: Inquisitive raised eyebrow on left eye with observant pupils
    if (emotion === 'curious') {
      const browOffset = isLeft ? -7 * intensity : 0;
      return (
        <g>
          <ellipse cx={cx} cy={cy} rx="15" ry="16" fill="url(#eye-iris-gradient)" filter="url(#mascot-glow)" />
          <ellipse cx={cx} cy={cy} rx="13.5" ry="14.5" fill="#0c4a6e" />
          <circle ref={pupilRef} cx={cx + gaze.x} cy={cy + gaze.y} r="7.5" fill="#00e5ff" filter="url(#mascot-glow)" />
          <circle cx={cx + gaze.x} cy={cy + gaze.y} r="4.2" fill="#ffffff" />
          <circle cx={cx - 3.5 + gaze.x} cy={cy - 4 + gaze.y} r="3" fill="#ffffff" />
          {/* Raised curious cyber brow */}
          <path
            d={isLeft ? `M ${cx - 14} ${cy - 12 + browOffset} Q ${cx} ${cy - 18 + browOffset} ${cx + 14} ${cy - 10 + browOffset}` : `M ${cx - 14} ${cy - 11} Q ${cx} ${cy - 15} ${cx + 14} ${cy - 11}`}
            fill="none"
            stroke="#38bdf8"
            strokeWidth="2.6"
            strokeLinecap="round"
          />
        </g>
      );
    }

    // 5. THINKING: Eyes narrowed and focused upwards with soft cognitive ring
    if (emotion === 'thinking') {
      return (
        <g>
          <ellipse cx={cx} cy={cy - 2} rx="14" ry="11" fill="url(#eye-iris-gradient)" filter="url(#mascot-glow)" />
          <ellipse cx={cx} cy={cy - 2} rx="12" ry="9" fill="#0c4a6e" />
          <circle ref={pupilRef} cx={cx + gaze.x} cy={cy - 3 + gaze.y} r="5" fill="#c084fc" filter="url(#mascot-glow)" />
          <circle cx={cx + gaze.x} cy={cy - 3 + gaze.y} r="3" fill="#ffffff" />
          {/* Thoughtful level brow */}
          <path
            d={`M ${cx - 14} ${cy - 10} Q ${cx} ${cy - 13} ${cx + 14} ${cy - 9}`}
            stroke="#818cf8"
            strokeWidth="2.5"
            strokeLinecap="round"
          />
        </g>
      );
    }

    // 6. CONFUSED: Asymmetric quizzical eyes (one wide, one squinted)
    if (emotion === 'confused') {
      if (isLeft) {
        return (
          <g>
            <circle cx={cx} cy={cy - 2} r="14" fill="none" stroke="#00e5ff" strokeWidth="3.8" filter="url(#mascot-glow)" />
            <circle cx={cx} cy={cy - 2} r="5.5" fill="#ffffff" />
            <path d={`M ${cx - 12} ${cy - 18} L ${cx + 12} ${cy - 21}`} stroke="#38bdf8" strokeWidth="2.5" strokeLinecap="round" />
          </g>
        );
      }
      return (
        <g>
          <path d={`M ${cx - 12} ${cy + 2} Q ${cx} ${cy - 8} ${cx + 12} ${cy}`} fill="none" stroke="#00e5ff" strokeWidth="4.5" strokeLinecap="round" filter="url(#mascot-glow)" />
          <path d={`M ${cx - 10} ${cy - 14} L ${cx + 12} ${cy - 10}`} stroke="#38bdf8" strokeWidth="2.5" strokeLinecap="round" />
        </g>
      );
    }

    // 7. SURPRISED: Wide open glowing circles with high luminous radiance
    if (emotion === 'surprised') {
      const r = 16.5 + intensity * 2;
      return (
        <g>
          <circle cx={cx} cy={cy} r={r} fill="none" stroke="#00e5ff" strokeWidth="4.2" filter="url(#mascot-glow)" />
          <circle cx={cx} cy={cy} r={r - 2.5} fill="#0369a1" fillOpacity="0.4" />
          <circle ref={pupilRef} cx={cx + gaze.x} cy={cy + gaze.y} r="5.5" fill="#ffffff" filter="url(#mascot-glow)" />
          <path
            d={`M ${cx - 12} ${cy - 18} Q ${cx} ${cy - 22} ${cx + 12} ${cy - 18}`}
            stroke="#00e5ff"
            strokeWidth="2.5"
            strokeLinecap="round"
          />
        </g>
      );
    }

    // 8. CONCERNED: Softer inward-angled gentle brows with amber-cyan tone
    if (emotion === 'concerned' || emotion === 'worried') {
      const d = isLeft ? 'M 148 202 Q 162 193 176 191' : 'M 224 191 Q 238 193 252 202';
      return (
        <g>
          <ellipse cx={cx} cy={cy} rx="13.5" ry="14" fill="url(#eye-iris-gradient)" />
          <circle ref={pupilRef} cx={cx + gaze.x} cy={cy + gaze.y} r="6.2" fill="#facc15" filter="url(#mascot-glow)" />
          <circle cx={cx + gaze.x} cy={cy + gaze.y} r="3.2" fill="#ffffff" />
          <path d={d} fill="none" stroke="#facc15" strokeWidth="4.2" strokeLinecap="round" filter="url(#mascot-glow)" />
          <path d={d} fill="none" stroke="#ffffff" strokeWidth="2.0" strokeLinecap="round" />
        </g>
      );
    }

    // 9. SERIOUS / FOCUSED: Firm level brows, sharp aperture, analytical scanning reticle
    if (emotion === 'serious' || emotion === 'focused') {
      return (
        <g>
          <ellipse cx={cx} cy={cy} rx="14" ry="12.5" fill="url(#eye-iris-gradient)" filter="url(#mascot-glow)" />
          <circle ref={pupilRef} cx={cx + gaze.x} cy={cy + gaze.y} r="6.5" fill="#00e5ff" />
          <circle cx={cx + gaze.x} cy={cy + gaze.y} r="3.2" fill="#ffffff" />
          {/* Analytical Reticle ring for focused */}
          {emotion === 'focused' && (
            <circle cx={cx} cy={cy} r="14.5" fill="none" stroke="#00e5ff" strokeWidth="1.8" strokeDasharray="4 3" filter="url(#mascot-glow)" />
          )}
          {/* Firm level cyber brow */}
          <path
            d={isLeft ? `M ${cx - 15} ${cy - 12} L ${cx + 15} ${cy - 10}` : `M ${cx - 15} ${cy - 10} L ${cx + 15} ${cy - 12}`}
            stroke="#0284c7"
            strokeWidth="3.2"
            strokeLinecap="round"
          />
        </g>
      );
    }

    // 10. CALM / RELIEVED: Soft serene almond eyes with peaceful teal/sky glow
    if (emotion === 'calm' || emotion === 'relieved') {
      return (
        <g>
          <ellipse cx={cx} cy={cy} rx="14.5" ry="12" fill="url(#eye-iris-gradient)" filter="url(#mascot-glow)" />
          <circle ref={pupilRef} cx={cx + gaze.x} cy={cy + gaze.y} r="5.5" fill="#34d399" filter="url(#mascot-glow)" />
          <circle cx={cx + gaze.x} cy={cy + gaze.y} r="2.8" fill="#ffffff" />
          <path
            d={`M ${cx - 14} ${cy - 7} Q ${cx} ${cy - 10} ${cx + 14} ${cy - 7}`}
            fill="none"
            stroke="#2dd4bf"
            strokeWidth="2.2"
            strokeLinecap="round"
          />
        </g>
      );
    }

    // 11. SAD / DISAPPOINTED: Downward drooping compassionate curves with soft tear sheen
    if (emotion === 'sad' || emotion === 'disappointed') {
      const d = isLeft ? 'M 148 194 Q 162 206 176 198' : 'M 224 198 Q 238 206 252 194';
      return (
        <g>
          <path d={d} fill="none" stroke="#38bdf8" strokeWidth="4.5" strokeLinecap="round" filter="url(#mascot-glow)" />
          <path d={d} fill="none" stroke="#ffffff" strokeWidth="2.5" strokeLinecap="round" />
          {/* Subtle luminous tear highlight */}
          <circle cx={isLeft ? 154 : 246} cy="209" r="2.5" fill="#00e5ff" filter="url(#mascot-glow)" />
        </g>
      );
    }

    // 12. PROUD / SUCCESS: Confident bright cyan-emerald radiance with cheerful sparkle
    if (emotion === 'proud' || emotion === 'success') {
      return (
        <g>
          <ellipse cx={cx} cy={cy} rx="15.5" ry="16" fill="url(#eye-iris-gradient)" filter="url(#mascot-glow)" />
          <circle ref={pupilRef} cx={cx + gaze.x} cy={cy + gaze.y} r="7.5" fill={emotion === 'success' ? '#34d399' : '#00e5ff'} filter="url(#mascot-glow)" />
          <circle cx={cx + gaze.x} cy={cy + gaze.y} r="4.2" fill="#ffffff" />
          {/* Sparkling victory glint */}
          <circle cx={cx - 4 + gaze.x} cy={cy - 4 + gaze.y} r="2.8" fill="#ffffff" />
          <path
            d={`M ${cx - 14} ${cy - 13} Q ${cx} ${cy - 17} ${cx + 14} ${cy - 11}`}
            stroke={emotion === 'success' ? '#34d399' : '#00e5ff'}
            strokeWidth="2.8"
            strokeLinecap="round"
          />
        </g>
      );
    }

    // 13. ERROR: Warning alert amber/red pulse with concerned furrow
    if (emotion === 'error') {
      const d = isLeft ? 'M 148 203 L 176 195' : 'M 224 195 L 252 203';
      return (
        <g>
          <ellipse cx={cx} cy={cy} rx="14" ry="14" fill="#450a0a" stroke="#f43f5e" strokeWidth="1.5" />
          <circle ref={pupilRef} cx={cx + gaze.x} cy={cy + gaze.y} r="6" fill="#f43f5e" filter="url(#mascot-glow)" />
          <circle cx={cx + gaze.x} cy={cy + gaze.y} r="3" fill="#ffffff" />
          <path d={d} stroke="#f43f5e" strokeWidth="3.2" strokeLinecap="round" filter="url(#mascot-glow)" />
        </g>
      );
    }

    // 14. IDLE / DEFAULT: Classic Cute Futuristic Cyber Eye
    return (
      <g>
        <ellipse cx={cx} cy={cy} rx="15" ry="17" fill="url(#eye-iris-gradient)" filter="url(#mascot-glow)" />
        <ellipse cx={cx} cy={cy} rx="13.5" ry="15.5" fill="#0c4a6e" fillOpacity="0.85" />
        <circle ref={pupilRef} cx={cx + gaze.x} cy={cy + gaze.y} r="7" fill="#00e5ff" filter="url(#mascot-glow)" />
        <circle cx={cx + gaze.x} cy={cy + gaze.y} r="4.5" fill="#ffffff" />
        <ellipse cx={cx - 4 + gaze.x} cy={cy - 5 + gaze.y} rx="3.5" ry="4" fill="#ffffff" opacity="0.95" />
        <circle cx={cx + 3.5 + gaze.x} cy={cy + 4 + gaze.y} r="1.8" fill="#ffffff" opacity="0.85" />
        <path
          d={isLeft ? `M ${cx - 15} ${cy - 12} Q ${cx} ${cy - 16} ${cx + 15} ${cy - 11}` : `M ${cx - 15} ${cy - 11} Q ${cx} ${cy - 16} ${cx + 15} ${cy - 12}`}
          fill="none"
          stroke="#0284c7"
          strokeWidth="2.5"
          strokeLinecap="round"
        />
      </g>
    );
  }
}
