import { HinataMouthState, HinataEmotion, AudioMetrics, MouthRenderParams } from './types';

export class MouthController {
  // Continuous interpolated mouth parameters
  private currentOpenness: number = 0;
  private currentWidth: number = 1.0;
  private currentCurvature: number = 0.3;
  private currentCornerLift: number = 0.0;

  private targetOpenness: number = 0;
  private targetWidth: number = 1.0;
  private targetCurvature: number = 0.3;
  private targetCornerLift: number = 0.0;

  // Active state
  private currentState: HinataMouthState = 'NEUTRAL';

  /**
   * Resets mouth state immediately (used during interruption or session stop)
   */
  public reset(): void {
    this.currentOpenness = 0;
    this.targetOpenness = 0;
    this.currentWidth = 1.0;
    this.targetWidth = 1.0;
    this.currentCurvature = 0.25;
    this.targetCurvature = 0.25;
    this.currentState = 'NEUTRAL';
  }

  /**
   * Determines the base mouth state given the current emotion and speaking state.
   */
  public resolveMouthState(
    emotion: HinataEmotion,
    isSpeaking: boolean,
    isVoicing: boolean
  ): HinataMouthState {
    if (isSpeaking && isVoicing) {
      return 'SPEAKING';
    }

    switch (emotion) {
      case 'happy':
      case 'excited':
      case 'proud':
      case 'success':
        return 'SMILE';

      case 'laughing':
        return 'LAUGHING';

      case 'surprised':
        return 'SURPRISED';

      case 'concerned':
      case 'worried':
      case 'sad':
      case 'disappointed':
      case 'error':
        return 'CONCERNED';

      case 'serious':
      case 'focused':
        return 'SERIOUS';

      case 'curious':
      case 'thinking':
      case 'calm':
      case 'relieved':
        return 'SMALL_SMILE';

      case 'idle':
      default:
        return 'NEUTRAL';
    }
  }

  /**
   * Updates mouth geometry per frame based on emotion resting shape and real-time audio visemes.
   */
  public update(
    dtSec: number,
    emotion: HinataEmotion,
    intensity: number,
    isSpeaking: boolean,
    audioMetrics: AudioMetrics
  ): MouthRenderParams {
    const isVoicing = audioMetrics.isVoicing && audioMetrics.volume > 0.015;
    const resolvedState = this.resolveMouthState(emotion, isSpeaking, isVoicing);
    this.currentState = resolvedState;

    // 1. Establish resting emotional shape targets
    let baseOpen = 0;
    let baseWidth = 1.0;
    let baseCurve = 0.3; // Default friendly gentle curve
    let baseLift = 0;

    switch (resolvedState) {
      case 'SMILE':
        baseCurve = 0.55 + intensity * 0.2;
        baseWidth = 1.15;
        baseOpen = 0.04;
        baseLift = 2.0;
        break;

      case 'LAUGHING':
        baseCurve = 0.65 + intensity * 0.25;
        baseWidth = 1.25;
        baseOpen = 0.25 + intensity * 0.15;
        baseLift = 3.0;
        break;

      case 'SMALL_SMILE':
        baseCurve = 0.38;
        baseWidth = 1.05;
        baseOpen = 0.0;
        baseLift = 1.0;
        break;

      case 'SURPRISED':
        baseCurve = 0.1;
        baseWidth = 0.82;
        baseOpen = 0.32 + intensity * 0.2;
        break;

      case 'CONCERNED':
        baseCurve = -0.32 - intensity * 0.15;
        baseWidth = 0.95;
        baseOpen = 0.02;
        break;

      case 'SERIOUS':
        baseCurve = 0.02;
        baseWidth = 0.98;
        baseOpen = 0.0;
        break;

      case 'NEUTRAL':
      default:
        baseCurve = 0.28;
        baseWidth = 1.0;
        baseOpen = 0.0;
        break;
    }

    // 2. Combine with real-time audio voice activity
    if (isSpeaking && isVoicing) {
      const vol = Math.min(1.0, audioMetrics.volume * 2.8);
      const cadence = audioMetrics.syllableRhythm;
      
      // Dynamic viseme adjustments
      let visemeOpenMult = 1.0;
      let visemeWidthMult = 1.0;
      let visemeCurveAdd = 0.0;

      switch (audioMetrics.visemeType) {
        case 'A': // Open vowel: maximum vertical aperture
          visemeOpenMult = 1.35;
          visemeWidthMult = 1.08;
          break;
        case 'O': // Rounded vowel: narrower width, high oval opening
          visemeOpenMult = 1.15;
          visemeWidthMult = 0.85;
          visemeCurveAdd = -0.1;
          break;
        case 'E': // Spread vowel: wide mouth with joyful upward corners
          visemeOpenMult = 0.85;
          visemeWidthMult = 1.32;
          visemeCurveAdd = 0.2;
          break;
        case 'M': // Bilabial consonant: rapid momentary lip closure
          visemeOpenMult = 0.18;
          visemeWidthMult = 0.95;
          break;
        case 'REST':
        default:
          visemeOpenMult = 0.3;
          break;
      }

      // Voice-driven vertical openness calculation
      const speechAperture = (vol * 0.75 + cadence * vol * 0.35) * visemeOpenMult;
      this.targetOpenness = Math.max(baseOpen, speechAperture);
      
      // Width modulation
      this.targetWidth = baseWidth * visemeWidthMult;
      
      // Curvature preserves emotional intent while talking:
      // e.g. Happy + Speaking retains smile curvature; Serious + Speaking remains controlled
      this.targetCurvature = Math.max(-0.25, baseCurve + visemeCurveAdd);
    } else {
      // Audio stopped or silence: smooth decay back to emotional resting baseline
      this.targetOpenness = baseOpen;
      this.targetWidth = baseWidth;
      this.targetCurvature = baseCurve;
      this.targetCornerLift = baseLift;
    }

    // 3. Smooth interpolation (Attack is brisk for syllables; Decay is organic)
    const attackSpeed = 32.0;
    const decaySpeed = isSpeaking ? 18.0 : 26.0; // Decay swiftly when speech ends
    const speed = this.targetOpenness > this.currentOpenness ? attackSpeed : decaySpeed;

    this.currentOpenness += (this.targetOpenness - this.currentOpenness) * Math.min(1, dtSec * speed);
    this.currentWidth += (this.targetWidth - this.currentWidth) * Math.min(1, dtSec * 16.0);
    this.currentCurvature += (this.targetCurvature - this.currentCurvature) * Math.min(1, dtSec * 12.0);
    this.currentCornerLift += (this.targetCornerLift - this.currentCornerLift) * Math.min(1, dtSec * 12.0);

    const mOpen = Math.max(0, this.currentOpenness);
    const mWidth = this.currentWidth;
    const mCurve = this.currentCurvature;

    // 4. Calculate SVG Path coordinates
    const halfW = 12 * mWidth;
    const centerX = 200;
    const baseY = 230;

    const mLeft = centerX - halfW;
    const mRight = centerX + halfW;
    const mTop = baseY - mCurve * 3 - this.currentCornerLift;
    const mBottom = baseY + mCurve * 2 + mOpen * 20;

    let pathD: string;
    let fillD: string;
    let fillOpacity: number = 0;

    if (mOpen < 0.05) {
      // Closed resting lip line
      pathD = `M ${mLeft.toFixed(1)} ${mTop.toFixed(1)} Q ${centerX} ${(mTop + 4 + mCurve * 6).toFixed(1)} ${mRight.toFixed(1)} ${mTop.toFixed(1)}`;
      fillD = '';
      fillOpacity = 0;
    } else {
      // Open animated mouth with upper and lower lip contours
      pathD = `M ${mLeft.toFixed(1)} ${mTop.toFixed(1)} Q ${centerX} ${(mTop - 1).toFixed(1)} ${mRight.toFixed(1)} ${mTop.toFixed(1)} Q ${centerX} ${mBottom.toFixed(1)} ${mLeft.toFixed(1)} ${mTop.toFixed(1)} Z`;
      fillD = pathD;
      fillOpacity = Math.min(0.95, 0.4 + mOpen * 1.5);
    }

    return {
      openness: mOpen,
      width: mWidth,
      curvature: mCurve,
      cornerLift: this.currentCornerLift,
      state: this.currentState,
      pathD,
      fillD,
      fillOpacity,
    };
  }
}
