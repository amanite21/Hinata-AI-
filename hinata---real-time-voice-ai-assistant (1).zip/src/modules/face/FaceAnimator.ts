import React from 'react';
import { AudioPlayer } from '../AudioPlayer';
import { AudioReactiveController } from './AudioReactiveController';
import { EyeController } from './EyeController';
import { MouthController } from './MouthController';
import { ExpressionController } from './ExpressionController';
import { HinataEmotion, HinataAIState, FaceVisualParams } from './types';

export interface FaceDomRefs {
  headGroupRef?: React.RefObject<SVGGElement | null>;
  haloGroupRef?: React.RefObject<SVGGElement | null>;
  orbitFrontRef?: React.RefObject<SVGGElement | null>;
  orbitBackRef?: React.RefObject<SVGGElement | null>;
  rippleGroupRef?: React.RefObject<SVGGElement | null>;
  leftEyeLidRef?: React.RefObject<SVGPathElement | null>;
  rightEyeLidRef?: React.RefObject<SVGPathElement | null>;
  mouthPathRef?: React.RefObject<SVGPathElement | null>;
  mouthFillRef?: React.RefObject<SVGPathElement | null>;
  leftBlushRef?: React.RefObject<SVGEllipseElement | null>;
  rightBlushRef?: React.RefObject<SVGEllipseElement | null>;
  auraGlowRef?: React.RefObject<HTMLDivElement | null>;
  leftPupilRef?: React.RefObject<SVGCircleElement | null>;
  rightPupilRef?: React.RefObject<SVGCircleElement | null>;
}

export class FaceAnimator {
  public audioController: AudioReactiveController;
  public eyeController: EyeController;
  public mouthController: MouthController;
  public expressionController: ExpressionController;

  // Floating & Breathing Physics State
  private floatTime: number = 0;
  private speechNodY: number = 0;
  private currentOrbitAngle: number = 0;

  constructor() {
    this.audioController = new AudioReactiveController();
    this.eyeController = new EyeController();
    this.mouthController = new MouthController();
    this.expressionController = new ExpressionController();
  }

  public setAudioPlayer(player: AudioPlayer | null): void {
    this.audioController.setAudioPlayer(player);
  }

  public setEmotion(emotion: HinataEmotion, intensity: number = 0.5): void {
    this.expressionController.setEmotion(emotion, intensity);
  }

  public resetSpeech(): void {
    this.audioController.reset();
    this.mouthController.reset();
    this.speechNodY = 0;
  }

  /**
   * Main per-frame update loop (called from requestAnimationFrame).
   * Calculates all visual micro-motions, lip-sync visemes, and gaze states.
   */
  public update(
    deltaMs: number,
    dtSec: number,
    aiState: HinataAIState,
    isSpeaking: boolean,
    fallbackOutputVol: number = 0
  ): FaceVisualParams {
    this.floatTime += dtSec;
    const t = this.floatTime;

    // 1. Audio Analysis & Voice Activity
    const audioMetrics = this.audioController.update(dtSec, isSpeaking, fallbackOutputVol);

    // 2. Expression & State Priority Resolution
    const expr = this.expressionController.update(dtSec, aiState);

    // 3. Eye Kinetics & Natural Saccades
    const eyes = this.eyeController.update(deltaMs, dtSec, expr.emotion, aiState, t);

    // 4. Lip-sync Mouth Synthesis
    const mouth = this.mouthController.update(
      dtSec,
      expr.emotion,
      expr.intensity,
      isSpeaking,
      audioMetrics
    );

    // 5. Breathing & Floating Micro-Motion Physics
    // Smooth harmonic hover with subtle sine curves
    const hoverY = Math.sin(t * expr.floatSpeed) * expr.floatAmp;
    const hoverRoll = Math.sin(t * (expr.floatSpeed * 0.5)) * 1.4;

    // Speech nodding emphasis
    if (isSpeaking && audioMetrics.isVoicing && audioMetrics.volume > 0.03) {
      this.speechNodY = Math.sin(t * 15.0) * (audioMetrics.volume * 4.2);
    } else {
      this.speechNodY *= Math.max(0, 1.0 - dtSec * 10.0);
    }

    const totalHeadY = hoverY + this.speechNodY;
    const totalRoll = hoverRoll + expr.tiltDeg;

    // Orbital ring continuous rotation
    this.currentOrbitAngle = (this.currentOrbitAngle + dtSec * expr.orbitSpeed) % 360;

    // Halo breathing scale
    const haloScale = 1.0 + Math.sin(t * 2.0) * 0.02 + (isSpeaking ? audioMetrics.volume * 0.08 : 0);

    return {
      emotion: expr.emotion,
      intensity: expr.intensity,
      aiState,
      floatY: totalHeadY,
      headRollDeg: totalRoll,
      headTiltDeg: expr.tiltDeg,
      speechNodY: this.speechNodY,
      auraColor: expr.config.auraGradient,
      auraScale: isSpeaking ? 1.22 : 1.0,
      auraOpacity: 0.65 + Math.sin(t * 2.2) * 0.15 + (isSpeaking ? 0.2 : 0),
      haloScale,
      haloColor: expr.config.haloColor,
      orbitSpeed: expr.orbitSpeed,
      orbitAngle: this.currentOrbitAngle,
      blushOpacity: expr.blushOpacity,
      blushColor: expr.config.blushColor,
      leftEye: eyes.leftEye,
      rightEye: eyes.rightEye,
      gaze: eyes.gaze,
      mouth,
    };
  }

  /**
   * Applies the calculated parameters directly to SVG DOM nodes for fast 60FPS mobile execution.
   */
  public applyToDom(params: FaceVisualParams, refs: FaceDomRefs): void {
    // 1. Head Floating & Roll
    if (refs.headGroupRef?.current) {
      refs.headGroupRef.current.setAttribute(
        'transform',
        `translate(0, ${params.floatY.toFixed(2)}) rotate(${params.headRollDeg.toFixed(2)}, 200, 200)`
      );
    }

    // 2. Halo tracking with soft lag
    if (refs.haloGroupRef?.current) {
      const haloY = params.floatY * 0.85;
      refs.haloGroupRef.current.setAttribute(
        'transform',
        `translate(0, ${haloY.toFixed(2)}) scale(${params.haloScale.toFixed(3)})`
      );
    }

    // 3. Orbital Rings Rotation
    if (refs.orbitFrontRef?.current && refs.orbitBackRef?.current) {
      const rot = `rotate(${params.orbitAngle.toFixed(1)}, 200, 208)`;
      refs.orbitFrontRef.current.setAttribute('transform', rot);
      refs.orbitBackRef.current.setAttribute('transform', rot);
    }

    // 4. Floor Ripple
    if (refs.rippleGroupRef?.current) {
      refs.rippleGroupRef.current.style.opacity = params.auraOpacity.toFixed(2);
    }

    // 5. Blinking Eyelids
    const blinkVal = params.leftEye.blinkProgress;
    const lidY = 186 + blinkVal * 24;
    if (refs.leftEyeLidRef?.current) {
      refs.leftEyeLidRef.current.setAttribute('d', `M 146 186 Q 162 ${lidY.toFixed(1)} 178 186 Q 162 182 146 186 Z`);
      refs.leftEyeLidRef.current.style.opacity = blinkVal > 0.05 ? '0.98' : '0';
    }
    if (refs.rightEyeLidRef?.current) {
      refs.rightEyeLidRef.current.setAttribute('d', `M 222 186 Q 238 ${lidY.toFixed(1)} 254 186 Q 238 182 222 186 Z`);
      refs.rightEyeLidRef.current.style.opacity = blinkVal > 0.05 ? '0.98' : '0';
    }

    // 6. Gaze Pupils
    const gx = params.gaze.x;
    const gy = params.gaze.y;
    if (refs.leftPupilRef?.current) {
      refs.leftPupilRef.current.setAttribute('cx', (162 + gx).toFixed(1));
      refs.leftPupilRef.current.setAttribute('cy', (198 + gy).toFixed(1));
    }
    if (refs.rightPupilRef?.current) {
      refs.rightPupilRef.current.setAttribute('cx', (238 + gx).toFixed(1));
      refs.rightPupilRef.current.setAttribute('cy', (198 + gy).toFixed(1));
    }

    // 7. Mouth Path & Fill
    if (refs.mouthPathRef?.current) {
      refs.mouthPathRef.current.setAttribute('d', params.mouth.pathD);
    }
    if (refs.mouthFillRef?.current) {
      if (params.mouth.fillD) {
        refs.mouthFillRef.current.setAttribute('d', params.mouth.fillD);
        refs.mouthFillRef.current.style.opacity = params.mouth.fillOpacity.toFixed(2);
      } else {
        refs.mouthFillRef.current.style.opacity = '0';
      }
    }

    // 8. Cheeks Blush
    if (refs.leftBlushRef?.current && refs.rightBlushRef?.current) {
      const blushStr = params.blushOpacity.toFixed(2);
      refs.leftBlushRef.current.style.opacity = blushStr;
      refs.rightBlushRef.current.style.opacity = blushStr;
    }
  }
}
