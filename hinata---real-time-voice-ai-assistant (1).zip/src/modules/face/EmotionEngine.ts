import { HinataEmotion, EmotionMetadata } from './types';

export type EmotionListener = (
  emotion: HinataEmotion,
  intensity: number,
  reason?: string
) => void;

export class EmotionEngine {
  private static instance: EmotionEngine | null = null;

  private currentEmotion: HinataEmotion = 'idle';
  private currentIntensity: number = 0.5; // 0.0 to 1.0
  private listeners: Set<EmotionListener> = new Set();
  
  // Turn tracking for natural cooldown
  private turnsInCurrentEmotion: number = 0;

  private constructor() {}

  public static getInstance(): EmotionEngine {
    if (!EmotionEngine.instance) {
      EmotionEngine.instance = new EmotionEngine();
    }
    return EmotionEngine.instance;
  }

  public getEmotion(): HinataEmotion {
    return this.currentEmotion;
  }

  public getIntensity(): number {
    return this.currentIntensity;
  }

  public subscribe(listener: EmotionListener): () => void {
    this.listeners.add(listener);
    // Trigger immediately with current state
    listener(this.currentEmotion, this.currentIntensity, 'Initial sync');
    return () => {
      this.listeners.delete(listener);
    };
  }

  /**
   * Sets emotion explicitly with normalized intensity (0.0 to 1.0).
   */
  public setEmotion(
    rawEmotion: string,
    rawIntensity: number = 0.5,
    reason?: string
  ): void {
    const emotion = this.normalizeEmotion(rawEmotion);
    
    // Normalize intensity: convert 1-5 scale if passed as integer, or clamp 0.0 to 1.0
    let intensity = rawIntensity;
    if (intensity > 1.0 && intensity <= 5.0) {
      intensity = intensity / 5.0; // scale 1-5 down to 0.2-1.0
    }
    intensity = Math.max(0.1, Math.min(1.0, intensity));

    this.currentEmotion = emotion;
    this.currentIntensity = intensity;
    this.turnsInCurrentEmotion = 0;

    this.notifyListeners(reason);
  }

  /**
   * Parses emotional metadata from AI response text or structured payloads.
   * Examples:
   * { "emotion": "happy", "intensity": 0.75 }
   * or embedded [emotion: thinking, intensity: 0.60]
   */
  public parseResponseMetadata(textOrObj: any): EmotionMetadata | null {
    if (!textOrObj) return null;

    // 1. Direct Object
    if (typeof textOrObj === 'object') {
      if (textOrObj.emotion) {
        const emo = this.normalizeEmotion(String(textOrObj.emotion));
        const inten = typeof textOrObj.intensity === 'number' ? textOrObj.intensity : 0.6;
        return { emotion: emo, intensity: inten, reason: textOrObj.reason };
      }
    }

    // 2. String Parsing
    if (typeof textOrObj === 'string') {
      const text = textOrObj.trim();

      // Look for JSON block in markdown or raw text: {"emotion": "...", "intensity": ...}
      const jsonMatch = text.match(/\{[\s\S]*?"emotion"\s*:\s*"([a-zA-Z_-]+)"[\s\S]*?\}/);
      if (jsonMatch) {
        try {
          const parsed = JSON.parse(jsonMatch[0]);
          if (parsed.emotion) {
            let inten = 0.5;
            if (typeof parsed.intensity === 'number') {
              inten = parsed.intensity > 1.0 ? parsed.intensity / 5.0 : parsed.intensity;
            }
            return {
              emotion: this.normalizeEmotion(parsed.emotion),
              intensity: Math.max(0.1, Math.min(1.0, inten)),
              reason: parsed.reason || 'Parsed from AI response JSON metadata',
            };
          }
        } catch {
          // Continue to regex fallbacks
        }
      }

      // Look for bracket tags: [emotion: happy, intensity: 0.75]
      const bracketMatch = text.match(/\[\s*emotion\s*:\s*([a-zA-Z_-]+)(?:\s*,\s*intensity\s*:\s*([0-9.]+))?\s*\]/i);
      if (bracketMatch) {
        const emo = this.normalizeEmotion(bracketMatch[1]);
        let inten = bracketMatch[2] ? parseFloat(bracketMatch[2]) : 0.6;
        if (inten > 1.0) inten /= 5.0;
        return {
          emotion: emo,
          intensity: Math.max(0.1, Math.min(1.0, inten)),
          reason: 'Parsed from bracket metadata',
        };
      }
    }

    return null;
  }

  /**
   * Analyzes conversation turn context to select natural expressions.
   * Does NOT randomly change emotions; only reacts to genuine context cues.
   */
  public processConversationContext(
    role: 'user' | 'assistant',
    text: string
  ): void {
    const raw = (text || '').toLowerCase().trim();
    if (!raw) return;

    // Check if AI response contained explicit metadata first
    const explicitMeta = this.parseResponseMetadata(text);
    if (explicitMeta) {
      this.setEmotion(explicitMeta.emotion as HinataEmotion, explicitMeta.intensity, explicitMeta.reason);
      return;
    }

    this.turnsInCurrentEmotion++;

    // Natural conversation sentiment detection
    if (role === 'user') {
      if (raw.includes('hello') || raw.includes('hi hinata') || raw.includes('hey')) {
        this.setEmotion('happy', 0.5, 'Warm user greeting');
      } else if (raw.includes('thank') || raw.includes('awesome') || raw.includes('great job') || raw.includes('perfect')) {
        this.setEmotion('proud', 0.75, 'User expressed gratitude/praise');
      } else if (raw.includes('why') || raw.includes('how does') || raw.includes('explain') || raw.includes('what is')) {
        this.setEmotion('curious', 0.5, 'User asked exploratory inquiry');
      } else if (raw.includes('error') || raw.includes('broken') || raw.includes('not working') || raw.includes('failed') || raw.includes('bug')) {
        this.setEmotion('concerned', 0.6, 'User reported an issue/error');
      } else if (raw.includes('haha') || raw.includes('lol') || raw.includes('lmao') || raw.includes('funny')) {
        this.setEmotion('laughing', 0.7, 'Shared laughter in conversation');
      }
    } else if (role === 'assistant') {
      if (raw.includes('i found') || raw.includes('here is the solution') || raw.includes('successfully') || raw.includes('all done')) {
        this.setEmotion('success', 0.8, 'Task completed successfully');
      } else if (raw.includes('let me think') || raw.includes('analyzing') || raw.includes('let me check')) {
        this.setEmotion('thinking', 0.65, 'Cognitive search and analysis');
      } else if (raw.includes('unfortunately') || raw.includes('i apologize') || raw.includes('sorry about that')) {
        this.setEmotion('concerned', 0.55, 'Polite supportive concern');
      }
    }

    // Cooldown drift: after 4 turns without strong emotions, drift back to calm/idle
    if (this.turnsInCurrentEmotion >= 4 && this.currentEmotion !== 'idle' && this.currentEmotion !== 'calm') {
      this.setEmotion('idle', 0.4, 'Conversational cooldown to equilibrium');
    }
  }

  /**
   * Normalizes any input string to a valid HinataEmotion.
   */
  public normalizeEmotion(raw: string): HinataEmotion {
    const clean = (raw || '').toLowerCase().trim();

    const validEmotions: HinataEmotion[] = [
      'idle',
      'happy',
      'excited',
      'curious',
      'thinking',
      'confused',
      'surprised',
      'concerned',
      'serious',
      'focused',
      'calm',
      'sad',
      'disappointed',
      'laughing',
      'proud',
      'relieved',
      'worried',
      'error',
      'success',
    ];

    if (validEmotions.includes(clean as HinataEmotion)) {
      return clean as HinataEmotion;
    }

    // Comprehensive alias mapping
    const aliasMap: Record<string, HinataEmotion> = {
      neutral: 'idle',
      cute: 'happy',
      playful: 'happy',
      amused: 'laughing',
      laugh: 'laughing',
      joy: 'happy',
      thrilled: 'excited',
      wonder: 'curious',
      inquisitive: 'curious',
      contemplative: 'thinking',
      puzzled: 'confused',
      astonished: 'surprised',
      shocked: 'surprised',
      empathetic: 'concerned',
      worried: 'worried',
      anxious: 'worried',
      firm: 'serious',
      determined: 'serious',
      analytical: 'focused',
      peaceful: 'calm',
      relaxed: 'calm',
      serene: 'calm',
      sorrow: 'sad',
      down: 'sad',
      bummed: 'disappointed',
      triumphant: 'proud',
      confident: 'proud',
      ease: 'relieved',
      danger: 'error',
      failed: 'error',
      done: 'success',
      solved: 'success',
    };

    return aliasMap[clean] || 'idle';
  }

  private notifyListeners(reason?: string): void {
    for (const listener of this.listeners) {
      try {
        listener(this.currentEmotion, this.currentIntensity, reason);
      } catch (err) {
        console.error('[EmotionEngine] Listener error:', err);
      }
    }
  }
}
