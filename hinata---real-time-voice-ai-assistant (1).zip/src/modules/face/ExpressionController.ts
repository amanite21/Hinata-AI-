import { HinataEmotion, HinataAIState } from './types';

export interface ExpressionConfig {
  emotion: HinataEmotion;
  label: string;
  emoji: string;
  auraGradient: string;
  haloColor: string;
  haloGlowColor: string;
  primaryEyeColor: string;
  blushOpacity: number;
  blushColor: string;
  headTiltDeg: number;
  floatSpeed: number;
  floatAmp: number;
  orbitSpeed: number;
}

export const EXPRESSION_PRESETS: Record<HinataEmotion, ExpressionConfig> = {
  idle: {
    emotion: 'idle',
    label: 'Idle',
    emoji: '✨',
    auraGradient: 'radial-gradient(circle, rgba(0, 229, 255, 0.25) 0%, rgba(168, 85, 247, 0.18) 50%, transparent 75%)',
    haloColor: '#00e5ff',
    haloGlowColor: 'rgba(0, 229, 255, 0.45)',
    primaryEyeColor: '#00e5ff',
    blushOpacity: 0.35,
    blushColor: '#ff4fd8',
    headTiltDeg: 0,
    floatSpeed: 1.6,
    floatAmp: 4.0,
    orbitSpeed: 16,
  },
  happy: {
    emotion: 'happy',
    label: 'Happy',
    emoji: '😊',
    auraGradient: 'radial-gradient(circle, rgba(0, 229, 255, 0.45) 0%, rgba(251, 191, 36, 0.25) 50%, transparent 75%)',
    haloColor: '#00e5ff',
    haloGlowColor: 'rgba(0, 229, 255, 0.65)',
    primaryEyeColor: '#00e5ff',
    blushOpacity: 0.75,
    blushColor: '#ff4fd8',
    headTiltDeg: 1.8,
    floatSpeed: 2.2,
    floatAmp: 5.5,
    orbitSpeed: 22,
  },
  excited: {
    emotion: 'excited',
    label: 'Excited',
    emoji: '😄',
    auraGradient: 'radial-gradient(circle, rgba(236, 72, 153, 0.55) 0%, rgba(0, 229, 255, 0.45) 50%, transparent 75%)',
    haloColor: '#ff4fd8',
    haloGlowColor: 'rgba(255, 79, 216, 0.7)',
    primaryEyeColor: '#00e5ff',
    blushOpacity: 0.85,
    blushColor: '#fb7185',
    headTiltDeg: -2.5,
    floatSpeed: 3.5,
    floatAmp: 6.8,
    orbitSpeed: 34,
  },
  curious: {
    emotion: 'curious',
    label: 'Curious',
    emoji: '🤔',
    auraGradient: 'radial-gradient(circle, rgba(168, 85, 247, 0.45) 0%, rgba(6, 182, 212, 0.3) 50%, transparent 75%)',
    haloColor: '#a855f7',
    haloGlowColor: 'rgba(168, 85, 247, 0.55)',
    primaryEyeColor: '#38bdf8',
    blushOpacity: 0.4,
    blushColor: '#c084fc',
    headTiltDeg: 4.2, // Inquisitive head tilt
    floatSpeed: 1.9,
    floatAmp: 4.5,
    orbitSpeed: 18,
  },
  thinking: {
    emotion: 'thinking',
    label: 'Thinking',
    emoji: '🧐',
    auraGradient: 'radial-gradient(circle, rgba(129, 140, 248, 0.4) 0%, rgba(168, 85, 247, 0.25) 50%, transparent 75%)',
    haloColor: '#818cf8',
    haloGlowColor: 'rgba(129, 140, 248, 0.5)',
    primaryEyeColor: '#c084fc',
    blushOpacity: 0.25,
    blushColor: '#818cf8',
    headTiltDeg: 2.8,
    floatSpeed: 1.3,
    floatAmp: 3.2,
    orbitSpeed: 12,
  },
  confused: {
    emotion: 'confused',
    label: 'Confused',
    emoji: '❓',
    auraGradient: 'radial-gradient(circle, rgba(56, 189, 248, 0.4) 0%, rgba(168, 85, 247, 0.25) 50%, transparent 75%)',
    haloColor: '#38bdf8',
    haloGlowColor: 'rgba(56, 189, 248, 0.45)',
    primaryEyeColor: '#38bdf8',
    blushOpacity: 0.35,
    blushColor: '#93c5fd',
    headTiltDeg: -3.8,
    floatSpeed: 1.7,
    floatAmp: 4.0,
    orbitSpeed: 15,
  },
  surprised: {
    emotion: 'surprised',
    label: 'Surprised',
    emoji: '😲',
    auraGradient: 'radial-gradient(circle, rgba(0, 229, 255, 0.6) 0%, rgba(56, 189, 248, 0.35) 50%, transparent 75%)',
    haloColor: '#00e5ff',
    haloGlowColor: 'rgba(0, 229, 255, 0.75)',
    primaryEyeColor: '#00e5ff',
    blushOpacity: 0.55,
    blushColor: '#38bdf8',
    headTiltDeg: 0,
    floatSpeed: 2.4,
    floatAmp: 5.2,
    orbitSpeed: 26,
  },
  concerned: {
    emotion: 'concerned',
    label: 'Concerned',
    emoji: '🥺',
    auraGradient: 'radial-gradient(circle, rgba(234, 179, 8, 0.35) 0%, rgba(56, 189, 248, 0.2) 50%, transparent 75%)',
    haloColor: '#facc15',
    haloGlowColor: 'rgba(250, 204, 21, 0.45)',
    primaryEyeColor: '#facc15',
    blushOpacity: 0.2,
    blushColor: '#fef08a',
    headTiltDeg: 1.5,
    floatSpeed: 1.4,
    floatAmp: 3.5,
    orbitSpeed: 13,
  },
  serious: {
    emotion: 'serious',
    label: 'Serious',
    emoji: '😐',
    auraGradient: 'radial-gradient(circle, rgba(2, 132, 199, 0.4) 0%, rgba(15, 23, 42, 0.5) 50%, transparent 75%)',
    haloColor: '#0284c7',
    haloGlowColor: 'rgba(2, 132, 199, 0.45)',
    primaryEyeColor: '#00e5ff',
    blushOpacity: 0.05,
    blushColor: '#0284c7',
    headTiltDeg: 0,
    floatSpeed: 1.2,
    floatAmp: 2.8,
    orbitSpeed: 10,
  },
  focused: {
    emotion: 'focused',
    label: 'Focused',
    emoji: '🎯',
    auraGradient: 'radial-gradient(circle, rgba(0, 229, 255, 0.48) 0%, rgba(30, 58, 138, 0.35) 50%, transparent 75%)',
    haloColor: '#00e5ff',
    haloGlowColor: 'rgba(0, 229, 255, 0.65)',
    primaryEyeColor: '#00e5ff',
    blushOpacity: 0.1,
    blushColor: '#0284c7',
    headTiltDeg: 0,
    floatSpeed: 1.4,
    floatAmp: 3.0,
    orbitSpeed: 14,
  },
  calm: {
    emotion: 'calm',
    label: 'Calm',
    emoji: '😌',
    auraGradient: 'radial-gradient(circle, rgba(45, 212, 191, 0.35) 0%, rgba(56, 189, 248, 0.2) 50%, transparent 75%)',
    haloColor: '#2dd4bf',
    haloGlowColor: 'rgba(45, 212, 191, 0.45)',
    primaryEyeColor: '#34d399',
    blushOpacity: 0.3,
    blushColor: '#99f6e4',
    headTiltDeg: 0,
    floatSpeed: 1.3,
    floatAmp: 3.5,
    orbitSpeed: 11,
  },
  sad: {
    emotion: 'sad',
    label: 'Sad',
    emoji: '😢',
    auraGradient: 'radial-gradient(circle, rgba(56, 189, 248, 0.3) 0%, rgba(30, 58, 138, 0.35) 50%, transparent 75%)',
    haloColor: '#38bdf8',
    haloGlowColor: 'rgba(56, 189, 248, 0.35)',
    primaryEyeColor: '#38bdf8',
    blushOpacity: 0.1,
    blushColor: '#bae6fd',
    headTiltDeg: 1.2,
    floatSpeed: 1.1,
    floatAmp: 2.6,
    orbitSpeed: 9,
  },
  disappointed: {
    emotion: 'disappointed',
    label: 'Disappointed',
    emoji: '😞',
    auraGradient: 'radial-gradient(circle, rgba(100, 116, 139, 0.3) 0%, rgba(30, 41, 59, 0.4) 50%, transparent 75%)',
    haloColor: '#64748b',
    haloGlowColor: 'rgba(100, 116, 139, 0.3)',
    primaryEyeColor: '#94a3b8',
    blushOpacity: 0.05,
    blushColor: '#64748b',
    headTiltDeg: 2.0,
    floatSpeed: 1.0,
    floatAmp: 2.4,
    orbitSpeed: 8,
  },
  laughing: {
    emotion: 'laughing',
    label: 'Laughing',
    emoji: '😆',
    auraGradient: 'radial-gradient(circle, rgba(0, 229, 255, 0.55) 0%, rgba(244, 63, 94, 0.35) 50%, transparent 75%)',
    haloColor: '#00e5ff',
    haloGlowColor: 'rgba(0, 229, 255, 0.75)',
    primaryEyeColor: '#00e5ff',
    blushOpacity: 0.85,
    blushColor: '#fb7185',
    headTiltDeg: -2.0,
    floatSpeed: 3.2,
    floatAmp: 6.2,
    orbitSpeed: 30,
  },
  proud: {
    emotion: 'proud',
    label: 'Proud',
    emoji: '😎',
    auraGradient: 'radial-gradient(circle, rgba(0, 229, 255, 0.5) 0%, rgba(234, 179, 8, 0.3) 50%, transparent 75%)',
    haloColor: '#00e5ff',
    haloGlowColor: 'rgba(0, 229, 255, 0.65)',
    primaryEyeColor: '#00e5ff',
    blushOpacity: 0.6,
    blushColor: '#ff4fd8',
    headTiltDeg: -1.5,
    floatSpeed: 2.0,
    floatAmp: 5.0,
    orbitSpeed: 24,
  },
  relieved: {
    emotion: 'relieved',
    label: 'Relieved',
    emoji: '😌',
    auraGradient: 'radial-gradient(circle, rgba(52, 211, 153, 0.35) 0%, rgba(6, 182, 212, 0.25) 50%, transparent 75%)',
    haloColor: '#34d399',
    haloGlowColor: 'rgba(52, 211, 153, 0.45)',
    primaryEyeColor: '#34d399',
    blushOpacity: 0.45,
    blushColor: '#a7f3d0',
    headTiltDeg: 0.8,
    floatSpeed: 1.4,
    floatAmp: 3.8,
    orbitSpeed: 12,
  },
  worried: {
    emotion: 'worried',
    label: 'Worried',
    emoji: '😰',
    auraGradient: 'radial-gradient(circle, rgba(234, 179, 8, 0.4) 0%, rgba(249, 115, 22, 0.25) 50%, transparent 75%)',
    haloColor: '#eab308',
    haloGlowColor: 'rgba(234, 179, 8, 0.5)',
    primaryEyeColor: '#facc15',
    blushOpacity: 0.25,
    blushColor: '#fef08a',
    headTiltDeg: 2.4,
    floatSpeed: 2.1,
    floatAmp: 4.2,
    orbitSpeed: 18,
  },
  error: {
    emotion: 'error',
    label: 'Error',
    emoji: '⚠️',
    auraGradient: 'radial-gradient(circle, rgba(239, 68, 68, 0.6) 0%, rgba(185, 28, 28, 0.4) 50%, transparent 75%)',
    haloColor: '#ef4444',
    haloGlowColor: 'rgba(239, 68, 68, 0.75)',
    primaryEyeColor: '#f43f5e',
    blushOpacity: 0.1,
    blushColor: '#fecaca',
    headTiltDeg: 0,
    floatSpeed: 1.8,
    floatAmp: 3.5,
    orbitSpeed: 16,
  },
  success: {
    emotion: 'success',
    label: 'Success',
    emoji: '🎉',
    auraGradient: 'radial-gradient(circle, rgba(16, 185, 129, 0.55) 0%, rgba(0, 229, 255, 0.4) 50%, transparent 75%)',
    haloColor: '#10b981',
    haloGlowColor: 'rgba(16, 185, 129, 0.75)',
    primaryEyeColor: '#34d399',
    blushOpacity: 0.75,
    blushColor: '#6ee7b7',
    headTiltDeg: -1.2,
    floatSpeed: 2.5,
    floatAmp: 5.6,
    orbitSpeed: 28,
  },
};

export class ExpressionController {
  private currentEmotion: HinataEmotion = 'idle';
  private targetEmotion: HinataEmotion = 'idle';
  private currentIntensity: number = 0.5; // 0.0 to 1.0
  private targetIntensity: number = 0.5;

  // Smoothed numerical values for gradual transitions
  private smoothedTilt: number = 0;
  private smoothedBlush: number = 0.35;
  private smoothedFloatSpeed: number = 1.6;
  private smoothedFloatAmp: number = 4.0;
  private smoothedOrbitSpeed: number = 16;

  /**
   * Priority system:
   * ERROR (6) > SUCCESS (5) > SPEAKING (4) > THINKING / TOOL_USING / UNDERSTANDING (3) > LISTENING (2) > IDLE (1) > STOPPED (0)
   */
  public resolveEffectiveEmotion(
    requestedEmotion: HinataEmotion,
    aiState: HinataAIState
  ): HinataEmotion {
    switch (aiState) {
      case 'ERROR':
        return 'error';

      case 'SUCCESS':
        return 'success';

      case 'SPEAKING':
        // Speaking uses the contextual emotion
        return requestedEmotion === 'idle' ? 'happy' : requestedEmotion;

      case 'THINKING':
      case 'TOOL_USING':
        return 'thinking';

      case 'UNDERSTANDING':
        return 'focused';

      case 'LISTENING':
        return requestedEmotion === 'confused' || requestedEmotion === 'curious'
          ? requestedEmotion
          : 'curious';

      case 'STOPPED':
        return 'calm';

      case 'IDLE':
      default:
        return requestedEmotion;
    }
  }

  public setEmotion(emotion: HinataEmotion, intensity: number = 0.5): void {
    this.targetEmotion = emotion;
    // Clamp intensity safely between 0.0 and 1.0
    this.targetIntensity = Math.max(0.0, Math.min(1.0, intensity));
  }

  /**
   * Smoothly interpolates expression parameters per animation frame
   */
  public update(
    dtSec: number,
    aiState: HinataAIState
  ): {
    emotion: HinataEmotion;
    intensity: number;
    config: ExpressionConfig;
    tiltDeg: number;
    blushOpacity: number;
    floatSpeed: number;
    floatAmp: number;
    orbitSpeed: number;
  } {
    const effectiveTarget = this.resolveEffectiveEmotion(this.targetEmotion, aiState);
    this.currentEmotion = effectiveTarget;

    const targetConfig = EXPRESSION_PRESETS[effectiveTarget] || EXPRESSION_PRESETS.idle;

    // Smooth intensity interpolation
    this.currentIntensity += (this.targetIntensity - this.currentIntensity) * Math.min(1, dtSec * 8.0);

    // Smooth continuous parameter transitions
    const lerpRate = Math.min(1, dtSec * 6.0);
    this.smoothedTilt += (targetConfig.headTiltDeg - this.smoothedTilt) * lerpRate;
    this.smoothedBlush += (targetConfig.blushOpacity * this.currentIntensity - this.smoothedBlush) * lerpRate;
    this.smoothedFloatSpeed += (targetConfig.floatSpeed - this.smoothedFloatSpeed) * lerpRate;
    this.smoothedFloatAmp += (targetConfig.floatAmp - this.smoothedFloatAmp) * lerpRate;
    this.smoothedOrbitSpeed += (targetConfig.orbitSpeed - this.smoothedOrbitSpeed) * lerpRate;

    return {
      emotion: this.currentEmotion,
      intensity: this.currentIntensity,
      config: targetConfig,
      tiltDeg: this.smoothedTilt,
      blushOpacity: this.smoothedBlush,
      floatSpeed: this.smoothedFloatSpeed,
      floatAmp: this.smoothedFloatAmp,
      orbitSpeed: this.smoothedOrbitSpeed,
    };
  }
}
