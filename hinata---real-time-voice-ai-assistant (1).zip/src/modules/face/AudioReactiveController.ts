import { AudioPlayer } from '../AudioPlayer';
import { AudioMetrics } from './types';

export class AudioReactiveController {
  private audioPlayer: AudioPlayer | null = null;
  private analyser: AnalyserNode | null = null;
  private freqData: Uint8Array | null = null;
  
  // Smoothing & VAD
  private smoothedVolume: number = 0;
  private peakVolume: number = 0;
  private isCurrentlyVoicing: boolean = false;
  private silenceTimer: number = 0;
  private speechPhase: number = 0;
  
  // Dynamic metrics cache
  private metrics: AudioMetrics = {
    volume: 0,
    rawVolume: 0,
    lowEnergy: 0,
    midEnergy: 0,
    highEnergy: 0,
    isVoicing: false,
    syllableRhythm: 0,
    visemeType: 'REST',
  };

  public setAudioPlayer(player: AudioPlayer | null): void {
    this.audioPlayer = player;
    this.analyser = null;
    this.freqData = null;
  }

  /**
   * Resets audio reaction immediately (e.g. upon user interruption or session stop)
   */
  public reset(): void {
    this.smoothedVolume = 0;
    this.peakVolume = 0;
    this.isCurrentlyVoicing = false;
    this.silenceTimer = 0;
    this.metrics = {
      volume: 0,
      rawVolume: 0,
      lowEnergy: 0,
      midEnergy: 0,
      highEnergy: 0,
      isVoicing: false,
      syllableRhythm: 0,
      visemeType: 'REST',
    };
  }

  /**
   * Samples the audio analyser node and computes real-time voice reactivity metrics.
   * Runs every animation frame (e.g. 60 FPS).
   */
  public update(
    dtSec: number,
    isSpeakingState: boolean,
    fallbackOutputVol: number = 0
  ): AudioMetrics {
    // Check if player is active
    let hasAudio = false;
    if (this.audioPlayer) {
      if (typeof this.audioPlayer.hasActiveAudio === 'function') {
        hasAudio = this.audioPlayer.hasActiveAudio();
      } else if (typeof this.audioPlayer.getIsPlaying === 'function') {
        hasAudio = this.audioPlayer.getIsPlaying();
      }
    }

    // Interruption / Silence guard: if not speaking and player has no active audio, decay to zero swiftly
    if (!hasAudio && !isSpeakingState) {
      this.smoothedVolume = Math.max(0, this.smoothedVolume - dtSec * 16.0);
      this.isCurrentlyVoicing = false;
      this.metrics.volume = this.smoothedVolume;
      this.metrics.rawVolume = 0;
      this.metrics.isVoicing = false;
      this.metrics.visemeType = 'REST';
      return this.metrics;
    }

    // Acquire AnalyserNode
    if (this.audioPlayer && !this.analyser) {
      if (typeof this.audioPlayer.getAudioAnalyser === 'function') {
        this.analyser = this.audioPlayer.getAudioAnalyser();
      } else if (typeof this.audioPlayer.getAnalyserNode === 'function') {
        this.analyser = this.audioPlayer.getAnalyserNode();
      }
    }

    let rawVol = 0;
    let lowEnergy = 0;
    let midEnergy = 0;
    let highEnergy = 0;

    if (this.analyser && hasAudio) {
      const binCount = this.analyser.frequencyBinCount;
      if (!this.freqData || this.freqData.length !== binCount) {
        this.freqData = new Uint8Array(binCount);
      }
      this.analyser.getByteFrequencyData(this.freqData);

      // Low / Bass resonant frequencies (bins 0 to 8: ~0 to 750Hz) -> O / U / Open throat
      let lowSum = 0;
      const lowBins = Math.min(8, binCount);
      for (let i = 0; i < lowBins; i++) {
        lowSum += this.freqData[i];
      }
      lowEnergy = lowSum / (lowBins * 255);

      // Mid frequencies (bins 8 to 28: ~750Hz to 2600Hz) -> A / Vowel Formants
      let midSum = 0;
      const midStart = lowBins;
      const midEnd = Math.min(28, binCount);
      for (let i = midStart; i < midEnd; i++) {
        midSum += this.freqData[i];
      }
      midEnergy = midSum / (Math.max(1, midEnd - midStart) * 255);

      // High frequencies (bins 28 to 64: ~2600Hz to 6000Hz) -> S / T / E / Fricatives
      let highSum = 0;
      const highStart = midEnd;
      const highEnd = Math.min(64, binCount);
      for (let i = highStart; i < highEnd; i++) {
        highSum += this.freqData[i];
      }
      highEnergy = highSum / (Math.max(1, highEnd - highStart) * 255);

      // Total raw volume RMS approximation
      rawVol = lowEnergy * 0.35 + midEnergy * 0.5 + highEnergy * 0.15;
    } else {
      // Fallback to output volume telemetry if analyser not available
      rawVol = hasAudio || isSpeakingState ? Math.max(0, fallbackOutputVol) : 0;
      lowEnergy = rawVol * 0.8;
      midEnergy = rawVol;
      highEnergy = rawVol * 0.5;
    }

    // Noise gate threshold: values below 0.015 are considered room floor
    if (rawVol < 0.015) {
      rawVol = 0;
    }

    // Track Voice Activity Detection (VAD)
    const isVoicingNow = rawVol > 0.02 && (hasAudio || isSpeakingState);
    if (isVoicingNow) {
      this.silenceTimer = 0;
      this.isCurrentlyVoicing = true;
    } else {
      this.silenceTimer += dtSec;
      if (this.silenceTimer > 0.08) {
        this.isCurrentlyVoicing = false;
      }
    }

    // Natural attack and decay filter
    // Attack is fast (opening mouth quickly to spoken syllables)
    // Decay is slightly slower to preserve natural vocal cadence without stutter
    const attackSpeed = 28.0;
    const decaySpeed = 14.0;
    const lerpSpeed = rawVol > this.smoothedVolume ? attackSpeed : decaySpeed;
    this.smoothedVolume += (rawVol - this.smoothedVolume) * Math.min(1, dtSec * lerpSpeed);

    // Dynamic Viseme Classification based on spectral envelope
    let viseme: 'A' | 'O' | 'E' | 'M' | 'REST' = 'REST';
    if (this.smoothedVolume > 0.04) {
      if (highEnergy > 0.28 && highEnergy >= midEnergy * 0.75) {
        viseme = 'E'; // wide lips, smiling vowel
      } else if (lowEnergy > 0.35 && lowEnergy > highEnergy * 1.3) {
        viseme = 'O'; // rounded lips, deep vowel
      } else if (midEnergy > 0.25 || this.smoothedVolume > 0.12) {
        viseme = 'A'; // open jaw, rich formant
      } else {
        viseme = 'M'; // semi-closed transition
      }
    } else {
      viseme = 'REST';
    }

    // Organic speech cadence micro-harmonic
    this.speechPhase += dtSec * (16.0 + (midEnergy * 10.0));
    const syllableRhythm = (Math.sin(this.speechPhase) + 1.0) * 0.5;

    this.metrics = {
      volume: this.smoothedVolume,
      rawVolume: rawVol,
      lowEnergy,
      midEnergy,
      highEnergy,
      isVoicing: this.isCurrentlyVoicing,
      syllableRhythm,
      visemeType: viseme,
    };

    return this.metrics;
  }
}
