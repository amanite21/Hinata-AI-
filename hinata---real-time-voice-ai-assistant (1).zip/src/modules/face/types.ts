import { HinataEmotion, HinataMouthState, HinataAIState, EmotionMetadata } from '../../types';

export type { HinataEmotion, HinataMouthState, HinataAIState, EmotionMetadata };

export interface AudioMetrics {
  volume: number; // 0.0 to 1.0 smoothed
  rawVolume: number; // instantaneous volume
  lowEnergy: number; // 0.0 to 1.0 (vowel openness / base resonant cavity)
  midEnergy: number; // 0.0 to 1.0 (vocal presence)
  highEnergy: number; // 0.0 to 1.0 (fricatives, consonants, lip spread)
  isVoicing: boolean; // voice activity detection threshold
  syllableRhythm: number; // natural speech cadence harmonic
  visemeType: 'A' | 'O' | 'E' | 'M' | 'REST'; // spectral shape classification
}

export interface GazeState {
  x: number; // -10 to +10 horizontal gaze offset
  y: number; // -10 to +10 vertical gaze offset
  targetX: number;
  targetY: number;
  microSaccadeX: number;
  microSaccadeY: number;
}

export interface EyeRenderParams {
  openness: number; // 0.0 (closed) to 1.0 (fully open) to 1.25 (wide surprised)
  width: number; // 0.8 (squint) to 1.2
  arcCurvature: number; // upward (>0) for smiling/happy, downward (<0) for sad/concerned
  pupilScale: number; // 0.7 to 1.35
  pupilGlow: number; // luminous intensity
  primaryColor: string;
  glowColor: string;
  irisColor: string;
  eyebrowSlant: number; // -10 (inward furrow) to +10 (arched)
  eyebrowHeight: number; // -8 (lowered) to +8 (raised)
  isBlinking: boolean;
  blinkProgress: number; // 0 (open) to 1 (closed)
  showHighlights: boolean;
  sparkleType: 'none' | 'star' | 'glint' | 'tear' | 'reticle';
}

export interface MouthRenderParams {
  openness: number; // 0.0 to 1.0 (vertical gap)
  width: number; // horizontal width scale (0.8 to 1.4)
  curvature: number; // smile (>0) vs neutral (0) vs frown (<0)
  cornerLift: number;
  state: HinataMouthState;
  pathD: string;
  fillD: string;
  fillOpacity: number;
}

export interface FaceVisualParams {
  emotion: HinataEmotion;
  intensity: number; // 0.0 to 1.0
  aiState: HinataAIState;
  
  // Ethereal Head & Float
  floatY: number;
  headRollDeg: number;
  headTiltDeg: number;
  speechNodY: number;
  
  // Aura & Halo
  auraColor: string;
  auraScale: number;
  auraOpacity: number;
  haloScale: number;
  haloColor: string;
  
  // Orbital Rings
  orbitSpeed: number;
  orbitAngle: number;
  
  // Blush
  blushOpacity: number;
  blushColor: string;
  
  // Eyes
  leftEye: EyeRenderParams;
  rightEye: EyeRenderParams;
  gaze: GazeState;
  
  // Mouth
  mouth: MouthRenderParams;
}
