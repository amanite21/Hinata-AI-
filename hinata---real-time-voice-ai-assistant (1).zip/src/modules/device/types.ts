/**
 * Device Action Types & Interfaces for Hinata AI.
 */

export type DeviceActionType =
  | 'open_app'
  | 'system_setting'
  | 'phone_call'
  | 'send_message'
  | 'set_alarm'
  | 'set_timer'
  | 'open_camera'
  | 'open_gallery'
  | 'open_maps'
  | 'control_media'
  | 'share_content'
  | 'device_info'
  | 'torch'
  | 'in_app_action';

export type PermissionType =
  | 'microphone'
  | 'camera'
  | 'geolocation'
  | 'notifications'
  | 'contacts'
  | 'storage'
  | 'accessibility';

export type PermissionStatus = 'granted' | 'denied' | 'prompt' | 'unsupported';

export interface DeviceActionResult {
  success: boolean;
  action: DeviceActionType | string;
  target?: string;
  message: string;
  data?: any;
  requiresConfirmation?: boolean;
  confirmationRequired?: boolean;
  confirmationPrompt?: string;
  pendingActionId?: string;
  isSimulated?: false; // We strictly adhere to real execution
  timestamp: number;
}

export interface AppDefinition {
  id: string;
  name: string;
  aliases: string[];
  packageName: string;
  androidIntentUri: string;
  customScheme?: string;
  webFallback: string;
  category: 'social' | 'media' | 'system' | 'navigation' | 'productivity' | 'communication';
}

export interface SensitiveAction {
  id: string;
  type: DeviceActionType;
  description: string;
  target: string;
  params: Record<string, any>;
  confirmationQuestion: string;
  createdAt: number;
  expiresAt: number;
}

export interface TaskStep {
  id: string;
  title: string;
  description: string;
  actionType: DeviceActionType | string;
  status: 'pending' | 'executing' | 'completed' | 'failed' | 'skipped';
  result?: DeviceActionResult;
}

export interface TaskPlan {
  id: string;
  userPrompt: string;
  summary: string;
  steps: TaskStep[];
  currentStepIndex: number;
  status: 'planning' | 'executing' | 'completed' | 'failed';
  requiresConfirmation: boolean;
  confirmationPrompt?: string;
  createdAt: number;
}
