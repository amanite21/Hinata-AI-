/**
 * AppLauncher - Reusable Android App & Intent Launch System for Hinata AI.
 *
 * Implements clean Android package/intent dispatch with verified web fallbacks.
 * Gracefully reports uninstalled apps without crashing or pretending.
 */

import { AppDefinition, DeviceActionResult } from './types';
import { ActionVerifier } from './ActionVerifier';

export class AppLauncher {
  private static instance: AppLauncher | null = null;
  private appRegistry: Map<string, AppDefinition> = new Map();

  private constructor() {
    this.registerDefaultApps();
  }

  public static getInstance(): AppLauncher {
    if (!AppLauncher.instance) {
      AppLauncher.instance = new AppLauncher();
    }
    return AppLauncher.instance;
  }

  private registerDefaultApps(): void {
    const apps: AppDefinition[] = [
      {
        id: 'youtube',
        name: 'YouTube',
        aliases: ['yt', 'youtube', 'video', 'videos'],
        packageName: 'com.google.android.youtube',
        androidIntentUri: 'intent:#Intent;package=com.google.android.youtube;scheme=vnd.youtube;end',
        customScheme: 'vnd.youtube:',
        webFallback: 'https://www.youtube.com',
        category: 'media',
      },
      {
        id: 'whatsapp',
        name: 'WhatsApp',
        aliases: ['whatsapp', 'wa', 'whats app'],
        packageName: 'com.whatsapp',
        androidIntentUri: 'intent:#Intent;package=com.whatsapp;scheme=whatsapp;end',
        customScheme: 'whatsapp://',
        webFallback: 'https://web.whatsapp.com',
        category: 'communication',
      },
      {
        id: 'camera',
        name: 'Camera',
        aliases: ['camera', 'cam', 'photo taker'],
        packageName: 'com.android.camera',
        androidIntentUri: 'intent:#Intent;action=android.media.action.IMAGE_CAPTURE;end',
        customScheme: undefined,
        webFallback: '',
        category: 'media',
      },
      {
        id: 'gallery',
        name: 'Gallery',
        aliases: ['gallery', 'photos', 'google photos', 'images', 'pictures'],
        packageName: 'com.google.android.apps.photos',
        androidIntentUri: 'intent:#Intent;action=android.intent.action.VIEW;type=image/*;end',
        customScheme: undefined,
        webFallback: 'https://photos.google.com',
        category: 'media',
      },
      {
        id: 'settings',
        name: 'Settings',
        aliases: ['settings', 'system settings', 'preferences'],
        packageName: 'com.android.settings',
        androidIntentUri: 'intent:#Intent;action=android.settings.SETTINGS;end',
        customScheme: undefined,
        webFallback: '',
        category: 'system',
      },
      {
        id: 'maps',
        name: 'Google Maps',
        aliases: ['maps', 'google maps', 'navigation', 'gps', 'directions'],
        packageName: 'com.google.android.apps.maps',
        androidIntentUri: 'intent:#Intent;package=com.google.android.apps.maps;scheme=geo;end',
        customScheme: 'geo:0,0',
        webFallback: 'https://www.google.com/maps',
        category: 'navigation',
      },
      {
        id: 'spotify',
        name: 'Spotify',
        aliases: ['spotify', 'music app'],
        packageName: 'com.spotify.music',
        androidIntentUri: 'intent:#Intent;package=com.spotify.music;scheme=spotify;end',
        customScheme: 'spotify:',
        webFallback: 'https://open.spotify.com',
        category: 'media',
      },
      {
        id: 'chrome',
        name: 'Google Chrome',
        aliases: ['chrome', 'browser', 'google chrome', 'web browser', 'internet'],
        packageName: 'com.android.chrome',
        androidIntentUri: 'intent:#Intent;package=com.android.chrome;end',
        customScheme: undefined,
        webFallback: 'https://www.google.com',
        category: 'productivity',
      },
      {
        id: 'gmail',
        name: 'Gmail',
        aliases: ['gmail', 'email', 'mail', 'inbox'],
        packageName: 'com.google.android.gm',
        androidIntentUri: 'intent:#Intent;package=com.google.android.gm;end',
        customScheme: 'mailto:',
        webFallback: 'https://mail.google.com',
        category: 'communication',
      },
      {
        id: 'telegram',
        name: 'Telegram',
        aliases: ['telegram', 'tg'],
        packageName: 'org.telegram.messenger',
        androidIntentUri: 'intent:#Intent;package=org.telegram.messenger;scheme=tg;end',
        customScheme: 'tg://',
        webFallback: 'https://web.telegram.org',
        category: 'communication',
      },
      {
        id: 'clock',
        name: 'Clock',
        aliases: ['clock', 'alarms', 'alarm', 'timer', 'stopwatch'],
        packageName: 'com.google.android.deskclock',
        androidIntentUri: 'intent:#Intent;action=android.intent.action.SHOW_ALARMS;end',
        customScheme: undefined,
        webFallback: '',
        category: 'system',
      },
      {
        id: 'calculator',
        name: 'Calculator',
        aliases: ['calculator', 'calc'],
        packageName: 'com.google.android.calculator',
        androidIntentUri: 'intent:#Intent;package=com.google.android.calculator;end',
        customScheme: undefined,
        webFallback: '',
        category: 'productivity',
      },
      {
        id: 'calendar',
        name: 'Calendar',
        aliases: ['calendar', 'google calendar', 'events'],
        packageName: 'com.google.android.calendar',
        androidIntentUri: 'intent:#Intent;package=com.google.android.calendar;end',
        customScheme: undefined,
        webFallback: 'https://calendar.google.com',
        category: 'productivity',
      },
      {
        id: 'notes',
        name: 'Google Keep',
        aliases: ['notes', 'keep', 'google keep', 'notepad', 'memo'],
        packageName: 'com.google.android.keep',
        androidIntentUri: 'intent:#Intent;package=com.google.android.keep;end',
        customScheme: undefined,
        webFallback: 'https://keep.google.com',
        category: 'productivity',
      },
    ];

    for (const app of apps) {
      this.appRegistry.set(app.id, app);
    }
  }

  /**
   * Finds an app in the registry by name, alias, or ID.
   */
  public findApp(query: string): AppDefinition | undefined {
    const cleanQuery = query.toLowerCase().trim().replace(/^(open|launch|start|show)\s+/, '');
    
    // Direct ID match
    if (this.appRegistry.has(cleanQuery)) {
      return this.appRegistry.get(cleanQuery);
    }

    // Search through names and aliases
    for (const app of this.appRegistry.values()) {
      if (app.name.toLowerCase() === cleanQuery) {
        return app;
      }
      if (app.aliases.some((alias) => cleanQuery.includes(alias) || alias === cleanQuery)) {
        return app;
      }
    }

    return undefined;
  }

  /**
   * Launches an application using Android intent or verified web fallback.
   */
  public async launchApp(
    appNameOrQuery: string,
    options?: { query?: string; subAction?: string }
  ): Promise<DeviceActionResult> {
    const app = this.findApp(appNameOrQuery);

    if (!app) {
      // If not in standard registry, check if it's a generic web address or unknown app
      if (appNameOrQuery.includes('.') || appNameOrQuery.startsWith('http')) {
        const url = appNameOrQuery.startsWith('http') ? appNameOrQuery : `https://${appNameOrQuery}`;
        try {
          const opened = window.open(url, '_blank');
          return ActionVerifier.getInstance().verifyWindowLaunch(opened, appNameOrQuery, url);
        } catch (err: any) {
          return {
            success: false,
            action: 'open_app',
            target: appNameOrQuery,
            message: `I couldn't open ${appNameOrQuery}: ${err.message}`,
            timestamp: Date.now(),
          };
        }
      }

      return {
        success: false,
        action: 'open_app',
        target: appNameOrQuery,
        message: `I couldn't find "${appNameOrQuery}". It may not be installed on this device.`,
        timestamp: Date.now(),
      };
    }

    // Determine target URL/Intent
    let targetUri = app.androidIntentUri;
    let fallbackUri = app.webFallback;

    // Handle contextual sub-actions (e.g. YouTube search)
    if (app.id === 'youtube' && options?.query) {
      const q = encodeURIComponent(options.query);
      targetUri = `intent:#Intent;action=android.intent.action.SEARCH;query=${q};package=com.google.android.youtube;end`;
      fallbackUri = `https://www.youtube.com/results?search_query=${q}`;
    } else if (app.id === 'maps' && options?.query) {
      const q = encodeURIComponent(options.query);
      targetUri = `intent:#Intent;action=android.intent.action.VIEW;data=geo:0,0?q=${q};package=com.google.android.apps.maps;end`;
      fallbackUri = `https://www.google.com/maps/search/?api=1&query=${q}`;
    }

    // Detect Android User Agent
    const isAndroid = typeof navigator !== 'undefined' && /Android/i.test(navigator.userAgent);

    try {
      if (isAndroid) {
        // Attempt intent launch on Android
        const intentTarget = targetUri || app.customScheme || fallbackUri;
        const win = window.open(intentTarget, '_blank');
        return ActionVerifier.getInstance().verifyWindowLaunch(win, app.name, fallbackUri);
      } else {
        // On desktop/browser, launch web fallback or custom scheme
        const launchTarget = fallbackUri || app.customScheme;
        if (launchTarget) {
          const win = window.open(launchTarget, '_blank');
          return ActionVerifier.getInstance().verifyWindowLaunch(win, app.name, launchTarget);
        } else {
          return {
            success: false,
            action: 'open_app',
            target: app.name,
            message: `${app.name} is an Android-native system application and cannot be opened in this desktop preview.`,
            timestamp: Date.now(),
          };
        }
      }
    } catch (err: any) {
      return {
        success: false,
        action: 'open_app',
        target: app.name,
        message: `I couldn't open ${app.name}: ${err.message}`,
        timestamp: Date.now(),
      };
    }
  }

  /**
   * Lists all recognized applications.
   */
  public getSupportedApps(): AppDefinition[] {
    return Array.from(this.appRegistry.values());
  }
}
