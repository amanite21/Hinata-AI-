/**
 * PermissionManager - Safe Android & Browser Permission Supervisor for Hinata AI.
 *
 * Checks, requests, and tracks device permissions without simulating or pretending.
 * Provides transparent status reporting and guides users through Android permission steps.
 */

import { PermissionType, PermissionStatus } from './types';
import { MicrophoneManager } from '../audio/MicrophoneManager';

export class PermissionManager {
  private static instance: PermissionManager | null = null;
  private statusCache: Map<PermissionType, PermissionStatus> = new Map();

  private constructor() {}

  public static getInstance(): PermissionManager {
    if (!PermissionManager.instance) {
      PermissionManager.instance = new PermissionManager();
    }
    return PermissionManager.instance;
  }

  /**
   * Queries the current status of a specific device permission.
   */
  public async checkPermission(permission: PermissionType): Promise<PermissionStatus> {
    if (typeof window === 'undefined') return 'unsupported';

    try {
      switch (permission) {
        case 'microphone': {
          const micStatus = await MicrophoneManager.getInstance().checkPermission();
          const mapped: PermissionStatus =
            micStatus === 'granted' ? 'granted' : micStatus === 'denied' || micStatus === 'permanently_denied' ? 'denied' : 'prompt';
          this.statusCache.set('microphone', mapped);
          return mapped;
        }

        case 'camera': {
          if (navigator.permissions && navigator.permissions.query) {
            const res = await navigator.permissions.query({ name: 'camera' as any });
            this.statusCache.set('camera', res.state as PermissionStatus);
            return res.state as PermissionStatus;
          }
          return 'prompt';
        }

        case 'geolocation': {
          if (navigator.permissions && navigator.permissions.query) {
            const res = await navigator.permissions.query({ name: 'geolocation' as any });
            this.statusCache.set('geolocation', res.state as PermissionStatus);
            return res.state as PermissionStatus;
          }
          return 'geolocation' in navigator ? 'prompt' : 'unsupported';
        }

        case 'notifications': {
          if ('Notification' in window) {
            const perm = Notification.permission;
            const status: PermissionStatus =
              perm === 'granted' ? 'granted' : perm === 'denied' ? 'denied' : 'prompt';
            this.statusCache.set('notifications', status);
            return status;
          }
          return 'unsupported';
        }

        case 'contacts': {
          if ('contacts' in navigator && 'ContactsManager' in window) {
            return 'prompt';
          }
          return 'unsupported';
        }

        case 'storage': {
          return 'granted'; // Browser storage/IndexedDB is accessible
        }

        case 'accessibility': {
          // In web environment or standard sandbox, OS-level Accessibility Service
          // requires native Android companion / settings configuration.
          return 'prompt';
        }

        default:
          return 'unsupported';
      }
    } catch {
      return 'prompt';
    }
  }

  /**
   * Prompts the user to grant a permission where supported by the browser or Android.
   */
  public async requestPermission(permission: PermissionType): Promise<{
    granted: boolean;
    status: PermissionStatus;
    message: string;
  }> {
    if (typeof window === 'undefined') {
      return { granted: false, status: 'unsupported', message: 'Window is not available.' };
    }

    switch (permission) {
      case 'microphone': {
        const res = await MicrophoneManager.getInstance().requestPermission();
        const mapped: PermissionStatus = res.granted ? 'granted' : 'denied';
        this.statusCache.set('microphone', mapped);
        return {
          granted: res.granted,
          status: mapped,
          message: res.message,
        };
      }

      case 'camera': {
        try {
          const stream = await navigator.mediaDevices.getUserMedia({ video: true });
          stream.getTracks().forEach((t) => t.stop());
          this.statusCache.set('camera', 'granted');
          return { granted: true, status: 'granted', message: 'Camera permission granted.' };
        } catch (err: any) {
          this.statusCache.set('camera', 'denied');
          return {
            granted: false,
            status: 'denied',
            message: 'Camera permission was denied by user or device.',
          };
        }
      }

      case 'geolocation': {
        return new Promise((resolve) => {
          if (!('geolocation' in navigator)) {
            resolve({
              granted: false,
              status: 'unsupported',
              message: 'Geolocation is not supported on this device.',
            });
            return;
          }

          navigator.geolocation.getCurrentPosition(
            () => {
              this.statusCache.set('geolocation', 'granted');
              resolve({
                granted: true,
                status: 'granted',
                message: 'Location access granted.',
              });
            },
            (err) => {
              this.statusCache.set('geolocation', 'denied');
              resolve({
                granted: false,
                status: 'denied',
                message: `Location access denied: ${err.message}`,
              });
            },
            { timeout: 10000 }
          );
        });
      }

      case 'notifications': {
        if (!('Notification' in window)) {
          return {
            granted: false,
            status: 'unsupported',
            message: 'Notifications are not supported in this browser.',
          };
        }
        const result = await Notification.requestPermission();
        const granted = result === 'granted';
        const status: PermissionStatus = granted ? 'granted' : 'denied';
        this.statusCache.set('notifications', status);
        return {
          granted,
          status,
          message: granted ? 'Notifications enabled.' : 'Notifications blocked.',
        };
      }

      case 'accessibility': {
        // Transparent explanation of Android Accessibility Service boundary (Requirement 4)
        return {
          granted: false,
          status: 'prompt',
          message:
            'Cross-app deep automation on Android requires enabling Accessibility Service in Android Settings -> Accessibility. Hinata never silently monitors other apps.',
        };
      }

      default:
        return {
          granted: false,
          status: 'unsupported',
          message: `Permission "${permission}" is not directly requestable via Web API.`,
        };
    }
  }

  /**
   * Returns current cached or estimated status of a permission.
   */
  public getPermissionStatus(permission: PermissionType): PermissionStatus {
    return this.statusCache.get(permission) || 'prompt';
  }

  /**
   * Returns a clean explanation of an Android permission requirement.
   */
  public getPermissionExplanation(permission: PermissionType): string {
    switch (permission) {
      case 'accessibility':
        return 'Android Accessibility Service allows automated interactions inside other apps. It must be explicitly enabled by you in Settings, and Hinata will never secretly inspect or log other apps.';
      case 'geolocation':
        return 'Location access is required to find nearby places or provide accurate turn-by-turn navigation in Maps.';
      case 'microphone':
        return 'Microphone access is required for real-time Gemini Live voice conversations with Hinata.';
      case 'camera':
        return 'Camera access is required for live visual design inspection or taking reference photos.';
      case 'contacts':
        return 'Contact access allows calling or messaging friends by name with your confirmation.';
      default:
        return `Permission for ${permission} is required to execute this device action safely.`;
    }
  }
}
