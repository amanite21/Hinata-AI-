/**
 * CommunicationActions - Phone, SMS, WhatsApp & Email Manager for Hinata AI.
 *
 * Enforces mandatory confirmation for sensitive actions (calling, sending messages).
 * Integrates Android telephony and messaging intents safely.
 */

import { DeviceActionResult, SensitiveAction } from './types';

export class CommunicationActions {
  private static instance: CommunicationActions | null = null;
  private pendingActions: Map<string, SensitiveAction> = new Map();

  private constructor() {}

  public static getInstance(): CommunicationActions {
    if (!CommunicationActions.instance) {
      CommunicationActions.instance = new CommunicationActions();
    }
    return CommunicationActions.instance;
  }

  /**
   * Initiates a phone call with mandatory user confirmation.
   * e.g., "Should I call Mom?"
   */
  public preparePhoneCall(
    contactOrNumber: string,
    requireConfirmation: boolean = true
  ): DeviceActionResult {
    const cleanTarget = contactOrNumber.trim();
    if (!cleanTarget) {
      return {
        success: false,
        action: 'phone_call',
        message: 'Who would you like me to call?',
        timestamp: Date.now(),
      };
    }

    const actionId = `call_${Date.now()}`;
    const question = `Should I call ${cleanTarget}?`;

    if (requireConfirmation) {
      const pending: SensitiveAction = {
        id: actionId,
        type: 'phone_call',
        description: `Phone call to ${cleanTarget}`,
        target: cleanTarget,
        params: { contactOrNumber: cleanTarget },
        confirmationQuestion: question,
        createdAt: Date.now(),
        expiresAt: Date.now() + 60000, // 1 min expiry
      };

      this.pendingActions.set(actionId, pending);

      return {
        success: true,
        action: 'phone_call',
        target: cleanTarget,
        message: question,
        requiresConfirmation: true,
        confirmationPrompt: question,
        pendingActionId: actionId,
        timestamp: Date.now(),
      };
    }

    // Direct confirmed execution
    return this.executePhoneCall(cleanTarget);
  }

  /**
   * Directly executes a confirmed phone call via Android tel: URI.
   */
  public executePhoneCall(target: string): DeviceActionResult {
    try {
      const telUri = `tel:${encodeURIComponent(target)}`;
      window.location.href = telUri;
      return {
        success: true,
        action: 'phone_call',
        target,
        message: `Calling ${target}.`,
        timestamp: Date.now(),
      };
    } catch (err: any) {
      return {
        success: false,
        action: 'phone_call',
        target,
        message: `I couldn't initiate the call to ${target}: ${err.message}`,
        timestamp: Date.now(),
      };
    }
  }

  /**
   * Prepares an SMS message with mandatory user confirmation.
   * e.g., "Do you want me to send it?"
   */
  public prepareMessage(
    recipient: string,
    messageText: string,
    requireConfirmation: boolean = true
  ): DeviceActionResult {
    const cleanRecipient = recipient.trim();
    const cleanText = messageText.trim();

    if (!cleanRecipient) {
      return {
        success: false,
        action: 'send_message',
        message: 'Who should I send the message to?',
        timestamp: Date.now(),
      };
    }

    const actionId = `msg_${Date.now()}`;
    const question = `Do you want me to send "${cleanText}" to ${cleanRecipient}?`;

    if (requireConfirmation) {
      const pending: SensitiveAction = {
        id: actionId,
        type: 'send_message',
        description: `Send SMS to ${cleanRecipient}: "${cleanText}"`,
        target: cleanRecipient,
        params: { recipient: cleanRecipient, messageText: cleanText },
        confirmationQuestion: question,
        createdAt: Date.now(),
        expiresAt: Date.now() + 60000,
      };

      this.pendingActions.set(actionId, pending);

      return {
        success: true,
        action: 'send_message',
        target: cleanRecipient,
        message: question,
        requiresConfirmation: true,
        confirmationPrompt: question,
        pendingActionId: actionId,
        timestamp: Date.now(),
      };
    }

    return this.executeMessage(cleanRecipient, cleanText);
  }

  /**
   * Executes SMS message intent.
   */
  public executeMessage(recipient: string, messageText: string): DeviceActionResult {
    try {
      const smsUri = `sms:${encodeURIComponent(recipient)}?body=${encodeURIComponent(messageText)}`;
      window.open(smsUri, '_blank');
      return {
        success: true,
        action: 'send_message',
        target: recipient,
        message: `Message drafted to ${recipient}.`,
        timestamp: Date.now(),
      };
    } catch (err: any) {
      return {
        success: false,
        action: 'send_message',
        target: recipient,
        message: `Could not prepare message: ${err.message}`,
        timestamp: Date.now(),
      };
    }
  }

  /**
   * Confirms and executes a pending sensitive action.
   */
  public confirmPendingAction(actionId: string): DeviceActionResult {
    const action = this.pendingActions.get(actionId);
    if (!action) {
      return {
        success: false,
        action: 'in_app_action',
        message: 'That action confirmation has expired or was not found.',
        timestamp: Date.now(),
      };
    }

    this.pendingActions.delete(actionId);

    if (action.type === 'phone_call') {
      return this.executePhoneCall(action.target);
    } else if (action.type === 'send_message') {
      return this.executeMessage(action.params.recipient, action.params.messageText);
    }

    return {
      success: true,
      action: action.type,
      message: 'Action confirmed and executed.',
      timestamp: Date.now(),
    };
  }

  /**
   * Cancels a pending sensitive action.
   */
  public cancelPendingAction(actionId: string): DeviceActionResult {
    const action = this.pendingActions.get(actionId);
    this.pendingActions.delete(actionId);
    return {
      success: true,
      action: action?.type || 'in_app_action',
      message: 'Action cancelled.',
      timestamp: Date.now(),
    };
  }

  public getPendingAction(actionId: string): SensitiveAction | undefined {
    return this.pendingActions.get(actionId);
  }

  public getAllPendingActions(): SensitiveAction[] {
    const now = Date.now();
    return Array.from(this.pendingActions.values()).filter((a) => a.expiresAt > now);
  }
}
