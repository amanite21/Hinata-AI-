/**
 * DeviceActionManager - Central Android & Web Action Supervisor for Hinata AI.
 *
 * Modular Architecture:
 * DeviceActionManager
 * ├── AppLauncher
 * ├── SystemActions
 * ├── CommunicationActions
 * ├── MediaActions
 * ├── NavigationActions
 * ├── AutomationActions
 * └── PermissionManager
 *
 * Enforces:
 * - Real execution (never hallucinating success)
 * - Confirmation before sensitive actions (calling, messaging, deleting)
 * - Android security boundaries & transparency
 */

import {
  DeviceActionResult,
  DeviceActionType,
  SensitiveAction,
  PermissionType,
} from './types';
import { AppLauncher } from './AppLauncher';
import { SystemActions } from './SystemActions';
import { CommunicationActions } from './CommunicationActions';
import { MediaActions } from './MediaActions';
import { NavigationActions } from './NavigationActions';
import { AutomationActions } from './AutomationActions';
import { PermissionManager } from './PermissionManager';
import { ActionVerifier } from './ActionVerifier';

export class DeviceActionManager {
  private static instance: DeviceActionManager | null = null;

  public readonly appLauncher = AppLauncher.getInstance();
  public readonly systemActions = SystemActions.getInstance();
  public readonly communication = CommunicationActions.getInstance();
  public readonly media = MediaActions.getInstance();
  public readonly navigation = NavigationActions.getInstance();
  public readonly automation = AutomationActions.getInstance();
  public readonly permissions = PermissionManager.getInstance();
  public readonly verifier = ActionVerifier.getInstance();

  private actionListeners: Array<(result: DeviceActionResult) => void> = [];

  private constructor() {}

  public static getInstance(): DeviceActionManager {
    if (!DeviceActionManager.instance) {
      DeviceActionManager.instance = new DeviceActionManager();
    }
    return DeviceActionManager.instance;
  }

  public addActionListener(listener: (result: DeviceActionResult) => void): () => void {
    this.actionListeners.push(listener);
    return () => {
      this.actionListeners = this.actionListeners.filter((l) => l !== listener);
    };
  }

  private notifyListeners(result: DeviceActionResult): void {
    for (const listener of this.actionListeners) {
      try {
        listener(result);
      } catch (err) {
        console.error('[DeviceActionManager] Listener error:', err);
      }
    }
  }

  /**
   * Unified dispatcher for all device actions.
   */
  public async executeAction(
    actionType: DeviceActionType,
    params: Record<string, any> = {}
  ): Promise<DeviceActionResult> {
    let result: DeviceActionResult;

    switch (actionType) {
      case 'open_app': {
        const appName = params.appName || params.target || params.query || 'YouTube';
        result = await this.appLauncher.launchApp(appName, { query: params.searchQuery });
        if (result.success) {
          this.automation.setLastActiveApp(appName);
        }
        break;
      }

      case 'system_setting': {
        const settingName = params.setting || params.target || 'settings';
        result = await this.systemActions.openSetting(settingName);
        break;
      }

      case 'phone_call': {
        const contact = params.contact || params.target || params.number || '';
        result = this.communication.preparePhoneCall(contact, params.confirmed !== true);
        break;
      }

      case 'send_message': {
        const recipient = params.recipient || params.target || '';
        const message = params.message || params.text || '';
        result = this.communication.prepareMessage(recipient, message, params.confirmed !== true);
        break;
      }

      case 'set_alarm': {
        const hours = Number(params.hours ?? 7);
        const minutes = Number(params.minutes ?? 0);
        const label = params.label || 'Hinata Alarm';
        result = await this.systemActions.setAlarm(hours, minutes, label);
        break;
      }

      case 'set_timer': {
        const seconds = Number(params.seconds ?? 300);
        const label = params.label || 'Hinata Timer';
        result = await this.systemActions.setTimer(seconds, label);
        break;
      }

      case 'open_camera': {
        result = await this.media.openCamera();
        break;
      }

      case 'open_gallery': {
        result = await this.media.openGallery();
        break;
      }

      case 'open_maps': {
        const destination = params.destination || params.target || params.query || '';
        if (params.nearby) {
          result = await this.navigation.searchNearby(params.category || destination);
        } else {
          result = await this.navigation.navigateTo(destination);
        }
        break;
      }

      case 'control_media': {
        const command = params.command || 'play';
        result = this.media.controlMedia(command);
        break;
      }

      case 'share_content': {
        const title = params.title || 'Shared from Hinata AI';
        const text = params.text || '';
        const url = params.url;
        result = await this.media.shareContent(title, text, url);
        break;
      }

      case 'torch': {
        result = await this.systemActions.toggleTorch(params.enable);
        break;
      }

      case 'device_info': {
        result = await this.systemActions.getBatteryInfo();
        break;
      }

      case 'in_app_action': {
        result = await this.automation.performInAppAction(
          params.appName || null,
          params.action || 'perform',
          params.query
        );
        break;
      }

      default:
        result = {
          success: false,
          action: actionType,
          message: `Device action "${actionType}" is not supported.`,
          timestamp: Date.now(),
        };
    }

    this.notifyListeners(result);
    return result;
  }

  /**
   * Confirms a sensitive pending action (calling, messaging, deleting).
   */
  public confirmPendingAction(actionId: string): DeviceActionResult {
    const result = this.communication.confirmPendingAction(actionId);
    this.notifyListeners(result);
    return result;
  }

  /**
   * Cancels a sensitive pending action.
   */
  public cancelPendingAction(actionId: string): DeviceActionResult {
    const result = this.communication.cancelPendingAction(actionId);
    this.notifyListeners(result);
    return result;
  }

  /**
   * Confirms or rejects a sensitive pending action.
   */
  public confirmAction(confirmed: boolean, actionId?: string): DeviceActionResult {
    if (confirmed) {
      return this.confirmPendingAction(actionId || '');
    } else {
      return this.cancelPendingAction(actionId || '');
    }
  }

  /**
   * Subscribes to action execution events.
   */
  public onActionExecuted(listener: (result: DeviceActionResult) => void): () => void {
    return this.addActionListener(listener);
  }

  public getPendingSensitiveActions(): SensitiveAction[] {
    return this.communication.getAllPendingActions();
  }
}
