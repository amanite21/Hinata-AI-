/**
 * AutomationActions - Safe Modular Android In-App Automation for Hinata AI.
 *
 * Adheres strictly to Android security boundaries.
 * Explains Accessibility Service requirements without false claims or secret monitoring.
 * Dispatches deep intent-based in-app actions where supported.
 */

import { DeviceActionResult } from './types';
import { AppLauncher } from './AppLauncher';
import { PermissionManager } from './PermissionManager';

export class AutomationActions {
  private static instance: AutomationActions | null = null;
  private isAccessibilityEnabled: boolean = false;
  private lastActiveApp: string | null = null;

  private constructor() {}

  public static getInstance(): AutomationActions {
    if (!AutomationActions.instance) {
      AutomationActions.instance = new AutomationActions();
    }
    return AutomationActions.instance;
  }

  public setLastActiveApp(appName: string | null): void {
    this.lastActiveApp = appName;
  }

  public getLastActiveApp(): string | null {
    return this.lastActiveApp;
  }

  /**
   * Executes a contextual in-app action (e.g. "Search for Python tutorials in YouTube").
   */
  public async performInAppAction(
    appName: string | null,
    action: string,
    query?: string
  ): Promise<DeviceActionResult> {
    const targetApp = appName || this.lastActiveApp || 'YouTube';
    const cleanApp = targetApp.toLowerCase().trim();

    // 1. YouTube Deep In-App Action: Search query
    if (cleanApp.includes('youtube') || cleanApp.includes('yt')) {
      const searchQuery = query || action;
      return AppLauncher.getInstance().launchApp('youtube', { query: searchQuery });
    }

    // 2. Maps Deep In-App Action: Search or Directions
    if (cleanApp.includes('map') || cleanApp.includes('navigation')) {
      const searchQuery = query || action;
      return AppLauncher.getInstance().launchApp('maps', { query: searchQuery });
    }

    // 3. WhatsApp Deep In-App Action: Send text to contact
    if (cleanApp.includes('whatsapp') && query) {
      const waUrl = `https://api.whatsapp.com/send?text=${encodeURIComponent(query)}`;
      const win = window.open(waUrl, '_blank');
      return {
        success: Boolean(win),
        action: 'in_app_action',
        target: 'WhatsApp',
        message: `Opened WhatsApp with pre-filled message "${query}".`,
        timestamp: Date.now(),
      };
    }

    // 4. If deep cross-app interaction requires Android Accessibility Service:
    if (!this.isAccessibilityEnabled) {
      return {
        success: false,
        action: 'in_app_action',
        target: targetApp,
        message: `Performing "${action}" inside ${targetApp} requires Android Accessibility automation. Hinata respects Android security and does not secretly control apps without explicit system permission.`,
        data: {
          needsAccessibility: true,
          explanation: PermissionManager.getInstance().getPermissionExplanation('accessibility'),
        },
        timestamp: Date.now(),
      };
    }

    return {
      success: false,
      action: 'in_app_action',
      target: targetApp,
      message: `In-app action "${action}" in ${targetApp} is not permitted by Android's sandbox.`,
      timestamp: Date.now(),
    };
  }

  /**
   * Enables accessibility automation state if confirmed by user.
   */
  public setAccessibilityEnabled(enabled: boolean): void {
    this.isAccessibilityEnabled = enabled;
  }

  public getAccessibilityEnabled(): boolean {
    return this.isAccessibilityEnabled;
  }
}
