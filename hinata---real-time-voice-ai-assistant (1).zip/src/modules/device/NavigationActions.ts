/**
 * NavigationActions - Maps & Route Navigation Manager for Hinata AI.
 *
 * Dispatches real Android Google Maps navigation intents and geo-coordinates
 * with verified web navigation fallbacks.
 */

import { DeviceActionResult } from './types';
import { ActionVerifier } from './ActionVerifier';
import { PermissionManager } from './PermissionManager';

export class NavigationActions {
  private static instance: NavigationActions | null = null;

  private constructor() {}

  public static getInstance(): NavigationActions {
    if (!NavigationActions.instance) {
      NavigationActions.instance = new NavigationActions();
    }
    return NavigationActions.instance;
  }

  /**
   * Retrieves current GPS coordinates if permitted by user.
   */
  public async getCurrentCoordinates(): Promise<{ lat: number; lng: number } | null> {
    return new Promise((resolve) => {
      if (!('geolocation' in navigator)) {
        resolve(null);
        return;
      }

      navigator.geolocation.getCurrentPosition(
        (pos) => {
          resolve({
            lat: pos.coords.latitude,
            lng: pos.coords.longitude,
          });
        },
        () => resolve(null),
        { timeout: 8000 }
      );
    });
  }

  /**
   * Starts navigation to a specific destination or search query.
   * e.g., "navigate to the nearest hospital", "take me home", "open maps"
   */
  public async navigateTo(destination: string): Promise<DeviceActionResult> {
    const clean = destination.trim();
    const isAndroid = typeof navigator !== 'undefined' && /Android/i.test(navigator.userAgent);

    if (!clean) {
      // Just open Maps
      const win = window.open(
        isAndroid ? 'geo:0,0' : 'https://www.google.com/maps',
        '_blank'
      );
      return ActionVerifier.getInstance().verifyWindowLaunch(win, 'Google Maps');
    }

    const encodedDest = encodeURIComponent(clean);

    if (isAndroid) {
      try {
        // Direct Android navigation intent
        const navIntent = `google.navigation:q=${encodedDest}`;
        const win = window.open(navIntent, '_blank');
        return ActionVerifier.getInstance().verifyWindowLaunch(win, `Navigation to ${clean}`);
      } catch (err: any) {
        // Fall back to web
      }
    }

    // High quality Google Maps Turn-by-Turn Web Fallback
    const mapsWebUrl = `https://www.google.com/maps/dir/?api=1&destination=${encodedDest}`;
    try {
      const win = window.open(mapsWebUrl, '_blank');
      return ActionVerifier.getInstance().verifyWindowLaunch(
        win,
        `Navigation to ${clean}`,
        mapsWebUrl
      );
    } catch (err: any) {
      return {
        success: false,
        action: 'open_maps',
        target: clean,
        message: `Could not open Maps navigation: ${err.message}`,
        timestamp: Date.now(),
      };
    }
  }

  /**
   * Searches for nearby locations (e.g., "nearest coffee shop", "nearest hospital")
   */
  public async searchNearby(category: string): Promise<DeviceActionResult> {
    const coords = await this.getCurrentCoordinates();
    const cleanCat = category.trim();

    let searchUrl: string;
    if (coords) {
      searchUrl = `https://www.google.com/maps/search/${encodeURIComponent(cleanCat)}/@${coords.lat},${coords.lng},14z`;
    } else {
      searchUrl = `https://www.google.com/maps/search/${encodeURIComponent(cleanCat)}`;
    }

    try {
      const win = window.open(searchUrl, '_blank');
      return ActionVerifier.getInstance().verifyWindowLaunch(
        win,
        `Nearby ${cleanCat}`,
        searchUrl
      );
    } catch (err: any) {
      return {
        success: false,
        action: 'open_maps',
        target: cleanCat,
        message: `Failed to search nearby places: ${err.message}`,
        timestamp: Date.now(),
      };
    }
  }
}
