/**
 * ActionVerifier - Real Result Verification for Hinata Device Actions.
 *
 * Verifies whether device operations actually succeeded or failed on Android/Web.
 * Strictly prevents hallucinating successful execution.
 */

import { DeviceActionResult, DeviceActionType } from './types';

export class ActionVerifier {
  private static instance: ActionVerifier | null = null;

  private constructor() {}

  public static getInstance(): ActionVerifier {
    if (!ActionVerifier.instance) {
      ActionVerifier.instance = new ActionVerifier();
    }
    return ActionVerifier.instance;
  }

  /**
   * Verifies if a window or app intent opened successfully.
   */
  public verifyWindowLaunch(
    targetWindow: Window | null,
    targetName: string,
    fallbackUrl?: string
  ): DeviceActionResult {
    const timestamp = Date.now();

    // If window.open was blocked by popup blocker or returned null
    if (!targetWindow || targetWindow.closed) {
      return {
        success: false,
        action: 'open_app',
        target: targetName,
        message: `I couldn't open ${targetName}. The browser popup was blocked or the application is not installed.`,
        data: { targetName, fallbackUrl },
        timestamp,
      };
    }

    return {
      success: true,
      action: 'open_app',
      target: targetName,
      message: `${targetName} is open.`,
      data: { targetName, fallbackUrl },
      timestamp,
    };
  }

  /**
   * Formats a truthful voice response for a completed or failed action.
   */
  public formatVoiceResult(result: DeviceActionResult): string {
    if (result.requiresConfirmation) {
      return result.confirmationPrompt || 'Should I proceed with this action?';
    }

    if (result.success) {
      return result.message;
    }

    // Honest failure report without hallucinating
    return result.message || 'I could not complete that device action.';
  }
}
