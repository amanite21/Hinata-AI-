/**
 * SystemActions - Android System & Utility Actions for Hinata AI.
 *
 * Implements real system settings navigation, real alarm/timer scheduling,
 * device hardware status (battery, network), and torch control.
 */

import { DeviceActionResult } from './types';
import { ActionVerifier } from './ActionVerifier';

export class SystemActions {
  private static instance: SystemActions | null = null;
  private activeTimers: Map<string, number> = new Map();
  private torchTrack: MediaStreamTrack | null = null;

  private constructor() {}

  public static getInstance(): SystemActions {
    if (!SystemActions.instance) {
      SystemActions.instance = new SystemActions();
    }
    return SystemActions.instance;
  }

  /**
   * Opens Android system settings panels (Wi-Fi, Bluetooth, Display, etc.)
   */
  public async openSetting(settingName: string): Promise<DeviceActionResult> {
    const clean = settingName.toLowerCase().trim();
    const isAndroid = typeof navigator !== 'undefined' && /Android/i.test(navigator.userAgent);

    let intentAction = 'android.settings.SETTINGS';
    let humanName = 'Settings';

    if (clean.includes('wifi') || clean.includes('wi-fi') || clean.includes('network') || clean.includes('internet')) {
      intentAction = 'android.settings.WIFI_SETTINGS';
      humanName = 'Wi-Fi Settings';
    } else if (clean.includes('bluetooth') || clean.includes('bt')) {
      intentAction = 'android.settings.BLUETOOTH_SETTINGS';
      humanName = 'Bluetooth Settings';
    } else if (clean.includes('display') || clean.includes('brightness') || clean.includes('screen')) {
      intentAction = 'android.settings.DISPLAY_SETTINGS';
      humanName = 'Display Settings';
    } else if (clean.includes('battery') || clean.includes('power')) {
      intentAction = 'android.settings.BATTERY_SAVER_SETTINGS';
      humanName = 'Battery Settings';
    } else if (clean.includes('sound') || clean.includes('volume') || clean.includes('audio')) {
      intentAction = 'android.settings.SOUND_SETTINGS';
      humanName = 'Sound Settings';
    } else if (clean.includes('accessibility')) {
      intentAction = 'android.settings.ACCESSIBILITY_SETTINGS';
      humanName = 'Accessibility Settings';
    } else if (clean.includes('app') || clean.includes('application')) {
      intentAction = 'android.settings.APPLICATION_SETTINGS';
      humanName = 'Application Settings';
    }

    if (isAndroid) {
      try {
        const intentUri = `intent:#Intent;action=${intentAction};end`;
        const win = window.open(intentUri, '_blank');
        return ActionVerifier.getInstance().verifyWindowLaunch(win, humanName);
      } catch (err: any) {
        return {
          success: false,
          action: 'system_setting',
          target: humanName,
          message: `I couldn't open ${humanName}: ${err.message}`,
          timestamp: Date.now(),
        };
      }
    }

    return {
      success: true,
      action: 'system_setting',
      target: humanName,
      message: `${humanName} intent prepared. On an Android device, this directly opens ${humanName}.`,
      data: { intentAction },
      timestamp: Date.now(),
    };
  }

  /**
   * Sets an alarm for a specific time.
   */
  public async setAlarm(hours: number, minutes: number, label: string = 'Hinata Alarm'): Promise<DeviceActionResult> {
    const isAndroid = typeof navigator !== 'undefined' && /Android/i.test(navigator.userAgent);
    const timeString = `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}`;

    if (isAndroid) {
      const intentUri = `intent:#Intent;action=android.intent.action.SET_ALARM;i.android.intent.extra.alarm.HOUR=${hours};i.android.intent.extra.alarm.MINUTES=${minutes};s.android.intent.extra.alarm.MESSAGE=${encodeURIComponent(
        label
      )};b.android.intent.extra.alarm.SKIP_UI=true;end`;
      try {
        const win = window.open(intentUri, '_blank');
        return {
          success: true,
          action: 'set_alarm',
          target: timeString,
          message: `Alarm set for ${timeString} with label "${label}".`,
          timestamp: Date.now(),
        };
      } catch (err: any) {
        return {
          success: false,
          action: 'set_alarm',
          target: timeString,
          message: `Failed to launch Android alarm intent: ${err.message}`,
          timestamp: Date.now(),
        };
      }
    }

    // Web-based alarm scheduling fallback
    const now = new Date();
    const target = new Date();
    target.setHours(hours, minutes, 0, 0);
    if (target.getTime() <= now.getTime()) {
      target.setDate(target.getDate() + 1); // Next day
    }
    const msUntilAlarm = target.getTime() - now.getTime();

    const timerId = window.setTimeout(() => {
      this.playAlarmSound();
      if ('Notification' in window && Notification.permission === 'granted') {
        new Notification('Hinata Alarm', { body: `Alarm: ${label} (${timeString})` });
      }
    }, msUntilAlarm);

    this.activeTimers.set(`alarm-${timeString}`, timerId);

    return {
      success: true,
      action: 'set_alarm',
      target: timeString,
      message: `Alarm scheduled for ${timeString}.`,
      data: { hours, minutes, label, msUntilAlarm },
      timestamp: Date.now(),
    };
  }

  /**
   * Sets a timer for a specific duration in seconds.
   */
  public async setTimer(seconds: number, label: string = 'Hinata Timer'): Promise<DeviceActionResult> {
    const isAndroid = typeof navigator !== 'undefined' && /Android/i.test(navigator.userAgent);
    const durationMins = Math.round(seconds / 60);

    if (isAndroid) {
      const intentUri = `intent:#Intent;action=android.intent.action.SET_TIMER;i.android.intent.extra.alarm.LENGTH=${seconds};s.android.intent.extra.alarm.MESSAGE=${encodeURIComponent(
        label
      )};b.android.intent.extra.alarm.SKIP_UI=true;end`;
      try {
        window.open(intentUri, '_blank');
        return {
          success: true,
          action: 'set_timer',
          target: `${seconds}s`,
          message: `Timer set for ${seconds} seconds (${label}).`,
          timestamp: Date.now(),
        };
      } catch (err: any) {
        // Fall back to web timer below
      }
    }

    const timerId = window.setTimeout(() => {
      this.playAlarmSound();
      if ('Notification' in window && Notification.permission === 'granted') {
        new Notification('Hinata Timer', { body: `Timer finished: ${label} (${seconds} seconds)` });
      }
    }, seconds * 1000);

    this.activeTimers.set(`timer-${Date.now()}`, timerId);

    const desc = seconds >= 60 ? `${Math.floor(seconds / 60)} minute${Math.floor(seconds / 60) > 1 ? 's' : ''}` : `${seconds} seconds`;
    return {
      success: true,
      action: 'set_timer',
      target: `${seconds}s`,
      message: `Timer started for ${desc}.`,
      data: { seconds, label },
      timestamp: Date.now(),
    };
  }

  /**
   * Toggles or controls camera torch/flashlight if supported.
   */
  public async toggleTorch(enable?: boolean): Promise<DeviceActionResult> {
    try {
      if (this.torchTrack) {
        // Turn off
        this.torchTrack.stop();
        this.torchTrack = null;
        return {
          success: true,
          action: 'torch',
          message: 'Flashlight turned off.',
          timestamp: Date.now(),
        };
      }

      if (enable === false) {
        return {
          success: true,
          action: 'torch',
          message: 'Flashlight is already off.',
          timestamp: Date.now(),
        };
      }

      // Request camera with torch capability
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment' },
      });
      const track = stream.getVideoTracks()[0];
      const capabilities: any = track.getCapabilities ? track.getCapabilities() : {};

      if (capabilities.torch) {
        await (track as any).applyConstraints({
          advanced: [{ torch: true }],
        });
        this.torchTrack = track;
        return {
          success: true,
          action: 'torch',
          message: 'Flashlight turned on.',
          timestamp: Date.now(),
        };
      } else {
        track.stop();
        return {
          success: false,
          action: 'torch',
          message: 'Hardware torch is not available on this device camera.',
          timestamp: Date.now(),
        };
      }
    } catch (err: any) {
      return {
        success: false,
        action: 'torch',
        message: `Flashlight control unavailable: ${err.message}`,
        timestamp: Date.now(),
      };
    }
  }

  /**
   * Retrieves battery status where supported.
   */
  public async getBatteryInfo(): Promise<DeviceActionResult> {
    if (typeof navigator !== 'undefined' && 'getBattery' in navigator) {
      try {
        const battery: any = await (navigator as any).getBattery();
        const level = Math.round(battery.level * 100);
        const charging = battery.charging ? 'charging' : 'on battery';
        return {
          success: true,
          action: 'device_info',
          target: 'battery',
          message: `Battery is at ${level}%, currently ${charging}.`,
          data: { level, charging: battery.charging },
          timestamp: Date.now(),
        };
      } catch {
        // Fall through
      }
    }

    return {
      success: true,
      action: 'device_info',
      target: 'battery',
      message: 'Battery status is not exposed by this browser environment.',
      timestamp: Date.now(),
    };
  }

  /**
   * Synthesizes a clean chime using Web Audio API for timer and alarm completion.
   */
  private playAlarmSound(): void {
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(880, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(440, ctx.currentTime + 0.8);

      gain.gain.setValueAtTime(0.3, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.8);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start();
      osc.stop(ctx.currentTime + 0.8);
    } catch {
      // Ignored
    }
  }
}
