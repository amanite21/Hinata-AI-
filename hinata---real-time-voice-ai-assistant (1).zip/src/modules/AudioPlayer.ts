/**
 * AudioPlayer - Continuous, gapless 24kHz PCM audio player with timeline tracking,
 * response completion synchronization, and anti-pop interruption handling.
 */

export interface AudioPlayerOptions {
  onPlaybackStart?: () => void;
  onPlaybackEnd?: () => void;
  onVolumeChange?: (volume: number) => void;
}

export class AudioPlayer {
  private audioCtx: AudioContext | null = null;
  private gainNode: GainNode | null = null;
  private analyserNode: AnalyserNode | null = null;

  // Timeline & queue state
  private nextPlaybackTime: number = 0;
  private activeSources: Set<AudioBufferSourceNode> = new Set();
  private isPlaying: boolean = false;
  private isTurnComplete: boolean = false;
  private responseId: number = 0;
  private currentGain: number = 1.0;

  // Timers
  private checkInterval: any = null;
  private completionTimer: any = null;
  private idleGuardTimer: any = null;

  // Telemetry
  private freqData: Uint8Array = new Uint8Array(128);
  private timeData: Uint8Array = new Uint8Array(128);

  private options: AudioPlayerOptions;

  constructor(options: AudioPlayerOptions = {}) {
    this.options = options;
  }

  /**
   * Initializes the persistent AudioContext once.
   * If suspended, automatically resumes.
   */
  public async init(): Promise<void> {
    if (this.audioCtx && this.audioCtx.state !== 'closed') {
      if (this.audioCtx.state === 'suspended') {
        await this.audioCtx.resume();
      }
      return;
    }

    const AudioCtxClass =
      window.AudioContext ||
      (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;

    // Model output audio is 24,000Hz PCM
    try {
      this.audioCtx = new AudioCtxClass({ sampleRate: 24000 });
    } catch {
      this.audioCtx = new AudioCtxClass();
    }

    if (this.audioCtx.state === 'suspended') {
      await this.audioCtx.resume();
    }

    this.gainNode = this.audioCtx.createGain();
    this.gainNode.gain.setValueAtTime(this.currentGain, this.audioCtx.currentTime);

    this.analyserNode = this.audioCtx.createAnalyser();
    this.analyserNode.fftSize = 256;
    this.analyserNode.smoothingTimeConstant = 0.6;
    this.freqData = new Uint8Array(this.analyserNode.frequencyBinCount);
    this.timeData = new Uint8Array(this.analyserNode.fftSize);

    this.gainNode.connect(this.analyserNode);
    this.analyserNode.connect(this.audioCtx.destination);

    this.nextPlaybackTime = this.audioCtx.currentTime;

    // Start activity and telemetry monitor
    this.startActivityMonitor();
  }

  /**
   * Enqueues and sequentially schedules an incoming 24kHz PCM chunk.
   * Chunks are scheduled seamlessly without gaps or overlaps.
   */
  public playChunk(base64Pcm24: string): void {
    if (!this.audioCtx || this.audioCtx.state === 'closed') {
      return;
    }

    // Ensure audio context is running
    if (this.audioCtx.state === 'suspended') {
      this.audioCtx.resume().catch(() => {});
    }

    try {
      // Decode base64 to binary ArrayBuffer
      const binaryString = window.atob(base64Pcm24);
      const len = binaryString.length;
      const bytes = new Uint8Array(len);
      for (let i = 0; i < len; i++) {
        bytes[i] = binaryString.charCodeAt(i);
      }

      // Convert 16-bit PCM little-endian to Float32
      const dataView = new DataView(bytes.buffer);
      const sampleCount = Math.floor(len / 2);
      if (sampleCount === 0) return;

      const float32Array = new Float32Array(sampleCount);
      for (let i = 0; i < sampleCount; i++) {
        const int16 = dataView.getInt16(i * 2, true);
        float32Array[i] = int16 / 32768.0;
      }

      // Create AudioBuffer at 24kHz
      const audioBuffer = this.audioCtx.createBuffer(1, sampleCount, 24000);
      audioBuffer.getChannelData(0).set(float32Array);

      const source = this.audioCtx.createBufferSource();
      source.buffer = audioBuffer;
      source.connect(this.gainNode!);

      // If this is a new response turn or new audio after turn complete:
      if (this.isTurnComplete) {
        this.isTurnComplete = false;
        if (this.completionTimer) {
          clearTimeout(this.completionTimer);
          this.completionTimer = null;
        }
      }

      // Reset any pending idle guard timer whenever active chunks arrive
      if (this.idleGuardTimer) {
        clearTimeout(this.idleGuardTimer);
        this.idleGuardTimer = null;
      }

      // Sequential scheduling: start at max(currentTime, nextPlaybackTime)
      const currentTime = this.audioCtx.currentTime;
      const scheduledStartTime = Math.max(currentTime, this.nextPlaybackTime);

      source.start(scheduledStartTime);
      this.nextPlaybackTime = scheduledStartTime + audioBuffer.duration;

      this.activeSources.add(source);

      if (!this.isPlaying) {
        this.isPlaying = true;
        this.options.onPlaybackStart?.();
      }

      source.onended = () => {
        this.activeSources.delete(source);
        try {
          source.disconnect();
        } catch {
          // Already disconnected
        }
        this.checkTurnFinished();
      };
    } catch (err) {
      console.error('[AudioPlayer] Error scheduling audio chunk:', err);
    }
  }

  /**
   * Called when the live assistant signals that the model response generation
   * for the current turn has completed. Playback continues until all scheduled
   * audio has finished playing.
   */
  public markTurnComplete(): void {
    if (!this.isPlaying) {
      return;
    }

    this.isTurnComplete = true;

    if (this.idleGuardTimer) {
      clearTimeout(this.idleGuardTimer);
      this.idleGuardTimer = null;
    }

    if (!this.audioCtx) {
      this.finalizePlayback();
      return;
    }

    const currentTime = this.audioCtx.currentTime;
    const remainingSeconds = Math.max(0, this.nextPlaybackTime - currentTime);

    // If audio is already completely finished playing
    if (this.activeSources.size === 0 && remainingSeconds <= 0.05) {
      this.finalizePlayback();
      return;
    }

    // Set precise timer to verify turn completion after remaining audio finishes
    if (this.completionTimer) {
      clearTimeout(this.completionTimer);
    }

    this.completionTimer = setTimeout(() => {
      this.completionTimer = null;
      if (this.isTurnComplete && this.isPlaying) {
        this.checkTurnFinished();
      }
    }, Math.ceil(remainingSeconds * 1000) + 40);
  }

  /**
   * Checks whether the current response has genuinely completed.
   * CRITICAL: Hinata must NEVER transition to finished if isTurnComplete is false,
   * as subsequent chunks may still be streaming over the network.
   */
  private checkTurnFinished(): void {
    if (!this.isPlaying || !this.audioCtx) return;

    if (!this.isTurnComplete) {
      // Turn is still generating / streaming from Gemini.
      // Do NOT finish playback. Reset safety idle guard timer (3.5s silence).
      this.resetIdleGuard();
      return;
    }

    const currentTime = this.audioCtx.currentTime;
    // Turn is confirmed complete AND all scheduled audio has finished playing
    if (this.activeSources.size === 0 && currentTime >= this.nextPlaybackTime - 0.05) {
      this.finalizePlayback();
    }
  }

  /**
   * Safety guard for missing or dropped turnComplete messages from the server.
   * If no audio has been received and nothing is playing for 3.5 seconds, cleanly end turn.
   */
  private resetIdleGuard(): void {
    if (this.idleGuardTimer) {
      clearTimeout(this.idleGuardTimer);
    }
    this.idleGuardTimer = setTimeout(() => {
      this.idleGuardTimer = null;
      if (
        this.isPlaying &&
        this.activeSources.size === 0 &&
        (!this.audioCtx || this.audioCtx.currentTime >= this.nextPlaybackTime - 0.05)
      ) {
        console.warn('[AudioPlayer] Idle guard timeout (3.5s without chunks); finalizing playback');
        this.finalizePlayback();
      }
    }, 3500);
  }

  /**
   * Cleanly finalizes playback and notifies listeners that Hinata is done speaking.
   */
  private finalizePlayback(): void {
    if (this.completionTimer) {
      clearTimeout(this.completionTimer);
      this.completionTimer = null;
    }
    if (this.idleGuardTimer) {
      clearTimeout(this.idleGuardTimer);
      this.idleGuardTimer = null;
    }

    this.isTurnComplete = false;

    if (this.isPlaying) {
      this.isPlaying = false;
      this.options.onPlaybackEnd?.();
    }
  }

  /**
   * Immediately stops audio playback with a 15ms anti-pop ramp.
   * Called ONLY on genuine user interruption or explicit session stop.
   */
  public interrupt(): void {
    this.responseId++;

    if (this.completionTimer) {
      clearTimeout(this.completionTimer);
      this.completionTimer = null;
    }
    if (this.idleGuardTimer) {
      clearTimeout(this.idleGuardTimer);
      this.idleGuardTimer = null;
    }
    this.isTurnComplete = false;

    // Fast 15ms micro-ramp down to eliminate speaker popping
    if (this.gainNode && this.audioCtx && this.audioCtx.state === 'running') {
      try {
        const now = this.audioCtx.currentTime;
        this.gainNode.gain.cancelScheduledValues(now);
        this.gainNode.gain.setValueAtTime(this.gainNode.gain.value, now);
        this.gainNode.gain.linearRampToValueAtTime(0.0001, now + 0.015);
      } catch {
        // Fallback
      }
    }

    const stopTime = this.audioCtx ? this.audioCtx.currentTime + 0.015 : 0;
    for (const source of this.activeSources) {
      try {
        source.stop(stopTime);
        setTimeout(() => {
          try {
            source.disconnect();
          } catch {
            // Already disconnected
          }
        }, 25);
      } catch {
        // Source may have already ended
      }
    }
    this.activeSources.clear();

    if (this.audioCtx) {
      this.nextPlaybackTime = this.audioCtx.currentTime;
    }

    // Restore target gain after ramp
    setTimeout(() => {
      if (this.gainNode && this.audioCtx && this.audioCtx.state === 'running') {
        const resetTime = this.audioCtx.currentTime;
        this.gainNode.gain.cancelScheduledValues(resetTime);
        this.gainNode.gain.setValueAtTime(this.currentGain, resetTime);
      }
    }, 30);

    if (this.isPlaying) {
      this.isPlaying = false;
      this.options.onPlaybackEnd?.();
    }
  }

  public setVolume(vol: number): void {
    this.currentGain = Math.max(0, Math.min(1.5, vol));
    if (this.gainNode && this.audioCtx && this.audioCtx.state === 'running') {
      this.gainNode.gain.setValueAtTime(this.currentGain, this.audioCtx.currentTime);
    }
  }

  public getIsPlaying(): boolean {
    return this.isPlaying;
  }

  public hasActiveAudio(): boolean {
    return this.isPlaying || this.activeSources.size > 0;
  }

  public getAnalyserNode(): AnalyserNode | null {
    return this.analyserNode;
  }

  public getAudioAnalyser(): AnalyserNode | null {
    return this.analyserNode;
  }

  public getFrequencyData(): Uint8Array {
    if (this.analyserNode && this.isPlaying) {
      this.analyserNode.getByteFrequencyData(this.freqData);
      return this.freqData;
    }
    return new Uint8Array(128);
  }

  public getTimeDomainData(): Uint8Array {
    if (this.analyserNode && this.isPlaying) {
      this.analyserNode.getByteTimeDomainData(this.timeData);
      return this.timeData;
    }
    return new Uint8Array(128);
  }

  public close(): void {
    this.interrupt();
    if (this.checkInterval) {
      clearInterval(this.checkInterval);
      this.checkInterval = null;
    }
    if (this.audioCtx && this.audioCtx.state !== 'closed') {
      this.audioCtx.close().catch(() => {});
      this.audioCtx = null;
    }
  }

  private startActivityMonitor(): void {
    if (this.checkInterval) clearInterval(this.checkInterval);
    this.checkInterval = setInterval(() => {
      if (!this.analyserNode) return;

      if (this.isPlaying) {
        this.analyserNode.getByteFrequencyData(this.freqData);
        let sum = 0;
        for (let i = 0; i < this.freqData.length; i++) {
          sum += this.freqData[i];
        }
        const avg = sum / this.freqData.length / 255;
        this.options.onVolumeChange?.(avg);
      }

      // Check turn finish ONLY if isTurnComplete is confirmed
      if (this.isPlaying && this.isTurnComplete) {
        this.checkTurnFinished();
      }
    }, 40);
  }
}
