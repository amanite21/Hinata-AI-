/**
 * AudioStreamer - Captures microphone audio using centralized MicrophoneManager,
 * calculates real-time input levels, and streams base64 PCM16 chunks to Gemini Live.
 */

import { MicrophoneManager } from './audio/MicrophoneManager';

export interface AudioStreamerOptions {
  onAudioData: (base64Pcm16: string) => void;
  onError?: (error: Error) => void;
  onVolumeChange?: (volume: number) => void;
}

export class AudioStreamer {
  private micManager: MicrophoneManager;
  private isMuted: boolean = false;
  private isStreaming: boolean = false;
  private options: AudioStreamerOptions;
  private unsubs: Array<() => void> = [];

  constructor(options: AudioStreamerOptions) {
    this.options = options;
    this.micManager = MicrophoneManager.getInstance();
  }

  public async start(): Promise<void> {
    if (this.isStreaming) return;

    try {
      // 1. Subscribe to PCM chunks & volume from the centralized manager
      const unPcm = this.micManager.onPcmData((base64) => {
        if (this.isStreaming && !this.isMuted) {
          this.options.onAudioData(base64);
        }
      });
      this.unsubs.push(unPcm);

      const unVol = this.micManager.onVolume((vol) => {
        if (this.isStreaming && !this.isMuted && this.options.onVolumeChange) {
          this.options.onVolumeChange(vol);
        }
      });
      this.unsubs.push(unVol);

      const unState = this.micManager.onStateChange((st, _owner, err) => {
        if (st === 'ERROR' && err && this.options.onError) {
          this.options.onError(new Error(err));
        }
      });
      this.unsubs.push(unState);

      // 2. Request mic capture via centralized manager
      const ok = await this.micManager.startListening('live_session', {
        sampleRate: 16000,
        channelCount: 1,
        streamPcm16: true,
      });

      if (!ok) {
        throw new Error('Microphone capture could not be initiated.');
      }

      this.isStreaming = true;
    } catch (err: any) {
      this.stop();
      if (this.options.onError) {
        this.options.onError(err instanceof Error ? err : new Error(String(err)));
      }
      throw err;
    }
  }

  public setMute(muted: boolean): void {
    this.isMuted = muted;
  }

  public getMuted(): boolean {
    return this.isMuted;
  }

  public getIsStreaming(): boolean {
    return this.isStreaming;
  }

  public getFrequencyData(): Uint8Array {
    return new Uint8Array(128);
  }

  public getTimeDomainData(): Uint8Array {
    return new Uint8Array(128);
  }

  public stop(): void {
    if (!this.isStreaming) return;
    this.isStreaming = false;

    // Unsubscribe listeners
    this.unsubs.forEach((un) => un());
    this.unsubs = [];

    // Stop listening via centralized manager
    this.micManager.stopListening('live_session').catch(() => {});
  }
}
