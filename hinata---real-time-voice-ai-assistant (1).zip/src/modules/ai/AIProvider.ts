import { BackendConfig } from '../../config/backendConfig';

export type AIStatusState =
  | 'NOT_CONFIGURED'
  | 'TESTING'
  | 'CONNECTED'
  | 'INVALID_KEY'
  | 'EXPIRED_OR_REVOKED'
  | 'QUOTA_EXCEEDED'
  | 'RATE_LIMITED'
  | 'NETWORK_ERROR'
  | 'PROVIDER_ERROR';

export interface AIProviderStatus {
  provider: 'gemini';
  model: string;
  status: AIStatusState;
  statusMessage?: string;
  lastTestedAt: number | null;
  keyUpdatedAt: number | null;
  maskedKeySuffix: string;
  isConfigured: boolean;
  environmentSource: 'env' | 'runtime';
}

export interface AITestResult {
  ok: boolean;
  status: AIStatusState;
  message: string;
  latencyMs: number;
  maskedKeySuffix?: string;
}

export interface AIRotateResult {
  success: boolean;
  status: AIStatusState;
  message: string;
  maskedKeySuffix?: string;
}

type AIStatusListener = (status: AIProviderStatus) => void;
type AuthFailureListener = (reason: string) => void;

/**
 * Client-Side Centralized AI Provider.
 *
 * Coordinates:
 * - API status checking & polling
 * - Safe testing without exposing raw secrets
 * - Zero-APK-rebuild runtime key rotation
 * - Automatic authentication failure alerts with reactive UI toast
 */
export class ClientAIProvider {
  private static instance: ClientAIProvider | null = null;

  private currentStatus: AIProviderStatus = {
    provider: 'gemini',
    model: 'gemini-3.8-flash / gemini-3.1-flash-live-preview',
    status: 'NOT_CONFIGURED',
    statusMessage: 'Checking API status...',
    lastTestedAt: null,
    keyUpdatedAt: null,
    maskedKeySuffix: '',
    isConfigured: false,
    environmentSource: 'env',
  };

  private listeners: Set<AIStatusListener> = new Set();
  private authFailureListeners: Set<AuthFailureListener> = new Set();
  private isFetching = false;
  private hasReportedAuthFailure = false;

  private constructor() {
    // Initial fetch
    if (typeof window !== 'undefined') {
      this.fetchStatus().catch(() => {});
    }
  }

  public static getInstance(): ClientAIProvider {
    if (!ClientAIProvider.instance) {
      ClientAIProvider.instance = new ClientAIProvider();
    }
    return ClientAIProvider.instance;
  }

  private getBaseUrl(): string {
    const configured = BackendConfig.getBackendUrl();
    if (configured && configured.trim().length > 0) {
      return configured.replace(/\/+$/, '');
    }
    return '';
  }

  public getStatus(): AIProviderStatus {
    return { ...this.currentStatus };
  }

  public subscribe(listener: AIStatusListener): () => void {
    this.listeners.add(listener);
    listener(this.getStatus());
    return () => {
      this.listeners.delete(listener);
    };
  }

  public onAuthFailure(listener: AuthFailureListener): () => void {
    this.authFailureListeners.add(listener);
    return () => {
      this.authFailureListeners.delete(listener);
    };
  }

  /**
   * Triggers an authentication failure notification across Hinata.
   * Called when any AI request detects 401/403/invalid credential.
   */
  public reportAuthFailure(reason: string = 'AI service authentication failed. Please update the API key.'): void {
    this.currentStatus = {
      ...this.currentStatus,
      status: 'INVALID_KEY',
      statusMessage: reason,
    };
    this.notifyListeners();

    // Notify auth failure subscribers (e.g. Toast / Banner)
    for (const listener of this.authFailureListeners) {
      try {
        listener(reason);
      } catch (err) {
        console.warn('[AIProvider] Error notifying auth failure listener:', err);
      }
    }
  }

  public resetAuthFailureReport(): void {
    this.hasReportedAuthFailure = false;
  }

  private notifyListeners(): void {
    const snap = this.getStatus();
    for (const l of this.listeners) {
      try {
        l(snap);
      } catch (e) {
        console.warn('[AIProvider] Listener error:', e);
      }
    }
  }

  /**
   * Fetches the safe status from the backend.
   * Never receives the raw key.
   */
  public async fetchStatus(): Promise<AIProviderStatus> {
    if (this.isFetching) return this.getStatus();
    this.isFetching = true;

    try {
      const baseUrl = this.getBaseUrl();
      const res = await fetch(`${baseUrl}/api/ai/status`, {
        method: 'GET',
        headers: {
          'Accept': 'application/json',
        },
      });

      if (!res.ok) {
        throw new Error(`HTTP ${res.status}`);
      }

      const data = await res.json();
      this.currentStatus = {
        provider: data.provider || 'gemini',
        model: data.model || 'gemini-3.8-flash',
        status: data.status || (data.isConfigured ? 'CONNECTED' : 'NOT_CONFIGURED'),
        statusMessage: data.statusMessage || '',
        lastTestedAt: data.lastTestedAt || null,
        keyUpdatedAt: data.keyUpdatedAt || null,
        maskedKeySuffix: data.maskedKeySuffix || '',
        isConfigured: Boolean(data.isConfigured),
        environmentSource: data.environmentSource || 'env',
      };
      this.notifyListeners();
    } catch (err: any) {
      // If network unreachable, set appropriate state
      this.currentStatus = {
        ...this.currentStatus,
        status: 'NETWORK_ERROR',
        statusMessage: 'Could not connect to Hinata backend API service.',
      };
      this.notifyListeners();
    } finally {
      this.isFetching = false;
    }

    return this.getStatus();
  }

  /**
   * Tests an API key safely.
   * If candidateKey is omitted, tests the currently active key.
   */
  public async testConnection(candidateKey?: string): Promise<AITestResult> {
    try {
      const baseUrl = this.getBaseUrl();
      const bodyPayload = candidateKey ? { apiKey: candidateKey.trim() } : {};

      const res = await fetch(`${baseUrl}/api/ai/test`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
        },
        body: JSON.stringify(bodyPayload),
      });

      const data = await res.json();

      if (!candidateKey) {
        // Refresh local status if testing current key
        this.currentStatus = {
          ...this.currentStatus,
          status: data.status,
          statusMessage: data.message,
          lastTestedAt: Date.now(),
          maskedKeySuffix: data.maskedKeySuffix || this.currentStatus.maskedKeySuffix,
        };
        this.notifyListeners();
      }

      return {
        ok: Boolean(data.ok),
        status: data.status as AIStatusState,
        message: data.message || (data.ok ? 'Connection successful' : 'Connection failed'),
        latencyMs: data.latencyMs || 0,
        maskedKeySuffix: data.maskedKeySuffix,
      };
    } catch (err: any) {
      return {
        ok: false,
        status: 'NETWORK_ERROR',
        message: err?.message || 'Network error reaching backend test service',
        latencyMs: 0,
      };
    }
  }

  /**
   * Rotates to a new API key without rebuilding the client APK.
   * If the new key is invalid, the backend preserves the existing key!
   */
  public async rotateKey(newKey: string): Promise<AIRotateResult> {
    if (!newKey || newKey.trim().length === 0) {
      return {
        success: false,
        status: 'NOT_CONFIGURED',
        message: 'Please enter a valid API key.',
      };
    }

    try {
      const baseUrl = this.getBaseUrl();
      const res = await fetch(`${baseUrl}/api/ai/rotate`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
        },
        body: JSON.stringify({ newKey: newKey.trim() }),
      });

      const data = await res.json();

      if (data.success) {
        this.currentStatus = {
          ...this.currentStatus,
          status: 'CONNECTED',
          statusMessage: data.message || 'API key updated',
          keyUpdatedAt: Date.now(),
          lastTestedAt: Date.now(),
          maskedKeySuffix: data.maskedKeySuffix || '',
          isConfigured: true,
          environmentSource: 'runtime',
        };
        this.notifyListeners();
      } else {
        // Did not replace working configuration
        if (data.status) {
          // If the attempt failed, update UI with the candidate's test failure
          this.notifyListeners();
        }
      }

      return {
        success: Boolean(data.success),
        status: data.status as AIStatusState,
        message: data.message,
        maskedKeySuffix: data.maskedKeySuffix,
      };
    } catch (err: any) {
      return {
        success: false,
        status: 'NETWORK_ERROR',
        message: err?.message || 'Network error reaching key rotation service',
      };
    }
  }
}
