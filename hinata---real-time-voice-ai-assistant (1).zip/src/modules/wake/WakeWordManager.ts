/**
 * WakeWordManager - Master Hands-Free Voice Assistant Controller for Hinata AI.
 *
 * Coordinates the full voice lifecycle:
 * WAKE_IDLE -> WAKE_DETECTED -> LISTENING -> THINKING -> SPEAKING -> WAKE_IDLE.
 *
 * Integrates:
 * - WakeWordDetector (lightweight local detection)
 * - EmotionManager (facial expressions & emotional transitions)
 * - ConversationManager (shared context with Chat Mode, TTS playback, mouth visemes)
 * - MemoryManager (retrieval of personalized facts)
 * - DeviceActionManager & ActionVerifier (Android Intents, real verification)
 * - Interruption handling & false-activation protection
 */

import { WakeWordState, WakeSensitivity, WakeWordConfig, WakeDetectionEvent } from './types';
import { WakeWordDetector } from './WakeWordDetector';
import { EmotionManager } from '../EmotionManager';
import { ConversationManager } from '../conversation/ConversationManager';
import { MemoryManager } from '../memory/MemoryManager';
import { DeviceActionManager } from '../device/DeviceActionManager';
import { ActionVerifier } from '../device/ActionVerifier';
import { DeviceActionType } from '../device/types';
import { PermissionManager } from '../device/PermissionManager';
import { VoiceChatCoordinator } from '../voiceChat/VoiceChatCoordinator';

const STORAGE_CONFIG_KEY = 'hinata_wake_config_v2';

export type WakeStateListener = (state: WakeWordState, details?: string) => void;
export type WakeTranscriptListener = (text: string, isFinal: boolean) => void;

export class WakeWordManager {
  private static instance: WakeWordManager | null = null;

  private state: WakeWordState = 'WAKE_IDLE';
  private stateDetails: string = 'Standing by for "Hey Hinata"';
  private config: WakeWordConfig;
  private detector: WakeWordDetector;

  private stateListeners: WakeStateListener[] = [];
  private transcriptListeners: WakeTranscriptListener[] = [];

  private listenTimeoutTimer: any = null;
  private currentCapturedCommand: string = '';
  private isProcessingCommand: boolean = false;
  private lastActiveTranscript: string = '';

  private constructor() {
    this.config = this.loadConfig();
    this.detector = WakeWordDetector.getInstance();
    this.detector.setWakePhrase(this.config.phrase);
    this.detector.setSensitivity(this.config.sensitivity);

    this.bindDetectorEvents();
    this.bindConversationEvents();

    if (this.config.enabled) {
      this.startWakeWordMonitoring();
    } else {
      this.state = 'DISABLED';
      this.stateDetails = 'Hands-Free mode is currently disabled';
    }
  }

  public static getInstance(): WakeWordManager {
    if (!WakeWordManager.instance) {
      WakeWordManager.instance = new WakeWordManager();
    }
    return WakeWordManager.instance;
  }

  private loadConfig(): WakeWordConfig {
    const defaults: WakeWordConfig = {
      enabled: false,
      phrase: 'Hey Hinata',
      sensitivity: 'medium',
      autoListenTimeoutMs: 8000,
      voiceResponse: true,
      cooldownMs: 2500,
      echoProtection: true,
      systemAssistantEnabled: false,
      notificationEnabled: true,
    };

    if (typeof window === 'undefined') return defaults;

    try {
      const raw = localStorage.getItem(STORAGE_CONFIG_KEY);
      if (raw) {
        return { ...defaults, ...JSON.parse(raw) };
      }
    } catch (e) {
      console.warn('[WakeWordManager] Failed to load config:', e);
    }
    return defaults;
  }

  public saveConfig(newConfig: Partial<WakeWordConfig>): void {
    this.config = { ...this.config, ...newConfig };
    try {
      localStorage.setItem(STORAGE_CONFIG_KEY, JSON.stringify(this.config));
    } catch {}

    this.detector.setWakePhrase(this.config.phrase);
    this.detector.setSensitivity(this.config.sensitivity);

    if (this.config.enabled) {
      if (this.state === 'DISABLED') {
        this.startWakeWordMonitoring();
      }
    } else {
      this.disableHandsFree();
    }
    this.notifyState();
  }

  public getConfig(): WakeWordConfig {
    return { ...this.config };
  }

  public getState(): WakeWordState {
    return this.state;
  }

  public getStateDetails(): string {
    return this.stateDetails;
  }

  public onStateChange(listener: WakeStateListener): () => void {
    this.stateListeners.push(listener);
    listener(this.state, this.stateDetails);
    return () => {
      this.stateListeners = this.stateListeners.filter((l) => l !== listener);
    };
  }

  public onTranscript(listener: WakeTranscriptListener): () => void {
    this.transcriptListeners.push(listener);
    return () => {
      this.transcriptListeners = this.transcriptListeners.filter((l) => l !== listener);
    };
  }

  private setState(state: WakeWordState, details: string = ''): void {
    this.state = state;
    this.stateDetails = details;
    this.notifyState();
  }

  private notifyState(): void {
    for (const listener of this.stateListeners) {
      try {
        listener(this.state, this.stateDetails);
      } catch (e) {
        console.error('[WakeWordManager] State listener error:', e);
      }
    }
  }

  private notifyTranscript(text: string, isFinal: boolean): void {
    for (const listener of this.transcriptListeners) {
      try {
        listener(text, isFinal);
      } catch (e) {
        console.error('[WakeWordManager] Transcript listener error:', e);
      }
    }
  }

  // ----------------------------------------------------
  // Bindings & Event Handling
  // ----------------------------------------------------

  private bindDetectorEvents(): void {
    // 1. Wake phrase recognized
    this.detector.onWakeDetected((event: WakeDetectionEvent) => {
      this.handleWakeDetected(event);
    });

    // 2. Incoming spoken chunks
    this.detector.onTranscript((text: string, isFinal: boolean) => {
      this.handleSpeechChunk(text, isFinal);
    });

    // 3. Errors
    this.detector.onError((error: string) => {
      console.warn('[WakeWordManager] Detector error:', error);
      if (this.state !== 'DISABLED') {
        this.setState('ERROR', error);
      }
    });
  }

  private bindConversationEvents(): void {
    // Connect to speech output events to manage TTS echo suppression & face states
    const conv = ConversationManager.getInstance();
    conv.onChatStateChange((chatState, details) => {
      if (chatState === 'speaking') {
        this.detector.setTtsSpeaking(true);
        if (this.state !== 'DISABLED' && this.state !== 'WAKE_IDLE') {
          this.setState('SPEAKING', details || 'Hinata is responding...');
        }
      } else if (chatState === 'idle') {
        this.detector.setTtsSpeaking(false);
        if (this.state === 'SPEAKING') {
          this.returnToIdle();
        }
      }
    });
  }

  /**
   * Starts local wake word listener with proper permissions check.
   */
  public async startWakeWordMonitoring(): Promise<boolean> {
    if (!this.config.enabled) {
      this.setState('DISABLED', 'Hands-Free is turned off');
      return false;
    }

    // Verify microphone permission
    const pm = PermissionManager.getInstance();
    const status = await pm.checkPermission('microphone');
    if (status === 'denied') {
      this.setState('ERROR', 'Microphone permission was denied. Please allow microphone access.');
      return false;
    }

    this.setState('WAKE_LISTENING', `Listening locally for "${this.config.phrase}"...`);
    const success = await this.detector.start();
    if (success) {
      this.setState('WAKE_IDLE', `Ready. Say "${this.config.phrase}" anytime.`);
      return true;
    } else {
      this.setState('ERROR', 'Could not start wake word detector.');
      return false;
    }
  }

  /**
   * Disables Hands-Free mode.
   */
  public disableHandsFree(): void {
    this.detector.stop();
    this.clearTimeoutTimer();
    this.setState('DISABLED', 'Hands-Free mode is OFF');
  }

  /**
   * Enables Hands-Free mode.
   */
  public async enableHandsFree(): Promise<boolean> {
    this.config.enabled = true;
    this.saveConfig({ enabled: true });
    return this.startWakeWordMonitoring();
  }

  // ----------------------------------------------------
  // Voice Flow Lifecycle
  // ----------------------------------------------------

  /**
   * Triggered when "Hey Hinata" is spotted by local detector.
   */
  private async handleWakeDetected(event: WakeDetectionEvent): Promise<void> {
    // Interruption logic: If currently speaking, immediately interrupt current speech
    if (this.state === 'SPEAKING' || ConversationManager.getInstance().getChatState() === 'speaking') {
      console.log('[WakeWordManager] Interruption triggered by wake phrase!');
      this.interruptSpeech();
    }

    console.log('[WakeWordManager] ✦ Wake Detected! Entering ACTIVATED state.');
    this.setState('WAKE_DETECTED', `Wake word heard! (${Math.round(event.confidence * 100)}% match)`);

    // Hinata face transition: attentive / curious
    try {
      EmotionManager.getInstance().transitionEmotion('curious', 3, 'Wake word activated');
    } catch {}

    // Acknowledge verbally or with chime
    if (this.config.voiceResponse) {
      await this.speakAcknowledgeGreeting();
    }

    // Transition to active listening for user command
    this.currentCapturedCommand = '';
    this.lastActiveTranscript = '';
    this.setState('LISTENING', 'Hinata is listening... speak your command');

    try {
      EmotionManager.getInstance().transitionEmotion('curious', 3, 'Listening to user request');
    } catch {}

    // Start auto-listen timeout to prevent hanging forever
    this.startListeningTimeout();
  }

  /**
   * Interruption handler: immediately stops speech and switches to listening.
   */
  public interruptSpeech(): void {
    const conv = ConversationManager.getInstance();
    conv.stopSpeaking();
    this.clearTimeoutTimer();
    this.setState('LISTENING', 'Interrupted. Listening to you...');
    try {
      EmotionManager.getInstance().transitionEmotion('calm', 2, 'User interrupted');
    } catch {}
    this.startListeningTimeout();
  }

  /**
   * Handles user speech after wake word has activated the session.
   */
  private handleSpeechChunk(text: string, isFinal: boolean): void {
    // If not in active listening state, ignore or evaluate for interruption
    if (this.state !== 'LISTENING' && this.state !== 'WAKE_DETECTED') {
      if (this.state === 'SPEAKING' && text.length > 3) {
        // Voice interruption detected while Hinata is speaking
        this.interruptSpeech();
      }
      return;
    }

    // Filter out the wake phrase itself if caught in the trailing buffer
    const phraseTarget = this.config.phrase.toLowerCase();
    let commandCandidate = text;
    if (commandCandidate.toLowerCase().startsWith(phraseTarget)) {
      commandCandidate = commandCandidate.slice(phraseTarget.length).trim();
    }

    if (!commandCandidate && !isFinal) return;

    this.currentCapturedCommand = commandCandidate;
    this.lastActiveTranscript = commandCandidate;
    this.notifyTranscript(commandCandidate, isFinal);

    // Reset timeout while user is actively talking
    this.resetListeningTimeout();

    // If final transcript captured or user paused after complete sentence
    if (isFinal && commandCandidate.trim().length > 1) {
      this.clearTimeoutTimer();
      this.processCapturedCommand(commandCandidate.trim());
    }
  }

  /**
   * Processes the user's spoken command through Device Actions or Conversational Intelligence.
   */
  public async processCapturedCommand(command: string): Promise<void> {
    if (this.isProcessingCommand || !command) return;
    this.isProcessingCommand = true;
    this.clearTimeoutTimer();

    console.log(`[WakeWordManager] Processing voice command: "${command}"`);
    this.setState('THINKING', `Analyzing: "${command}"`);

    try {
      EmotionManager.getInstance().transitionEmotion('focused', 3, 'Processing command');
    } catch {}

    try {
      // 1. Check for Android Device Actions first (e.g. "open camera", "turn on flashlight", "open maps")
      const actionMatch = this.detectDeviceActionIntent(command);
      if (actionMatch) {
        await this.handleDeviceActionFlow(actionMatch.type, actionMatch.params, command);
        this.isProcessingCommand = false;
        return;
      }

      // 2. Check for "Likho..." dictation, send draft, or cancel commands
      const vcc = VoiceChatCoordinator.getInstance();
      const isSend = vcc.isSendCommand(command);
      const isCancel = vcc.isCancelCommand(command);
      const likhoMatch = vcc.parseLikhoCommand(command);

      if (isSend || isCancel || likhoMatch.isLikho) {
        vcc.handleRecognizedSpeech(command, true);
        this.returnToIdle();
        this.isProcessingCommand = false;
        return;
      }

      // 3. Otherwise route to conversational intelligence with shared context & MemoryManager
      await this.handleConversationalFlow(command);
    } catch (err: any) {
      console.error('[WakeWordManager] Command execution error:', err);
      this.setState('ERROR', err.message || 'Error executing voice request');
      if (this.config.voiceResponse) {
        await this.speakMessage('I encountered an issue processing that request.');
      }
      this.returnToIdle();
    } finally {
      this.isProcessingCommand = false;
    }
  }

  /**
   * Detects if spoken phrase matches a direct device action.
   */
  private detectDeviceActionIntent(
    command: string
  ): { type: DeviceActionType; params: Record<string, any> } | null {
    const lower = command.toLowerCase().trim();

    // Camera
    if (lower.includes('open camera') || lower.includes('take a photo') || lower.includes('launch camera')) {
      return { type: 'open_camera', params: {} };
    }

    // Gallery / Photos
    if (lower.includes('open gallery') || lower.includes('open photos') || lower.includes('view photos')) {
      return { type: 'open_gallery', params: {} };
    }

    // Maps / Navigation
    if (lower.includes('open maps') || lower.includes('navigate to') || lower.includes('directions to')) {
      const dest = lower.replace(/(open maps|navigate to|directions to)/i, '').trim();
      return { type: 'open_maps', params: { destination: dest || 'Home' } };
    }

    // Flashlight / Torch
    if (lower.includes('turn on torch') || lower.includes('turn on flashlight') || lower.includes('torch on') || lower.includes('flashlight on')) {
      return { type: 'torch', params: { enabled: true } };
    }
    if (lower.includes('turn off torch') || lower.includes('turn off flashlight') || lower.includes('torch off') || lower.includes('flashlight off')) {
      return { type: 'torch', params: { enabled: false } };
    }

    // System Settings
    if (lower.includes('open settings') || lower.includes('system settings') || lower.includes('device settings')) {
      return { type: 'system_setting', params: { setting: 'settings' } };
    }
    if (lower.includes('wifi settings') || lower.includes('open wifi')) {
      return { type: 'system_setting', params: { setting: 'wifi' } };
    }
    if (lower.includes('bluetooth settings') || lower.includes('open bluetooth')) {
      return { type: 'system_setting', params: { setting: 'bluetooth' } };
    }

    // App Launchers
    const appMatch = lower.match(/(?:open|launch|start)\s+(youtube|spotify|whatsapp|chrome|calendar|gmail|clock|calculator)/i);
    if (appMatch) {
      return { type: 'open_app', params: { appName: appMatch[1] } };
    }

    // Alarm / Timer
    if (lower.includes('set alarm') || lower.includes('wake me up at')) {
      return { type: 'set_alarm', params: { time: '07:00', label: 'Hinata Alarm' } };
    }
    if (lower.includes('set timer') || lower.includes('timer for')) {
      return { type: 'set_timer', params: { seconds: 300, label: 'Voice Timer' } };
    }

    return null;
  }

  /**
   * Executes device action and verifies result using ActionVerifier.
   */
  private async handleDeviceActionFlow(
    actionType: DeviceActionType,
    params: Record<string, any>,
    rawCommand: string
  ): Promise<void> {
    const dam = DeviceActionManager.getInstance();
    const verifier = ActionVerifier.getInstance();

    // Execute real Android Intent / browser action
    const result = await dam.executeAction(actionType, params);

    // Sync into shared ConversationManager so Chat mode also knows!
    const conv = ConversationManager.getInstance();
    conv.syncVoiceTurn('user', rawCommand);

    const voiceSummary = verifier.formatVoiceResult(result);
    conv.syncVoiceTurn('assistant', voiceSummary);

    this.setState('SPEAKING', voiceSummary);

    // Voice response
    if (this.config.voiceResponse) {
      await this.speakMessage(voiceSummary);
    } else {
      setTimeout(() => this.returnToIdle(), 2000);
    }
  }

  /**
   * Routes conversational queries to server-side Gemini via ConversationManager with Memory retrieval.
   */
  private async handleConversationalFlow(command: string): Promise<void> {
    const conv = ConversationManager.getInstance();
    const mm = MemoryManager.getInstance();

    // 1. Retrieve relevant memories for this prompt
    const memories = mm.retriever.getFormattedContext(command, 3);

    // 2. Synchronize user command into active conversation
    await conv.sendMessage({
      text: command,
    });

    // The conversation manager will stream the response and handle TTS through its state listeners.
  }

  /**
   * Speaks acknowledgment greeting when wake word is detected.
   */
  private async speakAcknowledgeGreeting(): Promise<void> {
    return new Promise((resolve) => {
      if (typeof window === 'undefined' || !window.speechSynthesis) {
        resolve();
        return;
      }

      const phrases = ['Yes, how can I help?', "I'm listening!", 'Yes, Aman?'];
      const text = phrases[Math.floor(Math.random() * phrases.length)];

      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 1.1;
      utterance.pitch = 1.15;

      utterance.onend = () => resolve();
      utterance.onerror = () => resolve();

      window.speechSynthesis.speak(utterance);
    });
  }

  /**
   * Speaks text through speech synthesis while driving visemes and Face Animator.
   */
  private async speakMessage(text: string): Promise<void> {
    return new Promise((resolve) => {
      if (typeof window === 'undefined' || !window.speechSynthesis) {
        this.returnToIdle();
        resolve();
        return;
      }

      this.setState('SPEAKING', text);

      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 1.05;
      utterance.pitch = 1.1;

      utterance.onend = () => {
        this.returnToIdle();
        resolve();
      };
      utterance.onerror = () => {
        this.returnToIdle();
        resolve();
      };

      window.speechSynthesis.speak(utterance);
    });
  }

  private returnToIdle(): void {
    this.clearTimeoutTimer();
    this.setState('WAKE_IDLE', `Ready. Say "${this.config.phrase}" anytime.`);
    try {
      EmotionManager.getInstance().transitionEmotion('calm', 1, 'Return to standby');
    } catch {}
  }

  // ----------------------------------------------------
  // Timeout & False-Activation Handling
  // ----------------------------------------------------

  private startListeningTimeout(): void {
    this.clearTimeoutTimer();
    this.listenTimeoutTimer = setTimeout(() => {
      if (this.state === 'LISTENING' || this.state === 'WAKE_DETECTED') {
        console.log('[WakeWordManager] Listening timeout expired without command.');
        if (this.config.voiceResponse) {
          this.speakMessage("I'm here whenever you need me.");
        } else {
          this.returnToIdle();
        }
      }
    }, this.config.autoListenTimeoutMs);
  }

  private resetListeningTimeout(): void {
    if (this.listenTimeoutTimer) {
      clearTimeout(this.listenTimeoutTimer);
      this.startListeningTimeout();
    }
  }

  private clearTimeoutTimer(): void {
    if (this.listenTimeoutTimer) {
      clearTimeout(this.listenTimeoutTimer);
      this.listenTimeoutTimer = null;
    }
  }
}
