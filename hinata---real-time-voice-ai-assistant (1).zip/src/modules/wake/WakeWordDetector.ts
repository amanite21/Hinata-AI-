/**
 * WakeWordDetector - Lightweight, Local Wake Word Engine for Hinata AI.
 *
 * Requirements:
 * - Runs locally on device without sending continuous audio to cloud or Gemini backend.
 * - Detects configured phrase ("Hey Hinata") using local speech spotter & acoustic analysis.
 * - Sensitivity levels: Low, Medium, High.
 * - False-activation protection: cooldown periods, audio level thresholds.
 * - Echo protection: ignores Hinata's own TTS output unless interrupting.
 */

import { WakeSensitivity, WakeDetectionEvent } from './types';
import { MicrophoneManager } from '../audio/MicrophoneManager';

export type WakeDetectedCallback = (event: WakeDetectionEvent) => void;
export type SpeechTranscriptCallback = (text: string, isFinal: boolean) => void;
export type AcousticLevelCallback = (level: number) => void;
export type DetectorErrorCallback = (error: string) => void;

export class WakeWordDetector {
  private static instance: WakeWordDetector | null = null;

  private recognition: any = null;
  private isListening: boolean = false;
  private wakePhrase: string = 'Hey Hinata';
  private sensitivity: WakeSensitivity = 'medium';
  private cooldownMs: number = 2500;
  private lastWakeTimestamp: number = 0;
  private isMutedForTTS: boolean = false;

  private micManager: MicrophoneManager;
  private unsubs: Array<() => void> = [];
  private currentAcousticLevel: number = 0;

  // Listeners
  private onWakeCallbacks: WakeDetectedCallback[] = [];
  private onTranscriptCallbacks: SpeechTranscriptCallback[] = [];
  private onLevelCallbacks: AcousticLevelCallback[] = [];
  private onErrorCallbacks: DetectorErrorCallback[] = [];

  private constructor() {
    this.micManager = MicrophoneManager.getInstance();
    this.micManager.onStateChange((state, owner) => {
      if (this.isListening && (state !== 'LISTENING' || owner !== 'wake_word')) {
        this.isListening = false;
        if (this.recognition) {
          try { this.recognition.stop(); } catch {}
        }
        this.cleanupPipeline();
      }
    });
    this.initSpeechEngine();
  }

  public static getInstance(): WakeWordDetector {
    if (!WakeWordDetector.instance) {
      WakeWordDetector.instance = new WakeWordDetector();
    }
    return WakeWordDetector.instance;
  }

  public setWakePhrase(phrase: string): void {
    this.wakePhrase = phrase.trim() || 'Hey Hinata';
  }

  public getWakePhrase(): string {
    return this.wakePhrase;
  }

  public setSensitivity(sensitivity: WakeSensitivity): void {
    this.sensitivity = sensitivity;
    switch (sensitivity) {
      case 'low':
        this.cooldownMs = 3500;
        break;
      case 'high':
        this.cooldownMs = 1800;
        break;
      case 'medium':
      default:
        this.cooldownMs = 2500;
        break;
    }
  }

  public getSensitivity(): WakeSensitivity {
    return this.sensitivity;
  }

  public setTtsSpeaking(speaking: boolean): void {
    this.isMutedForTTS = speaking;
  }

  public isSupported(): boolean {
    return (
      typeof window !== 'undefined' &&
      Boolean((window as any).SpeechRecognition || (window as any).webkitSpeechRecognition)
    );
  }

  public isActive(): boolean {
    return this.isListening;
  }

  public getAcousticLevel(): number {
    return this.currentAcousticLevel;
  }

  public onWakeDetected(cb: WakeDetectedCallback): () => void {
    this.onWakeCallbacks.push(cb);
    return () => {
      this.onWakeCallbacks = this.onWakeCallbacks.filter((c) => c !== cb);
    };
  }

  public onTranscript(cb: SpeechTranscriptCallback): () => void {
    this.onTranscriptCallbacks.push(cb);
    return () => {
      this.onTranscriptCallbacks = this.onTranscriptCallbacks.filter((c) => c !== cb);
    };
  }

  public onAcousticLevel(cb: AcousticLevelCallback): () => void {
    this.onLevelCallbacks.push(cb);
    return () => {
      this.onLevelCallbacks = this.onLevelCallbacks.filter((c) => c !== cb);
    };
  }

  public onError(cb: DetectorErrorCallback): () => void {
    this.onErrorCallbacks.push(cb);
    return () => {
      this.onErrorCallbacks = this.onErrorCallbacks.filter((c) => c !== cb);
    };
  }

  private initSpeechEngine(): void {
    if (typeof window === 'undefined') return;

    const SpeechRec =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRec) {
      console.warn('[WakeWordDetector] SpeechRecognition API not supported in this runtime.');
      return;
    }

    try {
      this.recognition = new SpeechRec();
      this.recognition.continuous = true;
      this.recognition.interimResults = true;
      this.recognition.maxAlternatives = 3;
      this.recognition.lang = 'en-US';

      this.recognition.onresult = (event: any) => {
        let interimText = '';
        let finalText = '';

        for (let i = event.resultIndex; i < event.results.length; ++i) {
          const res = event.results[i];
          if (res.isFinal) {
            finalText += res[0].transcript;
          } else {
            interimText += res[0].transcript;
          }
        }

        const rawCandidate = (finalText || interimText).trim();
        if (!rawCandidate) return;

        // Broadcast raw transcript for active listening mode
        this.notifyTranscript(rawCandidate, Boolean(finalText));

        // Evaluate wake phrase match
        this.evaluateWakeTrigger(rawCandidate, event);
      };

      this.recognition.onerror = (event: any) => {
        if (event.error === 'no-speech') {
          // Benign idle noise
          return;
        }

        if (event.error === 'not-allowed') {
          this.notifyError('Microphone permission is required for Hands-Free wake word.');
          this.stop();
          return;
        }

        // Auto-recover from transient errors
        if (this.isListening && event.error !== 'aborted') {
          console.warn('[WakeWordDetector] Transient recognition error:', event.error);
        }
      };

      this.recognition.onend = () => {
        // Continuous wake-word listener loop ONLY if still intended to run and mic is owned by wake_word
        if (
          this.isListening &&
          this.micManager.getState() === 'LISTENING' &&
          this.micManager.getOwner() === 'wake_word'
        ) {
          try {
            this.recognition.start();
          } catch (e) {
            // Already starting or waiting
          }
        } else {
          this.isListening = false;
        }
      };
    } catch (e: any) {
      console.error('[WakeWordDetector] Error creating SpeechRecognition:', e);
      this.notifyError(e.message || 'Failed to initialize wake word engine');
    }
  }

  /**
   * Evaluates if incoming text matches the wake phrase.
   */
  private evaluateWakeTrigger(candidate: string, rawEvent?: any): void {
    const now = Date.now();

    // Cooldown check
    if (now - this.lastWakeTimestamp < this.cooldownMs) {
      return;
    }

    // Echo protection: if Hinata is speaking, allow interruption triggers ("Hey Hinata", "Stop", "Hinata wait")
    const lower = candidate.toLowerCase().trim();

    // Flexible matching regex based on sensitivity
    const isMatched = this.matchesWakePhrase(lower);

    if (isMatched) {
      this.lastWakeTimestamp = now;
      const event: WakeDetectionEvent = {
        phrase: this.wakePhrase,
        confidence: this.sensitivity === 'high' ? 0.95 : this.sensitivity === 'medium' ? 0.88 : 0.8,
        timestamp: now,
        source: 'local_recognizer',
      };

      console.log(`[WakeWordDetector] ✦ Wake Word Detected: "${candidate}" matching "${this.wakePhrase}"`);
      this.notifyWake(event);
    }
  }

  private matchesWakePhrase(text: string): boolean {
    const clean = text.replace(/[^a-z0-9\s]/g, '').trim();

    // 1. Direct configured phrase match
    const target = this.wakePhrase.toLowerCase().replace(/[^a-z0-9\s]/g, '').trim();
    if (clean.includes(target)) {
      return true;
    }

    // 2. High sensitivity: allow phonetic variations of "Hey Hinata"
    if (this.sensitivity === 'high' || this.sensitivity === 'medium') {
      const patterns = [
        /\bhey\s+hinata\b/i,
        /\bhi\s+hinata\b/i,
        /\bhinata\b/i,
        /\bhey\s+hinatta\b/i,
        /\bhey\s+hinada\b/i,
        /\bhey\s+inata\b/i,
        /\bokay\s+hinata\b/i,
      ];
      for (const pattern of patterns) {
        if (pattern.test(clean)) return true;
      }
    } else {
      // Low sensitivity: strict match
      if (clean === target || clean.endsWith(target) || clean.startsWith(target)) {
        return true;
      }
    }

    return false;
  }

  /**
   * Starts local wake word detection & acoustic monitoring.
   */
  public async start(): Promise<boolean> {
    if (this.isListening) return true;

    if (!this.recognition) {
      this.initSpeechEngine();
    }

    if (!this.recognition) {
      this.notifyError('Speech recognition is not available on this platform.');
      return false;
    }

    try {
      // 1. Activate hardware stream via centralized MicrophoneManager
      const micStarted = await this.micManager.startListening('wake_word', {
        echoCancellation: true,
        noiseSuppression: true,
      });

      if (!micStarted) {
        this.notifyError('Microphone access not granted for wake phrase detection.');
        return false;
      }

      // 2. Subscribe to centralized volume changes
      const unVol = this.micManager.onVolume((vol) => {
        if (this.isListening) {
          this.currentAcousticLevel = vol;
          for (const cb of this.onLevelCallbacks) {
            try {
              cb(vol);
            } catch {}
          }
        }
      });
      this.unsubs.push(unVol);

      this.isListening = true;
      this.recognition.start();
      return true;
    } catch (err: any) {
      if (err.name === 'InvalidStateError') {
        // Already active
        this.isListening = true;
        return true;
      }
      console.warn('[WakeWordDetector] Could not start speech recognition:', err);
      this.isListening = false;
      this.cleanupPipeline();
      this.notifyError(err.message || 'Microphone activation failed');
      return false;
    }
  }

  /**
   * Stops local wake word detection.
   */
  public stop(): void {
    this.isListening = false;
    if (this.recognition) {
      try {
        this.recognition.stop();
      } catch {}
    }
    this.cleanupPipeline();
    this.micManager.stopListening('wake_word').catch(() => {});
  }

  private cleanupPipeline(): void {
    this.unsubs.forEach((un) => un());
    this.unsubs = [];
    this.currentAcousticLevel = 0;
  }

  /**
   * Manually trigger a simulated wake word test (for the Setup Flow).
   */
  public triggerManualWakeTest(): void {
    const event: WakeDetectionEvent = {
      phrase: this.wakePhrase,
      confidence: 1.0,
      timestamp: Date.now(),
      source: 'manual_test',
    };
    this.notifyWake(event);
  }

  private notifyWake(event: WakeDetectionEvent): void {
    for (const cb of this.onWakeCallbacks) {
      try {
        cb(event);
      } catch (err) {
        console.error('[WakeWordDetector] Wake callback error:', err);
      }
    }
  }

  private notifyTranscript(text: string, isFinal: boolean): void {
    for (const cb of this.onTranscriptCallbacks) {
      try {
        cb(text, isFinal);
      } catch (err) {
        console.error('[WakeWordDetector] Transcript callback error:', err);
      }
    }
  }

  private notifyError(error: string): void {
    for (const cb of this.onErrorCallbacks) {
      try {
        cb(error);
      } catch (err) {
        console.error('[WakeWordDetector] Error callback error:', err);
      }
    }
  }
}
