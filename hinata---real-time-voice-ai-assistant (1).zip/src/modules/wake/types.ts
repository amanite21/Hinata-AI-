/**
 * Wake Word & Android Voice Assistant Type Definitions for Hinata AI.
 */

export type WakeWordState =
  | 'WAKE_IDLE'
  | 'WAKE_LISTENING'
  | 'WAKE_DETECTED'
  | 'LISTENING'
  | 'THINKING'
  | 'SPEAKING'
  | 'ERROR'
  | 'DISABLED';

export type WakeSensitivity = 'low' | 'medium' | 'high';

export interface WakeWordConfig {
  enabled: boolean;
  phrase: string;
  sensitivity: WakeSensitivity;
  autoListenTimeoutMs: number;
  voiceResponse: boolean;
  cooldownMs: number;
  echoProtection: boolean;
  systemAssistantEnabled: boolean;
  notificationEnabled: boolean;
}

export interface WakeDetectionEvent {
  phrase: string;
  confidence: number;
  timestamp: number;
  source: 'local_recognizer' | 'acoustic_vad' | 'system_service' | 'manual_test';
}

export interface VoiceAssistantSessionData {
  sessionId: string;
  startTime: number;
  wakePhrase: string;
  capturedCommand?: string;
  actionExecuted?: string;
  verifiedSuccess?: boolean;
  responseText?: string;
}

export interface AndroidVoiceAssistantStatus {
  isSupported: boolean;
  isDefaultAssistant: boolean;
  hasRecordAudioPermission: boolean;
  isForegroundServiceActive: boolean;
  serviceState: 'unregistered' | 'ready' | 'active_session' | 'background_standby';
  batteryOptimizationIgnored: boolean;
}
