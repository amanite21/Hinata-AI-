/**
 * HinataBrain - Master Conversational Intelligence Coordinator for Hinata AI.
 *
 * Capabilities:
 * - Natural Language Intent Parsing & Resolution
 * - Contextual Pronoun Resolution (resolving "it", "that", "the app", "call them")
 * - Ambiguity Detection & Clarification Asking
 * - Multi-Step Task Planning Dispatch
 * - Safe Device Action Orchestration
 * - Visual Design Intelligence Bridge
 * - Non-blocking asynchronous task execution with state tracking (Thinking, Executing, Completed, Failed)
 */

import { DeviceActionManager } from './device/DeviceActionManager';
import { TaskPlanner } from './task/TaskPlanner';
import { VisualDesignManager } from './visualDesign/VisualDesignManager';
import { MemoryManager } from './memory/MemoryManager';
import { OwnerManager } from './OwnerManager';
import { EmotionManager } from './EmotionManager';
import { DeviceActionResult, DeviceActionType } from './device/types';
import { DesignIntelligenceEngine } from './design/DesignIntelligenceEngine';
import { DesignReviewEngine } from './design/DesignReviewEngine';
import { HonestDecisionEngine } from './reasoning/HonestDecisionEngine';
import { HinataDesignSystem } from './design/HinataDesignSystem';
import { DesignGenerationResult } from './design/DesignIntelligenceTypes';
import { WorkIntelligenceCoordinator } from './work/WorkIntelligenceCoordinator';

export type CognitiveState = 'idle' | 'thinking' | 'executing' | 'completed' | 'failed';

export interface BrainContext {
  lastMentionedApp: string | null;
  lastMentionedContact: string | null;
  lastMentionedDestination: string | null;
  lastActionType: DeviceActionType | string | null;
  activeReferenceName: string | null;
  recentTopic: string | null;
  lastInteractionTime: number;
}

export class HinataBrain {
  private static instance: HinataBrain | null = null;

  public readonly device = DeviceActionManager.getInstance();
  public readonly taskPlanner = TaskPlanner.getInstance();
  public readonly vision = VisualDesignManager.getInstance();
  public readonly memory = MemoryManager.getInstance();
  public readonly owner = OwnerManager.getInstance();
  public readonly emotion = EmotionManager.getInstance();
  public readonly design = DesignIntelligenceEngine.getInstance();
  public readonly designReview = DesignReviewEngine.getInstance();
  public readonly honestDecision = HonestDecisionEngine.getInstance();
  public readonly designSystem = HinataDesignSystem.getInstance();

  private cognitiveState: CognitiveState = 'idle';
  private stateListeners: Array<(state: CognitiveState, details?: string) => void> = [];

  private context: BrainContext = {
    lastMentionedApp: null,
    lastMentionedContact: null,
    lastMentionedDestination: null,
    lastActionType: null,
    activeReferenceName: null,
    recentTopic: null,
    lastInteractionTime: Date.now(),
  };

  private constructor() {
    this.owner.syncWithOwnerProfile();
  }

  public static getInstance(): HinataBrain {
    if (!HinataBrain.instance) {
      HinataBrain.instance = new HinataBrain();
    }
    return HinataBrain.instance;
  }

  public onStateChange(listener: (state: CognitiveState, details?: string) => void): () => void {
    this.stateListeners.push(listener);
    listener(this.cognitiveState);
    return () => {
      this.stateListeners = this.stateListeners.filter((l) => l !== listener);
    };
  }

  private setCognitiveState(state: CognitiveState, details?: string): void {
    this.cognitiveState = state;
    for (const listener of this.stateListeners) {
      try {
        listener(state, details);
      } catch (err) {
        console.error('[HinataBrain] State listener error:', err);
      }
    }
  }

  public getCognitiveState(): CognitiveState {
    return this.cognitiveState;
  }

  public getContext(): Readonly<BrainContext> {
    return { ...this.context };
  }

  /**
   * Resolves contextual pronouns like "it", "that", "the app", or "them".
   * Example: If user previously talked about YouTube and says "Open it", resolves to YouTube.
   */
  public resolveContextualTarget(rawTarget: string): string {
    const clean = rawTarget.toLowerCase().trim();
    if (clean === 'it' || clean === 'that' || clean === 'the app' || clean === 'this app') {
      if (this.context.lastMentionedApp) {
        return this.context.lastMentionedApp;
      }
      const activeRef = this.vision.getActiveReference();
      if (activeRef) {
        return activeRef.name;
      }
    }

    if (clean === 'them' || clean === 'him' || clean === 'her') {
      if (this.context.lastMentionedContact) {
        return this.context.lastMentionedContact;
      }
    }

    if (clean === 'there' || clean === 'that place') {
      if (this.context.lastMentionedDestination) {
        return this.context.lastMentionedDestination;
      }
    }

    return rawTarget;
  }

  /**
   * Processes a natural language text command or transcript.
   */
  public async processNaturalCommand(text: string): Promise<{
    handled: boolean;
    result?: DeviceActionResult;
    clarificationNeeded?: boolean;
    clarificationPrompt?: string;
    designResult?: DesignGenerationResult;
  }> {
    const raw = text.trim();
    const lower = raw.toLowerCase();
    this.setCognitiveState('thinking', 'Analyzing command intent');

    // Update interaction time
    this.context.lastInteractionTime = Date.now();

    try {
      // 0. HONEST DECISION EVALUATION & CRITICAL THINKING CHECK
      const evaluation = this.honestDecision.evaluateRequest(raw);

      // Consequential / Destructive Action Safeguard (e.g. delete file, wipe data)
      if (evaluation.status === 'UNSAFE') {
        this.setCognitiveState('idle');
        return {
          handled: true,
          clarificationNeeded: true,
          clarificationPrompt: evaluation.recommendedResponse,
        };
      }

      // Impossible with permissions / sandbox restrictions
      if (evaluation.status === 'IMPOSSIBLE_WITH_CURRENT_PERMISSIONS') {
        this.setCognitiveState('failed');
        return {
          handled: true,
          result: {
            success: false,
            action: 'device_info',
            message: evaluation.recommendedResponse,
            timestamp: Date.now(),
          },
        };
      }

      // Usability Advisory (e.g. "make everything red", "remove all labels")
      if (evaluation.decisionSupport) {
        this.setCognitiveState('completed');
        return {
          handled: true,
          result: {
            success: true,
            action: 'in_app_action',
            message: evaluation.recommendedResponse,
            timestamp: Date.now(),
          },
        };
      }

      // Design System Memory Commands
      if (lower.includes('remember this design') || lower.includes('save my design preference') || lower.includes('remember my design style')) {
        this.design.rememberDesignPreference({
          preferredStyle: lower.includes('minimal') ? 'minimal' : lower.includes('cyber') ? 'cyberpunk' : 'cinematic',
          preferredPhilosophy: 'User prioritized high contrast, crisp component borders, and WCAG AA accessibility.',
        });
        this.setCognitiveState('completed');
        return {
          handled: true,
          result: {
            success: true,
            action: 'in_app_action',
            message: 'Saved your design style preference to long-term memory. Future designs will align with your aesthetic.',
            timestamp: Date.now(),
          },
        };
      }

      if (lower.includes('forget my old design') || lower.includes('forget my design preference') || lower.includes('reset design preference')) {
        this.design.forgetDesignPreference();
        this.setCognitiveState('completed');
        return {
          handled: true,
          result: {
            success: true,
            action: 'in_app_action',
            message: 'Reset and cleared your previous design preference memory.',
            timestamp: Date.now(),
          },
        };
      }

      // Work Intelligence & Freelancing Assistant Commands
      const workResult = await WorkIntelligenceCoordinator.getInstance().handleNaturalWorkCommand(raw);
      if (workResult.handled) {
        this.setCognitiveState('completed');
        return {
          handled: true,
          result: {
            success: true,
            action: 'in_app_action',
            message: workResult.response,
            timestamp: Date.now(),
          },
        };
      }

      // Autonomous Design Generation ("Design bana do", "Khud design socho", "Create an AI dashboard", etc.)
      if (
        lower.includes('design bana do') ||
        lower.includes('khud design socho') ||
        lower.includes('make a design') ||
        lower.includes('create a design') ||
        lower.includes('design karo') ||
        lower.includes('ai dashboard design') ||
        lower.includes('music player design') ||
        lower.includes('video stream design') ||
        lower.includes('mobile app ui') ||
        lower.includes('design a screen') ||
        lower.includes('design an app')
      ) {
        this.setCognitiveState('executing', 'Synthesizing original design alternatives');
        const designResult = this.design.generateDesign(raw);
        const selectedOpt = designResult.options.find(o => o.id === designResult.selectedOptionId) || designResult.options[0];
        
        this.setCognitiveState('completed');
        return {
          handled: true,
          designResult,
          result: {
            success: true,
            action: 'in_app_action',
            message: `I created an original ${designResult.domain.replace('_', ' ')} layout for "${raw}".\n\n` +
              `• **${selectedOpt.title}** (${selectedOpt.badge})\n` +
              `• **Visual Hierarchy**: ${selectedOpt.visualHierarchy}\n` +
              `• **Self-Critique Review**: ${designResult.reviewAudit.userFacingExplanation}\n\n` +
              `You can switch between Option A (Minimal), Option B (Cinematic), and Option C (Experimental) or copy the React / Compose code.`,
            timestamp: Date.now(),
          },
        };
      }

      // 1. Contextual Pronoun Resolution: "open it", "open that"
      if (/^(open|launch|start)\s+(it|that|the app)$/i.test(lower)) {
        if (this.context.lastMentionedApp) {
          this.setCognitiveState('executing', `Opening ${this.context.lastMentionedApp}`);
          const res = await this.device.executeAction('open_app', {
            target: this.context.lastMentionedApp,
          });
          this.setCognitiveState(res.success ? 'completed' : 'failed');
          return { handled: true, result: res };
        } else {
          this.setCognitiveState('idle');
          return {
            handled: true,
            clarificationNeeded: true,
            clarificationPrompt: 'What would you like me to open?',
          };
        }
      }

      // 2. Ambiguity: "Call" without contact
      if (/^(call|phone|ring)$/i.test(lower) || /^(call|phone|ring)\s+(them|someone)$/i.test(lower)) {
        if (this.context.lastMentionedContact) {
          const target = this.context.lastMentionedContact;
          this.setCognitiveState('executing', `Preparing call to ${target}`);
          const res = await this.device.executeAction('phone_call', { contact: target });
          this.setCognitiveState('completed');
          return { handled: true, result: res };
        }
        this.setCognitiveState('idle');
        return {
          handled: true,
          clarificationNeeded: true,
          clarificationPrompt: 'Who would you like me to call?',
        };
      }

      // 3. Direct Phone Call: "Call Mom", "Call 123456"
      const callMatch = lower.match(/^(?:please\s+)?call\s+([a-z0-9\s]+)$/i);
      if (callMatch) {
        const contact = callMatch[1].trim();
        this.context.lastMentionedContact = contact;
        this.setCognitiveState('executing', `Preparing call to ${contact}`);
        const res = await this.device.executeAction('phone_call', { contact });
        this.setCognitiveState('completed');
        return { handled: true, result: res };
      }

      // 4. Alarms & Timers: "Set an alarm for 7 AM", "Set a timer for 5 minutes"
      const alarmMatch = lower.match(/(?:set|create)\s+(?:an?\s+)?alarm\s+(?:for\s+)?(\d{1,2})(?::(\d{2}))?\s*(am|pm)?/i);
      if (alarmMatch) {
        let hours = parseInt(alarmMatch[1], 10);
        const minutes = alarmMatch[2] ? parseInt(alarmMatch[2], 10) : 0;
        const ampm = alarmMatch[3]?.toLowerCase();
        if (ampm === 'pm' && hours < 12) hours += 12;
        if (ampm === 'am' && hours === 12) hours = 0;

        this.setCognitiveState('executing', `Setting alarm for ${hours}:${minutes}`);
        const res = await this.device.executeAction('set_alarm', { hours, minutes });
        this.setCognitiveState(res.success ? 'completed' : 'failed');
        return { handled: true, result: res };
      }

      const timerMatch = lower.match(/(?:set|start)\s+(?:a\s+)?timer\s+(?:for\s+)?(\d+)\s*(minute|minutes|min|mins|second|seconds|sec|secs)/i);
      if (timerMatch) {
        const val = parseInt(timerMatch[1], 10);
        const unit = timerMatch[2];
        const seconds = unit.startsWith('min') ? val * 60 : val;

        this.setCognitiveState('executing', `Starting timer for ${seconds}s`);
        const res = await this.device.executeAction('set_timer', { seconds });
        this.setCognitiveState(res.success ? 'completed' : 'failed');
        return { handled: true, result: res };
      }

      // 5. Open Camera
      if (lower.includes('open camera') || lower.includes('take a photo') || lower.includes('open the camera')) {
        this.context.lastMentionedApp = 'Camera';
        this.setCognitiveState('executing', 'Opening Camera');
        const res = await this.device.executeAction('open_camera', {});
        this.setCognitiveState(res.success ? 'completed' : 'failed');
        return { handled: true, result: res };
      }

      // 6. Open Gallery / Photos
      if (lower.includes('open gallery') || lower.includes('open my gallery') || lower.includes('open photos')) {
        this.context.lastMentionedApp = 'Gallery';
        this.setCognitiveState('executing', 'Opening Gallery');
        const res = await this.device.executeAction('open_gallery', {});
        this.setCognitiveState(res.success ? 'completed' : 'failed');
        return { handled: true, result: res };
      }

      // 7. System Settings / Wi-Fi: "Turn on Wi-Fi", "Open Wi-Fi", "Take me to settings"
      if (lower.includes('setting') || lower.includes('wi-fi') || lower.includes('wifi') || lower.includes('bluetooth')) {
        const settingName = lower.includes('wi-fi') || lower.includes('wifi') ? 'wifi' : lower.includes('bluetooth') ? 'bluetooth' : 'settings';
        this.setCognitiveState('executing', `Opening ${settingName}`);
        const res = await this.device.executeAction('system_setting', { setting: settingName });
        this.setCognitiveState(res.success ? 'completed' : 'failed');
        return { handled: true, result: res };
      }

      // 8. Multi-Step Task: "Open Maps and navigate to the nearest hospital"
      if (lower.includes('and navigate') || (lower.includes('maps') && lower.includes('navigate'))) {
        this.setCognitiveState('executing', 'Planning multi-step navigation');
        this.taskPlanner.createPlan(raw);
        const res = await this.taskPlanner.executeActivePlan();
        this.setCognitiveState(res.success ? 'completed' : 'failed');
        return { handled: true, result: res };
      }

      // 9. Open Application: "Open YouTube", "Open WhatsApp", etc.
      const openMatch = lower.match(/^(?:please\s+)?(?:open|launch|start)\s+([a-z0-9\s]+)$/i);
      if (openMatch) {
        const appTarget = openMatch[1].trim();
        this.context.lastMentionedApp = appTarget;
        this.setCognitiveState('executing', `Launching ${appTarget}`);
        const res = await this.device.executeAction('open_app', { target: appTarget });
        this.setCognitiveState(res.success ? 'completed' : 'failed');
        return { handled: true, result: res };
      }

      // 10. Visual Design Command: "Make my UI like this", "Make this more futuristic"
      if (lower.includes('make my ui') || lower.includes('make this more') || lower.includes('design based on this') || lower.includes('use these colors')) {
        this.setCognitiveState('executing', 'Applying visual design transformation');
        if (lower.includes('futuristic')) {
          this.vision.applyDesignTransformation('futuristic');
        } else if (lower.includes('minimal')) {
          this.vision.applyDesignTransformation('minimalist');
        } else if (lower.includes('mobile')) {
          this.vision.applyDesignTransformation('mobile');
        } else {
          const activeRef = this.vision.getActiveReference();
          if (activeRef) {
            this.vision.applyThemeFromReference(activeRef.id);
          }
        }
        this.setCognitiveState('completed');
        return {
          handled: true,
          result: {
            success: true,
            action: 'in_app_action',
            message: 'Applied visual design styling to your interface.',
            timestamp: Date.now(),
          },
        };
      }

      // Not directly an interceptable device command
      this.setCognitiveState('idle');
      return { handled: false };
    } catch (err: any) {
      this.setCognitiveState('failed', err.message);
      return {
        handled: true,
        result: {
          success: false,
          action: 'in_app_action',
          message: `Action encountered an issue: ${err.message}`,
          timestamp: Date.now(),
        },
      };
    }
  }
}
