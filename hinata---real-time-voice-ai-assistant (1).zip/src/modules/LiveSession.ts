/**
 * LiveSession - Manages WebSocket connection to the server's Gemini Live bridge,
 * audio streaming, tool calls, turn management, and verified interruption handling.
 */

import { LiveSessionState, EmotionalState, EmotionalIntensity, AssistantMood, ToolCallItem, ServerMessage, ClientMessage } from '../types';
import { AudioStreamer } from './AudioStreamer';
import { AudioPlayer } from './AudioPlayer';
import { ToolManager } from './ToolManager';
import { MemoryManager } from './memory/MemoryManager';
import { EmotionManager } from './EmotionManager';
import { VisualDesignManager } from './visualDesign/VisualDesignManager';
import { backendConfig } from '../config/backendConfig';
import { ClientAIProvider } from './ai/AIProvider';

export interface LiveSessionCallbacks {
  onStateChange: (state: LiveSessionState) => void;
  onEmotionChange?: (emotion: EmotionalState, intensity?: EmotionalIntensity, reason?: string) => void;
  onMoodChange: (mood: AssistantMood) => void;
  onToolCall: (item: ToolCallItem) => void;
  onError: (errorMessage: string) => void;
  onLatencyUpdate: (latencyMs: number) => void;
  onInputVolume: (vol: number) => void;
  onOutputVolume: (vol: number) => void;
  onTranscript?: (role: 'user' | 'assistant', text: string) => void;
}

export class LiveSession {
  private ws: WebSocket | null = null;
  private streamer: AudioStreamer | null = null;
  private player: AudioPlayer;
  private toolManager: ToolManager;
  private state: LiveSessionState = 'disconnected';
  private mood: EmotionalState = 'playful';
  private callbacks: LiveSessionCallbacks;
  private pingTimestamp: number = 0;
  private latencyMs: number = 28;
  private isIntentionalClose: boolean = false;
  private currentVoice: string = 'Kore';

  // Real-time audio telemetry for reliable interruption handling
  private currentOutputVolume: number = 0;
  private consecutiveSpeechFrames: number = 0;

  constructor(callbacks: LiveSessionCallbacks) {
    this.callbacks = callbacks;

    this.toolManager = new ToolManager({
      onEmotionChange: (emotion, intensity, reason) => {
        this.mood = emotion;
        const emotionManager = EmotionManager.getInstance();
        emotionManager.updateEmotionalState(emotion, intensity || 2, reason);
        if (this.callbacks.onEmotionChange) {
          this.callbacks.onEmotionChange(emotion, intensity, reason);
        }
        this.callbacks.onMoodChange(emotion);
      },
      onMoodChange: (mood) => {
        this.mood = mood as EmotionalState;
        EmotionManager.getInstance().updateEmotionalState(this.mood, 2);
        this.callbacks.onMoodChange(this.mood);
      },
      onToolEvent: (event) => {
        this.callbacks.onToolCall({
          id: Math.random().toString(36).substring(2, 9),
          name: event.name,
          args: event.args,
          status: 'executed',
          result: event.result,
          timestamp: Date.now(),
        });
      },
    });

    this.player = new AudioPlayer({
      onPlaybackStart: () => {
        if (this.state !== 'disconnected' && this.state !== 'connecting') {
          this.setState('speaking');
        }
      },
      onPlaybackEnd: () => {
        this.consecutiveSpeechFrames = 0;
        if (this.state === 'speaking') {
          this.setState('listening');
        }
      },
      onVolumeChange: (vol) => {
        this.currentOutputVolume = vol;
        this.callbacks.onOutputVolume(vol);
      },
    });
  }

  public getState(): LiveSessionState {
    return this.state;
  }

  public getMood(): AssistantMood {
    return this.mood;
  }

  public getAudioPlayer(): AudioPlayer {
    return this.player;
  }

  public getAudioStreamer(): AudioStreamer | null {
    return this.streamer;
  }

  public async connect(voiceName: string = 'Kore'): Promise<void> {
    if (this.state === 'connecting' || this.state === 'listening' || this.state === 'speaking') {
      return;
    }

    // Check if backend is configured before attempting connection
    if (!backendConfig.isConfigured()) {
      console.warn('[LiveSession] Backend not configured. Live API voice is waiting for backend URL.');
      this.setState('error');
      this.callbacks.onError('Backend not configured. HINATA_BACKEND_URL is optional during development. Configure your backend URL in Settings or deployment environment.');
      return;
    }

    this.isIntentionalClose = false;
    this.currentVoice = voiceName;
    this.consecutiveSpeechFrames = 0;
    this.setState('connecting');

    try {
      // 1. Initialize AudioPlayer (Web Audio output context)
      await this.player.init();

      // 2. Initialize AudioStreamer (Microphone input context)
      this.streamer = new AudioStreamer({
        onAudioData: (base64Audio) => {
          this.sendClientMessage({
            type: 'realtime_audio',
            audio: base64Audio,
          });
        },
        onError: (err) => {
          console.error('[LiveSession] Mic error:', err);
          this.callbacks.onError('Microphone access denied or audio hardware error.');
          this.disconnect();
        },
        onVolumeChange: (vol) => {
          this.callbacks.onInputVolume(vol);

          // Robust confirmation logic for real user speech interruption
          // Do NOT interrupt on small noises, keyboard clicks, breathing, or Hinata's speaker leakage
          if (this.state === 'speaking') {
            // Dynamic speech threshold: baseline 0.38 and at least 1.35x current speaker volume
            const dynamicSpeechThreshold = Math.max(0.38, this.currentOutputVolume * 1.35);

            if (vol > dynamicSpeechThreshold) {
              this.consecutiveSpeechFrames++;
              // Require at least 5 consecutive sustained frames (~350ms of real user speech)
              if (this.consecutiveSpeechFrames >= 5) {
                console.log('[LiveSession] Confirmed genuine user speech interruption');
                this.consecutiveSpeechFrames = 0;
                this.interrupt();
              }
            } else {
              this.consecutiveSpeechFrames = Math.max(0, this.consecutiveSpeechFrames - 1);
            }
          } else {
            this.consecutiveSpeechFrames = 0;
          }
        },
      });

      await this.streamer.start();

      // 3. Establish WebSocket connection to backend Live API proxy
      const memoryManager = MemoryManager.getInstance();
      const baseMemoryContext = memoryManager.getMemoryContextForLiveSession();
      const visualContext = VisualDesignManager.getInstance().getVisualContextForVoice();
      const combinedContext = [baseMemoryContext, visualContext].filter(Boolean).join('\n\n');

      // Auto-register device with online backend in the background
      backendConfig.registerDevice().catch(() => {});

      const wsBase = backendConfig.getWsBackendUrl();
      const userId = backendConfig.getUserId();
      const deviceId = backendConfig.getDeviceId();
      const sessionId = backendConfig.getSessionId();
      const activeConv = backendConfig.getActiveConversationId();

      const params = new URLSearchParams({
        voice: voiceName,
        userId,
        deviceId,
        sessionId,
      });
      if (activeConv) {
        params.append('conversationId', activeConv);
      }

      const wsUrl = `${wsBase}/api/live?${params.toString()}`;

      this.ws = new WebSocket(wsUrl);

      this.ws.onopen = () => {
        this.pingTimestamp = Date.now();
        // Send initial handshake configuration over the open socket
        this.sendClientMessage({
          type: 'init',
          voice: voiceName,
          memoryContext: combinedContext,
          userId,
          deviceId,
          sessionId,
          conversationId: activeConv || undefined,
        });
      };

      this.ws.onmessage = async (event) => {
        try {
          const msg: ServerMessage = JSON.parse(event.data);
          await this.handleServerMessage(msg);
        } catch (e) {
          console.error('[LiveSession] Failed to parse message:', e);
        }
      };

      this.ws.onerror = (e) => {
        console.error('[LiveSession] WebSocket error:', e);
        if (this.state !== 'speaking' && this.state !== 'listening' && this.state !== 'processing') {
          this.callbacks.onError('Connection unavailable.');
        }
      };

      this.ws.onclose = (e: CloseEvent) => {
        if (!this.isIntentionalClose) {
          console.log(`[LiveSession] WebSocket closed unexpectedly (code: ${e.code}, reason: "${e.reason}")`);
        }
        this.cleanup();
        this.setState('disconnected');
      };
    } catch (err: any) {
      console.error('[LiveSession] Connect failed:', err);
      this.cleanup();
      this.setState('error');
      this.callbacks.onError('Connection unavailable.');
    }
  }

  public disconnect(): void {
    this.isIntentionalClose = true;
    try {
      MemoryManager.getInstance().createConversationSummary();
    } catch (e) {
      console.warn('[LiveSession] Could not save conversation summary on disconnect:', e);
    }
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.sendClientMessage({ type: 'close' });
      this.ws.close();
    }
    this.cleanup();
    this.setState('disconnected');
  }

  public toggleMute(): boolean {
    if (this.streamer) {
      const newMuted = !this.streamer.getMuted();
      this.streamer.setMute(newMuted);
      return newMuted;
    }
    return false;
  }

  public isMuted(): boolean {
    return this.streamer ? this.streamer.getMuted() : false;
  }

  /**
   * Stops active playback and transitions back to listening.
   * Only called on verified user interruption or explicit user stop.
   */
  public interrupt(): void {
    this.consecutiveSpeechFrames = 0;
    this.player.interrupt();
    if (this.state === 'speaking') {
      this.setState('listening');
    }
  }

  public setVolume(vol: number): void {
    this.player.setVolume(vol);
  }

  private async handleServerMessage(msg: ServerMessage): Promise<void> {
    switch (msg.type) {
      case 'connected': {
        this.latencyMs = Math.max(15, Date.now() - this.pingTimestamp);
        this.callbacks.onLatencyUpdate(this.latencyMs);
        this.setState('listening');
        break;
      }

      case 'audio': {
        if (msg.audio) {
          if (this.state !== 'speaking' && this.state !== 'disconnected' && this.state !== 'connecting') {
            this.setState('speaking');
          }
          this.player.playChunk(msg.audio);
        }
        break;
      }

      case 'interrupted': {
        // Authoritative server-side speech interruption from Gemini Live API
        console.log('[LiveSession] Gemini Live server signaled interruption');
        this.consecutiveSpeechFrames = 0;
        this.player.interrupt();
        if (this.state === 'speaking') {
          this.setState('listening');
        }
        break;
      }

      case 'turn_complete': {
        // Model response generation has completed for this turn.
        // Hand off to AudioPlayer so all remaining queued audio plays out continuously.
        this.player.markTurnComplete();
        break;
      }

      case 'tool_call': {
        if (msg.calls && Array.isArray(msg.calls)) {
          for (const call of msg.calls) {
            this.callbacks.onToolCall({
              id: call.id,
              name: call.name,
              args: call.args || {},
              status: 'invoked',
              timestamp: Date.now(),
            });

            // Execute immediately and return response to Gemini Live
            const execution = await this.toolManager.executeTool(call.id, call.name, call.args || {});

            this.sendClientMessage({
              type: 'tool_response',
              id: call.id,
              name: call.name,
              response: execution.output,
            });
          }
        }
        break;
      }

      case 'tool_result': {
        this.callbacks.onToolCall({
          id: msg.id,
          name: msg.name,
          args: {},
          status: 'executed',
          result: msg.result,
          timestamp: Date.now(),
        });
        break;
      }

      case 'emotion_update': {
        this.mood = msg.emotion;
        const intensity = msg.intensity !== undefined ? msg.intensity : 2;
        EmotionManager.getInstance().updateEmotionalState(msg.emotion, intensity, msg.reason);
        if (this.callbacks.onEmotionChange) {
          this.callbacks.onEmotionChange(msg.emotion, intensity, msg.reason);
        }
        this.callbacks.onMoodChange(this.mood);
        break;
      }

      case 'mood_update': {
        this.mood = msg.mood;
        EmotionManager.getInstance().updateEmotionalState(msg.mood, 2);
        if (this.callbacks.onEmotionChange) {
          this.callbacks.onEmotionChange(msg.mood, 2);
        }
        this.callbacks.onMoodChange(this.mood);
        break;
      }

      case 'transcript': {
        if (msg.text) {
          const memoryManager = MemoryManager.getInstance();
          memoryManager.shortTerm.recordTurn(msg.role, msg.text, this.mood);
          const emotionManager = EmotionManager.getInstance();

          if (msg.role === 'user') {
            memoryManager.processUserInput(msg.text);
            const detected = emotionManager.detectEmotion(msg.text);
            if (detected) {
              emotionManager.transitionEmotion(detected.emotion, detected.intensity, detected.reason);
              this.mood = detected.emotion;
              if (this.callbacks.onEmotionChange) {
                this.callbacks.onEmotionChange(detected.emotion, detected.intensity, detected.reason);
              }
              this.callbacks.onMoodChange(detected.emotion);
            }
          }
          emotionManager.onConversationTurn();
          this.callbacks.onTranscript?.(msg.role, msg.text);
        }
        break;
      }

      case 'error': {
        console.error('[LiveSession] Server reported error:', msg.message);
        if (
          msg.message?.includes('API_KEY_INVALID') ||
          msg.message?.includes('auth') ||
          msg.message?.includes('expired') ||
          msg.message?.includes('revoked') ||
          msg.message?.includes('authentication failed')
        ) {
          ClientAIProvider.getInstance().reportAuthFailure('AI service authentication failed. Please update the API key.');
        }
        this.callbacks.onError(msg.message);
        break;
      }

      case 'closed': {
        this.disconnect();
        break;
      }
    }
  }

  private sendClientMessage(msg: ClientMessage): void {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify(msg));
    }
  }

  private setState(newState: LiveSessionState): void {
    if (this.state !== newState) {
      this.state = newState;
      this.callbacks.onStateChange(newState);
    }
  }

  public sendVideoFrame(base64: string, mimeType: string = 'image/jpeg'): void {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.sendClientMessage({
        type: 'realtime_video',
        video: base64,
        mimeType,
      });
    }
  }

  public pauseStreaming(): void {
    if (this.streamer) {
      this.streamer.setMute(true);
    }
  }

  public resumeStreaming(): void {
    if (this.streamer) {
      this.streamer.setMute(false);
    }
  }

  public setVoice(voice: string): void {
    this.currentVoice = voice;
  }

  private cleanup(): void {
    this.consecutiveSpeechFrames = 0;
    if (this.streamer) {
      this.streamer.stop();
      this.streamer = null;
    }
    if (this.player) {
      this.player.interrupt();
    }
    if (this.ws) {
      this.ws.onopen = null;
      this.ws.onmessage = null;
      this.ws.onerror = null;
      this.ws.onclose = null;
      this.ws = null;
    }
  }
}
