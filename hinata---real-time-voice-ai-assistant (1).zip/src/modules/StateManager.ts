/**
 * StateManager - Unified Reactive State Coordinator for Hinata AI.
 *
 * Manages:
 * - LiveSession connection state, audio volume, and latency
 * - Emotional states, mood, and intensity
 * - Active tool execution badges
 * - Cognitive state (Thinking, Executing, Completed, Failed)
 * - Safe Android Device Action alerts & confirmations
 * - Owner profile information
 */

import { LiveSessionState, EmotionalState, EmotionalIntensity, AssistantMood, ToolCallItem, MascotState, SelectedImage } from '../types';
import { HinataBrain, CognitiveState } from './HinataBrain';
import { OwnerManager } from './OwnerManager';
import { VisualDesignManager } from './visualDesign/VisualDesignManager';
import { DeviceActionManager } from './device/DeviceActionManager';
import { TaskPlanner } from './task/TaskPlanner';
import { DeviceActionResult, TaskPlan } from './device/types';

export interface AppState {
  sessionState: LiveSessionState;
  mascotState: MascotState;
  mood: AssistantMood;
  emotionalIntensity: EmotionalIntensity;
  isMuted: boolean;
  latencyMs: number;
  inputVolume: number;
  outputVolume: number;
  activeTools: ToolCallItem[];
  errorMessage: string | null;
  selectedVoice: string;
  speechGain: number;

  // Real-Time Vision & Screen Sharing
  selectedImage: SelectedImage | null;
  isScreenSharing: boolean;
  isVisionAnalyzing: boolean;

  // Smart Conversational & Device Action additions
  cognitiveState: CognitiveState;
  cognitiveDetails?: string;
  ownerName: string;
  activeThemeName: string;
  recentDeviceAction: DeviceActionResult | null;
  activeTaskPlan: TaskPlan | null;
  pendingSensitiveAction: { id: string; target: string; action: string; prompt?: string } | null;
}

export type StateListener = (state: AppState) => void;

export class StateManager {
  private static instance: StateManager | null = null;
  private listeners: Set<StateListener> = new Set();

  private state: AppState = {
    sessionState: 'disconnected',
    mascotState: 'IDLE',
    mood: 'playful',
    emotionalIntensity: 2,
    isMuted: false,
    latencyMs: 24,
    inputVolume: 0,
    outputVolume: 0,
    activeTools: [],
    errorMessage: null,
    selectedVoice: 'Kore',
    speechGain: 1.0,
    selectedImage: null,
    isScreenSharing: false,
    isVisionAnalyzing: false,
    cognitiveState: 'idle',
    ownerName: 'Aman',
    activeThemeName: 'Cyber Hologram',
    recentDeviceAction: null,
    activeTaskPlan: null,
    pendingSensitiveAction: null,
  };

  constructor(defaultVoice: string = 'Kore') {
    this.state.selectedVoice = defaultVoice;
    StateManager.instance = this;
    this.initSupervisors();
  }

  public static getInstance(): StateManager {
    if (!StateManager.instance) {
      StateManager.instance = new StateManager('Kore');
    }
    return StateManager.instance;
  }

  private initSupervisors(): void {
    try {
      // 1. Brain cognitive state
      const brain = HinataBrain.getInstance();
      brain.onStateChange((cogState, details) => {
        this.state.cognitiveState = cogState;
        this.state.cognitiveDetails = details;
        this.notify();
      });

      // 2. Owner Profile
      const owner = OwnerManager.getInstance();
      this.state.ownerName = owner.getOwnerName();
      owner.onProfileChange((profile) => {
        this.state.ownerName = profile.name || 'Aman';
        this.notify();
      });

      // 3. Visual Design
      const vision = VisualDesignManager.getInstance();
      this.state.activeThemeName = vision.getActiveTheme().name;
      vision.subscribe(() => {
        this.state.activeThemeName = vision.getActiveTheme().name;
        this.notify();
      });

      // 4. Device Action Supervisor
      const dam = DeviceActionManager.getInstance();
      dam.onActionExecuted((result) => {
        this.state.recentDeviceAction = result;
        if (result.confirmationRequired && result.pendingActionId) {
          this.state.pendingSensitiveAction = {
            id: result.pendingActionId,
            target: result.target || '',
            action: result.action,
            prompt: result.message,
          };
        } else {
          this.state.pendingSensitiveAction = null;
        }
        this.notify();
      });

      // 5. Task Planner
      const planner = TaskPlanner.getInstance();
      planner.subscribe((plan) => {
        this.state.activeTaskPlan = plan;
        this.notify();
      });
    } catch (e) {
      console.warn('[StateManager] Init supervisor warning:', e);
    }
  }

  public getState(): AppState {
    return { ...this.state };
  }

  public subscribe(listener: StateListener): () => void {
    this.listeners.add(listener);
    listener({ ...this.state });
    return () => {
      this.listeners.delete(listener);
    };
  }

  private notify(): void {
    const copy = { ...this.state };
    for (const listener of this.listeners) {
      try {
        listener(copy);
      } catch (err) {
        console.error('[StateManager] Listener error:', err);
      }
    }
  }

  public setSessionState(sessionState: LiveSessionState): void {
    this.state.sessionState = sessionState;
    this.updateMascotState();
    this.notify();
  }

  public setEmotionalState(mood: EmotionalState, emotionalIntensity: EmotionalIntensity = 2): void {
    this.state.mood = mood;
    this.state.emotionalIntensity = emotionalIntensity;
    this.notify();
  }

  public setMood(mood: AssistantMood): void {
    this.state.mood = mood;
    this.notify();
  }

  public addToolCall(item: ToolCallItem): void {
    this.state.activeTools = [item, ...this.state.activeTools.filter((t) => t.id !== item.id)].slice(0, 5);
    this.notify();
  }

  public removeToolCall(id: string): void {
    this.state.activeTools = this.state.activeTools.filter((t) => t.id !== id);
    this.notify();
  }

  public setErrorMessage(errorMessage: string | null): void {
    this.state.errorMessage = errorMessage;
    this.notify();
  }

  public setLatency(latencyMs: number): void {
    this.state.latencyMs = latencyMs;
    this.notify();
  }

  public setInputVolume(inputVolume: number): void {
    this.state.inputVolume = inputVolume;
    this.notify();
  }

  public setOutputVolume(outputVolume: number): void {
    this.state.outputVolume = outputVolume;
    this.notify();
  }

  public setMuted(isMuted: boolean): void {
    this.state.isMuted = isMuted;
    this.notify();
  }

  public setSelectedVoice(selectedVoice: string): void {
    this.state.selectedVoice = selectedVoice;
    this.notify();
  }

  public setSpeechGain(speechGain: number): void {
    this.state.speechGain = speechGain;
    this.notify();
  }

  public setSelectedImage(img: SelectedImage | null): void {
    this.state.selectedImage = img;
    this.updateMascotState();
    this.notify();
  }

  public setScreenSharing(isActive: boolean): void {
    this.state.isScreenSharing = isActive;
    this.updateMascotState();
    this.notify();
  }

  public setVisionAnalyzing(isAnalyzing: boolean, isScreen: boolean = false): void {
    this.state.isVisionAnalyzing = isAnalyzing;
    if (isAnalyzing) {
      this.state.mascotState = isScreen ? 'SCREEN_ANALYZING' : 'VISION_ANALYZING';
    } else {
      this.updateMascotState();
    }
    this.notify();
  }

  public setMascotState(mascotState: MascotState): void {
    this.state.mascotState = mascotState;
    this.notify();
  }

  private updateMascotState(): void {
    if (this.state.sessionState === 'error') {
      this.state.mascotState = 'ERROR';
    } else if (this.state.isVisionAnalyzing) {
      this.state.mascotState = this.state.isScreenSharing ? 'SCREEN_ANALYZING' : 'VISION_ANALYZING';
    } else if (this.state.isScreenSharing) {
      this.state.mascotState = 'SCREEN_SHARING';
    } else if (this.state.sessionState === 'speaking') {
      this.state.mascotState = 'SPEAKING';
    } else if (this.state.sessionState === 'processing') {
      this.state.mascotState = 'THINKING';
    } else if (this.state.sessionState === 'listening') {
      this.state.mascotState = 'LISTENING';
    } else {
      this.state.mascotState = 'IDLE';
    }
  }

  public dismissPendingSensitiveAction(): void {
    this.state.pendingSensitiveAction = null;
    this.notify();
  }
}
