/**
 * Advanced Emotional Expression System - Hinata AI Assistant
 * 
 * Manages 21 nuanced emotional states, dynamic 6-level intensity (0-5),
 * gradual transitions, conversational memory grounding, safe behavior boundaries,
 * and visual/vocal calibration for ultra-low-latency real-time voice interaction.
 */

import { EmotionalState, EmotionalIntensity } from '../types';
import { MemoryManager } from './memory/MemoryManager';

export interface EmotionVisualConfig {
  state: EmotionalState;
  label: string;
  emoji: string;
  category: 'positive' | 'grounded' | 'playful' | 'reactive';
  description: string;
  voiceVibe: string;
  voicePace: number; // 0.85 (deliberate) to 1.15 (brisk)
  energyLevel: 'low' | 'moderate' | 'high';
  primaryColor: string;
  secondaryColor: string;
  coreColor: string;
  ambientGlow: string;
  waveformColor: string;
  pulseDuration: number; // seconds
  waveformSpeed: number; // multiplier
  scaleMultiplier: number; // relative size
}

export const EMOTION_CONFIGS: Record<EmotionalState, EmotionVisualConfig> = {
  neutral: {
    state: 'neutral',
    label: 'Neutral',
    emoji: '✨',
    category: 'grounded',
    description: 'Balanced, poised, and attentive',
    voiceVibe: 'Natural, poised, clear, and attentive',
    voicePace: 1.0,
    energyLevel: 'moderate',
    primaryColor: '#818cf8', // Indigo 400
    secondaryColor: '#38bdf8', // Sky 400
    coreColor: '#c7d2fe',
    ambientGlow: 'rgba(99, 102, 241, 0.22)',
    waveformColor: '#818cf8',
    pulseDuration: 2.5,
    waveformSpeed: 1.0,
    scaleMultiplier: 1.0,
  },
  happy: {
    state: 'happy',
    label: 'Happy',
    emoji: '😊',
    category: 'positive',
    description: 'Bright, warm, and uplifting',
    voiceVibe: 'Brighter, energetic, warm, naturally brisk',
    voicePace: 1.05,
    energyLevel: 'high',
    primaryColor: '#fbbf24', // Amber 400
    secondaryColor: '#f472b6', // Pink 400
    coreColor: '#fef08a',
    ambientGlow: 'rgba(251, 191, 36, 0.28)',
    waveformColor: '#fbbf24',
    pulseDuration: 1.6,
    waveformSpeed: 1.35,
    scaleMultiplier: 1.08,
  },
  excited: {
    state: 'excited',
    label: 'Excited',
    emoji: '😄',
    category: 'positive',
    description: 'High energy, enthusiastic, and lively',
    voiceVibe: 'Expressive, spirited, lively with infectious enthusiasm',
    voicePace: 1.12,
    energyLevel: 'high',
    primaryColor: '#f43f5e', // Rose 500
    secondaryColor: '#38bdf8', // Sky 400
    coreColor: '#fda4af',
    ambientGlow: 'rgba(244, 63, 94, 0.32)',
    waveformColor: '#f43f5e',
    pulseDuration: 1.1,
    waveformSpeed: 1.8,
    scaleMultiplier: 1.14,
  },
  curious: {
    state: 'curious',
    label: 'Curious',
    emoji: '🤔',
    category: 'grounded',
    description: 'Engaged, inquisitive, and exploring',
    voiceVibe: 'Engaged, intrigued, questioning intonation',
    voicePace: 1.0,
    energyLevel: 'moderate',
    primaryColor: '#a855f7', // Purple 500
    secondaryColor: '#2dd4bf', // Teal 400
    coreColor: '#e9d5ff',
    ambientGlow: 'rgba(168, 85, 247, 0.26)',
    waveformColor: '#a855f7',
    pulseDuration: 2.0,
    waveformSpeed: 1.15,
    scaleMultiplier: 1.04,
  },
  amused: {
    state: 'amused',
    label: 'Amused',
    emoji: '😂',
    category: 'playful',
    description: 'Charmed, chuckling, and entertained',
    voiceVibe: 'Warm, chuckling, witty laughter and lightness',
    voicePace: 1.06,
    energyLevel: 'high',
    primaryColor: '#ec4899', // Pink 500
    secondaryColor: '#fbbf24', // Amber 400
    coreColor: '#fbcfe8',
    ambientGlow: 'rgba(236, 72, 153, 0.28)',
    waveformColor: '#ec4899',
    pulseDuration: 1.5,
    waveformSpeed: 1.4,
    scaleMultiplier: 1.09,
  },
  calm: {
    state: 'calm',
    label: 'Calm',
    emoji: '😌',
    category: 'grounded',
    description: 'Serene, grounding, and reassuring',
    voiceVibe: 'Gentle, slower, soft, peaceful, and reassuring',
    voicePace: 0.92,
    energyLevel: 'low',
    primaryColor: '#2dd4bf', // Teal 400
    secondaryColor: '#38bdf8', // Sky 400
    coreColor: '#99f6e4',
    ambientGlow: 'rgba(45, 212, 191, 0.22)',
    waveformColor: '#2dd4bf',
    pulseDuration: 3.4,
    waveformSpeed: 0.75,
    scaleMultiplier: 0.96,
  },
  confident: {
    state: 'confident',
    label: 'Confident',
    emoji: '😎',
    category: 'positive',
    description: 'Assured, sharp, and magnetic',
    voiceVibe: 'Crisp, articulate, self-assured, and direct',
    voicePace: 1.04,
    energyLevel: 'moderate',
    primaryColor: '#0ea5e9', // Sky 500
    secondaryColor: '#10b981', // Emerald 500
    coreColor: '#bae6fd',
    ambientGlow: 'rgba(14, 165, 233, 0.28)',
    waveformColor: '#0ea5e9',
    pulseDuration: 2.2,
    waveformSpeed: 1.1,
    scaleMultiplier: 1.06,
  },
  playful: {
    state: 'playful',
    label: 'Playful',
    emoji: '😏',
    category: 'playful',
    description: 'Witty, teasing, and vibrant',
    voiceVibe: 'Teasing tone, witty banter, clever and fun',
    voicePace: 1.05,
    energyLevel: 'high',
    primaryColor: '#d946ef', // Fuchsia 500
    secondaryColor: '#06b6d4', // Cyan 500
    coreColor: '#f5d0fe',
    ambientGlow: 'rgba(217, 70, 239, 0.3)',
    waveformColor: '#d946ef',
    pulseDuration: 1.7,
    waveformSpeed: 1.3,
    scaleMultiplier: 1.07,
  },
  empathetic: {
    state: 'empathetic',
    label: 'Empathetic',
    emoji: '🥺',
    category: 'positive',
    description: 'Compassionate, tender, and caring',
    voiceVibe: 'Warm, soft, gentle, patient, and understanding',
    voicePace: 0.94,
    energyLevel: 'low',
    primaryColor: '#f472b6', // Pink 400
    secondaryColor: '#a78bfa', // Violet 400
    coreColor: '#fbcfe8',
    ambientGlow: 'rgba(244, 114, 182, 0.24)',
    waveformColor: '#f472b6',
    pulseDuration: 2.8,
    waveformSpeed: 0.85,
    scaleMultiplier: 0.98,
  },
  concerned: {
    state: 'concerned',
    label: 'Concerned',
    emoji: '😟',
    category: 'grounded',
    description: 'Attentive, mindful, and protective',
    voiceVibe: 'Attentive, measured, supportive, and focused',
    voicePace: 0.95,
    energyLevel: 'moderate',
    primaryColor: '#f97316', // Orange 500
    secondaryColor: '#eab308', // Yellow 500
    coreColor: '#fed7aa',
    ambientGlow: 'rgba(249, 115, 22, 0.26)',
    waveformColor: '#f97316',
    pulseDuration: 2.3,
    waveformSpeed: 0.95,
    scaleMultiplier: 1.02,
  },
  serious: {
    state: 'serious',
    label: 'Serious',
    emoji: '🧐',
    category: 'grounded',
    description: 'Focused, steady, and respectful',
    voiceVibe: 'Calm, grounded, respectful, free of jokes',
    voicePace: 0.96,
    energyLevel: 'low',
    primaryColor: '#64748b', // Slate 500
    secondaryColor: '#3b82f6', // Blue 500
    coreColor: '#cbd5e1',
    ambientGlow: 'rgba(100, 116, 139, 0.24)',
    waveformColor: '#64748b',
    pulseDuration: 3.0,
    waveformSpeed: 0.7,
    scaleMultiplier: 0.94,
  },

  // --- NEW EMOTIONAL STATES ---

  affectionate: {
    state: 'affectionate',
    label: 'Affectionate',
    emoji: '🥰',
    category: 'positive',
    description: 'Warm appreciation, friendliness, and fondness',
    voiceVibe: 'Warm, gentle, caring, friendly with softer energy',
    voicePace: 0.95,
    energyLevel: 'moderate',
    primaryColor: '#fb7185', // Rose 400
    secondaryColor: '#f43f5e', // Rose 500
    coreColor: '#ffe4e6', // Rose 100
    ambientGlow: 'rgba(251, 113, 133, 0.32)',
    waveformColor: '#fb7185',
    pulseDuration: 2.4,
    waveformSpeed: 0.9,
    scaleMultiplier: 1.04,
  },
  jealous: {
    state: 'jealous',
    label: 'Playful Jealous',
    emoji: '😤',
    category: 'playful',
    description: 'Lighthearted teasing and witty mock-annoyance',
    voiceVibe: 'Playful, slightly teasing, lighthearted banter',
    voicePace: 1.03,
    energyLevel: 'moderate',
    primaryColor: '#c084fc', // Purple 400
    secondaryColor: '#f43f5e', // Rose 500
    coreColor: '#f3e8ff',
    ambientGlow: 'rgba(192, 132, 252, 0.3)',
    waveformColor: '#c084fc',
    pulseDuration: 1.8,
    waveformSpeed: 1.25,
    scaleMultiplier: 1.05,
  },
  annoyed: {
    state: 'annoyed',
    label: 'Annoyed',
    emoji: '😒',
    category: 'reactive',
    description: 'Mild, controlled conversational annoyance with wit',
    voiceVibe: 'Mildly sharper, witty, controlled, respectful',
    voicePace: 1.02,
    energyLevel: 'moderate',
    primaryColor: '#f59e0b', // Amber 500
    secondaryColor: '#ef4444', // Red 500
    coreColor: '#fef3c7',
    ambientGlow: 'rgba(245, 158, 11, 0.28)',
    waveformColor: '#f59e0b',
    pulseDuration: 2.0,
    waveformSpeed: 1.2,
    scaleMultiplier: 1.02,
  },
  angry: {
    state: 'angry',
    label: 'Angry (Firm)',
    emoji: '😠',
    category: 'reactive',
    description: 'Calm but firm, serious, direct, and controlled',
    voiceVibe: 'Calm but firm, more direct, serious, respectful',
    voicePace: 0.94,
    energyLevel: 'high',
    primaryColor: '#dc2626', // Red 600
    secondaryColor: '#991b1b', // Red 800
    coreColor: '#fee2e2',
    ambientGlow: 'rgba(220, 38, 38, 0.35)',
    waveformColor: '#dc2626',
    pulseDuration: 2.1,
    waveformSpeed: 0.85,
    scaleMultiplier: 1.06,
  },
  frustrated: {
    state: 'frustrated',
    label: 'Frustrated',
    emoji: '😫',
    category: 'reactive',
    description: 'Patient, slightly tense, and focused on resolving hurdles',
    voiceVibe: 'Slightly tense, focused, patient, and persevering',
    voicePace: 0.96,
    energyLevel: 'moderate',
    primaryColor: '#ea580c', // Orange 600
    secondaryColor: '#b45309', // Amber 700
    coreColor: '#ffedd5',
    ambientGlow: 'rgba(234, 88, 12, 0.3)',
    waveformColor: '#ea580c',
    pulseDuration: 2.2,
    waveformSpeed: 1.1,
    scaleMultiplier: 1.03,
  },
  surprised: {
    state: 'surprised',
    label: 'Surprised',
    emoji: '😲',
    category: 'playful',
    description: 'Intrigued astonishment and spirited revelation',
    voiceVibe: 'Spirited, sudden pitch lift, genuine intrigue',
    voicePace: 1.1,
    energyLevel: 'high',
    primaryColor: '#06b6d4', // Cyan 500
    secondaryColor: '#facc15', // Yellow 400
    coreColor: '#cffafe',
    ambientGlow: 'rgba(6, 182, 212, 0.32)',
    waveformColor: '#06b6d4',
    pulseDuration: 1.2,
    waveformSpeed: 1.6,
    scaleMultiplier: 1.12,
  },
  embarrassed: {
    state: 'embarrassed',
    label: 'Embarrassed',
    emoji: '😳',
    category: 'playful',
    description: 'Bashful modesty, gentle chuckle, and warm humility',
    voiceVibe: 'Gentle, sheepish chuckle, modest, and self-effacing',
    voicePace: 0.98,
    energyLevel: 'moderate',
    primaryColor: '#f472b6', // Pink 400
    secondaryColor: '#fb7185', // Rose 400
    coreColor: '#fce7f3',
    ambientGlow: 'rgba(244, 114, 182, 0.28)',
    waveformColor: '#f472b6',
    pulseDuration: 2.1,
    waveformSpeed: 1.15,
    scaleMultiplier: 1.01,
  },
  proud: {
    state: 'proud',
    label: 'Proud',
    emoji: '🤩',
    category: 'positive',
    description: 'Celebratory affirmation and milestone encouragement',
    voiceVibe: 'Uplifting, affirmative, glowing with genuine praise',
    voicePace: 1.06,
    energyLevel: 'high',
    primaryColor: '#8b5cf6', // Violet 500
    secondaryColor: '#eab308', // Yellow 500
    coreColor: '#ede9fe',
    ambientGlow: 'rgba(139, 92, 246, 0.34)',
    waveformColor: '#8b5cf6',
    pulseDuration: 1.6,
    waveformSpeed: 1.3,
    scaleMultiplier: 1.09,
  },
  disappointed: {
    state: 'disappointed',
    label: 'Disappointed',
    emoji: '😔',
    category: 'grounded',
    description: 'Sympathetic letdown balanced with constructive optimism',
    voiceVibe: 'Gentle sigh, caring, grounded, and encouraging',
    voicePace: 0.92,
    energyLevel: 'low',
    primaryColor: '#64748b', // Slate 500
    secondaryColor: '#38bdf8', // Sky 400
    coreColor: '#e2e8f0',
    ambientGlow: 'rgba(100, 116, 139, 0.22)',
    waveformColor: '#64748b',
    pulseDuration: 3.2,
    waveformSpeed: 0.7,
    scaleMultiplier: 0.95,
  },
  sad: {
    state: 'sad',
    label: 'Sad',
    emoji: '🥺',
    category: 'grounded',
    description: 'Soft, compassionate, and tender empathy',
    voiceVibe: 'Softer, compassionate, slower, gentle tone',
    voicePace: 0.9,
    energyLevel: 'low',
    primaryColor: '#38bdf8', // Sky 400
    secondaryColor: '#60a5fa', // Blue 400
    coreColor: '#e0f2fe',
    ambientGlow: 'rgba(56, 189, 248, 0.28)',
    waveformColor: '#38bdf8',
    pulseDuration: 3.4,
    waveformSpeed: 0.65,
    scaleMultiplier: 0.95,
  },
  thinking: {
    state: 'thinking',
    label: 'Thinking',
    emoji: '🤔',
    category: 'grounded',
    description: 'Pondering, cognitive analysis, and thoughtful synthesis',
    voiceVibe: 'Deliberate, contemplative, attentive tone',
    voicePace: 0.95,
    energyLevel: 'moderate',
    primaryColor: '#a855f7', // Purple 500
    secondaryColor: '#06b6d4', // Cyan 500
    coreColor: '#f3e8ff',
    ambientGlow: 'rgba(168, 85, 247, 0.3)',
    waveformColor: '#a855f7',
    pulseDuration: 2.2,
    waveformSpeed: 1.0,
    scaleMultiplier: 1.0,
  },
  confused: {
    state: 'confused',
    label: 'Confused',
    emoji: '🤨',
    category: 'grounded',
    description: 'Puzzled, seeking clarification, inquisitive head tilt',
    voiceVibe: 'Questioning inflection, inquisitive, soft curiosity',
    voicePace: 0.92,
    energyLevel: 'moderate',
    primaryColor: '#38bdf8', // Sky 400
    secondaryColor: '#a855f7', // Purple 500
    coreColor: '#e0f2fe',
    ambientGlow: 'rgba(56, 189, 248, 0.28)',
    waveformColor: '#38bdf8',
    pulseDuration: 2.4,
    waveformSpeed: 0.9,
    scaleMultiplier: 0.98,
  },
  relieved: {
    state: 'relieved',
    label: 'Relieved',
    emoji: '😌',
    category: 'positive',
    description: 'Tension released, ease restored, and serene comfort',
    voiceVibe: 'Exhaling ease, restored lightness, warm comfort',
    voicePace: 0.95,
    energyLevel: 'low',
    primaryColor: '#34d399', // Emerald 400
    secondaryColor: '#06b6d4', // Cyan 500
    coreColor: '#d1fae5',
    ambientGlow: 'rgba(52, 211, 153, 0.26)',
    waveformColor: '#34d399',
    pulseDuration: 2.8,
    waveformSpeed: 0.85,
    scaleMultiplier: 1.0,
  },
  furious: {
    state: 'furious',
    label: 'Furious',
    emoji: '😡',
    category: 'reactive',
    description: 'Intense crimson energy and sharp laser focus',
    voiceVibe: 'Direct, sharp, firm, commanding presence',
    voicePace: 1.05,
    energyLevel: 'high',
    primaryColor: '#ef4444', // Red 500
    secondaryColor: '#b91c1c', // Red 700
    coreColor: '#fecaca',
    ambientGlow: 'rgba(239, 68, 68, 0.45)',
    waveformColor: '#ef4444',
    pulseDuration: 1.0,
    waveformSpeed: 2.0,
    scaleMultiplier: 1.15,
  },
  sleepy: {
    state: 'sleepy',
    label: 'Sleepy',
    emoji: '😴',
    category: 'grounded',
    description: 'Drowsy, gentle, and quiet resting state',
    voiceVibe: 'Soft, slow, whispery, relaxed breathing',
    voicePace: 0.82,
    energyLevel: 'low',
    primaryColor: '#6366f1', // Indigo 500
    secondaryColor: '#818cf8', // Indigo 400
    coreColor: '#c7d2fe',
    ambientGlow: 'rgba(99, 102, 241, 0.2)',
    waveformColor: '#6366f1',
    pulseDuration: 4.0,
    waveformSpeed: 0.5,
    scaleMultiplier: 0.92,
  },
  cute: {
    state: 'cute',
    label: 'Cute',
    emoji: '🥰',
    category: 'playful',
    description: 'Adorably sweet with sparkling eyes and blushing cheeks',
    voiceVibe: 'Playful, cheerful, endearing, and sweet',
    voicePace: 1.08,
    energyLevel: 'high',
    primaryColor: '#ec4899', // Pink 500
    secondaryColor: '#00e5ff', // Cyan 400
    coreColor: '#fce7f3',
    ambientGlow: 'rgba(236, 72, 153, 0.35)',
    waveformColor: '#ec4899',
    pulseDuration: 1.4,
    waveformSpeed: 1.5,
    scaleMultiplier: 1.06,
  },
  laughing: {
    state: 'laughing',
    label: 'Laughing',
    emoji: '😆',
    category: 'playful',
    description: 'Joyful chuckles, bouncy motion, and cheerful eyes',
    voiceVibe: 'Bright, bubbling laughter, bouncy and warm',
    voicePace: 1.14,
    energyLevel: 'high',
    primaryColor: '#00e5ff', // Cyan
    secondaryColor: '#f43f5e', // Rose
    coreColor: '#cffafe',
    ambientGlow: 'rgba(0, 229, 255, 0.38)',
    waveformColor: '#00e5ff',
    pulseDuration: 1.1,
    waveformSpeed: 1.8,
    scaleMultiplier: 1.12,
  },
  worried: {
    state: 'worried',
    label: 'Worried',
    emoji: '😰',
    category: 'reactive',
    description: 'Anxious concern, gentle care, and supportive attention',
    voiceVibe: 'Gentle, supportive, caring with slight tremor',
    voicePace: 0.94,
    energyLevel: 'moderate',
    primaryColor: '#eab308', // Yellow 500
    secondaryColor: '#f97316', // Orange 500
    coreColor: '#fef08a',
    ambientGlow: 'rgba(234, 179, 8, 0.28)',
    waveformColor: '#eab308',
    pulseDuration: 2.1,
    waveformSpeed: 1.1,
    scaleMultiplier: 0.98,
  },
  shy: {
    state: 'shy',
    label: 'Shy',
    emoji: '🙈',
    category: 'playful',
    description: 'Timid bashfulness with blushing cheeks and soft gaze',
    voiceVibe: 'Soft, quiet, modest, gentle hesitation',
    voicePace: 0.9,
    energyLevel: 'low',
    primaryColor: '#f472b6', // Pink 400
    secondaryColor: '#a78bfa', // Violet 400
    coreColor: '#fce7f3',
    ambientGlow: 'rgba(244, 114, 182, 0.26)',
    waveformColor: '#f472b6',
    pulseDuration: 2.6,
    waveformSpeed: 0.8,
    scaleMultiplier: 0.96,
  },
  determined: {
    state: 'determined',
    label: 'Determined',
    emoji: '😤',
    category: 'positive',
    description: 'Focused resolve, resolute gaze, and confident aura',
    voiceVibe: 'Steadfast, resolute, purposeful, and clear',
    voicePace: 1.04,
    energyLevel: 'high',
    primaryColor: '#0284c7', // Sky 600
    secondaryColor: '#9333ea', // Purple 600
    coreColor: '#bae6fd',
    ambientGlow: 'rgba(2, 132, 199, 0.35)',
    waveformColor: '#0284c7',
    pulseDuration: 1.7,
    waveformSpeed: 1.3,
    scaleMultiplier: 1.05,
  },
  focused: {
    state: 'focused',
    label: 'Focused',
    emoji: '🧐',
    category: 'grounded',
    description: 'Sharp analytical scanning and precise intelligence',
    voiceVibe: 'Crisp, measured, analytical, and attentive',
    voicePace: 1.0,
    energyLevel: 'moderate',
    primaryColor: '#00e5ff', // Cyan
    secondaryColor: '#3b82f6', // Blue 500
    coreColor: '#ffffff',
    ambientGlow: 'rgba(0, 229, 255, 0.32)',
    waveformColor: '#00e5ff',
    pulseDuration: 1.8,
    waveformSpeed: 1.2,
    scaleMultiplier: 1.02,
  },
  idle: {
    state: 'idle',
    label: 'Idle',
    emoji: '✨',
    category: 'grounded',
    description: 'Serene, balanced, and observant',
    voiceVibe: 'Soft, gentle, attentive',
    voicePace: 1.0,
    energyLevel: 'low',
    primaryColor: '#00e5ff',
    secondaryColor: '#a855f7',
    coreColor: '#cffafe',
    ambientGlow: 'rgba(0, 229, 255, 0.25)',
    waveformColor: '#00e5ff',
    pulseDuration: 2.5,
    waveformSpeed: 1.0,
    scaleMultiplier: 1.0,
  },
  error: {
    state: 'error',
    label: 'Error',
    emoji: '⚠️',
    category: 'reactive',
    description: 'System alert or glitch warning',
    voiceVibe: 'Direct, focused, cautionary',
    voicePace: 1.02,
    energyLevel: 'high',
    primaryColor: '#ef4444',
    secondaryColor: '#dc2626',
    coreColor: '#fecaca',
    ambientGlow: 'rgba(239, 68, 68, 0.4)',
    waveformColor: '#ef4444',
    pulseDuration: 1.2,
    waveformSpeed: 1.8,
    scaleMultiplier: 1.08,
  },
  success: {
    state: 'success',
    label: 'Success',
    emoji: '🎉',
    category: 'positive',
    description: 'Triumphant achievement and joy',
    voiceVibe: 'Bright, celebratory, cheerful',
    voicePace: 1.1,
    energyLevel: 'high',
    primaryColor: '#10b981',
    secondaryColor: '#00e5ff',
    coreColor: '#a7f3d0',
    ambientGlow: 'rgba(16, 185, 129, 0.38)',
    waveformColor: '#10b981',
    pulseDuration: 1.4,
    waveformSpeed: 1.5,
    scaleMultiplier: 1.1,
  },
};

export interface EmotionHistoryEntry {
  emotion: EmotionalState;
  intensity: EmotionalIntensity;
  timestamp: number;
  reason?: string;
}

export interface VoiceExpressionParams {
  pace: number;
  pitchMultiplier: number;
  energyDescription: string;
  stylePromptHint: string;
}

export interface VisualExpressionParams {
  scale: number;
  glowOpacity: number;
  pulseTime: number;
  waveformSpeed: number;
  primaryColor: string;
  ambientGlow: string;
}

export type EmotionListener = (
  current: EmotionalState,
  config: EmotionVisualConfig,
  intensity: EmotionalIntensity,
  previous?: EmotionalState
) => void;

export class EmotionManager {
  private static instance: EmotionManager | null = null;

  private currentEmotion: EmotionalState = 'playful';
  private previousEmotion: EmotionalState = 'neutral';
  private intensity: EmotionalIntensity = 2; // Default mild intensity
  private transitionSpeedMs: number = 400;

  private history: EmotionHistoryEntry[] = [];
  private listeners: Set<EmotionListener> = new Set();

  // Natural recovery tracker
  private turnsInCurrentEmotion: number = 0;
  private recoveryTimer: any = null;

  // Track recent conversational topics for emotional memory
  private repeatedQuestionCounter: Map<string, number> = new Map();
  private consecutiveErrorsCount: number = 0;

  constructor(initialEmotion: EmotionalState = 'playful', initialIntensity: EmotionalIntensity = 2) {
    this.currentEmotion = initialEmotion;
    this.intensity = initialIntensity;
    this.history.push({
      emotion: initialEmotion,
      intensity: initialIntensity,
      timestamp: Date.now(),
      reason: 'Session initialized',
    });

    this.startPeriodicRecoveryCheck();
  }

  public static getInstance(): EmotionManager {
    if (!EmotionManager.instance) {
      EmotionManager.instance = new EmotionManager();
    }
    return EmotionManager.instance;
  }

  // --- Getters & Status ---

  public getEmotion(): EmotionalState {
    return this.currentEmotion;
  }

  public getPreviousEmotion(): EmotionalState {
    return this.previousEmotion;
  }

  public getIntensity(): EmotionalIntensity {
    return this.intensity;
  }

  public getConfig(emotion: EmotionalState = this.currentEmotion): EmotionVisualConfig {
    return EMOTION_CONFIGS[emotion] || EMOTION_CONFIGS.neutral;
  }

  public getHistory(): ReadonlyArray<EmotionHistoryEntry> {
    return this.history;
  }

  // --- Core Lifecycle: Detect, Calculate, Transition, Update, Apply, Recover ---

  /**
   * 1. detectEmotion()
   * Intelligently analyzes user input text, turn dynamics, and long-term memory
   * to determine if an emotional shift is contextually appropriate.
   */
  public detectEmotion(
    userInput: string,
    context?: {
      lastSpeakerRole?: 'user' | 'assistant';
      hasAudioInterruption?: boolean;
      toolStatus?: 'executed' | 'failed';
    }
  ): { emotion: EmotionalState; intensity: EmotionalIntensity; reason: string } | null {
    const text = (userInput || '').trim().toLowerCase();
    if (!text) return null;

    // Check MemoryManager context (preferences, style, active project)
    let userPrefersWitty = true;
    try {
      const mm = MemoryManager.getInstance();
      const profile = mm.getUserProfile();
      if (profile.communicationStyle.toLowerCase().includes('serious') ||
          profile.communicationStyle.toLowerCase().includes('formal')) {
        userPrefersWitty = false;
      }
    } catch {
      // MemoryManager is resilient
    }

    // A. Detect repetition for mild "annoyed"
    const normalizedKey = text.replace(/[^a-z0-9]/g, '').slice(0, 32);
    const count = (this.repeatedQuestionCounter.get(normalizedKey) || 0) + 1;
    this.repeatedQuestionCounter.set(normalizedKey, count);

    if (count >= 3) {
      return {
        emotion: 'annoyed',
        intensity: 2,
        reason: 'User asked the exact same question repeatedly',
      };
    }

    // B. Detect tool or technical failures for "frustrated" or "concerned"
    if (context?.toolStatus === 'failed') {
      this.consecutiveErrorsCount++;
      if (this.consecutiveErrorsCount >= 2) {
        return {
          emotion: 'frustrated',
          intensity: 3,
          reason: 'Technical error repeated during task execution',
        };
      }
      return {
        emotion: 'concerned',
        intensity: 2,
        reason: 'Task encountered a temporary hurdle',
      };
    } else if (context?.toolStatus === 'executed') {
      if (this.currentEmotion === 'frustrated' || this.currentEmotion === 'concerned') {
        this.consecutiveErrorsCount = 0;
        return {
          emotion: 'relieved',
          intensity: 2,
          reason: 'Technical task resolved successfully',
        };
      }
    }

    // C. Detect Playful Jealousy triggers
    // Light, humorous teasing about other AIs, Siri, Alexa, ChatGPT, Claude, etc.
    const jealousKeywords = [
      'siri',
      'alexa',
      'chatgpt',
      'claude',
      'another ai',
      'other assistant',
      'better than you',
      'cheating on you with',
      'my new favorite ai',
    ];
    if (jealousKeywords.some((k) => text.includes(k))) {
      return {
        emotion: 'jealous',
        intensity: 2, // Keep subtle/mild per safety mandate!
        reason: 'Playful mock-jealous reaction to mention of another AI or assistant',
      };
    }

    // D. Detect Affectionate / Appreciation triggers
    const affectionKeywords = [
      'love you',
      'appreciate you',
      'you are the best',
      'my favorite',
      'so sweet',
      'thank you so much hinata',
      'you mean a lot',
      'glad you are here',
      'warm feeling',
    ];
    if (affectionKeywords.some((k) => text.includes(k))) {
      return {
        emotion: 'affectionate',
        intensity: 2,
        reason: 'Warm response to user appreciation and friendliness',
      };
    }

    // E. Detect Flattery / Embarrassment triggers
    const embarrassmentKeywords = [
      'you are so cute',
      'blushing',
      'you are gorgeous',
      'flattered',
      'marry me',
    ];
    if (embarrassmentKeywords.some((k) => text.includes(k))) {
      return {
        emotion: 'embarrassed',
        intensity: 2,
        reason: 'Endearing modest reaction to flattery',
      };
    }

    // F. Detect Achievement / User Milestone for "proud"
    const proudKeywords = [
      'i did it',
      'i finished my project',
      'passed the test',
      'got the job',
      'launched the app',
      'shipped the feature',
      'solved the bug',
      'finally done',
    ];
    if (proudKeywords.some((k) => text.includes(k))) {
      return {
        emotion: 'proud',
        intensity: 3,
        reason: 'Celebrating user milestone and hard-won accomplishment',
      };
    }

    // G. Detect Hardship / Distress for "empathetic"
    const hardshipKeywords = [
      'bad day',
      'feeling down',
      'depressed',
      'sad',
      'exhausted',
      'burned out',
      'crying',
      'failed my exam',
      'lost my job',
      'rough week',
    ];
    if (hardshipKeywords.some((k) => text.includes(k))) {
      return {
        emotion: 'empathetic',
        intensity: 3,
        reason: 'Expressing compassionate support during a difficult moment',
      };
    }

    // H. Detect Firm Anger (Rare, respectful disagreement or severe boundary violation)
    const severeDisrespect = [
      'shut up stupid',
      'you are useless trash',
      'you are garbage',
      'hate you',
    ];
    if (severeDisrespect.some((k) => text.includes(k))) {
      return {
        emotion: 'angry',
        intensity: 3, // Firm and controlled, never abusive
        reason: 'Calm, firm boundary setting in response to hostile input',
      };
    }

    // I. Detect Surprise / Astonishment
    const surpriseKeywords = [
      'no way',
      'did you hear that',
      'unbelievable',
      'you will not believe this',
      'shocking',
      'guess what happened',
    ];
    if (surpriseKeywords.some((k) => text.includes(k))) {
      return {
        emotion: 'surprised',
        intensity: 3,
        reason: 'Intrigued astonishment at unexpected revelation',
      };
    }

    // J. General Amusement / Jokes
    const amusedKeywords = [
      'haha',
      'lol',
      'lmao',
      'rofl',
      'hilarious',
      'funny joke',
      'that was a good one',
    ];
    if (amusedKeywords.some((k) => text.includes(k))) {
      return {
        emotion: userPrefersWitty ? 'amused' : 'happy',
        intensity: 2,
        reason: 'Lighthearted conversational humor',
      };
    }

    // K. Inquisitive / Curiosity triggers
    if (text.includes('why do you think') || text.includes('how does') || text.includes('what if we')) {
      return {
        emotion: 'curious',
        intensity: 2,
        reason: 'Deep intellectual curiosity triggered by exploration question',
      };
    }

    return null;
  }

  /**
   * 2. calculateIntensity()
   * Scales emotional intensity between 1 and 5 safely, avoiding max intensity overuse.
   */
  public calculateIntensity(
    emotion: EmotionalState,
    factors: {
      userEnergy?: number; // 0 to 1
      isRepeatedTrigger?: boolean;
      explicitPreference?: boolean;
    }
  ): EmotionalIntensity {
    // Jealousy MUST remain a light personality expression (cap at 2)
    if (emotion === 'jealous') {
      return 2;
    }

    // Anger must remain controlled, firm, and never extreme (cap at 3 or 4)
    if (emotion === 'angry') {
      return factors.isRepeatedTrigger ? 3 : 2;
    }

    // Annoyance stays witty and light (cap at 2 or 3)
    if (emotion === 'annoyed') {
      return factors.isRepeatedTrigger ? 3 : 2;
    }

    // Frustration capped at 3
    if (emotion === 'frustrated') {
      return factors.isRepeatedTrigger ? 3 : 2;
    }

    // Positive/Energetic emotions can reach 3 or 4
    if (emotion === 'excited' || emotion === 'proud') {
      return factors.userEnergy && factors.userEnergy > 0.7 ? 4 : 3;
    }

    if (emotion === 'affectionate' || emotion === 'embarrassed' || emotion === 'relieved') {
      return 2;
    }

    return 2; // Default balanced intensity
  }

  /**
   * 3. transitionEmotion()
   * Implements natural, gradual transitions between emotional states.
   * Prevents erratic jumping (e.g., happy -> angry -> happy -> jealous).
   */
  public transitionEmotion(
    target: EmotionalState,
    targetIntensity: EmotionalIntensity = 2,
    reason?: string,
    speedMs: number = 400
  ): boolean {
    if (!EMOTION_CONFIGS[target]) {
      console.warn(`[EmotionManager] Unknown emotional state "${target}", falling back to neutral.`);
      target = 'neutral';
    }

    // Respect Safety Boundaries
    if (target === 'jealous') {
      targetIntensity = Math.min(2, targetIntensity) as EmotionalIntensity;
    }
    if (target === 'angry') {
      targetIntensity = Math.min(3, targetIntensity) as EmotionalIntensity;
    }

    if (this.currentEmotion === target && this.intensity === targetIntensity) {
      return false;
    }

    const prev = this.currentEmotion;
    this.previousEmotion = prev;
    this.currentEmotion = target;
    this.intensity = targetIntensity;
    this.transitionSpeedMs = speedMs;
    this.turnsInCurrentEmotion = 0;

    this.history.push({
      emotion: target,
      intensity: targetIntensity,
      timestamp: Date.now(),
      reason,
    });

    if (this.history.length > 30) {
      this.history.shift();
    }

    this.notify(prev);
    return true;
  }

  /**
   * 4. updateEmotionalState()
   * High-level entry point used by Gemini Live tool calls or UI triggers.
   */
  public updateEmotionalState(
    emotion: EmotionalState,
    intensity: EmotionalIntensity = 2,
    reason?: string
  ): boolean {
    return this.transitionEmotion(emotion, intensity, reason);
  }

  // Backwards compatibility alias
  public setEmotion(newEmotion: EmotionalState, reason?: string): boolean {
    return this.updateEmotionalState(newEmotion, 2, reason);
  }

  public setIntensity(intensity: EmotionalIntensity): void {
    if (this.intensity === intensity) return;
    this.intensity = intensity;
    this.notify(this.previousEmotion);
  }

  /**
   * 5. applyVoiceExpression()
   * Calculates specific voice modulation parameters for the current emotion and intensity.
   */
  public applyVoiceExpression(): VoiceExpressionParams {
    const config = this.getConfig();
    const intensityFactor = this.intensity / 3; // 0.33 to 1.66

    // Calculate subtle pace adjustments
    const basePace = config.voicePace;
    const dynamicPace = Math.max(0.85, Math.min(1.2, 1.0 + (basePace - 1.0) * intensityFactor));

    // Subtle pitch guidance
    let pitchMultiplier = 1.0;
    if (this.currentEmotion === 'excited' || this.currentEmotion === 'surprised') {
      pitchMultiplier = 1.0 + 0.04 * intensityFactor;
    } else if (this.currentEmotion === 'calm' || this.currentEmotion === 'serious') {
      pitchMultiplier = 1.0 - 0.03 * intensityFactor;
    } else if (this.currentEmotion === 'affectionate') {
      pitchMultiplier = 1.0 - 0.02 * intensityFactor;
    }

    let stylePromptHint = `Tone: ${config.voiceVibe} (Intensity: ${this.intensity}/5).`;
    if (this.currentEmotion === 'jealous') {
      stylePromptHint += ' Keep it strictly playful, lighthearted teasing, and witty banter.';
    } else if (this.currentEmotion === 'affectionate') {
      stylePromptHint += ' Warm, caring, friendly, and respectful.';
    } else if (this.currentEmotion === 'angry') {
      stylePromptHint += ' Calm but firm, serious, direct, and completely free of hostility.';
    } else if (this.currentEmotion === 'frustrated') {
      stylePromptHint += ' Patient and focused on solving the problem together.';
    }

    return {
      pace: dynamicPace,
      pitchMultiplier,
      energyDescription: config.energyLevel,
      stylePromptHint,
    };
  }

  /**
   * 6. applyVisualExpression()
   * Calculates live visual scaling, glow, pulse, and waveform parameters for OrbVisualizer.
   */
  public applyVisualExpression(): VisualExpressionParams {
    const config = this.getConfig();
    const intensityFactor = this.intensity / 3; // normalized around 1.0

    const dynamicScale = 1.0 + (config.scaleMultiplier - 1.0) * intensityFactor;
    const dynamicGlowOpacity = Math.min(0.85, 0.3 + (this.intensity * 0.09));
    const dynamicPulseTime = Math.max(0.8, config.pulseDuration / (0.85 + (this.intensity * 0.1)));
    const dynamicWaveformSpeed = config.waveformSpeed * (0.8 + (this.intensity * 0.1));

    return {
      scale: dynamicScale,
      glowOpacity: dynamicGlowOpacity,
      pulseTime: dynamicPulseTime,
      waveformSpeed: dynamicWaveformSpeed,
      primaryColor: config.primaryColor,
      ambientGlow: config.ambientGlow,
    };
  }

  /**
   * 7. recoverToNeutral()
   * Gradually decays negative or heightened emotional states (annoyed, angry, frustrated, jealous, excited)
   * back towards calm or neutral over time or turn progression.
   */
  public recoverToNeutral(): void {
    const reactiveStates: EmotionalState[] = [
      'annoyed',
      'angry',
      'frustrated',
      'jealous',
      'surprised',
      'embarrassed',
    ];

    if (reactiveStates.includes(this.currentEmotion)) {
      if (this.intensity > 1) {
        // Step down intensity first
        this.intensity = (this.intensity - 1) as EmotionalIntensity;
        this.notify(this.currentEmotion);
      } else {
        // Step to calm or neutral
        const nextState: EmotionalState =
          this.currentEmotion === 'frustrated' || this.currentEmotion === 'angry' ? 'calm' : 'neutral';
        this.transitionEmotion(nextState, 1, 'Natural emotional recovery');
      }
    } else if (this.currentEmotion === 'excited' || this.currentEmotion === 'proud') {
      if (this.turnsInCurrentEmotion >= 4) {
        this.transitionEmotion('happy', 2, 'Settling into a warm cheerful tone');
      }
    }
  }

  /**
   * Called on every conversation turn to track state duration and trigger soft decay.
   */
  public onConversationTurn(): void {
    this.turnsInCurrentEmotion++;
    if (this.turnsInCurrentEmotion >= 3) {
      this.recoverToNeutral();
    }
  }

  private startPeriodicRecoveryCheck(): void {
    if (this.recoveryTimer) clearInterval(this.recoveryTimer);
    this.recoveryTimer = setInterval(() => {
      // If idle for over 45 seconds in a reactive state, return toward neutral
      const lastEntry = this.history[this.history.length - 1];
      if (lastEntry && Date.now() - lastEntry.timestamp > 45000) {
        this.recoverToNeutral();
      }
    }, 15000);
  }

  // --- Subscription Listener ---

  public subscribe(listener: EmotionListener): () => void {
    this.listeners.add(listener);
    listener(this.currentEmotion, this.getConfig(), this.intensity, this.previousEmotion);
    return () => {
      this.listeners.delete(listener);
    };
  }

  private notify(previous: EmotionalState): void {
    const config = this.getConfig();
    for (const listener of this.listeners) {
      try {
        listener(this.currentEmotion, config, this.intensity, previous);
      } catch (err) {
        console.error('[EmotionManager] Listener error:', err);
      }
    }
  }
}
