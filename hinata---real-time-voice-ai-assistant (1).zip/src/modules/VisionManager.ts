/**
 * VisionManager - Master Vision Orchestrator for Hinata AI (Part 2: Vision & Design Intelligence)
 *
 * Coordinates:
 * - ImageInputManager (Android image picker & screenshot intake)
 * - ScreenShareManager (Live Android MediaProjection screen capture with change-detection)
 * - Google Gemini Vision backend (gemini-3.8-flash)
 * - Structured vision understanding & confidence scoring
 * - Voice explanation engine (reads findings through voice, animating Hinata's face)
 * - EmotionManager integration (focused -> confident / curious / concerned)
 * - MascotState updates (VISION_ANALYZING, SCREEN_ANALYZING, THINKING, SPEAKING)
 * - Design Intelligence (Layout, Colors, Typography, Components, UX, Improvements, Code)
 */

import { ScreenShareManager } from './ScreenShareManager';
import { ImageInputManager } from './ImageInputManager';
import {
  SelectedImage,
  ScreenShareState,
  VisionAnalysisResult,
  StructuredVisionAnalysis,
  MascotState,
} from '../types';
import { EmotionManager } from './EmotionManager';
import { AudioPlayer } from './AudioPlayer';

export type VisionMode = 'none' | 'image' | 'screen';
export type VisionStateListener = (state: {
  mode: VisionMode;
  isAnalyzing: boolean;
  activeAnalysisType: 'none' | 'image' | 'screen' | 'design_improvement' | 'design_to_code';
  selectedImage: SelectedImage | null;
  screenShareState: ScreenShareState;
  lastAnalysis: StructuredVisionAnalysis | null;
  statusMessage: string | null;
}) => void;

export class VisionManager {
  private static instance: VisionManager | null = null;
  public readonly screenShare = ScreenShareManager.getInstance();
  public readonly imageInput = ImageInputManager.getInstance();

  private isAnalyzing: boolean = false;
  private activeAnalysisType: 'none' | 'image' | 'screen' | 'design_improvement' | 'design_to_code' = 'none';
  private lastAnalysis: StructuredVisionAnalysis | null = null;
  private statusMessage: string | null = null;
  private listeners: VisionStateListener[] = [];
  private onFrameToLiveSession: ((base64: string, mimeType: string) => void) | null = null;
  private onMascotStateChange: ((state: MascotState) => void) | null = null;
  private audioPlayer: AudioPlayer | null = null;
  private speechSynthUtterance: SpeechSynthesisUtterance | null = null;

  private constructor() {
    // Automatically stream screen frames to Gemini Live if session is hooked
    this.screenShare.setFrameCallback((base64, mimeType) => {
      if (this.onFrameToLiveSession) {
        this.onFrameToLiveSession(base64, mimeType);
      }
    });

    // Automatically notify subscribers on screen state changes
    this.screenShare.subscribe((screenState) => {
      if (!screenState.isActive && this.onMascotStateChange && !this.isAnalyzing) {
        this.onMascotStateChange('IDLE');
      } else if (screenState.isActive && this.onMascotStateChange && !this.isAnalyzing) {
        this.onMascotStateChange('SCREEN_SHARING');
      }
      this.notifyListeners();
    });

    // Automatically notify subscribers on image selection changes
    this.imageInput.subscribe((img) => {
      if (img) {
        if (this.onFrameToLiveSession) {
          // Send initial image frame to Gemini Live so Hinata immediately sees it
          this.onFrameToLiveSession(img.base64, img.mimeType);
        }
        // When image is picked, trigger automatic structured analysis and voice explanation
        this.analyzeVisual('Please analyze this image or screenshot and explain it to me.', 'image');
      }
      this.notifyListeners();
    });
  }

  public static getInstance(): VisionManager {
    if (!VisionManager.instance) {
      VisionManager.instance = new VisionManager();
    }
    return VisionManager.instance;
  }

  public subscribe(listener: VisionStateListener): () => void {
    this.listeners.push(listener);
    this.notifySingleListener(listener);
    return () => {
      this.listeners = this.listeners.filter((l) => l !== listener);
    };
  }

  public setAudioPlayer(player: AudioPlayer | null): void {
    this.audioPlayer = player;
  }

  public bindMascotStateSetter(setter: ((state: MascotState) => void) | null): void {
    this.onMascotStateChange = setter;
  }

  private notifyListeners(): void {
    const payload = this.getCurrentState();
    for (const listener of this.listeners) {
      try {
        listener(payload);
      } catch (e) {
        console.error('[VisionManager] Listener error:', e);
      }
    }
  }

  private notifySingleListener(listener: VisionStateListener): void {
    try {
      listener(this.getCurrentState());
    } catch (e) {
      console.error('[VisionManager] Single listener error:', e);
    }
  }

  public getCurrentState() {
    const screenState = this.screenShare.getState();
    const selImage = this.imageInput.getSelectedImage();

    let mode: VisionMode = 'none';
    if (screenState.isActive) {
      mode = 'screen';
    } else if (selImage) {
      mode = 'image';
    }

    return {
      mode,
      isAnalyzing: this.isAnalyzing,
      activeAnalysisType: this.activeAnalysisType,
      selectedImage: selImage,
      screenShareState: screenState,
      lastAnalysis: this.lastAnalysis,
      statusMessage: this.statusMessage,
    };
  }

  public getLastAnalysis(): StructuredVisionAnalysis | null {
    return this.lastAnalysis;
  }

  public getVisionMode(): VisionMode {
    if (this.screenShare.isScreenSharing()) return 'screen';
    if (this.imageInput.hasImage()) return 'image';
    return 'none';
  }

  public isVisionAnalyzing(): boolean {
    return this.isAnalyzing;
  }

  /**
   * Binds LiveSession frame sender so incoming vision frames are forwarded directly to Gemini Live.
   */
  public bindLiveSessionSender(sender: ((base64: string, mimeType: string) => void) | null): void {
    this.onFrameToLiveSession = sender;
  }

  /**
   * Retrieves the current visual frame from either the selected image or active screen share.
   */
  public getActiveVisualFrame(): { base64: string; dataUrl?: string; mimeType: string; source: 'screen' | 'image' } | null {
    if (this.screenShare.isScreenSharing()) {
      const frame = this.screenShare.captureImmediateFrame();
      if (frame) {
        return {
          base64: frame.base64,
          dataUrl: frame.dataUrl,
          mimeType: frame.mimeType,
          source: 'screen',
        };
      }
    }

    const img = this.imageInput.getSelectedImage();
    if (img) {
      return {
        base64: img.base64,
        dataUrl: img.dataUrl,
        mimeType: img.mimeType,
        source: 'image',
      };
    }

    return null;
  }

  /**
   * Performs deep visual analysis using server-side Google Gemini Vision (gemini-3.8-flash).
   * Maps visual states and explains findings through voice.
   */
  public async analyzeVisual(
    question?: string,
    forcedSource?: 'screen' | 'image'
  ): Promise<VisionAnalysisResult> {
    const activeFrame = this.getActiveVisualFrame();
    if (!activeFrame) {
      const fallbackSummary = 'No active visual frame found. Please choose an image or turn on screen sharing.';
      this.speakVoiceExplanation(fallbackSummary);
      return { summary: fallbackSummary };
    }

    const source = forcedSource || activeFrame.source;
    this.isAnalyzing = true;
    this.activeAnalysisType = source === 'screen' ? 'screen' : 'image';
    this.statusMessage = source === 'screen' ? 'Scanning live Android screen...' : 'Analyzing selected image...';

    // 1. Update Hinata Visual States: SCREEN_ANALYZING or VISION_ANALYZING
    if (this.onMascotStateChange) {
      this.onMascotStateChange(source === 'screen' ? 'SCREEN_ANALYZING' : 'VISION_ANALYZING');
    }

    // 2. Emotion Engine: Transition to focused / thinking
    try {
      const emotionMgr = EmotionManager.getInstance();
      emotionMgr.transitionEmotion('focused', 3, `Analyzing visual content from ${source}`);
    } catch (e) {
      console.warn('[VisionManager] Emotion transition warning:', e);
    }

    this.notifyListeners();

    try {
      const promptQuestion =
        question ||
        (source === 'screen'
          ? 'What is on my screen? Read and explain clearly.'
          : 'Analyze this image, UI elements, and layout structure.');

      const res = await fetch('/api/vision/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          image: activeFrame.base64,
          mimeType: activeFrame.mimeType,
          source,
          question: promptQuestion,
          task: 'general',
        }),
      });

      if (!res.ok) {
        const errorData = await res.json().catch(() => ({}));
        throw new Error(errorData.error || `Vision analysis failed with status ${res.status}`);
      }

      const structured: StructuredVisionAnalysis = await res.json();
      this.lastAnalysis = structured;
      this.statusMessage = null;

      // 3. Emotion Engine calibration based on confidence:
      // High confidence -> proud / confident
      // Low confidence -> curious
      try {
        const emotionMgr = EmotionManager.getInstance();
        if (structured.confidence && structured.confidence < 0.6) {
          emotionMgr.transitionEmotion('curious', 2, 'Ambiguous visual elements detected with low confidence');
        } else {
          emotionMgr.transitionEmotion('proud', 3, 'Visual analysis completed successfully');
        }
      } catch (e) {
        console.warn('[VisionManager] Emotion success warning:', e);
      }

      // 4. Hinata explains primarily through voice!
      if (structured.summary) {
        await this.speakVoiceExplanation(structured.summary);
      }

      const legacyResult: VisionAnalysisResult = {
        summary: structured.summary,
        uiElements: structured.uiElements.map((el) => el.label || el.type),
        designCritique: structured.designAnalysis?.visualStyle?.description || '',
        suggestedActions: structured.designAnalysis?.improvements?.map((i) => i.suggestion) || [],
        extractedText: structured.text.join('\n'),
        structured,
        confidence: structured.confidence,
      };

      return legacyResult;
    } catch (err: any) {
      console.error('[VisionManager] analyzeVisual error:', err);
      const errMessage = `I encountered an issue analyzing this: ${err?.message || 'Visual processing error'}`;
      this.statusMessage = 'Analysis error';

      try {
        EmotionManager.getInstance().transitionEmotion('concerned', 2, 'Vision analysis encountered an error');
      } catch {}

      this.speakVoiceExplanation(errMessage);

      return {
        summary: errMessage,
        confidence: 0,
      };
    } finally {
      this.isAnalyzing = false;
      this.activeAnalysisType = 'none';
      if (this.onMascotStateChange) {
        if (this.screenShare.isScreenSharing()) {
          this.onMascotStateChange('SCREEN_SHARING');
        } else {
          this.onMascotStateChange('IDLE');
        }
      }
      this.notifyListeners();
    }
  }

  /**
   * Dedicated Design Intelligence: "Improve this design."
   * Analyzes weaknesses, suggests enhancements, explains rationale, and preserves intended style.
   */
  public async improveActiveDesign(
    instructions?: string,
    framework: 'react-tailwind' | 'html-css' | 'jetpack-compose' | 'typescript' = 'react-tailwind'
  ): Promise<StructuredVisionAnalysis | null> {
    const activeFrame = this.getActiveVisualFrame();
    if (!activeFrame) {
      this.speakVoiceExplanation('Please provide a screen or image to improve.');
      return null;
    }

    this.isAnalyzing = true;
    this.activeAnalysisType = 'design_improvement';
    this.statusMessage = 'Critiquing design architecture & suggesting improvements...';

    if (this.onMascotStateChange) {
      this.onMascotStateChange('THINKING');
    }

    try {
      EmotionManager.getInstance().transitionEmotion('focused', 3, 'Deep design improvement analysis');
    } catch {}

    this.notifyListeners();

    try {
      const res = await fetch('/api/vision/improve-design', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          image: activeFrame.base64,
          mimeType: activeFrame.mimeType,
          source: activeFrame.source,
          customInstructions: instructions,
          framework,
        }),
      });

      if (!res.ok) {
        throw new Error(`Improve design API returned ${res.status}`);
      }

      const structured: StructuredVisionAnalysis = await res.json();
      this.lastAnalysis = structured;
      this.statusMessage = null;

      try {
        EmotionManager.getInstance().transitionEmotion('proud', 3, 'Design improvements generated');
      } catch {}

      if (structured.summary) {
        await this.speakVoiceExplanation(structured.summary);
      }

      return structured;
    } catch (err: any) {
      console.error('[VisionManager] improveActiveDesign error:', err);
      const msg = `Could not critique design: ${err?.message || 'Server error'}`;
      this.speakVoiceExplanation(msg);
      return null;
    } finally {
      this.isAnalyzing = false;
      this.activeAnalysisType = 'none';
      if (this.onMascotStateChange) {
        this.onMascotStateChange(this.screenShare.isScreenSharing() ? 'SCREEN_SHARING' : 'IDLE');
      }
      this.notifyListeners();
    }
  }

  /**
   * Dedicated Design-to-Code: Converts visual design into modular code.
   */
  public async convertActiveDesignToCode(
    framework: 'react-tailwind' | 'html-css' | 'jetpack-compose' | 'typescript' = 'react-tailwind'
  ): Promise<StructuredVisionAnalysis | null> {
    const activeFrame = this.getActiveVisualFrame();
    if (!activeFrame) {
      this.speakVoiceExplanation('Please provide a screen or image to convert into code.');
      return null;
    }

    this.isAnalyzing = true;
    this.activeAnalysisType = 'design_to_code';
    this.statusMessage = `Synthesizing ${framework} code implementation...`;

    if (this.onMascotStateChange) {
      this.onMascotStateChange('THINKING');
    }

    try {
      EmotionManager.getInstance().transitionEmotion('focused', 3, 'Synthesizing code from visual design');
    } catch {}

    this.notifyListeners();

    try {
      const res = await fetch('/api/vision/design-to-code', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          image: activeFrame.base64,
          mimeType: activeFrame.mimeType,
          source: activeFrame.source,
          framework,
        }),
      });

      if (!res.ok) {
        throw new Error(`Design to code API returned ${res.status}`);
      }

      const structured: StructuredVisionAnalysis = await res.json();
      this.lastAnalysis = structured;
      this.statusMessage = null;

      try {
        EmotionManager.getInstance().transitionEmotion('proud', 3, 'Code architecture created');
      } catch {}

      if (structured.summary) {
        await this.speakVoiceExplanation(structured.summary);
      }

      return structured;
    } catch (err: any) {
      console.error('[VisionManager] convertActiveDesignToCode error:', err);
      const msg = `Could not generate code: ${err?.message || 'Server error'}`;
      this.speakVoiceExplanation(msg);
      return null;
    } finally {
      this.isAnalyzing = false;
      this.activeAnalysisType = 'none';
      if (this.onMascotStateChange) {
        this.onMascotStateChange(this.screenShare.isScreenSharing() ? 'SCREEN_SHARING' : 'IDLE');
      }
      this.notifyListeners();
    }
  }

  /**
   * Speaks Hinata's visual explanation aloud using browser speech synthesis,
   * driving mouth movements and lip-sync via audio-reactive controller.
   */
  public async speakVoiceExplanation(text: string): Promise<void> {
    if (typeof window === 'undefined' || !window.speechSynthesis) {
      return;
    }

    // Cancel any ongoing speech
    window.speechSynthesis.cancel();

    return new Promise((resolve) => {
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 1.05;
      utterance.pitch = 1.1;

      // Select female/clear English voice if available
      const voices = window.speechSynthesis.getVoices();
      const preferred = voices.find(
        (v) =>
          v.lang.startsWith('en') &&
          (v.name.toLowerCase().includes('female') ||
            v.name.toLowerCase().includes('samantha') ||
            v.name.toLowerCase().includes('zira') ||
            v.name.toLowerCase().includes('natural') ||
            v.name.toLowerCase().includes('google'))
      );
      if (preferred) {
        utterance.voice = preferred;
      }

      utterance.onstart = () => {
        if (this.onMascotStateChange) {
          this.onMascotStateChange('SPEAKING');
        }
      };

      utterance.onend = () => {
        if (this.onMascotStateChange) {
          this.onMascotStateChange(this.screenShare.isScreenSharing() ? 'SCREEN_SHARING' : 'IDLE');
        }
        resolve();
      };

      utterance.onerror = () => {
        if (this.onMascotStateChange) {
          this.onMascotStateChange(this.screenShare.isScreenSharing() ? 'SCREEN_SHARING' : 'IDLE');
        }
        resolve();
      };

      this.speechSynthUtterance = utterance;
      window.speechSynthesis.speak(utterance);
    });
  }

  /**
   * Stops any ongoing voice explanation.
   */
  public stopVoiceExplanation(): void {
    if (typeof window !== 'undefined' && window.speechSynthesis) {
      window.speechSynthesis.cancel();
    }
  }
}

