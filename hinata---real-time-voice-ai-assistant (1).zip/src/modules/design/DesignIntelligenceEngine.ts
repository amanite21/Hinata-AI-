/**
 * DesignIntelligenceEngine - Master Design Creation & Synthesis Engine for Hinata AI.
 *
 * Implements:
 * - Autonomous original design generation across 20 distinct design domains
 * - Clear reasonable assumptions engine (never stalls on tiny details)
 * - Tri-Option Generation: Option A (Minimal), Option B (Cinematic), Option C (Experimental)
 * - Multi-language Code Generation: React + Tailwind TSX, Android Jetpack Compose (Kotlin), HTML5 + CSS
 * - Integration with MemoryManager for persistent user design preferences
 * - Pre-presentation automated quality review through DesignReviewEngine
 */

import {
  DesignDomain,
  DesignOption,
  DesignGenerationResult,
  StoredDesignPreference,
  GeneratedCodeSnippets,
} from './DesignIntelligenceTypes';
import { HinataDesignSystem } from './HinataDesignSystem';
import { DesignReviewEngine } from './DesignReviewEngine';
import { MemoryManager } from '../memory/MemoryManager';

const STORAGE_DESIGN_PREFERENCE_KEY = 'hinata_design_preference_v1';

export class DesignIntelligenceEngine {
  private static instance: DesignIntelligenceEngine | null = null;
  private readonly reviewer = DesignReviewEngine.getInstance();
  private readonly designSystem = HinataDesignSystem.getInstance();

  private constructor() {}

  public static getInstance(): DesignIntelligenceEngine {
    if (!DesignIntelligenceEngine.instance) {
      DesignIntelligenceEngine.instance = new DesignIntelligenceEngine();
    }
    return DesignIntelligenceEngine.instance;
  }

  /**
   * Infers design domain from natural language prompt.
   */
  public inferDomain(prompt: string): DesignDomain {
    const p = prompt.toLowerCase();

    if (p.includes('dashboard') || p.includes('metrics') || p.includes('analytics') || p.includes('telemetry')) {
      return 'dashboard';
    }
    if (p.includes('music') || p.includes('player') || p.includes('audio') || p.includes('spotify') || p.includes('song')) {
      return 'music_player';
    }
    if (p.includes('video') || p.includes('stream') || p.includes('youtube') || p.includes('watch') || p.includes('netflix')) {
      return 'video_streaming';
    }
    if (p.includes('chat') || p.includes('messaging') || p.includes('conversation') || p.includes('inbox')) {
      return 'chat_interface';
    }
    if (p.includes('login') || p.includes('sign in') || p.includes('signup') || p.includes('auth')) {
      return 'login_screen';
    }
    if (p.includes('setting') || p.includes('preferences') || p.includes('config')) {
      return 'settings_screen';
    }
    if (p.includes('profile') || p.includes('account') || p.includes('user details')) {
      return 'profile_screen';
    }
    if (p.includes('landing') || p.includes('homepage') || p.includes('hero section')) {
      return 'landing_page';
    }
    if (p.includes('game') || p.includes('hud') || p.includes('quest') || p.includes('inventory')) {
      return 'game_menu';
    }
    if (p.includes('card') || p.includes('bento') || p.includes('widget')) {
      return 'card_system';
    }
    if (p.includes('poster') || p.includes('banner')) {
      return 'poster_banner';
    }
    if (p.includes('logo') || p.includes('branding') || p.includes('concept')) {
      return 'logo_concept';
    }
    if (p.includes('icon') || p.includes('glyphs')) {
      return 'icon_system';
    }
    if (p.includes('component') || p.includes('button') || p.includes('ui kit')) {
      return 'component_system';
    }
    if (p.includes('system') || p.includes('tokens') || p.includes('guidelines')) {
      return 'design_system';
    }
    if (p.includes('android') || p.includes('apk') || p.includes('compose') || p.includes('phone')) {
      return 'android_ui';
    }
    if (p.includes('web') || p.includes('website') || p.includes('desktop')) {
      return 'web_ui';
    }
    if (p.includes('assistant') || p.includes('ai companion') || p.includes('hinata')) {
      return 'ai_assistant';
    }

    return 'mobile_app';
  }

  /**
   * Generates a complete, original, multi-alternative design result.
   */
  public generateDesign(prompt: string, explicitDomain?: DesignDomain): DesignGenerationResult {
    const domain = explicitDomain || this.inferDomain(prompt);
    const pref = this.loadDesignPreference();

    // 1. Establish clear assumptions so user is never stalled
    const assumptions: string[] = [
      `Assumed target platform: Android Mobile & Responsive Web with 48dp ergonomic touch boundaries.`,
      `Assumed color strategy: High-contrast dark canvas for optical depth and OLED power efficiency.`,
      `Assumed user intent: Modern, fast-scanning hierarchical layout with zero decorative fluff.`,
    ];

    if (pref) {
      assumptions.push(`Applied user memory preference: ${pref.preferredStyle} styling with ${pref.preferredDensity} density.`);
    }

    // 2. Synthesize Design Thinking Blueprint
    const designThinking = this.buildDesignThinking(domain, prompt);

    // 3. Synthesize Options: Minimal (A), Cinematic (B), Experimental (C)
    const rawOptions = [
      this.buildMinimalOption(domain, prompt),
      this.buildCinematicOption(domain, prompt),
      this.buildExperimentalOption(domain, prompt),
    ];

    // 4. Run Self-Critique & Review Engine across each option
    const reviewedOptions: DesignOption[] = [];
    let primaryAudit = this.reviewer.reviewAndImproveOption(rawOptions[1], domain).audit;

    for (let i = 0; i < rawOptions.length; i++) {
      const { improvedOption, audit } = this.reviewer.reviewAndImproveOption(rawOptions[i], domain);
      reviewedOptions.push(improvedOption);
      if (i === 1) {
        primaryAudit = audit; // Use primary (Cinematic) as reference audit
      }
    }

    return {
      id: 'design-' + Date.now(),
      query: prompt,
      domain,
      targetPlatform: 'android',
      assumptions,
      designThinking,
      options: reviewedOptions,
      selectedOptionId: 'option_b', // Default to Cinematic
      reviewAudit: primaryAudit,
      timestamp: Date.now(),
    };
  }

  // ----------------------------------------------------
  // Option Builders (Minimal, Cinematic, Experimental)
  // ----------------------------------------------------

  private buildMinimalOption(domain: string, prompt: string): DesignOption {
    const code = this.generateCodeSnippets(domain, 'minimal');
    return {
      id: 'option_a',
      type: 'minimal',
      title: 'Option A: Studio Minimal',
      badge: 'Zero Fluff · Clean · Fast',
      description: 'Disciplined typographic hierarchy with subtle borders, generous negative space, and amber focus accents.',
      visualHierarchy: 'Primary action button anchored at thumb-reach, followed by clean list cards and 14px secondary metadata.',
      layoutPattern: 'Single-column vertical stack with 16px margins and 12px card gutters.',
      spacingRhythm: '16px outer padding, 12px inner component padding, 2:1 button padding.',
      typography: 'Clean geometric Sans-serif with tight headings and comfortable 1.6 line-height body.',
      accentColors: {
        primary: '#f59e0b',
        secondary: '#e2e8f0',
        background: '#0a0d14',
        surface: '#111726',
        text: '#f8fafc',
      },
      components: ['Header Bar', 'Focus Metric Card', 'Compact Data Row', 'Primary Pill Button'],
      code,
      interactivePreviewProps: { style: 'minimal', domain },
    };
  }

  private buildCinematicOption(domain: string, prompt: string): DesignOption {
    const code = this.generateCodeSnippets(domain, 'cinematic');
    return {
      id: 'option_b',
      type: 'cinematic',
      title: 'Option B: Hinata Cinematic',
      badge: 'Signature · Depth · Atmosphere',
      description: 'Luminous cyan & indigo gradients, frosted glass surfaces, and soft optical glow highlighting focal tasks.',
      visualHierarchy: 'Hero visual visualizer or telemetry card dominating the upper viewport, flanked by responsive interaction trays.',
      layoutPattern: 'Layered elevation with 20px outer padding, backdrop-blur-xl cards, and floating pill navigation dock.',
      spacingRhythm: '20px outer margins, 16px container padding, 10px component gap.',
      typography: 'Plus Jakarta Sans with high tracking on badges and crisp numeric telemetry.',
      accentColors: {
        primary: '#00e5ff',
        secondary: '#6366f1',
        background: '#040714',
        surface: '#080d22',
        text: '#ffffff',
      },
      components: ['Atmospheric Hero Header', 'Frosted Telemetry Card', 'Glow Action Button', 'Bottom Float Dock'],
      code,
      interactivePreviewProps: { style: 'cinematic', domain },
    };
  }

  private buildExperimentalOption(domain: string, prompt: string): DesignOption {
    const code = this.generateCodeSnippets(domain, 'experimental');
    return {
      id: 'option_c',
      type: 'experimental',
      title: 'Option C: Tactical Bento',
      badge: 'Bento Grid · Tactical · Modular',
      description: 'Asymmetric bento grid layout with neon emerald telemetry badges, modular quick-actions, and live status meters.',
      visualHierarchy: 'Multi-aspect bento modules allowing simultaneous glances at vital statistics, media states, and shortcuts.',
      layoutPattern: 'Asymmetric 2x2 grid transitioning into single-column responsive cards on narrow displays.',
      spacingRhythm: '14px uniform grid gutters, 16px card padding, mathematical corner nesting.',
      typography: 'Technical hybrid typography pairing monospace telemetry figures with bold display headings.',
      accentColors: {
        primary: '#10b981',
        secondary: '#a855f7',
        background: '#030806',
        surface: '#07150e',
        text: '#ecfdf5',
      },
      components: ['Bento Grid Container', 'Telemetry Gauge', 'Quick Shortcut Strip', 'Live Activity Capsule'],
      code,
      interactivePreviewProps: { style: 'experimental', domain },
    };
  }

  // ----------------------------------------------------
  // Code Generators (React, Jetpack Compose, HTML/CSS)
  // ----------------------------------------------------

  public generateCodeSnippets(domain: string, style: 'minimal' | 'cinematic' | 'experimental'): GeneratedCodeSnippets {
    const isCinematic = style === 'cinematic';
    const isMinimal = style === 'minimal';
    const accentColor = isMinimal ? '#f59e0b' : isCinematic ? '#00e5ff' : '#10b981';
    const componentName = `${domain.split('_').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join('')}Screen`;

    // 1. React + Tailwind (TSX)
    const reactTailwind = `import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Activity, Sparkles, ChevronRight, Zap, CheckCircle2 } from 'lucide-react';

export const ${componentName}: React.FC = () => {
  const [activeTab, setActiveTab] = useState('overview');

  return (
    <div className="min-h-screen bg-[${isMinimal ? '#0a0d14' : isCinematic ? '#040714' : '#030806'}] text-slate-100 p-4 md:p-6 flex flex-col justify-between">
      {/* Top Header */}
      <header className="flex items-center justify-between pb-4 border-b border-white/10">
        <div>
          <span className="text-[11px] font-semibold text-[${accentColor}] tracking-wider uppercase">
            ${style.toUpperCase()} · ${domain.toUpperCase()}
          </span>
          <h1 className="text-xl font-bold tracking-tight text-white mt-0.5">
            ${domain.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase())}
          </h1>
        </div>
        <span className="w-9 h-9 rounded-full bg-white/5 border border-white/10 flex items-center justify-center text-xs">
          <Activity className="w-4 h-4 text-[${accentColor}]" />
        </span>
      </header>

      {/* Main Content Area */}
      <main className="my-6 space-y-4">
        <div className="relative overflow-hidden rounded-2xl border border-[${accentColor}]/30 bg-white/5 p-5 backdrop-blur-xl">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-semibold text-white">System Status</h2>
            <span className="flex items-center gap-1.5 text-xs text-emerald-400 font-medium">
              <CheckCircle2 className="w-3.5 h-3.5" /> Operational
            </span>
          </div>
          <p className="text-xs text-slate-300 mt-2 leading-relaxed">
            Engineered with strict mathematical spacing, ergonomic 48dp touch bounds, and WCAG AA contrast.
          </p>
        </div>

        {/* Action Grid */}
        <div className="grid grid-cols-2 gap-3">
          <button className="flex flex-col items-start p-4 rounded-xl bg-white/5 border border-white/10 hover:border-[${accentColor}]/50 transition-all text-left min-h-[48px]">
            <Zap className="w-4 h-4 text-[${accentColor}] mb-2" />
            <span className="text-sm font-medium text-white">Quick Trigger</span>
            <span className="text-[11px] text-slate-400">Launch intent</span>
          </button>
          <button className="flex flex-col items-start p-4 rounded-xl bg-white/5 border border-white/10 hover:border-[${accentColor}]/50 transition-all text-left min-h-[48px]">
            <Sparkles className="w-4 h-4 text-[${accentColor}] mb-2" />
            <span className="text-sm font-medium text-white">Optimize</span>
            <span className="text-[11px] text-slate-400">Run audit</span>
          </button>
        </div>
      </main>

      {/* Primary Action Button (Single line, 2:1 horizontal padding) */}
      <footer className="pt-2">
        <button className="w-full py-3 px-6 rounded-xl bg-[${accentColor}] text-black font-semibold text-sm shadow-[0_0_20px_${accentColor}40] active:scale-[0.99] transition-transform min-h-[48px] flex items-center justify-center gap-2">
          <span>Execute Action</span>
          <ChevronRight className="w-4 h-4" />
        </button>
      </footer>
    </div>
  );
};`;

    // 2. Android Jetpack Compose (Kotlin)
    const jetpackCompose = `package com.hinata.ui.design

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

val AccentColor = Color(0xFF${accentColor.replace('#', '')})
val BgDark = Color(0xFF${isMinimal ? '0A0D14' : isCinematic ? '040714' : '030806'})
val SurfaceColor = Color(0x1AFFFFFF)

@Composable
fun ${componentName}Compose() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BgDark)
            .padding(16.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // Header
        Column(modifier = Modifier.fillMaxWidth()) {
            Text(
                text = "${style.toUpperCase()} · ${domain.toUpperCase()}",
                color = AccentColor,
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold
            )
            Text(
                text = "${domain.replace('_', ' ').replace(/\b\w/g, (l) => l.toUpperCase())}",
                color = Color.White,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(top = 4.dp)
            )
        }

        // Status Card
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, AccentColor.copy(alpha = 0.35f), RoundedCornerShape(16.dp))
                .background(SurfaceColor, RoundedCornerShape(16.dp))
                .padding(16.dp)
        ) {
            Column {
                Text("System Status", color = Color.White, fontWeight = FontWeight.SemiBold)
                Text(
                    "Operates with high-contrast accessibility and native Android edge-to-edge layout.",
                    color = Color(0xFFCBD5E1),
                    fontSize = 12.sp,
                    modifier = Modifier.padding(top = 6.dp)
                )
            }
        }

        // Action Button (Conforms to >= 48dp touch target)
        Button(
            onClick = { /* Action callback */ },
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = 48.dp),
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(containerColor = AccentColor)
        ) {
            Text("Execute Action", color = Color.Black, fontWeight = FontWeight.Bold)
        }
    }
}`;

    // 3. HTML5 + CSS
    const htmlCss = `<!-- Hinata Design Intelligence Export (${style} - ${domain}) -->
<div class="hinata-screen">
  <header class="hinata-header">
    <span class="hinata-badge">${style.toUpperCase()} · ${domain.toUpperCase()}</span>
    <h1 class="hinata-title">${domain.replace('_', ' ').toUpperCase()}</h1>
  </header>
  
  <section class="hinata-card">
    <h3 class="hinata-card-title">Operational Telemetry</h3>
    <p class="hinata-card-desc">Engineered with WCAG AA compliance and ergonomic touch boundaries.</p>
  </section>
  
  <footer class="hinata-footer">
    <button class="hinata-btn">Execute Action</button>
  </footer>
</div>

<style>
  :root {
    --accent: ${accentColor};
    --bg: ${isMinimal ? '#0a0d14' : isCinematic ? '#040714' : '#030806'};
  }
  .hinata-screen {
    background-color: var(--bg);
    color: #fff;
    padding: 16px;
    min-height: 100vh;
    box-sizing: border-box;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
  }
  .hinata-badge {
    font-size: 11px;
    font-weight: 600;
    color: var(--accent);
    letter-spacing: 0.05em;
  }
  .hinata-title {
    font-size: 20px;
    margin: 4px 0 16px 0;
  }
  .hinata-card {
    background: rgba(255,255,255,0.06);
    border: 1px solid rgba(255,255,255,0.12);
    border-radius: 16px;
    padding: 16px;
  }
  .hinata-card-title {
    margin: 0 0 6px 0;
    font-size: 15px;
  }
  .hinata-card-desc {
    margin: 0;
    font-size: 12px;
    color: #94a3b8;
    line-height: 1.5;
  }
  .hinata-btn {
    width: 100%;
    min-height: 48px;
    background: var(--accent);
    color: #000;
    border: none;
    border-radius: 12px;
    font-weight: 600;
    font-size: 14px;
    cursor: pointer;
  }
</style>`;

    return { reactTailwind, jetpackCompose, htmlCss };
  }

  // ----------------------------------------------------
  // Design Thinking Blueprint Generator
  // ----------------------------------------------------

  private buildDesignThinking(domain: string, prompt: string) {
    return {
      purpose: `Create an intuitive, high-efficiency ${domain.replace('_', ' ')} layout tailored to "${prompt}".`,
      targetUser: 'Modern Android & Web user requiring fast recognition, clear hierarchy, and zero cognitive friction.',
      visualHierarchy: '1. Primary telemetry or status metric. 2. Main functional view cards. 3. Anchored action controls.',
      layoutStrategy: 'Single-screen, edge-to-edge mobile-first flow with collapsible secondary details.',
      usabilityFactors: [
        'Interactive elements maintain at least 48dp touch hitbox',
        'Text contrast passes WCAG AA (>= 4.5:1 ratio)',
        'Labels stay strictly on a single line without awkward wrapping',
        'Spacing follows 4px base scale with 16px outer margin discipline',
      ],
      visualSystem: 'Hinata Design System tokens with mathematical corner nesting (Inner = Outer - Padding).',
      consistencyCheck: 'Matches Hinata signature visual language; avoids cluttered multi-tabs or arbitrary hero banners.',
      performanceNote: 'Pure hardware-accelerated CSS transforms; 60fps fluid frame budget on mobile chipsets.',
    };
  }

  // ----------------------------------------------------
  // Persistent Design Style Memory Integration
  // ----------------------------------------------------

  public rememberDesignPreference(pref: Partial<StoredDesignPreference>): void {
    const existing = this.loadDesignPreference() || {
      preferredStyle: 'cinematic',
      preferredDensity: 'comfortable',
      preferredTypography: 'modern_sans',
      preferredAnimationLevel: 'smooth',
      preferredPhilosophy: 'Clean, high-contrast, atmospheric UI with intentional glowing focal points.',
      preferredColors: {
        primary: '#00e5ff',
        accent: '#6366f1',
        background: '#040714',
      },
      savedAt: Date.now(),
    };

    const updated: StoredDesignPreference = {
      ...existing,
      ...pref,
      savedAt: Date.now(),
    };

    try {
      localStorage.setItem(STORAGE_DESIGN_PREFERENCE_KEY, JSON.stringify(updated));
      MemoryManager.getInstance().saveMemory({
        content: `User stated design preference: ${updated.preferredStyle} visual style with ${updated.preferredDensity} layout density.`,
        category: 'preference',
        importance: 8,
        tags: ['design', 'theme', 'ui_style'],
      });
    } catch (err) {
      console.warn('[DesignIntelligenceEngine] Failed to persist design preference:', err);
    }
  }

  public forgetDesignPreference(): void {
    try {
      localStorage.removeItem(STORAGE_DESIGN_PREFERENCE_KEY);
      MemoryManager.getInstance().saveMemory({
        content: 'User requested to reset and forget saved design preferences.',
        category: 'preference',
        importance: 5,
        tags: ['design', 'reset'],
      });
    } catch (err) {}
  }

  public loadDesignPreference(): StoredDesignPreference | null {
    try {
      const raw = localStorage.getItem(STORAGE_DESIGN_PREFERENCE_KEY);
      if (!raw) return null;
      return JSON.parse(raw);
    } catch {
      return null;
    }
  }
}
