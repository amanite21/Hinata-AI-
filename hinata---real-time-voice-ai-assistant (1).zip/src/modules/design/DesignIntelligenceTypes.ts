/**
 * DesignIntelligenceTypes - Type Definitions for Hinata's Design Intelligence & Review System.
 */

import { ColorToken } from './HinataDesignSystem';

export type DesignDomain =
  | 'mobile_app'
  | 'android_ui'
  | 'web_ui'
  | 'dashboard'
  | 'landing_page'
  | 'login_screen'
  | 'settings_screen'
  | 'profile_screen'
  | 'chat_interface'
  | 'music_player'
  | 'video_streaming'
  | 'ai_assistant'
  | 'game_menu'
  | 'card_system'
  | 'poster_banner'
  | 'logo_concept'
  | 'icon_system'
  | 'component_system'
  | 'design_system';

export type DesignAlternativeType = 'minimal' | 'cinematic' | 'experimental';

export interface GeneratedCodeSnippets {
  reactTailwind: string;
  jetpackCompose: string;
  htmlCss: string;
}

export interface DesignOption {
  id: string; // 'option_a' | 'option_b' | 'option_c'
  type: DesignAlternativeType;
  title: string;
  badge: string;
  description: string;
  visualHierarchy: string;
  layoutPattern: string;
  spacingRhythm: string;
  typography: string;
  accentColors: {
    primary: string;
    secondary: string;
    background: string;
    surface: string;
    text: string;
  };
  components: string[];
  code: GeneratedCodeSnippets;
  interactivePreviewProps?: Record<string, any>;
}

export interface DesignReviewAudit {
  passed: boolean;
  score: number; // 0 - 100 overall
  readability: { score: number; notes: string };
  contrast: { score: number; wcagAA: boolean; notes: string };
  spacing: { score: number; notes: string };
  alignment: { score: number; notes: string };
  hierarchy: { score: number; notes: string };
  mobileUsability: { score: number; touchTargetValid: boolean; notes: string };
  performance: { score: number; notes: string };
  detectedFlaws: string[];
  improvementsApplied: string[];
  userFacingExplanation: string; // Concise explanation of what was tuned
}

export interface DesignGenerationResult {
  id: string;
  query: string;
  domain: DesignDomain;
  targetPlatform: 'android' | 'web' | 'cross_platform';
  assumptions: string[];
  designThinking: {
    purpose: string;
    targetUser: string;
    visualHierarchy: string;
    layoutStrategy: string;
    usabilityFactors: string[];
    visualSystem: string;
    consistencyCheck: string;
    performanceNote: string;
  };
  options: DesignOption[];
  selectedOptionId: string;
  reviewAudit: DesignReviewAudit;
  timestamp: number;
}

export interface ScreenshotCritiqueResult {
  id: string;
  analyzedAt: number;
  imageUrl?: string;
  overallScore: number;
  whatWorks: string[];
  whatCouldImprove: string[];
  whatIWouldChange: string[];
  isAlreadyStrong: boolean;
  contrastAssessment: string;
  typographyAssessment: string;
  spacingAssessment: string;
  mobileUsabilityAssessment: string;
  alternativeSuggestion?: string;
}

export interface StoredDesignPreference {
  preferredStyle: 'minimal' | 'cinematic' | 'experimental' | 'cyberpunk' | 'editorial';
  preferredDensity: 'compact' | 'comfortable' | 'spacious';
  preferredTypography: 'modern_sans' | 'geometric' | 'mono_hybrid';
  preferredAnimationLevel: 'subtle' | 'smooth' | 'rich';
  preferredPhilosophy: string;
  preferredColors: {
    primary: string;
    accent: string;
    background: string;
  };
  savedAt: number;
  lastUpdatedByCommand?: string;
}
