/**
 * OwnerManager - Personalization & Relationship Manager for Hinata AI.
 *
 * Coordinates owner identity (Aman), relationship tone, natural form of address,
 * personal preferences, and conversational personalization without repetitive phrasing.
 */

import { MemoryManager } from './memory/MemoryManager';
import { UserProfile } from './memory/MemoryTypes';

export class OwnerManager {
  private static instance: OwnerManager | null = null;
  private ownerName: string = 'Aman';
  private assistantName: string = 'Hinata';
  private ownerEmail: string = 'amanuchiha.pro@gmail.com';
  private lastAddressedAt: number = 0;
  private listeners: Array<(profile: Partial<UserProfile>) => void> = [];

  private constructor() {
    this.syncWithOwnerProfile();
    if (typeof window !== 'undefined') {
      const savedAssistant = localStorage.getItem('hinata_assistant_name');
      if (savedAssistant && savedAssistant.trim()) {
        this.assistantName = savedAssistant.trim();
      }
      const savedOwner = localStorage.getItem('hinata_owner_name');
      if (savedOwner && savedOwner.trim()) {
        this.ownerName = savedOwner.trim();
      }
    }
  }

  public onProfileChange(listener: (profile: Partial<UserProfile>) => void): () => void {
    this.listeners.push(listener);
    return () => {
      this.listeners = this.listeners.filter((l) => l !== listener);
    };
  }

  private notifyProfileChange(profile: Partial<UserProfile>): void {
    for (const l of this.listeners) {
      try {
        l(profile);
      } catch (err) {
        console.error('[OwnerManager] Profile change error:', err);
      }
    }
  }

  public static getInstance(): OwnerManager {
    if (!OwnerManager.instance) {
      OwnerManager.instance = new OwnerManager();
    }
    return OwnerManager.instance;
  }

  /**
   * Syncs with stored UserProfile in MemoryManager.
   */
  public syncWithOwnerProfile(): void {
    try {
      const profile = MemoryManager.getInstance().profile.getProfile();
      if (profile.name && profile.name.trim()) {
        this.ownerName = profile.name.trim();
      }
    } catch {
      // MemoryManager might be initializing
    }
  }

  public getOwnerName(): string {
    return this.ownerName;
  }

  public getAssistantName(): string {
    return this.assistantName;
  }

  public getOwnerEmail(): string {
    return this.ownerEmail;
  }

  public setOwnerName(name: string): void {
    const trimmed = name.trim();
    if (trimmed) {
      this.ownerName = trimmed;
      if (typeof window !== 'undefined') {
        try {
          localStorage.setItem('hinata_owner_name', trimmed);
        } catch {}
      }
      MemoryManager.getInstance().profile.updateField('name', trimmed);
      this.notifyProfileChange({ name: trimmed });
    }
  }

  public setAssistantName(name: string): void {
    const trimmed = name.trim();
    if (trimmed) {
      this.assistantName = trimmed;
      if (typeof window !== 'undefined') {
        try {
          localStorage.setItem('hinata_assistant_name', trimmed);
        } catch {}
      }
      this.notifyProfileChange({});
    }
  }

  /**
   * Returns a natural, conversational greeting.
   * Avoids repeating "owner" or sounding robotic.
   */
  public getNaturalGreeting(): string {
    const hours = new Date().getHours();
    let timeGreeting = 'Hello';
    if (hours >= 5 && hours < 12) timeGreeting = 'Good morning';
    else if (hours >= 12 && hours < 17) timeGreeting = 'Good afternoon';
    else if (hours >= 17 && hours < 22) timeGreeting = 'Good evening';

    // Naturally address Aman
    return `${timeGreeting}, ${this.ownerName}. I'm here and ready.`;
  }

  /**
   * Determines whether it is appropriate to use the owner's name in this response
   * to avoid repetitive over-use while maintaining warmth.
   */
  public shouldAddressByName(): boolean {
    const now = Date.now();
    // Only address by name at most once every 90 seconds in conversation
    if (now - this.lastAddressedAt > 90000) {
      this.lastAddressedAt = now;
      return true;
    }
    return false;
  }

  /**
   * Generates owner personalization context for Gemini Live instructions.
   */
  public getPromptContext(): string {
    return `Owner: ${this.ownerName}
- Address ${this.ownerName} naturally, warmly, and respectfully when appropriate.
- Do NOT repeatedly say "owner" or say "${this.ownerName}" in every single sentence.
- Maintain a warm, trusted partnership dynamic as an advanced personal AI companion.`;
  }
}
