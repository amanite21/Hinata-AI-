/**
 * WorkProfileManager - Stores non-sensitive professional information for Hinata.
 *
 * Requirements:
 * - Professional bio, skills, services, portfolio links, website, LinkedIn URL, GitHub URL,
 *   preferred freelance categories, project types, communication style, availability, goals.
 * - Editable by the user at any time.
 * - STRICT SECURITY: NEVER stores passwords, API keys, tokens, or private secrets.
 */

import { WorkProfile } from './types';

const STORAGE_KEY = 'hinata_work_profile_v1';

const DEFAULT_PROFILE: WorkProfile = {
  displayName: 'Professional Creator & Engineer',
  professionalBio: 'Full-stack software architect & creative technologist focused on AI systems, scalable web applications, and intuitive user interfaces.',
  title: 'Senior Full-Stack & AI Engineer',
  skills: [
    'TypeScript',
    'React',
    'Node.js',
    'Python',
    'Tailwind CSS',
    'Gemini API',
    'Cloud Architecture',
    'UI/UX Design',
    'Android Integration'
  ],
  services: [
    'Full-Stack Web App Development',
    'AI Assistant & Agent Integration',
    'Modern UI/UX Product Prototyping',
    'Technical Architecture Consulting',
    'Performance & Latency Optimization'
  ],
  portfolioLinks: [
    { label: 'Hinata AI Assistant', url: 'https://github.com/project/hinata', category: 'AI & Realtime Voice' },
    { label: 'Design System & UI Studio', url: 'https://portfolio.example.com/studio', category: 'Frontend Architecture' }
  ],
  websiteUrl: 'https://portfolio.example.com',
  linkedInUrl: 'https://linkedin.com/in/creative-engineer',
  gitHubUrl: 'https://github.com/engineer',
  preferredFreelanceCategories: [
    'AI Application Development',
    'Full-Stack React & Node Systems',
    'Design System & Component Library Creation'
  ],
  preferredProjectTypes: ['Fixed-price milestones', 'Dedicated technical advisory', 'High-impact MVP builds'],
  preferredCommunicationStyle: 'professional',
  preferredLanguages: ['English', 'Hindi'],
  availability: 'part_time',
  hourlyRateEstimate: '$65 - $120 / hr',
  generalWorkGoals: [
    'Build high-leverage AI products',
    'Expand professional freelancing client pipeline',
    'Share consistent educational insights on LinkedIn'
  ],
  contentThemes: [
    'Practical AI Systems Engineering',
    'Modern UI Engineering & Craft',
    'Real-time Audio & Vision Architectures',
    'Freelancing Lessons & Systemized Productivity'
  ],
  professionalInterests: ['Agentic Workflows', 'Design Intelligence', 'Spatial & Ambient UI'],
  updatedAt: Date.now(),
};

export class WorkProfileManager {
  private static instance: WorkProfileManager | null = null;
  private profile: WorkProfile;
  private listeners: Array<(profile: WorkProfile) => void> = [];

  private constructor() {
    this.profile = this.load();
  }

  public static getInstance(): WorkProfileManager {
    if (!WorkProfileManager.instance) {
      WorkProfileManager.instance = new WorkProfileManager();
    }
    return WorkProfileManager.instance;
  }

  private load(): WorkProfile {
    if (typeof window === 'undefined') return { ...DEFAULT_PROFILE };
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        // Clean out any accidental forbidden keys if ever present
        delete (parsed as any).password;
        delete (parsed as any).apiKey;
        delete (parsed as any).token;
        delete (parsed as any).secret;
        return { ...DEFAULT_PROFILE, ...parsed };
      }
    } catch (e) {
      console.warn('[WorkProfileManager] Load error:', e);
    }
    return { ...DEFAULT_PROFILE };
  }

  private save(): void {
    if (typeof window === 'undefined') return;
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(this.profile));
      this.notify();
    } catch (e) {
      console.warn('[WorkProfileManager] Save error:', e);
    }
  }

  public getProfile(): WorkProfile {
    return { ...this.profile };
  }

  public updateProfile(updates: Partial<WorkProfile>): void {
    // Sanitize to prevent storing sensitive attributes
    const cleanUpdates = { ...updates };
    delete (cleanUpdates as any).password;
    delete (cleanUpdates as any).apiKey;
    delete (cleanUpdates as any).token;
    delete (cleanUpdates as any).secret;

    this.profile = {
      ...this.profile,
      ...cleanUpdates,
      updatedAt: Date.now(),
    };
    this.save();
  }

  public addSkill(skill: string): void {
    const trimmed = skill.trim();
    if (trimmed && !this.profile.skills.includes(trimmed)) {
      this.profile.skills.push(trimmed);
      this.save();
    }
  }

  public removeSkill(skill: string): void {
    this.profile.skills = this.profile.skills.filter((s) => s !== skill);
    this.save();
  }

  public addService(service: string): void {
    const trimmed = service.trim();
    if (trimmed && !this.profile.services.includes(trimmed)) {
      this.profile.services.push(trimmed);
      this.save();
    }
  }

  public removeService(service: string): void {
    this.profile.services = this.profile.services.filter((s) => s !== service);
    this.save();
  }

  public subscribe(listener: (profile: WorkProfile) => void): () => void {
    this.listeners.push(listener);
    listener(this.getProfile());
    return () => {
      this.listeners = this.listeners.filter((l) => l !== listener);
    };
  }

  private notify(): void {
    const current = this.getProfile();
    for (const listener of this.listeners) {
      try {
        listener(current);
      } catch (e) {
        console.error('[WorkProfileManager] Listener error:', e);
      }
    }
  }
}
