/**
 * EmailIntelligenceManager - Smart Email Categorization, Triage & Reply Drafting
 *
 * Rules:
 * - Checks IntegrationManager first: If email is NOT connected, returns honest notice.
 * - Categorizes into CLIENT, LEAD, WORK, PERSONAL, IMPORTANT, FOLLOW_UP, NEWSLETTER, PROMOTION, LOW_PRIORITY, UNCERTAIN.
 * - Extracts deadlines, action items, freelance inquiries.
 * - Generates context-aware replies (Short, Professional, Friendly).
 * - STRICT SAFETY: Never sends emails silently or automatically without human approval.
 */

import { EmailCategory, EmailItem, EmailDraft, ReplyTone } from './types';
import { IntegrationManager } from './IntegrationManager';
import { WorkProfileManager } from './WorkProfileManager';

const STORAGE_EMAILS_KEY = 'hinata_email_items_v1';
const STORAGE_DRAFTS_KEY = 'hinata_email_drafts_v1';

export class EmailIntelligenceManager {
  private static instance: EmailIntelligenceManager | null = null;
  private emails: EmailItem[] = [];
  private drafts: EmailDraft[] = [];
  private listeners: Array<() => void> = [];

  private constructor() {
    this.load();
  }

  public static getInstance(): EmailIntelligenceManager {
    if (!EmailIntelligenceManager.instance) {
      EmailIntelligenceManager.instance = new EmailIntelligenceManager();
    }
    return EmailIntelligenceManager.instance;
  }

  private load(): void {
    if (typeof window === 'undefined') return;
    try {
      const rawEmails = localStorage.getItem(STORAGE_EMAILS_KEY);
      if (rawEmails) {
        this.emails = JSON.parse(rawEmails);
      }
      const rawDrafts = localStorage.getItem(STORAGE_DRAFTS_KEY);
      if (rawDrafts) {
        this.drafts = JSON.parse(rawDrafts);
      }
    } catch (e) {
      console.warn('[EmailIntelligenceManager] Load error:', e);
    }
  }

  private save(): void {
    if (typeof window === 'undefined') return;
    try {
      localStorage.setItem(STORAGE_EMAILS_KEY, JSON.stringify(this.emails));
      localStorage.setItem(STORAGE_DRAFTS_KEY, JSON.stringify(this.drafts));
      this.notify();
    } catch (e) {
      console.warn('[EmailIntelligenceManager] Save error:', e);
    }
  }

  public getEmails(): EmailItem[] {
    return [...this.emails];
  }

  public getDrafts(): EmailDraft[] {
    return [...this.drafts];
  }

  public getImportantEmails(): EmailItem[] {
    return this.emails.filter(
      (e) => e.category === 'CLIENT' || e.category === 'LEAD' || e.category === 'IMPORTANT' || e.category === 'FOLLOW_UP'
    );
  }

  public getFreelanceInquiries(): EmailItem[] {
    return this.emails.filter((e) => e.category === 'LEAD' || e.potentialOpportunity);
  }

  /**
   * Triage and classify an incoming or imported email message with confidence value.
   */
  public classifyEmail(subject: string, body: string, sender: { name: string; email: string }): {
    category: EmailCategory;
    confidence: number;
    reason: string;
    actionItems: string[];
    hasDeadline: boolean;
    deadlineText?: string;
    potentialOpportunity: boolean;
  } {
    const text = `${subject} ${body}`.toLowerCase();
    const actionItems: string[] = [];
    let hasDeadline = false;
    let deadlineText: string | undefined;

    // Detect deadlines
    if (text.includes('deadline') || text.includes('by tomorrow') || text.includes('by friday') || text.includes('by eod') || text.includes('due date')) {
      hasDeadline = true;
      if (text.includes('by tomorrow')) deadlineText = 'Tomorrow';
      else if (text.includes('by friday')) deadlineText = 'Friday';
      else if (text.includes('by eod')) deadlineText = 'End of Day';
      else deadlineText = 'Soon (Explicit deadline mentioned)';
      actionItems.push(`Address deadline (${deadlineText})`);
    }

    // Classify
    if (text.includes('unsubscribe') || text.includes('opt-out') || text.includes('digest') || text.includes('newsletter')) {
      return {
        category: 'NEWSLETTER',
        confidence: 0.94,
        reason: 'Contains subscription footer and newsletter broadcast markers.',
        actionItems,
        hasDeadline: false,
        potentialOpportunity: false,
      };
    }

    if (text.includes('% off') || text.includes('discount') || text.includes('special offer') || text.includes('sale ends')) {
      return {
        category: 'PROMOTION',
        confidence: 0.92,
        reason: 'Contains marketing, sales pitch, or discount keywords.',
        actionItems,
        hasDeadline: false,
        potentialOpportunity: false,
      };
    }

    if (
      text.includes('hire') ||
      text.includes('freelance') ||
      text.includes('project quote') ||
      text.includes('looking for a developer') ||
      text.includes('interested in your services') ||
      text.includes('consulting') ||
      text.includes('budget') ||
      text.includes('hourly rate')
    ) {
      actionItems.push('Review project scope & respond with availability/quote');
      return {
        category: 'LEAD',
        confidence: 0.89,
        reason: 'Inquiry relates to hiring, freelance services, or project budget.',
        actionItems,
        hasDeadline,
        deadlineText,
        potentialOpportunity: true,
      };
    }

    if (text.includes('client') || text.includes('feedback on the design') || text.includes('milestone') || text.includes('revision request') || text.includes('invoice')) {
      actionItems.push('Review client feedback or deliverable milestone');
      return {
        category: 'CLIENT',
        confidence: 0.88,
        reason: 'Direct communication regarding an ongoing client engagement or deliverable.',
        actionItems,
        hasDeadline,
        deadlineText,
        potentialOpportunity: false,
      };
    }

    if (text.includes('following up') || text.includes('checking in') || text.includes('did you get a chance') || text.includes('any update')) {
      actionItems.push('Reply to pending follow-up question');
      return {
        category: 'FOLLOW_UP',
        confidence: 0.85,
        reason: 'Sender is checking in on previous conversation status.',
        actionItems,
        hasDeadline,
        deadlineText,
        potentialOpportunity: false,
      };
    }

    if (text.includes('urgent') || text.includes('asap') || text.includes('action required') || hasDeadline) {
      actionItems.push('High-priority action required');
      return {
        category: 'IMPORTANT',
        confidence: 0.82,
        reason: 'Marked with high urgency or imminent deadline.',
        actionItems,
        hasDeadline,
        deadlineText,
        potentialOpportunity: false,
      };
    }

    // Default with uncertainty check
    if (text.length < 30) {
      return {
        category: 'UNCERTAIN',
        confidence: 0.45,
        reason: 'Message text is too brief to classify with high confidence.',
        actionItems: ['Read full thread to clarify intent'],
        hasDeadline: false,
        potentialOpportunity: false,
      };
    }

    return {
      category: 'WORK',
      confidence: 0.75,
      reason: 'General professional communication.',
      actionItems,
      hasDeadline,
      deadlineText,
      potentialOpportunity: false,
    };
  }

  /**
   * Generates context-aware reply drafts (Short, Professional, Friendly) based on sender, history, and work profile.
   */
  public generateReplyDraft(emailId: string): EmailDraft | null {
    const email = this.emails.find((e) => e.id === emailId);
    if (!email) return null;

    const profile = WorkProfileManager.getInstance().getProfile();
    const senderName = email.sender.name || 'there';
    const isOpportunity = email.category === 'LEAD' || email.potentialOpportunity;

    let shortReply = '';
    let profReply = '';
    let friendlyReply = '';

    if (isOpportunity) {
      shortReply = `Hi ${senderName}, thanks for reaching out! I am available for freelance work and would love to review the project details. Could you share the timeline and scope requirements? Best, ${profile.displayName}.`;
      profReply = `Dear ${senderName},\n\nThank you for considering me for this project. Based on my background in ${profile.skills.slice(0, 3).join(', ')}, this aligns well with my experience.\n\nI would be delighted to schedule a brief discovery call or review your project specification document to provide an accurate estimate.\n\nBest regards,\n${profile.displayName}\n${profile.title}`;
      friendlyReply = `Hey ${senderName}!\n\nThanks so much for reaching out—this project sounds really exciting! I'd love to help bring it to life.\n\nLet's connect over email or a quick 15-min chat whenever suits you best so we can go over the details.\n\nWarm regards,\n${profile.displayName}`;
    } else if (email.category === 'FOLLOW_UP') {
      shortReply = `Hi ${senderName}, thanks for checking in. I'm currently reviewing this and will have an update for you shortly. Thanks!`;
      profReply = `Dear ${senderName},\n\nThank you for following up. I am currently progressing on the requested items and will share the revised updates with you by ${email.deadlineText || 'tomorrow'}.\n\nPlease let me know if any other priorities arise in the meantime.\n\nSincerely,\n${profile.displayName}`;
      friendlyReply = `Hey ${senderName}! Thanks for the reminder—I appreciate your patience. Working on this right now and will send everything over very soon!`;
    } else {
      shortReply = `Hi ${senderName}, thank you for your note. Received and will get back to you soon.`;
      profReply = `Dear ${senderName},\n\nThank you for your message. I have reviewed the details and will proceed with the next steps as discussed.\n\nBest regards,\n${profile.displayName}`;
      friendlyReply = `Hi ${senderName}! Great hearing from you. Thanks for sending this over—I'll check it out and follow up shortly!`;
    }

    const draft: EmailDraft = {
      id: 'draft-' + Date.now(),
      emailId: email.id,
      recipientEmail: email.sender.email,
      recipientName: email.sender.name,
      subject: email.subject.startsWith('Re:') ? email.subject : `Re: ${email.subject}`,
      tone: 'professional',
      shortReply,
      professionalReply: profReply,
      friendlyReply,
      selectedReply: profReply,
      status: 'DRAFT',
      createdAt: Date.now(),
      updatedAt: Date.now(),
    };

    this.drafts = this.drafts.filter((d) => d.emailId !== emailId);
    this.drafts.push(draft);
    this.save();
    return draft;
  }

  /**
   * Adds an authorized email to the triage store.
   */
  public addEmail(raw: {
    sender: { name: string; email: string };
    subject: string;
    body: string;
    receivedAt?: number;
  }): EmailItem {
    const classification = this.classifyEmail(raw.subject, raw.body, raw.sender);
    const item: EmailItem = {
      id: 'email-' + Date.now() + '-' + Math.random().toString(36).substring(2, 6),
      sender: raw.sender,
      subject: raw.subject,
      snippet: raw.body.slice(0, 140) + (raw.body.length > 140 ? '...' : ''),
      body: raw.body,
      receivedAt: raw.receivedAt || Date.now(),
      category: classification.category,
      confidence: classification.confidence,
      classificationReason: classification.reason,
      actionItems: classification.actionItems,
      hasDeadline: classification.hasDeadline,
      deadlineText: classification.deadlineText,
      potentialOpportunity: classification.potentialOpportunity,
      isRead: false,
    };

    this.emails.unshift(item);
    this.save();
    return item;
  }

  public updateDraftReply(draftId: string, text: string, tone: ReplyTone): void {
    const draft = this.drafts.find((d) => d.id === draftId);
    if (draft) {
      draft.selectedReply = text;
      draft.tone = tone;
      draft.updatedAt = Date.now();
      this.save();
    }
  }

  public markEmailRead(emailId: string): void {
    const email = this.emails.find((e) => e.id === emailId);
    if (email && !email.isRead) {
      email.isRead = true;
      this.save();
    }
  }

  public deleteEmail(emailId: string): void {
    this.emails = this.emails.filter((e) => e.id !== emailId);
    this.drafts = this.drafts.filter((d) => d.emailId !== emailId);
    this.save();
  }

  public subscribe(listener: () => void): () => void {
    this.listeners.push(listener);
    return () => {
      this.listeners = this.listeners.filter((l) => l !== listener);
    };
  }

  private notify(): void {
    for (const l of this.listeners) {
      try { l(); } catch {}
    }
  }
}
