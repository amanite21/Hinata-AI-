/**
 * WorkMemory - Dedicated Personal Work Memory for Hinata
 *
 * Rules:
 * - Stores stable work facts: services offered, preferred work types, portfolio projects,
 *   communication preferences, content themes, recurring tasks, client notes.
 * - STRICT SECURITY: NEVER stores passwords, API keys, tokens, or private credentials.
 * - Explicitly supports: "Remember this", "Forget this", "Update this".
 */

import { WorkMemoryEntry } from './types';

const STORAGE_KEY = 'hinata_work_memory_v1';

export class WorkMemory {
  private static instance: WorkMemory | null = null;
  private entries: WorkMemoryEntry[] = [];
  private listeners: Array<() => void> = [];

  private constructor() {
    this.load();
    if (this.entries.length === 0) {
      this.seedInitialMemory();
    }
  }

  public static getInstance(): WorkMemory {
    if (!WorkMemory.instance) {
      WorkMemory.instance = new WorkMemory();
    }
    return WorkMemory.instance;
  }

  private load(): void {
    if (typeof window === 'undefined') return;
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        this.entries = JSON.parse(raw);
      }
    } catch (e) {
      console.warn('[WorkMemory] Load error:', e);
    }
  }

  private save(): void {
    if (typeof window === 'undefined') return;
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(this.entries));
      this.notify();
    } catch (e) {
      console.warn('[WorkMemory] Save error:', e);
    }
  }

  private seedInitialMemory(): void {
    this.entries = [
      {
        id: 'mem-1',
        category: 'services',
        key: 'Core Offering',
        value: 'Full-stack AI assistant architecture and high-performance React & Node systems.',
        createdAt: Date.now(),
        updatedAt: Date.now(),
      },
      {
        id: 'mem-2',
        category: 'preferences',
        key: 'Communication Tone',
        value: 'Prefers concise, transparent, client-centric proposals without corporate buzzwords.',
        createdAt: Date.now(),
        updatedAt: Date.now(),
      },
      {
        id: 'mem-3',
        category: 'content_themes',
        key: 'LinkedIn Content Focus',
        value: 'System design, real-time audio/vision engineering, and practical freelancing lessons.',
        createdAt: Date.now(),
        updatedAt: Date.now(),
      },
    ];
    this.save();
  }

  public getAll(): WorkMemoryEntry[] {
    return [...this.entries];
  }

  public getByCategory(category: WorkMemoryEntry['category']): WorkMemoryEntry[] {
    return this.entries.filter((e) => e.category === category);
  }

  /**
   * "Remember this": Adds or updates a work memory entry.
   */
  public remember(category: WorkMemoryEntry['category'], key: string, value: string): WorkMemoryEntry {
    const cleanKey = key.trim();
    const cleanVal = value.trim();

    // Check for forbidden secret keywords
    const lower = `${cleanKey} ${cleanVal}`.toLowerCase();
    if (lower.includes('password') || lower.includes('token') || lower.includes('api_key') || lower.includes('secret')) {
      throw new Error('Security policy violation: Passwords, tokens, and private secrets cannot be stored in work memory.');
    }

    const existing = this.entries.find((e) => e.key.toLowerCase() === cleanKey.toLowerCase());
    if (existing) {
      existing.value = cleanVal;
      existing.category = category;
      existing.updatedAt = Date.now();
      this.save();
      return existing;
    }

    const entry: WorkMemoryEntry = {
      id: 'mem-' + Date.now() + '-' + Math.random().toString(36).substring(2, 6),
      category,
      key: cleanKey,
      value: cleanVal,
      createdAt: Date.now(),
      updatedAt: Date.now(),
    };

    this.entries.unshift(entry);
    this.save();
    return entry;
  }

  /**
   * "Forget this": Removes memory matching key or ID.
   */
  public forget(idOrKey: string): boolean {
    const initialLen = this.entries.length;
    this.entries = this.entries.filter(
      (e) => e.id !== idOrKey && e.key.toLowerCase() !== idOrKey.toLowerCase()
    );
    if (this.entries.length !== initialLen) {
      this.save();
      return true;
    }
    return false;
  }

  public subscribe(listener: () => void): () => void {
    this.listeners.push(listener);
    return () => {
      this.listeners = this.listeners.filter((l) => l !== listener);
    };
  }

  private notify(): void {
    for (const l of this.listeners) {
      try { l(); } catch {}
    }
  }
}
