/**
 * Hinata Work Intelligence & Personal Freelancing Agent - Core Type System
 * Comprehensive, modular, and non-destructive type definitions.
 */

export type WorkMode = 'overview' | 'freelance' | 'linkedin' | 'email' | 'portfolio' | 'approvals' | 'profile';

// ============================================================
// 1. USER WORK PROFILE
// ============================================================
export interface WorkProfile {
  displayName: string;
  professionalBio: string;
  title: string;
  skills: string[];
  services: string[];
  portfolioLinks: Array<{ label: string; url: string; category?: string }>;
  websiteUrl: string;
  linkedInUrl: string;
  gitHubUrl: string;
  preferredFreelanceCategories: string[];
  preferredProjectTypes: string[];
  preferredCommunicationStyle: 'concise' | 'professional' | 'consultative' | 'friendly' | 'direct';
  preferredLanguages: string[];
  availability: 'immediate' | 'part_time' | 'full_time' | 'booked_out' | 'limited';
  hourlyRateEstimate?: string;
  generalWorkGoals: string[];
  contentThemes: string[];
  professionalInterests: string[];
  updatedAt: number;
}

// ============================================================
// 2. OFFICIAL INTEGRATIONS
// ============================================================
export type IntegrationProvider = 'email' | 'linkedin' | 'github' | 'cloud_storage' | 'calendar';

export type IntegrationConnectionStatus = 'CONNECTED' | 'NOT_CONNECTED' | 'ERROR';

export interface IntegrationStatus {
  provider: IntegrationProvider;
  name: string;
  description: string;
  status: IntegrationConnectionStatus;
  accountIdentifier?: string;
  connectedAt?: number;
  lastSyncAt?: number;
  errorMessage?: string;
  capabilities: string[];
}

// ============================================================
// 3. EMAIL INTELLIGENCE
// ============================================================
export type EmailCategory =
  | 'CLIENT'
  | 'LEAD'
  | 'WORK'
  | 'PERSONAL'
  | 'IMPORTANT'
  | 'FOLLOW_UP'
  | 'NEWSLETTER'
  | 'PROMOTION'
  | 'LOW_PRIORITY'
  | 'UNCERTAIN';

export interface EmailItem {
  id: string;
  sender: { name: string; email: string };
  subject: string;
  snippet: string;
  body: string;
  receivedAt: number;
  category: EmailCategory;
  confidence: number; // 0 to 1
  classificationReason: string;
  actionItems: string[];
  hasDeadline?: boolean;
  deadlineText?: string;
  potentialOpportunity?: boolean;
  isRead: boolean;
}

export type ReplyTone = 'short' | 'professional' | 'friendly';

export interface EmailDraft {
  id: string;
  emailId: string;
  recipientEmail: string;
  recipientName: string;
  subject: string;
  tone: ReplyTone;
  shortReply: string;
  professionalReply: string;
  friendlyReply: string;
  selectedReply: string;
  status: 'DRAFT' | 'PENDING_APPROVAL' | 'APPROVED' | 'SENT' | 'FAILED';
  createdAt: number;
  updatedAt: number;
}

// ============================================================
// 4. FOLLOW-UP INTELLIGENCE
// ============================================================
export interface FollowUpItem {
  id: string;
  contactName: string;
  contactEmailOrHandle: string;
  topic: string;
  lastContactDate: number;
  dueFollowUpDate: number;
  responseStatus: 'waiting_reply' | 'replied' | 'stale' | 'resolved';
  nextActionSuggestion: string;
  recommendedDraft?: string;
  isCompleted: boolean;
  notes?: string;
}

// ============================================================
// 5. LINKEDIN INTELLIGENCE & CONTENT ENGINE
// ============================================================
export type LinkedInContentType =
  | 'educational'
  | 'project_showcase'
  | 'case_study'
  | 'behind_the_scenes'
  | 'learning_update'
  | 'freelancing_insight'
  | 'technical_explanation'
  | 'portfolio_showcase'
  | 'question_discussion'
  | 'milestone';

export interface LinkedInPost {
  id: string;
  contentType: LinkedInContentType;
  topic: string;
  hook: string;
  content: string;
  hashtags: string[];
  cta: string;
  visualConceptIdea: string;
  status: 'DRAFT' | 'SCHEDULED' | 'APPROVED' | 'PUBLISHED' | 'CANCELLED';
  scheduledDate?: string; // YYYY-MM-DD
  publishedAt?: number;
  createdAt: number;
  verificationStatus: 'SUCCESS' | 'FAILED' | 'UNVERIFIED' | 'NOT_APPLICABLE';
}

export interface ContentScheduleItem {
  id: string;
  dayOfWeek: 'Monday' | 'Tuesday' | 'Wednesday' | 'Thursday' | 'Friday' | 'Saturday' | 'Sunday';
  dateStr?: string;
  contentType: LinkedInContentType;
  topic: string;
  hook: string;
  mainIdea: string;
  draft: string;
  cta: string;
  visualIdea: string;
  status: 'planned' | 'drafted' | 'ready_for_review' | 'published';
}

export interface BrandAnalysis {
  professionalThemes: string[];
  confirmedStrengths: string[];
  portfolioGaps: string[];
  contentOpportunities: string[];
  consistencyScore: number; // 0 - 100
  positioningSummary: string;
  recommendedNextTopics: string[];
}

// ============================================================
// 6. FREELANCING & PROPOSAL PIPELINE
// ============================================================
export type FreelancePipelineStage =
  | 'LEAD'
  | 'RESEARCH'
  | 'QUALIFIED'
  | 'DRAFT_PROPOSAL'
  | 'USER_REVIEW'
  | 'SUBMITTED'
  | 'FOLLOW_UP'
  | 'RESPONSE'
  | 'PROJECT'
  | 'COMPLETED';

export interface FreelanceOpportunity {
  id: string;
  title: string;
  clientOrCompany: string;
  source: string; // e.g. 'Upwork', 'Direct Email', 'LinkedIn', 'Referral'
  requiredSkills: string[];
  projectSummary: string;
  apparentRequirements: string[];
  budgetPublic?: string;
  deadlineText?: string;
  sourceUrl?: string;
  stage: FreelancePipelineStage;
  matchScore: number; // 0 - 100
  matchReasons: string[];
  possibleGaps: string[];
  questionsToCheck: string[];
  createdAt: number;
  updatedAt: number;
}

export interface Proposal {
  id: string;
  opportunityId: string;
  title: string;
  clientName: string;
  personalizedOpening: string;
  projectUnderstanding: string;
  relevantSkillsHighlight: string[];
  selectedPortfolioExamples: Array<{ title: string; link?: string; relevance: string }>;
  proposedApproach: string;
  clarificationQuestions: string[];
  conciseClosing: string;
  estimatedTimeline?: string;
  status: 'DRAFT' | 'PENDING_REVIEW' | 'APPROVED' | 'SUBMITTED';
  submittedAt?: number;
  createdAt: number;
}

export interface OutreachMessage {
  id: string;
  recipientName: string;
  recipientHandleOrEmail: string;
  platform: 'email' | 'linkedin' | 'portfolio' | 'other';
  reasonForContact: string;
  personalizedDraft: string;
  status: 'DRAFT' | 'REQUIRE_APPROVAL' | 'SENT' | 'FAILED' | 'COOLDOWN';
  createdAt: number;
  sentAt?: number;
}

// ============================================================
// 7. PORTFOLIO & CASE STUDY INTELLIGENCE
// ============================================================
export interface PortfolioProject {
  id: string;
  title: string;
  purpose: string;
  technologies: string[];
  userContribution: string;
  keyFeatures: string[];
  liveUrl?: string;
  githubUrl?: string;
  screenshotUrls?: string[];
  hasCaseStudy: boolean;
  updatedAt: number;
}

export interface CaseStudy {
  id: string;
  projectId: string;
  projectTitle: string;
  problem: string;
  approach: string;
  technologiesUsed: string[];
  keyFeatures: string[];
  challengesOvercome: string;
  resultsAndImpact: string;
  lessonsLearned: string;
  screenshotSuggestions: string[];
  formattedArticleMarkdown: string;
  createdAt: number;
}

// ============================================================
// 8. DOCUMENT & RESEARCH INTELLIGENCE
// ============================================================
export interface DocumentAnalysisResult {
  id: string;
  fileName: string;
  fileType: 'pdf' | 'docx' | 'xlsx' | 'image' | 'text';
  summary: string;
  extractedInformation: Record<string, string>;
  actionItems: string[];
  clarifiedSections: Array<{ section: string; explanation: string }>;
  potentialOpportunities: string[];
  analyzedAt: number;
}

export interface ResearchFact {
  fact: string;
  source: string;
  reliability: 'CONFIRMED' | 'INFERRED' | 'UNCERTAIN';
}

export interface ResearchReport {
  id: string;
  query: string;
  summary: string;
  facts: ResearchFact[];
  assumptions: string[];
  conclusions: string[];
  references: string[];
  createdAt: number;
}

// ============================================================
// 9. WORK MEMORY
// ============================================================
export interface WorkMemoryEntry {
  id: string;
  category: 'services' | 'preferences' | 'active_projects' | 'recurring_tasks' | 'content_themes' | 'client_notes';
  key: string;
  value: string;
  createdAt: number;
  updatedAt: number;
}

// ============================================================
// 10. DAILY WORKFLOW (BRIEF & REVIEW)
// ============================================================
export interface DailyBriefData {
  dateStr: string;
  greeting: string;
  importantEmailsCount: number;
  pendingFollowUpsCount: number;
  activeProjectsCount: number;
  scheduledContentToday: LinkedInPost | null;
  topTasksToday: string[];
  opportunitiesFoundCount: number;
  generatedAt: number;
}

export interface DailyReviewData {
  dateStr: string;
  completedTasks: string[];
  unfinishedTasks: string[];
  pendingRepliesCount: number;
  contentStatusSummary: string;
  opportunitiesDiscoveredCount: number;
  nextDayActionItems: string[];
  generatedAt: number;
}

// ============================================================
// 11. HUMAN APPROVAL SYSTEM
// ============================================================
export type ApprovalLevel = 'READ' | 'DRAFT' | 'SUGGEST' | 'REQUIRE_APPROVAL' | 'EXECUTE';

export interface ApprovalRequest {
  id: string;
  actionType: 'send_email' | 'publish_linkedin' | 'send_outreach' | 'submit_proposal' | 'delete_data';
  title: string;
  description: string;
  recipientOrTarget: string;
  previewContent: string;
  level: ApprovalLevel;
  status: 'PENDING' | 'APPROVED' | 'REJECTED' | 'EXECUTED';
  createdAt: number;
  resolvedAt?: number;
}

// ============================================================
// 12. AUDIT LOG
// ============================================================
export type ActionVerificationStatus = 'SUCCESS' | 'FAILED' | 'CANCELLED' | 'UNKNOWN';

export interface ActivityLogEntry {
  id: string;
  timestamp: number;
  action: string;
  target: string;
  source: 'user_command' | 'automated_schedule' | 'voice_prompt' | 'chat_prompt';
  userApproval: 'APPROVED' | 'NOT_REQUIRED' | 'BYPASS_DENIED';
  status: ActionVerificationStatus;
  resultMessage: string;
}

// ============================================================
// 13. WORK GRAPH
// ============================================================
export interface WorkGraphNode {
  id: string;
  type: 'Project' | 'Client' | 'Opportunity' | 'Email' | 'Proposal' | 'Post' | 'Task' | 'FollowUp';
  label: string;
  status?: string;
  metadata?: Record<string, any>;
}

export interface WorkGraphEdge {
  id: string;
  fromId: string;
  toId: string;
  relation:
    | 'PROJECT_TO_PORTFOLIO'
    | 'PROJECT_TO_CONTENT'
    | 'OPPORTUNITY_TO_PROPOSAL'
    | 'CLIENT_TO_EMAIL'
    | 'CLIENT_TO_FOLLOWUP'
    | 'PROJECT_TO_CLIENT';
}

export interface WorkGraphSnapshot {
  nodes: WorkGraphNode[];
  edges: WorkGraphEdge[];
}
