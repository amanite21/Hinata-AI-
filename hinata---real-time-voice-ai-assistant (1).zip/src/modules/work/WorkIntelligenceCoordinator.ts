/**
 * WorkIntelligenceCoordinator - Master Coordinator for Hinata's Personal Work & Freelancing System.
 *
 * Directs:
 * - WorkProfileManager
 * - IntegrationManager
 * - EmailIntelligenceManager
 * - FollowUpManager
 * - LinkedInContentManager
 * - FreelanceManager
 * - PortfolioManager
 * - DocumentIntelligence
 * - WorkMemory
 * - DailyWorkflowManager
 * - ApprovalManager
 * - WorkGraph
 *
 * Enforces the strict pipeline:
 * UNDERSTAND -> CHECK DATA -> CHECK PERMISSIONS -> PLAN -> PREPARE -> APPROVAL IF REQUIRED -> EXECUTE -> VERIFY -> LOG -> RESPOND.
 */

import { WorkProfileManager } from './WorkProfileManager';
import { IntegrationManager } from './IntegrationManager';
import { EmailIntelligenceManager } from './EmailIntelligenceManager';
import { FollowUpManager } from './FollowUpManager';
import { LinkedInContentManager } from './LinkedInContentManager';
import { FreelanceManager } from './FreelanceManager';
import { PortfolioManager } from './PortfolioManager';
import { DocumentIntelligence } from './DocumentIntelligence';
import { WorkMemory } from './WorkMemory';
import { DailyWorkflowManager } from './DailyWorkflowManager';
import { ApprovalManager } from './ApprovalManager';
import { WorkGraph } from './WorkGraph';

export interface WorkCommandResult {
  handled: boolean;
  action: string;
  response: string;
  category?: 'email' | 'freelance' | 'linkedin' | 'portfolio' | 'followup' | 'brief' | 'memory' | 'document';
  requiresApproval?: boolean;
  approvalRequestId?: string;
}

export class WorkIntelligenceCoordinator {
  private static instance: WorkIntelligenceCoordinator | null = null;

  public readonly profile = WorkProfileManager.getInstance();
  public readonly integrations = IntegrationManager.getInstance();
  public readonly email = EmailIntelligenceManager.getInstance();
  public readonly followUp = FollowUpManager.getInstance();
  public readonly linkedin = LinkedInContentManager.getInstance();
  public readonly freelance = FreelanceManager.getInstance();
  public readonly portfolio = PortfolioManager.getInstance();
  public readonly documents = DocumentIntelligence.getInstance();
  public readonly memory = WorkMemory.getInstance();
  public readonly workflow = DailyWorkflowManager.getInstance();
  public readonly approvals = ApprovalManager.getInstance();
  public readonly graph = WorkGraph.getInstance();

  private constructor() {}

  public static getInstance(): WorkIntelligenceCoordinator {
    if (!WorkIntelligenceCoordinator.instance) {
      WorkIntelligenceCoordinator.instance = new WorkIntelligenceCoordinator();
    }
    return WorkIntelligenceCoordinator.instance;
  }

  /**
   * Process natural language work requests from Chat, Voice, or Keyboard.
   */
  public async handleNaturalWorkCommand(rawText: string): Promise<WorkCommandResult> {
    const text = rawText.toLowerCase().trim();

    // 1. Morning Work Brief / Daily Plan / "Handle my work today"
    if (
      text.includes('morning brief') ||
      text.includes('work brief') ||
      text.includes('handle my work today') ||
      text.includes('plan my day') ||
      text.includes('what are my tasks today') ||
      text.includes('daily review')
    ) {
      if (text.includes('daily review') || text.includes('end of day')) {
        const review = this.workflow.generateDailyReview();
        return {
          handled: true,
          action: 'generate_daily_review',
          category: 'brief',
          response: `**End-of-Day Work Review (${review.dateStr})**:\n\n• **Completed Actions**: ${review.completedTasks.join(', ')}\n• **Pending Follow-ups**: ${review.pendingRepliesCount} waiting response\n• **Opportunities Discovered**: ${review.opportunitiesDiscoveredCount} active leads\n\n**Next Actions Planned**:\n${review.nextDayActionItems.map((a) => `• ${a}`).join('\n')}`,
        };
      }

      const brief = this.workflow.generateMorningBrief();
      return {
        handled: true,
        action: 'generate_morning_brief',
        category: 'brief',
        response: `**${brief.greeting}**\n\n• **Priority Emails**: ${brief.importantEmailsCount} requiring attention\n• **Pending Follow-ups**: ${brief.pendingFollowUpsCount} waiting response\n• **Active Freelance Pipeline**: ${brief.activeProjectsCount} opportunities in progress\n• **Scheduled Content**: ${brief.scheduledContentToday ? brief.scheduledContentToday.topic : 'None scheduled today'}\n\n**Top Focus Items Today**:\n${brief.topTasksToday.map((t) => `1. ${t}`).join('\n')}`,
      };
    }

    // 2. Email Intelligence: "Check my mail", "Any freelance inquiries", "Draft a reply"
    if (
      text.includes('check my mail') ||
      text.includes('check my email') ||
      text.includes('read my email') ||
      text.includes('freelance work in email') ||
      text.includes('draft a reply') ||
      text.includes('reply to client')
    ) {
      const emailStatus = this.integrations.getStatus('email');

      if (emailStatus.status !== 'CONNECTED' && this.email.getEmails().length === 0) {
        return {
          handled: true,
          action: 'check_email_unauthorized',
          category: 'email',
          response: `Email integration is currently **not connected**. Hinata never fabricates email data or pretends to read an unauthorized mailbox.\n\nTo connect your email provider safely, open the **Work Dashboard → Work Profile & Integrations** and connect your authorized email account.`,
        };
      }

      if (text.includes('freelance') || text.includes('client')) {
        const inquiries = this.email.getFreelanceInquiries();
        if (inquiries.length === 0) {
          return {
            handled: true,
            action: 'triage_freelance_emails',
            category: 'email',
            response: `I checked your authorized email triage list. Currently, there are **0 new incoming freelance inquiries**. All current messages have been categorized under general work or newsletters.`,
          };
        }

        const topInquiry = inquiries[0];
        const draft = this.email.generateReplyDraft(topInquiry.id);
        return {
          handled: true,
          action: 'triage_freelance_emails',
          category: 'email',
          response: `**Found 1 Potential Freelance Inquiry**:\n• **From**: ${topInquiry.sender.name} (${topInquiry.sender.email})\n• **Subject**: ${topInquiry.subject}\n• **Summary**: ${topInquiry.snippet}\n• **Classification**: LEAD (${Math.round(topInquiry.confidence * 100)}% confidence)\n\nI have generated 3 contextual reply drafts (Short, Professional, Friendly). You can review and approve them in the **Email & Outreach** tab.`,
        };
      }

      const important = this.email.getImportantEmails();
      return {
        handled: true,
        action: 'check_emails',
        category: 'email',
        response: `**Email Triage Summary**:\nFound **${important.length} priority messages**:\n${important.slice(0, 3).map((e) => `• [${e.category}] **${e.sender.name}**: "${e.subject}" (${e.classificationReason})`).join('\n')}\n\nWould you like me to prepare reply drafts for any of these?`,
      };
    }

    // 3. Freelancing & Leads: "Find freelance opportunities", "Find clients", "Prepare proposal"
    if (
      text.includes('find freelance') ||
      text.includes('find clients') ||
      text.includes('freelance opportunities') ||
      text.includes('prepare proposal') ||
      text.includes('draft proposal')
    ) {
      const opps = this.freelance.getOpportunities();

      if (text.includes('proposal') && opps.length > 0) {
        const targetOpp = opps[0];
        const proposal = this.freelance.generateProposal(targetOpp.id);
        return {
          handled: true,
          action: 'generate_proposal',
          category: 'freelance',
          requiresApproval: true,
          response: `**Proposal Prepared for "${targetOpp.title}" (${targetOpp.clientOrCompany})**:\n\n**Opening**:\n${proposal?.personalizedOpening}\n\n**Proposed Approach**:\n${proposal?.proposedApproach}\n\n**Clarification Questions Included**:\n${proposal?.clarificationQuestions.map((q) => `• ${q}`).join('\n')}\n\n*Saved to Proposals in Freelance Pipeline. Requires your review and explicit approval before sending.*`,
        };
      }

      return {
        handled: true,
        action: 'find_freelance_opportunities',
        category: 'freelance',
        response: `**Active Verified Freelance Opportunities (${opps.length} available)**:\n\n${opps.map((o) => `• **${o.title}** (${o.clientOrCompany})\n  Budget: ${o.budgetPublic || 'TBD'} | Match: ${o.matchScore}%\n  Why it matches: ${o.matchReasons[0]}`).join('\n\n')}\n\nWould you like me to draft a customized milestone proposal for any of these?`,
      };
    }

    // 4. LinkedIn & Content: "Make a LinkedIn post", "Plan my LinkedIn content", "Content calendar"
    if (
      text.includes('linkedin post') ||
      text.includes('plan my linkedin') ||
      text.includes('plan my week') ||
      text.includes('content calendar') ||
      text.includes('create tomorrow\'s post')
    ) {
      if (text.includes('plan') || text.includes('calendar')) {
        const schedule = this.linkedin.generateWeeklyPlan();
        return {
          handled: true,
          action: 'plan_linkedin_content',
          category: 'linkedin',
          response: `**Weekly Content Strategy Planned (Adaptive to your actual work)**:\n\n${schedule.map((s) => `• **${s.dayOfWeek}** [${s.contentType.replace('_', ' ').toUpperCase()}]: "${s.topic}"\n  *Hook*: "${s.hook}"\n  *Visual Concept*: ${s.visualIdea}`).join('\n\n')}\n\nAll drafts are ready for your review in the **LinkedIn & Content Studio**!`,
        };
      }

      const post = this.linkedin.generatePostDraft('project_showcase');
      return {
        handled: true,
        action: 'generate_linkedin_post',
        category: 'linkedin',
        requiresApproval: true,
        response: `**LinkedIn Post Draft Prepared** [PROJECT SHOWCASE]:\n\n**Hook**: ${post.hook}\n\n${post.content}\n\n**Visual Concept Idea**: ${post.visualConceptIdea}\n**Hashtags**: ${post.hashtags.join(' ')}\n\n*Saved as Draft. You can edit, copy, or schedule it from the Content Studio.*`,
      };
    }

    // 5. Follow-ups: "Show me what needs follow-up", "Follow up with client"
    if (
      text.includes('follow-up') ||
      text.includes('follow up') ||
      text.includes('needs follow up') ||
      text.includes('waiting for reply')
    ) {
      const pending = this.followUp.getPending();
      if (pending.length === 0) {
        return {
          handled: true,
          action: 'check_follow_ups',
          category: 'followup',
          response: `All client communications are currently up to date! There are **0 overdue follow-ups**.`,
        };
      }

      return {
        handled: true,
        action: 'check_follow_ups',
        category: 'followup',
        response: `**Pending Follow-Ups (${pending.length} active)**:\n\n${pending.map((p) => `• **${p.contactName}** (${p.topic}):\n  Next Action: ${p.nextActionSuggestion}\n  Draft: "${p.recommendedDraft?.slice(0, 100)}..."`).join('\n\n')}\n\nWould you like to review and send a polite follow-up?`,
      };
    }

    // 6. Case Studies & Portfolio: "Turn this project into a case study", "Analyze my portfolio"
    if (
      text.includes('case study') ||
      text.includes('analyze my portfolio') ||
      text.includes('personal brand')
    ) {
      if (text.includes('brand')) {
        const brand = this.linkedin.analyzePersonalBrand();
        return {
          handled: true,
          action: 'analyze_personal_brand',
          category: 'portfolio',
          response: `**Personal Brand Intelligence Analysis**:\n• **Positioning**: ${brand.positioningSummary}\n• **Confirmed Strengths**: ${brand.confirmedStrengths.join(', ')}\n• **Portfolio Gaps**: ${brand.portfolioGaps.join('; ') || 'None detected'}\n• **Consistency Score**: ${brand.consistencyScore}/100\n\n**Recommended Next Focus Topics**:\n${brand.recommendedNextTopics.map((t) => `• ${t}`).join('\n')}`,
        };
      }

      const projects = this.portfolio.getProjects();
      if (projects.length > 0) {
        const cs = this.portfolio.generateCaseStudy(projects[0].id);
        return {
          handled: true,
          action: 'generate_case_study',
          category: 'portfolio',
          response: `**Case Study Generated for "${projects[0].title}"**:\n\n• **Problem**: ${cs?.problem}\n• **Approach**: ${cs?.approach}\n• **Key Results**: ${cs?.resultsAndImpact}\n• **Lessons**: ${cs?.lessonsLearned}\n\nFull formatted article markdown is ready in the **Portfolio & Case Studies** tab.`,
        };
      }
    }

    // 7. Work Memory: "Remember this...", "Forget this..."
    if (text.startsWith('remember that') || text.startsWith('remember this') || text.startsWith('remember:')) {
      const cleanVal = rawText.replace(/^remember\s*(that|this|:)?\s*/i, '').trim();
      if (cleanVal) {
        this.memory.remember('preferences', cleanVal.slice(0, 30), cleanVal);
        return {
          handled: true,
          action: 'remember_work_memory',
          category: 'memory',
          response: `Saved to Work Memory: "${cleanVal}". I will incorporate this stable preference across future work drafts, proposals, and briefs.`,
        };
      }
    }

    return {
      handled: false,
      action: 'unhandled',
      response: '',
    };
  }
}
