/**
 * WorkGraph - Cross-System Relationship Model
 *
 * Connects work entities into a coherent conceptual graph:
 * - PROJECT -> PORTFOLIO
 * - PROJECT -> CONTENT (LinkedIn Posts)
 * - OPPORTUNITY -> PROPOSAL
 * - CLIENT -> EMAIL
 * - CLIENT -> FOLLOWUP
 * - PROJECT -> CLIENT
 */

import { WorkGraphSnapshot, WorkGraphNode, WorkGraphEdge } from './types';
import { PortfolioManager } from './PortfolioManager';
import { FreelanceManager } from './FreelanceManager';
import { EmailIntelligenceManager } from './EmailIntelligenceManager';
import { FollowUpManager } from './FollowUpManager';
import { LinkedInContentManager } from './LinkedInContentManager';

export class WorkGraph {
  private static instance: WorkGraph | null = null;

  private constructor() {}

  public static getInstance(): WorkGraph {
    if (!WorkGraph.instance) {
      WorkGraph.instance = new WorkGraph();
    }
    return WorkGraph.instance;
  }

  /**
   * Generates a snapshot of the current work relationship graph.
   */
  public getSnapshot(): WorkGraphSnapshot {
    const nodes: WorkGraphNode[] = [];
    const edges: WorkGraphEdge[] = [];

    const portfolioMgr = PortfolioManager.getInstance();
    const freelanceMgr = FreelanceManager.getInstance();
    const emailMgr = EmailIntelligenceManager.getInstance();
    const followUpMgr = FollowUpManager.getInstance();
    const linkedinMgr = LinkedInContentManager.getInstance();

    // 1. Project Nodes
    const projects = portfolioMgr.getProjects();
    for (const proj of projects) {
      nodes.push({
        id: proj.id,
        type: 'Project',
        label: proj.title,
        status: proj.hasCaseStudy ? 'Documented' : 'Active',
        metadata: { tech: proj.technologies },
      });
    }

    // 2. Opportunity Nodes & Proposals
    const opps = freelanceMgr.getOpportunities();
    for (const opp of opps) {
      nodes.push({
        id: opp.id,
        type: 'Opportunity',
        label: opp.title,
        status: opp.stage,
        metadata: { client: opp.clientOrCompany, budget: opp.budgetPublic },
      });
    }

    const proposals = freelanceMgr.getProposals();
    for (const prop of proposals) {
      nodes.push({
        id: prop.id,
        type: 'Proposal',
        label: prop.title,
        status: prop.status,
      });

      edges.push({
        id: `e-opp-prop-${prop.id}`,
        fromId: prop.opportunityId,
        toId: prop.id,
        relation: 'OPPORTUNITY_TO_PROPOSAL',
      });
    }

    // 3. Email Nodes
    const emails = emailMgr.getImportantEmails().slice(0, 5);
    for (const em of emails) {
      nodes.push({
        id: em.id,
        type: 'Email',
        label: em.subject,
        status: em.category,
        metadata: { sender: em.sender.name },
      });
    }

    // 4. Follow-up Nodes
    const followUps = followUpMgr.getAll().slice(0, 5);
    for (const fu of followUps) {
      nodes.push({
        id: fu.id,
        type: 'FollowUp',
        label: `Follow-up: ${fu.contactName}`,
        status: fu.responseStatus,
      });
    }

    // 5. Post Nodes
    const posts = linkedinMgr.getPosts().slice(0, 5);
    for (const post of posts) {
      nodes.push({
        id: post.id,
        type: 'Post',
        label: `Post: ${post.topic}`,
        status: post.status,
      });

      // Link to first project if matching
      if (projects.length > 0) {
        edges.push({
          id: `e-proj-post-${post.id}`,
          fromId: projects[0].id,
          toId: post.id,
          relation: 'PROJECT_TO_CONTENT',
        });
      }
    }

    return { nodes, edges };
  }
}
