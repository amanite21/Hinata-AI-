/**
 * FollowUpManager - Follow-up Intelligence & Relationship Tracking
 *
 * Rules:
 * - Tracks who was contacted, date, topic, response status, next action, follow-up date.
 * - Detects overdue/pending follow-ups ("Client hasn't replied for 3 days").
 * - Anti-spam safeguard: respects reasonable communication intervals, prevents spamming.
 */

import { FollowUpItem } from './types';

const STORAGE_KEY = 'hinata_follow_ups_v1';
const MIN_FOLLOW_UP_INTERVAL_DAYS = 3; // Minimum days between polite follow-ups

export class FollowUpManager {
  private static instance: FollowUpManager | null = null;
  private items: FollowUpItem[] = [];
  private listeners: Array<() => void> = [];

  private constructor() {
    this.load();
  }

  public static getInstance(): FollowUpManager {
    if (!FollowUpManager.instance) {
      FollowUpManager.instance = new FollowUpManager();
    }
    return FollowUpManager.instance;
  }

  private load(): void {
    if (typeof window === 'undefined') return;
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        this.items = JSON.parse(raw);
      }
    } catch (e) {
      console.warn('[FollowUpManager] Load error:', e);
    }
  }

  private save(): void {
    if (typeof window === 'undefined') return;
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(this.items));
      this.notify();
    } catch (e) {
      console.warn('[FollowUpManager] Save error:', e);
    }
  }

  public getAll(): FollowUpItem[] {
    return [...this.items];
  }

  public getPending(): FollowUpItem[] {
    return this.items.filter((item) => !item.isCompleted && item.responseStatus !== 'resolved');
  }

  public getOverdue(): FollowUpItem[] {
    const now = Date.now();
    return this.items.filter(
      (item) => !item.isCompleted && item.responseStatus !== 'resolved' && item.dueFollowUpDate <= now
    );
  }

  /**
   * Adds or registers a follow-up tracker item.
   */
  public addFollowUp(params: {
    contactName: string;
    contactEmailOrHandle: string;
    topic: string;
    daysUntilFollowUp?: number;
    notes?: string;
  }): FollowUpItem {
    const now = Date.now();
    const days = Math.max(MIN_FOLLOW_UP_INTERVAL_DAYS, params.daysUntilFollowUp || 3);
    const dueDate = now + days * 24 * 60 * 60 * 1000;

    const draft = `Hi ${params.contactName},\n\nJust following up on our previous conversation regarding ${params.topic}. Please let me know if you have had an opportunity to review or if there are any questions I can assist with!\n\nBest regards.`;

    const item: FollowUpItem = {
      id: 'fu-' + Date.now() + '-' + Math.random().toString(36).substring(2, 6),
      contactName: params.contactName,
      contactEmailOrHandle: params.contactEmailOrHandle,
      topic: params.topic,
      lastContactDate: now,
      dueFollowUpDate: dueDate,
      responseStatus: 'waiting_reply',
      nextActionSuggestion: `Send polite follow-up on ${params.topic}`,
      recommendedDraft: draft,
      isCompleted: false,
      notes: params.notes,
    };

    this.items.unshift(item);
    this.save();
    return item;
  }

  public markCompleted(id: string): void {
    const item = this.items.find((i) => i.id === id);
    if (item) {
      item.isCompleted = true;
      item.responseStatus = 'resolved';
      this.save();
    }
  }

  public markReplied(id: string): void {
    const item = this.items.find((i) => i.id === id);
    if (item) {
      item.responseStatus = 'replied';
      item.isCompleted = true;
      this.save();
    }
  }

  public deleteItem(id: string): void {
    this.items = this.items.filter((i) => i.id !== id);
    this.save();
  }

  public subscribe(listener: () => void): () => void {
    this.listeners.push(listener);
    return () => {
      this.listeners = this.listeners.filter((l) => l !== listener);
    };
  }

  private notify(): void {
    for (const l of this.listeners) {
      try { l(); } catch {}
    }
  }
}
