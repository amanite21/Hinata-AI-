/**
 * ApprovalManager & ActivityLog - Human Approval Gates & Immutable Audit Trail
 *
 * Rules:
 * - Approval levels: READ, DRAFT, SUGGEST, REQUIRE_APPROVAL, EXECUTE.
 * - Sensitive external actions (sending emails, publishing posts, cold outreach) REQUIRE human approval.
 * - ActivityLog: Records timestamp, action, target, source, approval state, verification status, and result.
 * - STRICT SECURITY: NEVER logs passwords, API keys, tokens, or private secrets.
 */

import {
  ApprovalRequest,
  ApprovalLevel,
  ActivityLogEntry,
  ActionVerificationStatus,
} from './types';

const STORAGE_APPROVALS_KEY = 'hinata_approvals_v1';
const STORAGE_ACTIVITY_KEY = 'hinata_activity_log_v1';

export class ApprovalManager {
  private static instance: ApprovalManager | null = null;
  private pendingRequests: ApprovalRequest[] = [];
  private activityLogs: ActivityLogEntry[] = [];
  private listeners: Array<() => void> = [];

  private constructor() {
    this.load();
  }

  public static getInstance(): ApprovalManager {
    if (!ApprovalManager.instance) {
      ApprovalManager.instance = new ApprovalManager();
    }
    return ApprovalManager.instance;
  }

  private load(): void {
    if (typeof window === 'undefined') return;
    try {
      const rawReqs = localStorage.getItem(STORAGE_APPROVALS_KEY);
      if (rawReqs) this.pendingRequests = JSON.parse(rawReqs);
      const rawLogs = localStorage.getItem(STORAGE_ACTIVITY_KEY);
      if (rawLogs) this.activityLogs = JSON.parse(rawLogs);
    } catch (e) {
      console.warn('[ApprovalManager] Load error:', e);
    }
  }

  private save(): void {
    if (typeof window === 'undefined') return;
    try {
      localStorage.setItem(STORAGE_APPROVALS_KEY, JSON.stringify(this.pendingRequests));
      localStorage.setItem(STORAGE_ACTIVITY_KEY, JSON.stringify(this.activityLogs));
      this.notify();
    } catch (e) {
      console.warn('[ApprovalManager] Save error:', e);
    }
  }

  public getPendingRequests(): ApprovalRequest[] {
    return this.pendingRequests.filter((r) => r.status === 'PENDING');
  }

  public getAllRequests(): ApprovalRequest[] {
    return [...this.pendingRequests];
  }

  public getActivityLogs(): ActivityLogEntry[] {
    return [...this.activityLogs];
  }

  /**
   * Request human approval for an external or sensitive action.
   */
  public requestApproval(params: {
    actionType: ApprovalRequest['actionType'];
    title: string;
    description: string;
    recipientOrTarget: string;
    previewContent: string;
    level?: ApprovalLevel;
  }): ApprovalRequest {
    const req: ApprovalRequest = {
      id: 'appr-' + Date.now() + '-' + Math.random().toString(36).substring(2, 6),
      actionType: params.actionType,
      title: params.title,
      description: params.description,
      recipientOrTarget: params.recipientOrTarget,
      previewContent: params.previewContent,
      level: params.level || 'REQUIRE_APPROVAL',
      status: 'PENDING',
      createdAt: Date.now(),
    };

    this.pendingRequests.unshift(req);
    this.save();
    return req;
  }

  /**
   * Approve a pending action, moving it to execution or approved state.
   */
  public approve(id: string): boolean {
    const req = this.pendingRequests.find((r) => r.id === id);
    if (req && req.status === 'PENDING') {
      req.status = 'APPROVED';
      req.resolvedAt = Date.now();

      this.logActivity({
        action: `Approved Action: ${req.title}`,
        target: req.recipientOrTarget,
        source: 'user_command',
        userApproval: 'APPROVED',
        status: 'SUCCESS',
        resultMessage: `User explicitly approved execution of "${req.title}".`,
      });

      this.save();
      return true;
    }
    return false;
  }

  /**
   * Reject a pending action.
   */
  public reject(id: string, reason?: string): boolean {
    const req = this.pendingRequests.find((r) => r.id === id);
    if (req && req.status === 'PENDING') {
      req.status = 'REJECTED';
      req.resolvedAt = Date.now();

      this.logActivity({
        action: `Rejected Action: ${req.title}`,
        target: req.recipientOrTarget,
        source: 'user_command',
        userApproval: 'BYPASS_DENIED',
        status: 'CANCELLED',
        resultMessage: reason ? `Rejected by user: ${reason}` : 'Cancelled by user during review.',
      });

      this.save();
      return true;
    }
    return false;
  }

  /**
   * Logs an action in the audit trail with verified outcome.
   */
  public logActivity(entry: Omit<ActivityLogEntry, 'id' | 'timestamp'>): ActivityLogEntry {
    const logItem: ActivityLogEntry = {
      id: 'log-' + Date.now() + '-' + Math.random().toString(36).substring(2, 6),
      timestamp: Date.now(),
      action: entry.action,
      target: entry.target,
      source: entry.source,
      userApproval: entry.userApproval,
      status: entry.status,
      resultMessage: entry.resultMessage,
    };

    this.activityLogs.unshift(logItem);
    // Keep last 150 entries
    if (this.activityLogs.length > 150) {
      this.activityLogs = this.activityLogs.slice(0, 150);
    }
    this.save();
    return logItem;
  }

  public clearActivityLogs(): void {
    this.activityLogs = [];
    this.save();
  }

  public subscribe(listener: () => void): () => void {
    this.listeners.push(listener);
    return () => {
      this.listeners = this.listeners.filter((l) => l !== listener);
    };
  }

  private notify(): void {
    for (const l of this.listeners) {
      try { l(); } catch {}
    }
  }
}
