/**
 * FreelanceManager, OpportunityMatcher, ProposalManager & OutreachManager
 *
 * Rules:
 * - Full pipeline: LEAD -> RESEARCH -> QUALIFIED -> DRAFT_PROPOSAL -> USER_REVIEW -> SUBMITTED -> FOLLOW_UP -> RESPONSE -> PROJECT -> COMPLETED.
 * - Compares opportunities against actual user skills, projects, and availability.
 * - Provides MATCH REASONS, POSSIBLE Gaps, and QUESTIONS TO CHECK.
 * - Proposals use personalized opening, clear project understanding, relevant portfolio examples, and clarification questions.
 * - STRICT ANTI-SPAM: Enforces daily outreach limits (max 5/day), duplicate detection, and mandatory user approval before sending.
 */

import {
  FreelanceOpportunity,
  FreelancePipelineStage,
  Proposal,
  OutreachMessage,
} from './types';
import { WorkProfileManager } from './WorkProfileManager';

const STORAGE_OPPS_KEY = 'hinata_freelance_opps_v1';
const STORAGE_PROPOSALS_KEY = 'hinata_proposals_v1';
const STORAGE_OUTREACH_KEY = 'hinata_outreach_v1';

export const MAX_DAILY_OUTREACH = 5;

export class FreelanceManager {
  private static instance: FreelanceManager | null = null;
  private opportunities: FreelanceOpportunity[] = [];
  private proposals: Proposal[] = [];
  private outreachMessages: OutreachMessage[] = [];
  private listeners: Array<() => void> = [];

  private constructor() {
    this.load();
    if (this.opportunities.length === 0) {
      this.seedInitialOpportunities();
    }
  }

  public static getInstance(): FreelanceManager {
    if (!FreelanceManager.instance) {
      FreelanceManager.instance = new FreelanceManager();
    }
    return FreelanceManager.instance;
  }

  private load(): void {
    if (typeof window === 'undefined') return;
    try {
      const rawOpps = localStorage.getItem(STORAGE_OPPS_KEY);
      if (rawOpps) this.opportunities = JSON.parse(rawOpps);
      const rawProps = localStorage.getItem(STORAGE_PROPOSALS_KEY);
      if (rawProps) this.proposals = JSON.parse(rawProps);
      const rawOut = localStorage.getItem(STORAGE_OUTREACH_KEY);
      if (rawOut) this.outreachMessages = JSON.parse(rawOut);
    } catch (e) {
      console.warn('[FreelanceManager] Load error:', e);
    }
  }

  private save(): void {
    if (typeof window === 'undefined') return;
    try {
      localStorage.setItem(STORAGE_OPPS_KEY, JSON.stringify(this.opportunities));
      localStorage.setItem(STORAGE_PROPOSALS_KEY, JSON.stringify(this.proposals));
      localStorage.setItem(STORAGE_OUTREACH_KEY, JSON.stringify(this.outreachMessages));
      this.notify();
    } catch (e) {
      console.warn('[FreelanceManager] Save error:', e);
    }
  }

  private seedInitialOpportunities(): void {
    const opp1 = this.createOpportunity({
      title: 'Full-Stack React & Node AI Dashboard MVP',
      clientOrCompany: 'Apex HealthTech',
      source: 'Direct Client Inquiry',
      requiredSkills: ['React', 'TypeScript', 'Node.js', 'AI Integration'],
      projectSummary: 'Need an experienced engineer to build a real-time analytics dashboard with AI-powered insight summaries and responsive UI.',
      apparentRequirements: [
        'Build frontend in React 18+ and Tailwind CSS',
        'Integrate server-side AI model proxy with streaming responses',
        'Ensure sub-second response times and secure credential isolation',
      ],
      budgetPublic: '$3,500 - $5,000 (Fixed Milestone)',
      deadlineText: '3 weeks from kickoff',
      sourceUrl: 'https://client-inquiry.example.com/req-101',
    });

    const opp2 = this.createOpportunity({
      title: 'Real-Time Audio & WebRTC Frontend Architect',
      clientOrCompany: 'VoiceSphere Labs',
      source: 'LinkedIn Network Referral',
      requiredSkills: ['TypeScript', 'Web Audio API', 'WebSockets', 'UI/UX Design'],
      projectSummary: 'Architecting an interactive audio streaming web app with fluid visualizer animations and low-latency audio capture.',
      apparentRequirements: [
        'Implement Web Audio API pipeline with PCM streaming',
        'Handle mobile browser autoplay policy cleanly',
        'Deliver responsive cyber/neon visualizer interface',
      ],
      budgetPublic: '$75 - $110 / hr',
      deadlineText: 'Kickoff next month',
      sourceUrl: 'https://voicesphere.example.com/project-brief',
    });

    this.opportunities = [opp1, opp2];
    this.save();
  }

  public getOpportunities(): FreelanceOpportunity[] {
    return [...this.opportunities];
  }

  public getProposals(): Proposal[] {
    return [...this.proposals];
  }

  public getOutreach(): OutreachMessage[] {
    return [...this.outreachMessages];
  }

  /**
   * Matches an opportunity against the user's WorkProfile, returning match score and gaps.
   */
  public evaluateOpportunity(
    opp: Pick<FreelanceOpportunity, 'requiredSkills' | 'projectSummary' | 'apparentRequirements'>
  ): {
    matchScore: number;
    matchReasons: string[];
    possibleGaps: string[];
    questionsToCheck: string[];
  } {
    const profile = WorkProfileManager.getInstance().getProfile();
    const userSkills = profile.skills.map((s) => s.toLowerCase());
    const matchedSkills: string[] = [];
    const missingSkills: string[] = [];

    for (const req of opp.requiredSkills) {
      if (userSkills.some((us) => us.includes(req.toLowerCase()) || req.toLowerCase().includes(us))) {
        matchedSkills.push(req);
      } else {
        missingSkills.push(req);
      }
    }

    const matchRatio = opp.requiredSkills.length > 0 ? matchedSkills.length / opp.requiredSkills.length : 0.8;
    const matchScore = Math.min(100, Math.round(matchRatio * 75 + 25));

    const matchReasons = [
      `Matches ${matchedSkills.length} of ${opp.requiredSkills.length} required skills: ${matchedSkills.join(', ')}`,
      `Aligns with preferred services: ${profile.services.slice(0, 2).join(' & ')}`,
      `Communication style (${profile.preferredCommunicationStyle}) fits collaborative milestone delivery`,
    ];

    const possibleGaps = missingSkills.length > 0 ? [`Skills to clarify or verify: ${missingSkills.join(', ')}`] : [];
    if (profile.availability === 'booked_out') {
      possibleGaps.push('Current availability is marked as booked out');
    }

    const questionsToCheck = [
      'Are the API specifications and backend schemas already documented?',
      'Who is the primary stakeholder for design review and milestone sign-off?',
      'What is the target deployment infrastructure (Cloud Run, Vercel, AWS)?',
    ];

    return { matchScore, matchReasons, possibleGaps, questionsToCheck };
  }

  /**
   * Creates a new freelance opportunity with auto-evaluation.
   */
  public createOpportunity(params: {
    title: string;
    clientOrCompany: string;
    source: string;
    requiredSkills: string[];
    projectSummary: string;
    apparentRequirements: string[];
    budgetPublic?: string;
    deadlineText?: string;
    sourceUrl?: string;
    stage?: FreelancePipelineStage;
  }): FreelanceOpportunity {
    const evaluation = this.evaluateOpportunity(params);
    const opp: FreelanceOpportunity = {
      id: 'opp-' + Date.now() + '-' + Math.random().toString(36).substring(2, 6),
      title: params.title,
      clientOrCompany: params.clientOrCompany,
      source: params.source,
      requiredSkills: params.requiredSkills,
      projectSummary: params.projectSummary,
      apparentRequirements: params.apparentRequirements,
      budgetPublic: params.budgetPublic,
      deadlineText: params.deadlineText,
      sourceUrl: params.sourceUrl,
      stage: params.stage || 'LEAD',
      matchScore: evaluation.matchScore,
      matchReasons: evaluation.matchReasons,
      possibleGaps: evaluation.possibleGaps,
      questionsToCheck: evaluation.questionsToCheck,
      createdAt: Date.now(),
      updatedAt: Date.now(),
    };

    this.opportunities.unshift(opp);
    this.save();
    return opp;
  }

  public updateOpportunityStage(id: string, stage: FreelancePipelineStage): void {
    const opp = this.opportunities.find((o) => o.id === id);
    if (opp) {
      opp.stage = stage;
      opp.updatedAt = Date.now();
      this.save();
    }
  }

  /**
   * Generates a tailored, professional proposal for an opportunity without generic fluff.
   */
  public generateProposal(opportunityId: string): Proposal | null {
    const opp = this.opportunities.find((o) => o.id === opportunityId);
    if (!opp) return null;

    const profile = WorkProfileManager.getInstance().getProfile();

    const opening = `Hi ${opp.clientOrCompany} team,\n\nI reviewed your requirements for ${opp.title}. Based on your goal of ${opp.projectSummary.slice(0, 100).toLowerCase()}..., I have architected similar systems and can deliver this cleanly.`;

    const understanding = `Project Understanding:\nYou need an engineer who can handle both clean frontend state architecture and dependable backend integration while maintaining rapid load times and robust error boundaries.`;

    const skillsHighlight = opp.requiredSkills.filter((s) =>
      profile.skills.some((ps) => ps.toLowerCase().includes(s.toLowerCase()))
    );

    const portfolioExamples = profile.portfolioLinks.map((link) => ({
      title: link.label,
      link: link.url,
      relevance: `Direct demonstration of ${link.category || 'production engineering'}`,
    }));

    const approach = `Proposed Milestone Approach:\n1. Milestone 1 (Discovery & Architecture): Core schema setup, state machine design, and high-fidelity prototype.\n2. Milestone 2 (Implementation & Integration): Full API proxy integration, streaming state, and error handling.\n3. Milestone 3 (Verification & Polish): Latency optimization, edge-case testing, and deployment handoff.`;

    const clarificationQuestions = [
      'Do you have existing Figma designs or wireframes, or will UI styling be part of the initial milestone?',
      'Are there specific third-party APIs or authentication providers that need to be supported?',
    ];

    const closing = `I am available to start immediately on the initial architecture and can provide a transparent milestone schedule. Looking forward to discussing next steps!\n\nBest regards,\n${profile.displayName}\n${profile.title}`;

    const proposal: Proposal = {
      id: 'prop-' + Date.now() + '-' + Math.random().toString(36).substring(2, 6),
      opportunityId: opp.id,
      title: `Proposal: ${opp.title}`,
      clientName: opp.clientOrCompany,
      personalizedOpening: opening,
      projectUnderstanding: understanding,
      relevantSkillsHighlight: skillsHighlight,
      selectedPortfolioExamples: portfolioExamples,
      proposedApproach: approach,
      clarificationQuestions,
      conciseClosing: closing,
      estimatedTimeline: opp.deadlineText || '2-3 weeks',
      status: 'DRAFT',
      createdAt: Date.now(),
    };

    this.proposals = this.proposals.filter((p) => p.opportunityId !== opportunityId);
    this.proposals.unshift(proposal);
    this.updateOpportunityStage(opportunityId, 'DRAFT_PROPOSAL');
    this.save();
    return proposal;
  }

  /**
   * Generates a personalized outreach message respecting daily rate limits.
   */
  public prepareOutreach(params: {
    recipientName: string;
    recipientHandleOrEmail: string;
    platform: 'email' | 'linkedin' | 'portfolio' | 'other';
    reasonForContact: string;
  }): { success: boolean; message: string; outreach?: OutreachMessage } {
    // Check daily rate limit
    const today = new Date().toDateString();
    const sentToday = this.outreachMessages.filter(
      (m) => m.sentAt && new Date(m.sentAt).toDateString() === today
    );

    if (sentToday.length >= MAX_DAILY_OUTREACH) {
      return {
        success: false,
        message: `Daily outreach limit reached (${MAX_DAILY_OUTREACH} messages/day). Safeguard active to prevent spam. Try again tomorrow.`,
      };
    }

    // Check duplicate
    const existing = this.outreachMessages.find(
      (m) => m.recipientHandleOrEmail.toLowerCase() === params.recipientHandleOrEmail.toLowerCase()
    );
    if (existing) {
      return {
        success: false,
        message: `A previous outreach was already created for ${params.recipientHandleOrEmail} on ${new Date(existing.createdAt).toLocaleDateString()}. Cooldown active to avoid duplicate contact.`,
      };
    }

    const profile = WorkProfileManager.getInstance().getProfile();
    const draft = `Hi ${params.recipientName},\n\nI came across your work in ${params.reasonForContact} and was impressed by your recent projects.\n\nAs a ${profile.title}, I specialize in ${profile.services[0] || 'Full-Stack Systems'}. If you ever need experienced engineering support or an extra set of hands on high-impact initiatives, I would welcome the chance to connect.\n\nNo pitch—just wanted to introduce myself and say hello!\n\nBest regards,\n${profile.displayName}`;

    const outreach: OutreachMessage = {
      id: 'outreach-' + Date.now() + '-' + Math.random().toString(36).substring(2, 6),
      recipientName: params.recipientName,
      recipientHandleOrEmail: params.recipientHandleOrEmail,
      platform: params.platform,
      reasonForContact: params.reasonForContact,
      personalizedDraft: draft,
      status: 'REQUIRE_APPROVAL',
      createdAt: Date.now(),
    };

    this.outreachMessages.unshift(outreach);
    this.save();
    return {
      success: true,
      message: `Personalized outreach prepared for ${params.recipientName}. Approval required before sending.`,
      outreach,
    };
  }

  public updateProposalStatus(proposalId: string, status: Proposal['status']): void {
    const prop = this.proposals.find((p) => p.id === proposalId);
    if (prop) {
      prop.status = status;
      if (status === 'SUBMITTED') {
        prop.submittedAt = Date.now();
        this.updateOpportunityStage(prop.opportunityId, 'SUBMITTED');
      } else if (status === 'APPROVED') {
        this.updateOpportunityStage(prop.opportunityId, 'USER_REVIEW');
      }
      this.save();
    }
  }

  public deleteOpportunity(id: string): void {
    this.opportunities = this.opportunities.filter((o) => o.id !== id);
    this.proposals = this.proposals.filter((p) => p.opportunityId !== id);
    this.save();
  }

  public subscribe(listener: () => void): () => void {
    this.listeners.push(listener);
    return () => {
      this.listeners = this.listeners.filter((l) => l !== listener);
    };
  }

  private notify(): void {
    for (const l of this.listeners) {
      try { l(); } catch {}
    }
  }
}
