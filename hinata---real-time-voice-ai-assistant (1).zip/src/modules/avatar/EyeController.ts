/**
 * EyeController - Gaze management, micro-saccadic eye movements, pupil dilation
 * Synchronizes with LiveSessionState and Hinata's current emotional state.
 */

import { LiveSessionState, EmotionalState } from '../../types';

export interface EyeState {
  gazeX: number; // -1 to 1 (horizontal gaze offset)
  gazeY: number; // -1 to 1 (vertical gaze offset)
  pupilDilation: number; // 0.8 to 1.3
  squint: number; // 0 to 1
  sparkleOpacity: number; // 0 to 1
}

export class EyeController {
  private currentX: number = 0;
  private currentY: number = 0;
  private targetX: number = 0;
  private targetY: number = 0;
  private saccadeTimer: number = 0;
  private nextSaccadeInterval: number = 2200; // ms

  constructor() {
    this.resetSaccadeInterval();
  }

  private resetSaccadeInterval(): void {
    this.nextSaccadeInterval = 1800 + Math.random() * 2400;
  }

  public update(
    deltaMs: number,
    state: LiveSessionState,
    emotion: EmotionalState,
    intensity: number = 2
  ): EyeState {
    this.saccadeTimer += deltaMs;

    // Determine target gaze according to session state
    if (this.saccadeTimer >= this.nextSaccadeInterval) {
      this.saccadeTimer = 0;
      this.resetSaccadeInterval();

      if (state === 'listening') {
        // Listening: Attentive forward gaze directly engaging user with micro-drift
        this.targetX = (Math.random() - 0.5) * 0.15;
        this.targetY = (Math.random() - 0.5) * 0.1;
      } else if (state === 'speaking') {
        // Speaking: Natural subtle cognitive glance away occasionally
        const glanceChoice = Math.random();
        if (glanceChoice < 0.3) {
          this.targetX = -0.25 - Math.random() * 0.2; // Glance slightly left
          this.targetY = -0.15 - Math.random() * 0.15; // Glance slightly up
        } else if (glanceChoice < 0.5) {
          this.targetX = 0.2 + Math.random() * 0.15;
          this.targetY = -0.05;
        } else {
          this.targetX = (Math.random() - 0.5) * 0.2;
          this.targetY = (Math.random() - 0.5) * 0.15;
        }
      } else {
        // Disconnected or connecting: Gentle ambient roving
        this.targetX = Math.sin(Date.now() / 4000) * 0.2;
        this.targetY = Math.cos(Date.now() / 5000) * 0.15;
      }
    }

    // Smooth lerp toward target gaze
    const lerpFactor = Math.min(1, (deltaMs / 1000) * 8.5);
    this.currentX += (this.targetX - this.currentX) * lerpFactor;
    this.currentY += (this.targetY - this.currentY) * lerpFactor;

    // Compute pupil dilation & squint based on emotion & intensity
    let pupilDilation = 1.0;
    let squint = 0;
    let sparkleOpacity = 0.5;

    if (state === 'listening') {
      pupilDilation = 1.15; // Attentive focus
    }

    switch (emotion) {
      case 'happy':
      case 'amused':
      case 'affectionate':
        squint = 0.35 + (intensity / 5) * 0.3;
        pupilDilation += 0.1;
        sparkleOpacity = 0.85;
        break;
      case 'excited':
      case 'surprised':
        pupilDilation += 0.25;
        squint = 0;
        sparkleOpacity = 1.0;
        break;
      case 'curious':
        pupilDilation += 0.15;
        sparkleOpacity = 0.75;
        break;
      case 'calm':
        squint = 0.15;
        pupilDilation = 0.95;
        break;
      case 'serious':
      case 'concerned':
        squint = 0.2;
        pupilDilation = 1.05;
        sparkleOpacity = 0.3;
        break;
      case 'embarrassed':
        this.targetY = 0.25; // Look down bashfully
        squint = 0.25;
        pupilDilation += 0.1;
        sparkleOpacity = 0.9;
        break;
      case 'proud':
        this.targetY = -0.15; // Confident upward gaze
        pupilDilation += 0.15;
        sparkleOpacity = 0.9;
        break;
      default:
        break;
    }

    return {
      gazeX: this.currentX,
      gazeY: this.currentY,
      pupilDilation: Math.max(0.8, Math.min(1.35, pupilDilation)),
      squint: Math.max(0, Math.min(0.8, squint)),
      sparkleOpacity,
    };
  }
}
