/**
 * FacialExpressionController - Maps EmotionManager emotional states into
 * expressive facial morph targets, eye shapes, blush accents, and eyebrow poses.
 */

import { EmotionalState, EmotionalIntensity } from '../../types';

export interface FacialPose {
  eyebrowLeftY: number; // -10 to +10 px
  eyebrowLeftAngle: number; // degrees
  eyebrowRightY: number;
  eyebrowRightAngle: number;
  restingSmile: number; // -0.4 to 0.8
  blushOpacity: number; // 0 to 1
  blushColor: string; // rgba
  eyeSquint: number; // 0 to 1
  sparkleOpacity: number; // 0 to 1
  glowColor: string;
}

export class FacialExpressionController {
  private currentPose: FacialPose = {
    eyebrowLeftY: 0,
    eyebrowLeftAngle: 0,
    eyebrowRightY: 0,
    eyebrowRightAngle: 0,
    restingSmile: 0.2,
    blushOpacity: 0.15,
    blushColor: 'rgba(244, 114, 182, 0.25)',
    eyeSquint: 0,
    sparkleOpacity: 0.4,
    glowColor: 'rgba(0, 229, 255, 0.45)',
  };

  public update(
    deltaMs: number,
    emotion: EmotionalState,
    intensity: EmotionalIntensity = 2
  ): FacialPose {
    const dtSec = deltaMs / 1000;
    const target = this.computeTargetPose(emotion, intensity);

    const lerpRate = Math.min(1, 6.0 * dtSec);

    this.currentPose.eyebrowLeftY += (target.eyebrowLeftY - this.currentPose.eyebrowLeftY) * lerpRate;
    this.currentPose.eyebrowLeftAngle += (target.eyebrowLeftAngle - this.currentPose.eyebrowLeftAngle) * lerpRate;
    this.currentPose.eyebrowRightY += (target.eyebrowRightY - this.currentPose.eyebrowRightY) * lerpRate;
    this.currentPose.eyebrowRightAngle += (target.eyebrowRightAngle - this.currentPose.eyebrowRightAngle) * lerpRate;
    this.currentPose.restingSmile += (target.restingSmile - this.currentPose.restingSmile) * lerpRate;
    this.currentPose.blushOpacity += (target.blushOpacity - this.currentPose.blushOpacity) * lerpRate;
    this.currentPose.eyeSquint += (target.eyeSquint - this.currentPose.eyeSquint) * lerpRate;
    this.currentPose.sparkleOpacity += (target.sparkleOpacity - this.currentPose.sparkleOpacity) * lerpRate;
    this.currentPose.blushColor = target.blushColor;
    this.currentPose.glowColor = target.glowColor;

    return { ...this.currentPose };
  }

  private computeTargetPose(
    emotion: EmotionalState,
    intensity: EmotionalIntensity
  ): FacialPose {
    const intFactor = Math.min(1.5, 0.7 + (intensity / 5) * 0.6);

    switch (emotion) {
      case 'happy':
        return {
          eyebrowLeftY: -3 * intFactor,
          eyebrowLeftAngle: -2,
          eyebrowRightY: -3 * intFactor,
          eyebrowRightAngle: 2,
          restingSmile: 0.65 * intFactor,
          blushOpacity: 0.45 * intFactor,
          blushColor: 'rgba(251, 113, 133, 0.65)',
          eyeSquint: 0.35 * intFactor,
          sparkleOpacity: 0.85,
          glowColor: 'rgba(56, 189, 248, 0.55)',
        };

      case 'excited':
        return {
          eyebrowLeftY: -6 * intFactor,
          eyebrowLeftAngle: -3,
          eyebrowRightY: -6 * intFactor,
          eyebrowRightAngle: 3,
          restingSmile: 0.75 * intFactor,
          blushOpacity: 0.6 * intFactor,
          blushColor: 'rgba(244, 63, 94, 0.75)',
          eyeSquint: 0.2,
          sparkleOpacity: 1.0,
          glowColor: 'rgba(168, 85, 247, 0.65)',
        };

      case 'affectionate':
        return {
          eyebrowLeftY: -2,
          eyebrowLeftAngle: 2, // gentle soft slope
          eyebrowRightY: -2,
          eyebrowRightAngle: -2,
          restingSmile: 0.55 * intFactor,
          blushOpacity: 0.7 * intFactor,
          blushColor: 'rgba(251, 113, 133, 0.85)',
          eyeSquint: 0.4 * intFactor,
          sparkleOpacity: 0.9,
          glowColor: 'rgba(244, 114, 182, 0.6)',
        };

      case 'curious':
        return {
          eyebrowLeftY: -6 * intFactor, // One eyebrow cocked higher
          eyebrowLeftAngle: -4,
          eyebrowRightY: -1,
          eyebrowRightAngle: 1,
          restingSmile: 0.25,
          blushOpacity: 0.2,
          blushColor: 'rgba(192, 132, 252, 0.4)',
          eyeSquint: 0.05,
          sparkleOpacity: 0.75,
          glowColor: 'rgba(45, 212, 191, 0.55)',
        };

      case 'playful':
      case 'amused':
        return {
          eyebrowLeftY: -4,
          eyebrowLeftAngle: -3,
          eyebrowRightY: -2,
          eyebrowRightAngle: 2,
          restingSmile: 0.6 * intFactor,
          blushOpacity: 0.5 * intFactor,
          blushColor: 'rgba(236, 72, 153, 0.65)',
          eyeSquint: 0.3,
          sparkleOpacity: 0.85,
          glowColor: 'rgba(192, 132, 252, 0.6)',
        };

      case 'embarrassed':
        return {
          eyebrowLeftY: 2,
          eyebrowLeftAngle: 3,
          eyebrowRightY: 2,
          eyebrowRightAngle: -3,
          restingSmile: 0.3,
          blushOpacity: 0.95 * intFactor,
          blushColor: 'rgba(244, 63, 94, 0.9)',
          eyeSquint: 0.45,
          sparkleOpacity: 0.9,
          glowColor: 'rgba(244, 114, 182, 0.65)',
        };

      case 'proud':
        return {
          eyebrowLeftY: -4,
          eyebrowLeftAngle: -2,
          eyebrowRightY: -4,
          eyebrowRightAngle: 2,
          restingSmile: 0.55 * intFactor,
          blushOpacity: 0.35,
          blushColor: 'rgba(244, 114, 182, 0.4)',
          eyeSquint: 0.2,
          sparkleOpacity: 0.95,
          glowColor: 'rgba(139, 92, 246, 0.65)',
        };

      case 'serious':
        return {
          eyebrowLeftY: 3 * intFactor,
          eyebrowLeftAngle: 3,
          eyebrowRightY: 3 * intFactor,
          eyebrowRightAngle: -3,
          restingSmile: 0.05,
          blushOpacity: 0.05,
          blushColor: 'rgba(148, 163, 184, 0.2)',
          eyeSquint: 0.15,
          sparkleOpacity: 0.2,
          glowColor: 'rgba(14, 165, 233, 0.45)',
        };

      case 'calm':
        return {
          eyebrowLeftY: -1,
          eyebrowLeftAngle: 0,
          eyebrowRightY: -1,
          eyebrowRightAngle: 0,
          restingSmile: 0.3,
          blushOpacity: 0.2,
          blushColor: 'rgba(244, 114, 182, 0.3)',
          eyeSquint: 0.1,
          sparkleOpacity: 0.45,
          glowColor: 'rgba(56, 189, 248, 0.45)',
        };

      case 'neutral':
      default:
        return {
          eyebrowLeftY: 0,
          eyebrowLeftAngle: 0,
          eyebrowRightY: 0,
          eyebrowRightAngle: 0,
          restingSmile: 0.25,
          blushOpacity: 0.2,
          blushColor: 'rgba(244, 114, 182, 0.3)',
          eyeSquint: 0,
          sparkleOpacity: 0.5,
          glowColor: 'rgba(0, 229, 255, 0.45)',
        };
    }
  }
}
