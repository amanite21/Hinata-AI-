/**
 * LipSyncController - Real-time mouth and speech synchronization
 * Converts AudioPlayer output volume into responsive, smooth viseme movements.
 */

export interface MouthState {
  mouthOpen: number; // 0 (closed) to 1 (wide open)
  mouthWidth: number; // 0.8 to 1.3 (horizontal stretch)
  mouthCurve: number; // -0.5 (frown) to 0.8 (smile)
  visemeType: 'rest' | 'aa' | 'oh' | 'ee' | 'ih';
}

export class LipSyncController {
  private currentOpen: number = 0;
  private currentWidth: number = 1.0;
  private currentCurve: number = 0.2;
  private targetOpen: number = 0;
  private targetWidth: number = 1.0;
  private speechPhaseTimer: number = 0;

  public update(
    deltaMs: number,
    outputVolume: number,
    isSpeaking: boolean,
    baselineSmile: number = 0.2
  ): MouthState {
    const dtSec = deltaMs / 1000;

    if (!isSpeaking || outputVolume < 0.015) {
      // Return gently toward closed resting mouth with baseline smile
      const closeSpeed = 12 * dtSec;
      this.currentOpen += (0 - this.currentOpen) * closeSpeed;
      this.currentWidth += (1.0 - this.currentWidth) * closeSpeed;
      this.currentCurve += (baselineSmile - this.currentCurve) * closeSpeed;

      return {
        mouthOpen: Math.max(0, this.currentOpen),
        mouthWidth: this.currentWidth,
        mouthCurve: this.currentCurve,
        visemeType: 'rest',
      };
    }

    this.speechPhaseTimer += deltaMs;

    // Amplify volume non-linearly to match human speech syllable dynamics
    const normalizedVol = Math.min(1.0, outputVolume * 2.2);
    // Add rhythmic syllable pulsation
    const syllableWave = (Math.sin(this.speechPhaseTimer * 0.018) + 1) * 0.5;
    this.targetOpen = Math.min(1.0, normalizedVol * 0.75 + syllableWave * normalizedVol * 0.35);

    // Phoneme width variation
    const vowelCycle = Math.sin(this.speechPhaseTimer * 0.012);
    if (vowelCycle > 0.3) {
      this.targetWidth = 1.15; // "ee" / wide vowel
    } else if (vowelCycle < -0.3) {
      this.targetWidth = 0.88; // "oo" / narrow vowel
    } else {
      this.targetWidth = 1.0;
    }

    // Dynamic smoothing: fast attack on speech onset, natural release
    const attackRate = 22 * dtSec;
    const decayRate = 14 * dtSec;
    const lerpRate = this.targetOpen > this.currentOpen ? attackRate : decayRate;

    this.currentOpen += (this.targetOpen - this.currentOpen) * Math.min(1, lerpRate);
    this.currentWidth += (this.targetWidth - this.currentWidth) * Math.min(1, 12 * dtSec);
    this.currentCurve += (baselineSmile + 0.15 - this.currentCurve) * Math.min(1, 8 * dtSec);

    // Determine viseme for subtle aesthetic shading
    let visemeType: 'rest' | 'aa' | 'oh' | 'ee' | 'ih' = 'rest';
    if (this.currentOpen > 0.45) {
      visemeType = this.currentWidth < 0.95 ? 'oh' : 'aa';
    } else if (this.currentOpen > 0.15) {
      visemeType = this.currentWidth > 1.05 ? 'ee' : 'ih';
    }

    return {
      mouthOpen: Math.max(0, Math.min(1, this.currentOpen)),
      mouthWidth: Math.max(0.8, Math.min(1.3, this.currentWidth)),
      mouthCurve: Math.max(-0.4, Math.min(0.8, this.currentCurve)),
      visemeType,
    };
  }
}
