/**
 * BlinkController - Simulates human-like natural blinking
 * Includes randomized intervals, variable close/open speeds, and occasional double-blinking.
 */

export class BlinkController {
  private blinkProgress: number = 0; // 0 = open, 1 = closed
  private isBlinking: boolean = false;
  private blinkTimer: number = 0;
  private nextBlinkInterval: number = 3200; // ms
  private blinkPhase: 'closing' | 'opening' | 'idle' = 'idle';
  private closeDuration: number = 85; // ms
  private openDuration: number = 130; // ms
  private phaseTimer: number = 0;
  private isDoubleBlinkPending: boolean = false;

  constructor() {
    this.resetNextInterval();
  }

  private resetNextInterval(): void {
    // Random interval between 2.8s and 5.5s
    this.nextBlinkInterval = 2800 + Math.random() * 2700;
  }

  public triggerBlink(forceDouble: boolean = false): void {
    this.isBlinking = true;
    this.blinkPhase = 'closing';
    this.phaseTimer = 0;
    this.isDoubleBlinkPending = forceDouble || Math.random() < 0.18;
  }

  public update(deltaMs: number): number {
    this.blinkTimer += deltaMs;

    if (!this.isBlinking) {
      if (this.blinkTimer >= this.nextBlinkInterval) {
        this.triggerBlink();
        this.blinkTimer = 0;
        this.resetNextInterval();
      }
      this.blinkProgress = 0;
      return 0;
    }

    this.phaseTimer += deltaMs;

    if (this.blinkPhase === 'closing') {
      const progress = Math.min(1, this.phaseTimer / this.closeDuration);
      // Ease in for snappy eyelid closure
      this.blinkProgress = progress * progress;

      if (progress >= 1) {
        this.blinkProgress = 1;
        this.blinkPhase = 'opening';
        this.phaseTimer = 0;
      }
    } else if (this.blinkPhase === 'opening') {
      const progress = Math.min(1, this.phaseTimer / this.openDuration);
      // Ease out for smooth eyelid rise
      this.blinkProgress = 1 - Math.sin((progress * Math.PI) / 2);

      if (progress >= 1) {
        this.blinkProgress = 0;
        if (this.isDoubleBlinkPending) {
          this.isDoubleBlinkPending = false;
          this.blinkPhase = 'closing';
          this.phaseTimer = 0;
        } else {
          this.blinkPhase = 'idle';
          this.isBlinking = false;
          this.blinkTimer = 0;
          this.resetNextInterval();
        }
      }
    }

    return this.blinkProgress;
  }

  public getProgress(): number {
    return this.blinkProgress;
  }
}
