/**
 * HologramController - Manages holographic visual effects, projection beam intensity,
 * futuristic scanlines, particle physics, and platform illumination.
 */

import { LiveSessionState, EmotionalState } from '../../types';

export interface Particle {
  id: number;
  x: number; // 0 to 100%
  y: number; // 0 to 100%
  size: number; // px
  speedY: number;
  opacity: number;
  hue: number;
}

export interface HologramFX {
  coreGlow: string;
  rimColor: string;
  beamOpacity: number;
  scanlineOpacity: number;
  platformBrightness: number;
  ringRotationSpeed: number; // deg/sec
  glitchActive: boolean;
}

export class HologramController {
  private particles: Particle[] = [];
  private glitchTimer: number = 0;
  private isGlitching: boolean = false;

  constructor() {
    this.initParticles(24);
  }

  private initParticles(count: number): void {
    this.particles = [];
    for (let i = 0; i < count; i++) {
      this.particles.push({
        id: i,
        x: Math.random() * 90 + 5,
        y: Math.random() * 100,
        size: Math.random() * 2.5 + 1.2,
        speedY: Math.random() * 18 + 12,
        opacity: Math.random() * 0.6 + 0.2,
        hue: Math.random() > 0.4 ? 190 : 280, // Cyan or Purple
      });
    }
  }

  public triggerGlitch(durationMs: number = 180): void {
    this.isGlitching = true;
    this.glitchTimer = durationMs;
  }

  public update(
    deltaMs: number,
    state: LiveSessionState,
    emotion: EmotionalState,
    outputVolume: number = 0
  ): { fx: HologramFX; particles: Particle[] } {
    const dtSec = deltaMs / 1000;

    // Update glitch
    if (this.isGlitching) {
      this.glitchTimer -= deltaMs;
      if (this.glitchTimer <= 0) {
        this.isGlitching = false;
      }
    }

    // Update floating hologram particles
    for (const p of this.particles) {
      p.y -= p.speedY * dtSec * (state === 'speaking' ? 1.6 : 1.0);
      if (p.y < -5) {
        p.y = 105;
        p.x = Math.random() * 80 + 10;
        p.opacity = Math.random() * 0.6 + 0.2;
      }
    }

    // Base properties by state
    let beamOpacity = 0.25;
    let scanlineOpacity = 0.08;
    let platformBrightness = 0.4;
    let ringRotationSpeed = 15; // deg/sec
    let coreGlow = 'rgba(0, 229, 255, 0.45)';
    let rimColor = 'rgba(168, 85, 247, 0.6)';

    if (state === 'disconnected') {
      beamOpacity = 0.18;
      scanlineOpacity = 0.05;
      platformBrightness = 0.3;
      ringRotationSpeed = 8;
      coreGlow = 'rgba(79, 70, 229, 0.25)';
      rimColor = 'rgba(99, 102, 241, 0.35)';
    } else if (state === 'connecting') {
      beamOpacity = 0.55;
      scanlineOpacity = 0.16;
      platformBrightness = 0.75;
      ringRotationSpeed = 45;
      coreGlow = 'rgba(168, 85, 247, 0.65)';
      rimColor = 'rgba(217, 70, 239, 0.8)';
    } else if (state === 'listening') {
      beamOpacity = 0.45;
      scanlineOpacity = 0.09;
      platformBrightness = 0.65;
      ringRotationSpeed = 22;
      coreGlow = 'rgba(6, 182, 212, 0.6)';
      rimColor = 'rgba(56, 189, 248, 0.7)';
    } else if (state === 'speaking') {
      const volBoost = Math.min(0.4, outputVolume * 1.5);
      beamOpacity = 0.65 + volBoost;
      scanlineOpacity = 0.12 + volBoost * 0.1;
      platformBrightness = 0.85 + volBoost;
      ringRotationSpeed = 35 + volBoost * 30;
      coreGlow = 'rgba(168, 85, 247, 0.75)';
      rimColor = 'rgba(34, 211, 238, 0.85)';
    }

    return {
      fx: {
        coreGlow,
        rimColor,
        beamOpacity,
        scanlineOpacity,
        platformBrightness,
        ringRotationSpeed,
        glitchActive: this.isGlitching,
      },
      particles: [...this.particles],
    };
  }
}
