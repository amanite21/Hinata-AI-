/**
 * AvatarController - Master coordinator for Hinata's animated holographic projection.
 * Connects EmotionManager, StateManager, and AudioPlayer to facial expressions,
 * eye gaze, blinking, micro-head movements, lip-sync, and futuristic hologram effects.
 */

import { LiveSessionState, EmotionalState, EmotionalIntensity } from '../../types';
import { BlinkController } from './BlinkController';
import { EyeController, EyeState } from './EyeController';
import { LipSyncController, MouthState } from './LipSyncController';
import { HeadMovementController, HeadPose } from './HeadMovementController';
import { FacialExpressionController, FacialPose } from './FacialExpressionController';
import { HologramController, HologramFX, Particle } from './HologramController';

export interface AvatarFrameState {
  blinkProgress: number;
  eyeState: EyeState;
  mouthState: MouthState;
  headPose: HeadPose;
  facialPose: FacialPose;
  hologramFx: HologramFX;
  particles: Particle[];
}

export class AvatarController {
  public blink: BlinkController;
  public eye: EyeController;
  public lipSync: LipSyncController;
  public head: HeadMovementController;
  public facial: FacialExpressionController;
  public hologram: HologramController;

  constructor() {
    this.blink = new BlinkController();
    this.eye = new EyeController();
    this.lipSync = new LipSyncController();
    this.head = new HeadMovementController();
    this.facial = new FacialExpressionController();
    this.hologram = new HologramController();
  }

  public update(
    deltaMs: number,
    state: LiveSessionState,
    emotion: EmotionalState,
    intensity: EmotionalIntensity = 2,
    outputVolume: number = 0,
    inputVolume: number = 0
  ): AvatarFrameState {
    const blinkProgress = this.blink.update(deltaMs);
    const eyeState = this.eye.update(deltaMs, state, emotion, intensity);
    const facialPose = this.facial.update(deltaMs, emotion, intensity);
    const mouthState = this.lipSync.update(
      deltaMs,
      outputVolume,
      state === 'speaking',
      facialPose.restingSmile
    );
    const headPose = this.head.update(deltaMs, state, outputVolume);
    const { fx: hologramFx, particles } = this.hologram.update(
      deltaMs,
      state,
      emotion,
      outputVolume
    );

    return {
      blinkProgress,
      eyeState,
      mouthState,
      headPose,
      facialPose,
      hologramFx,
      particles,
    };
  }

  public triggerReactionGlitch(): void {
    this.hologram.triggerGlitch(220);
    this.blink.triggerBlink(true);
  }
}
