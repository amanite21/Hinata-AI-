/**
 * HeadMovementController - Manages micro-head movements, natural idle breathing,
 * attentive listening tilt, and expressive speaking nods.
 */

import { LiveSessionState } from '../../types';

export interface HeadPose {
  roll: number; // degrees (head tilt sideways)
  pitch: number; // degrees (head nod up/down)
  yaw: number; // degrees (head turn left/right)
  translateY: number; // px (breathing float)
  scale: number; // slight breathing scale factor
}

export class HeadMovementController {
  private breathPhase: number = 0;
  private currentRoll: number = 0;
  private currentPitch: number = 0;
  private currentYaw: number = 0;
  private currentTranslateY: number = 0;

  private targetRoll: number = 0;
  private targetPitch: number = 0;
  private targetYaw: number = 0;

  public update(
    deltaMs: number,
    state: LiveSessionState,
    outputVolume: number = 0
  ): HeadPose {
    const dtSec = deltaMs / 1000;

    // Breathing wave: ~3.4 second sine wave
    this.breathPhase += dtSec * 1.85;
    const breathOffset = Math.sin(this.breathPhase) * 3.5;
    const breathScale = 1 + Math.sin(this.breathPhase) * 0.008;

    // Determine target posture based on state
    if (state === 'listening') {
      // Attentive head tilt (~2.5 deg) and slight forward pitch
      this.targetRoll = 2.2;
      this.targetPitch = -1.2;
      this.targetYaw = Math.sin(this.breathPhase * 0.5) * 1.2;
    } else if (state === 'speaking') {
      // Micro nodding synchronized with speech energy
      const speechNod = Math.sin(this.breathPhase * 3.2) * (outputVolume * 2.8);
      this.targetPitch = 1.0 + speechNod;
      this.targetRoll = Math.sin(this.breathPhase * 0.8) * 1.8;
      this.targetYaw = Math.cos(this.breathPhase * 0.6) * 1.5;
    } else {
      // Idle / Disconnected: very gentle natural posture
      this.targetRoll = Math.sin(this.breathPhase * 0.4) * 0.8;
      this.targetPitch = Math.cos(this.breathPhase * 0.5) * 0.6;
      this.targetYaw = Math.sin(this.breathPhase * 0.3) * 0.8;
    }

    // Smooth lerping
    const lerpSpeed = 4.5 * dtSec;
    this.currentRoll += (this.targetRoll - this.currentRoll) * lerpSpeed;
    this.currentPitch += (this.targetPitch - this.currentPitch) * lerpSpeed;
    this.currentYaw += (this.targetYaw - this.currentYaw) * lerpSpeed;
    this.currentTranslateY = breathOffset;

    return {
      roll: this.currentRoll,
      pitch: this.currentPitch,
      yaw: this.currentYaw,
      translateY: this.currentTranslateY,
      scale: breathScale,
    };
  }
}
