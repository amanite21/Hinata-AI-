/**
 * VoiceChatCoordinator - Master Voice + Chat Hybrid Engine for Hinata AI.
 *
 * Implements seamless hybrid collaboration:
 * 1. VOICE_MODE: Natural speech conversation -> Speech-to-Text -> Hinata AI -> Voice Reply + Chat Text.
 * 2. DICTATION_MODE ("Likho" / "Type this"): User speaks -> text placed in Chat composer for editing.
 *    Voice commands: "Send this" / "Isko send karo", "Cancel" / "Clear this" / "Isko hata do".
 * 3. Immediate Interruption: User speech stops active Hinata TTS & mouth animations immediately.
 * 4. Shared Context: Single active Conversation thread and MemoryManager across voice and chat.
 */

import { VoiceInputService } from '../voice/VoiceInputService';
import { ConversationManager } from '../conversation/ConversationManager';
import { EmotionManager } from '../EmotionManager';
import { CommandDetector, DictationCommandResult } from './CommandDetector';
import { DictationManager, DictationState } from './DictationManager';
import { MicrophoneManager } from '../audio/MicrophoneManager';

export type HybridMode = 'VOICE_MODE' | 'DICTATION_MODE';
export type HybridStatus = 'IDLE' | 'LISTENING' | 'DICTATING' | 'THINKING' | 'SPEAKING';

export interface LikhoParseResult {
  isLikho: boolean;
  extractedText: string;
  isModeToggleOnly: boolean;
}

export interface HybridStateSnapshot {
  mode: HybridMode;
  status: HybridStatus;
  draftText: string;
  isListening: boolean;
  inputVolume: number;
  speechVolume: number;
  lastActionMessage: string | null;
  autoVoiceReply: boolean;
}

export type HybridStateListener = (state: HybridStateSnapshot) => void;

export class VoiceChatCoordinator {
  private static instance: VoiceChatCoordinator | null = null;

  private mode: HybridMode = 'VOICE_MODE';
  private status: HybridStatus = 'IDLE';
  private draftText: string = '';
  private isListening: boolean = false;
  private inputVolume: number = 0;
  private speechVolume: number = 0;
  private lastActionMessage: string | null = null;

  private voiceService: VoiceInputService;
  private convManager: ConversationManager;
  private dictationManager: DictationManager;
  private micManager: MicrophoneManager;
  private listeners: HybridStateListener[] = [];
  private actionMessageTimer: any = null;

  private constructor() {
    this.voiceService = VoiceInputService.getInstance();
    this.convManager = ConversationManager.getInstance();
    this.dictationManager = DictationManager.getInstance();
    this.micManager = MicrophoneManager.getInstance();
    this.setupSubscriptions();
  }

  public static getInstance(): VoiceChatCoordinator {
    if (!VoiceChatCoordinator.instance) {
      VoiceChatCoordinator.instance = new VoiceChatCoordinator();
    }
    return VoiceChatCoordinator.instance;
  }

  private setupSubscriptions(): void {
    // 1. Sync Hinata speaking status from ConversationManager
    this.convManager.onChatStateChange((chatState) => {
      if (chatState === 'speaking') {
        this.status = 'SPEAKING';
      } else if (chatState === 'thinking' || chatState === 'streaming' || chatState === 'sending') {
        this.status = 'THINKING';
      } else if (this.isListening) {
        this.status = this.mode === 'DICTATION_MODE' ? 'DICTATING' : 'LISTENING';
      } else {
        this.status = 'IDLE';
      }
      this.notify();
    });

    // 2. Sync Hinata speech volume for mouth visemes
    this.convManager.onSpeechVolume((vol) => {
      this.speechVolume = vol;
      this.notify();
    });

    // 3. Sync DictationManager composer text & status
    this.dictationManager.subscribe((snap) => {
      this.draftText = snap.composerText;
      if (snap.isDictating && this.mode !== 'DICTATION_MODE') {
        this.mode = 'DICTATION_MODE';
        if (this.isListening) this.status = 'DICTATING';
      } else if (!snap.isDictating && this.mode === 'DICTATION_MODE') {
        this.mode = 'VOICE_MODE';
        if (this.isListening) this.status = 'LISTENING';
      }
      if (snap.statusMessage) {
        this.lastActionMessage = snap.statusMessage;
      }
      this.notify();
    });

    // 4. Sync hardware microphone state from MicrophoneManager
    this.micManager.onStateChange((state, owner, error) => {
      if (state === 'LISTENING') {
        this.isListening = true;
        this.status = this.mode === 'DICTATION_MODE' ? 'DICTATING' : 'LISTENING';
      } else if (state === 'IDLE') {
        this.isListening = false;
        if (this.status === 'LISTENING' || this.status === 'DICTATING') {
          this.status = 'IDLE';
        }
      } else if (state === 'ERROR') {
        this.isListening = false;
        this.status = 'IDLE';
        if (error) {
          this.setActionMessage(error);
        }
      }
      this.notify();
    });
  }

  public subscribe(listener: HybridStateListener): () => void {
    this.listeners.push(listener);
    listener(this.getSnapshot());
    return () => {
      this.listeners = this.listeners.filter((l) => l !== listener);
    };
  }

  public getSnapshot(): HybridStateSnapshot {
    return {
      mode: this.mode,
      status: this.status,
      draftText: this.draftText,
      isListening: this.isListening,
      inputVolume: this.inputVolume,
      speechVolume: this.speechVolume,
      lastActionMessage: this.lastActionMessage,
      autoVoiceReply: this.convManager.getAutoVoiceReply(),
    };
  }

  private notify(): void {
    const snapshot = this.getSnapshot();
    for (const listener of this.listeners) {
      try {
        listener(snapshot);
      } catch (e) {
        console.error('[VoiceChatCoordinator] Listener error:', e);
      }
    }
  }

  private setActionMessage(msg: string, durationMs: number = 3500): void {
    this.lastActionMessage = msg;
    this.notify();
    if (this.actionMessageTimer) clearTimeout(this.actionMessageTimer);
    this.actionMessageTimer = setTimeout(() => {
      this.lastActionMessage = null;
      this.notify();
    }, durationMs);
  }

  // ----------------------------------------------------
  // Natural Command & Intent Parsers
  // ----------------------------------------------------

  /**
   * Detects if user wants to send the current composer draft.
   * e.g. "Send this", "Send it", "Isko send karo", "Bhej do", "Please send this"
   */
  public isSendCommand(text: string): boolean {
    return CommandDetector.isSendCommand(text);
  }

  /**
   * Detects if user wants to cancel or clear the current composer draft.
   * e.g. "Cancel", "Clear this", "Isko hata do", "Clear draft", "Cancel dictation"
   */
  public isCancelCommand(text: string): boolean {
    return CommandDetector.isCancelCommand(text);
  }

  /**
   * Detects "Chat par likho...", "Likho...", "Type this...", or dictation activation.
   */
  public parseLikhoCommand(text: string): LikhoParseResult {
    const res = CommandDetector.parseDictationCommand(text);
    return {
      isLikho: res.isDictation,
      extractedText: res.content,
      isModeToggleOnly: res.isToggleOnly,
    };
  }

  public getDictationManager(): DictationManager {
    return this.dictationManager;
  }

  // ----------------------------------------------------
  // Voice Processing Pipeline
  // ----------------------------------------------------

  /**
   * Main speech recognition handler.
   */
  public handleRecognizedSpeech(transcript: string, isFinal: boolean): void {
    if (!transcript || !transcript.trim()) return;
    const clean = transcript.trim();

    // Interrupt active Hinata TTS on user speech
    if (this.convManager.getChatState() === 'speaking') {
      this.convManager.interrupt();
    }

    // 1. DICTATION_MODE active:
    if (this.mode === 'DICTATION_MODE') {
      // Check for voice send command ("Send this", "Isko send karo", "Bhej do")
      if (isFinal && CommandDetector.isSendCommand(clean)) {
        console.log('[VoiceChatCoordinator] Sending current dictation draft via voice command.');
        this.sendCurrentDraft();
        return;
      }

      // Check for voice cancel command ("Cancel", "Clear this", "Isko hata do")
      if (isFinal && CommandDetector.isCancelCommand(clean)) {
        console.log('[VoiceChatCoordinator] Cancelling dictation draft via voice command.');
        this.clearDraft();
        this.setMode('VOICE_MODE');
        return;
      }

      // Process speech chunk through DictationManager (prevents word duplication)
      this.dictationManager.handleSpeechResult(clean, isFinal);
      this.draftText = this.dictationManager.getComposerText();
      this.status = 'DICTATING';
      this.notify();
      return;
    }

    // 2. VOICE_MODE active:
    // Only process final transcripts for top-level mode routing / queries
    if (!isFinal) {
      return;
    }

    console.log(`[VoiceChatCoordinator] Final speech in VOICE_MODE: "${clean}"`);

    // Check for send command if text is already present in composer
    if (CommandDetector.isSendCommand(clean)) {
      if (this.draftText.trim()) {
        this.sendCurrentDraft();
      } else {
        this.setActionMessage("Composer is empty.");
      }
      return;
    }

    // Check for cancel command
    if (CommandDetector.isCancelCommand(clean)) {
      this.clearDraft();
      this.setActionMessage("Draft cleared.");
      return;
    }

    // Check for "Chat par likho...", "Likho...", "Type this..." dictation command
    const dictation = CommandDetector.parseDictationCommand(clean);
    if (dictation.isDictation) {
      console.log(`[VoiceChatCoordinator] ✎ Dictation command detected:`, dictation);
      this.setMode('DICTATION_MODE');
      this.dictationManager.startDictation(dictation.content);
      this.draftText = this.dictationManager.getComposerText();
      this.status = 'DICTATING';
      this.notify();
      // Hinata will NOT answer the question or query Gemini! The content is in the composer.
      return;
    }

    // In VOICE_MODE with no command match: execute natural conversational turn
    // Speech recognition -> Hinata AI (Gemini) -> Voice reply + Chat message
    this.executeVoiceTurn(clean);
  }

  /**
   * Executes a normal voice conversational turn.
   * Sends prompt to ConversationManager with speakVoice: true so Hinata speaks response
   * aloud using TTS and renders text into Chat thread.
   */
  public async executeVoiceTurn(prompt: string): Promise<void> {
    if (!prompt.trim()) return;

    this.status = 'THINKING';
    this.setActionMessage(`Hinata is thinking...`);
    this.notify();

    try {
      // Send to server-side Gemini through ConversationManager (shared context + memory)
      await this.convManager.sendMessage({
        text: prompt.trim(),
        speakVoice: true, // Always speak response for voice conversational turns!
      });
    } catch (err: any) {
      console.error('[VoiceChatCoordinator] Voice turn error:', err);
      this.status = 'IDLE';
      this.setActionMessage('Error processing voice query.');
      this.notify();
    }
  }

  /**
   * Sends the current draft text from the composer.
   */
  public async sendCurrentDraft(): Promise<void> {
    const textToSend = (this.draftText || this.dictationManager.getComposerText()).trim();
    if (!textToSend) {
      this.setActionMessage("Composer is empty.");
      return;
    }

    this.draftText = '';
    this.setMode('VOICE_MODE');
    this.setActionMessage("Sending message...");
    this.notify();

    try {
      await this.dictationManager.sendComposerMessage();
    } catch (err) {
      console.error('[VoiceChatCoordinator] Send draft error:', err);
      this.setActionMessage('Failed to send draft.');
    }
  }

  /**
   * Clears the current draft in composer.
   */
  public clearDraft(): void {
    this.draftText = '';
    this.dictationManager.clearComposerText();
    this.notify();
  }

  /**
   * Updates composer draft text.
   */
  public setDraftText(text: string): void {
    this.draftText = text;
    this.dictationManager.setComposerText(text);
    this.notify();
  }

  /**
   * Sets mode: 'VOICE_MODE' or 'DICTATION_MODE'.
   */
  public setMode(mode: HybridMode): void {
    if (this.mode === mode) return;
    this.mode = mode;
    if (this.isListening) {
      this.status = mode === 'DICTATION_MODE' ? 'DICTATING' : 'LISTENING';
    }
    this.notify();
  }

  public toggleMode(): void {
    this.setMode(this.mode === 'VOICE_MODE' ? 'DICTATION_MODE' : 'VOICE_MODE');
  }

  public setAutoVoiceReply(enabled: boolean): void {
    this.convManager.setAutoVoiceReply(enabled);
    this.notify();
  }

  // ----------------------------------------------------
  // Microphone Listening Lifecycle
  // ----------------------------------------------------

  public startListening(): boolean {
    if (!this.voiceService.isSupported()) {
      this.setActionMessage('Speech recognition not supported in this browser.');
      return false;
    }

    // Interrupt any playing speech before starting to listen
    if (this.convManager.getChatState() === 'speaking') {
      this.convManager.interrupt();
    }

    const owner = this.mode === 'DICTATION_MODE' ? 'dictation' : 'chat_voice';

    const success = this.voiceService.startListening({
      lang: 'en-IN',
      owner,
      onTranscript: (text, isFinal) => {
        this.handleRecognizedSpeech(text, isFinal);
      },
      onSpeechStart: () => {
        // Instant interruption on speech start
        if (this.convManager.getChatState() === 'speaking') {
          this.convManager.interrupt();
        }
      },
      onVolumeChange: (vol) => {
        this.inputVolume = vol;
        this.notify();
      },
      onError: (err) => {
        console.warn('[VoiceChatCoordinator] Mic error:', err);
        this.isListening = false;
        this.status = 'IDLE';
        this.inputVolume = 0;
        this.setActionMessage(err);
        this.notify();
      },
      onEnd: () => {
        this.isListening = false;
        if (this.status === 'LISTENING' || this.status === 'DICTATING') {
          this.status = 'IDLE';
        }
        this.inputVolume = 0;
        this.notify();
      },
    });

    if (success) {
      this.isListening = true;
      this.status = this.mode === 'DICTATION_MODE' ? 'DICTATING' : 'LISTENING';
      this.setActionMessage(
        this.mode === 'DICTATION_MODE'
          ? 'Dictating... Speak your text'
          : 'Listening... Speak naturally'
      );
      this.notify();
    }

    return success;
  }

  public stopListening(): void {
    this.voiceService.stopListening();
    this.isListening = false;
    this.inputVolume = 0;
    if (this.status === 'LISTENING' || this.status === 'DICTATING') {
      this.status = 'IDLE';
    }
    this.notify();
  }

  public toggleListening(): void {
    if (this.micManager.isBusy()) {
      console.log('[VoiceChatCoordinator] Toggle ignored: MicrophoneManager is busy.');
      return;
    }
    const isChatOwner =
      this.micManager.getOwner() === 'chat_voice' || this.micManager.getOwner() === 'dictation';
    if (this.isListening || (this.micManager.getState() === 'LISTENING' && isChatOwner)) {
      this.stopListening();
    } else {
      this.startListening();
    }
  }

  /**
   * Provides rapid, non-blocking verbal confirmation for user commands.
   */
  private speakConfirmation(text: string): void {
    if (typeof window === 'undefined' || !window.speechSynthesis) return;
    try {
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 1.15;
      utterance.pitch = 1.12;
      const voices = window.speechSynthesis.getVoices();
      const femaleVoice = voices.find(
        (v) =>
          v.lang.startsWith('en') &&
          (v.name.toLowerCase().includes('female') ||
            v.name.toLowerCase().includes('samantha') ||
            v.name.toLowerCase().includes('natural'))
      );
      if (femaleVoice) utterance.voice = femaleVoice;
      window.speechSynthesis.speak(utterance);
    } catch (e) {
      console.warn('[VoiceChatCoordinator] Speech confirmation error:', e);
    }
  }
}
