/**
 * CommandDetector - Local natural voice command detector for Hinata.
 *
 * Fast, regex-based local detection without querying Gemini.
 * Detects:
 * - Dictation commands with content: "Chat par likho What is photosynthesis" -> content: "What is photosynthesis"
 * - Dictation toggle commands: "Chat par likho", "Dictation on", "Jo main bolu woh chat mein likho"
 * - Send commands: "Send this", "Send it", "Isko send karo", "Bhej do"
 * - Cancel commands: "Cancel", "Clear this", "Isko hata do", "Clear draft"
 */

export interface DictationCommandResult {
  isDictation: boolean;
  content: string;
  isToggleOnly: boolean;
}

export type DetectedCommand =
  | { type: 'DICTATION'; content: string; isToggleOnly: boolean }
  | { type: 'SEND' }
  | { type: 'CANCEL' }
  | { type: 'NONE' };

export class CommandDetector {
  /**
   * Cleans text and strips leading wake words or politeness prefixes.
   */
  private static cleanPrefixes(text: string): string {
    return text
      .trim()
      .replace(/^(?:hey\s+|ok\s+|hello\s+)?hinata\s*[,:]?\s*/i, '')
      .replace(/^(?:please|kripya)\s+/i, '')
      .trim();
  }

  /**
   * Detects "Send this" / "Isko send karo" / "Bhej do"
   */
  public static isSendCommand(text: string): boolean {
    const clean = CommandDetector.cleanPrefixes(text)
      .toLowerCase()
      .replace(/[.,!?;:]/g, '')
      .trim();

    const sendPatterns = [
      /^(?:isko\s+|ye\s+)?(?:send|bhej)\s*(?:karo|kardo|it|this|message|now)?$/i,
      /^(?:send\s+this|send\s+it|send\s+now|send\s+message|send|bhej\s+do|bhejo|isko\s+bhej\s+do|ye\s+bhej\s+do|isko\s+send\s+karo|ye\s+send\s+karo|send\s+karo)$/i,
      /^(?:please\s+)?send(?:\s+it|\s+this|\s+now)?$/i,
    ];

    return sendPatterns.some((p) => p.test(clean));
  }

  /**
   * Detects "Cancel" / "Clear this" / "Isko hata do"
   */
  public static isCancelCommand(text: string): boolean {
    const clean = CommandDetector.cleanPrefixes(text)
      .toLowerCase()
      .replace(/[.,!?;:]/g, '')
      .trim();

    const cancelPatterns = [
      /^(?:isko\s+|ye\s+)?(?:cancel|clear|discard|hata\s+do|mita\s+do|delete)\s*(?:karo|kardo|it|this|draft)?$/i,
      /^(?:cancel|clear|clear\s+this|cancel\s+this|clear\s+draft|cancel\s+dictation|discard\s+draft|delete\s+draft|clear\s+composer)$/i,
      /^(?:isko\s+hata\s+do|hata\s+do|ye\s+hata\s+do|draft\s+hata\s+do|isko\s+mita\s+do|mita\s+do|radd\s+karo)$/i,
    ];

    return cancelPatterns.some((p) => p.test(clean));
  }

  /**
   * Detects and separates dictation command from spoken content.
   *
   * Handles:
   * - "Chat par likho What is photosynthesis"
   * - "Chat pe likho Explain gravity in simple words"
   * - "Chat mein likho What is Python"
   * - "Chat me likho ..."
   * - "Isko chat par likho ..."
   * - "Ye chat mein type karo ..."
   * - "Chat mein type karo ..."
   * - "Jo main bolu woh chat mein likho ..."
   * - "Question likho What is machine learning"
   * - "Ye question chat par likho ..."
   * - "Type this ..." / "Write this ..." / "Put this in chat ..."
   * - "Likho What is AI?"
   * - "Chat par likho" (toggle only)
   * - "Dictation on" (toggle only)
   */
  public static parseDictationCommand(text: string): DictationCommandResult {
    if (!text || !text.trim()) {
      return { isDictation: false, content: '', isToggleOnly: false };
    }

    const stripped = CommandDetector.cleanPrefixes(text);
    const lower = stripped.toLowerCase().replace(/[.,!?;:]/g, '').trim();

    // 1. Check for pure mode toggles (no content following)
    const togglePatterns = [
      /^(?:dictation\s+(?:on|mode)|start\s+dictation|turn\s+on\s+dictation|switch\s+to\s+dictation)$/i,
      /^(?:jo\s+main\s+bol\s*(?:raha\s+hoon|raha\s+hu|u)?\s*woh\s*(?:chat\s+(?:mein|me|par|pe)\s+)?(?:type|likho)\s*karo|jo\s+main\s+bolu\s+woh\s+type\s+karo)$/i,
      /^(?:chat\s+(?:par|pe|mein|me)\s+(?:likho|type\s+karo|type)|isko\s+chat\s+(?:par|pe|mein|me)\s+likho|ye\s+chat\s+(?:par|pe|mein|me)\s+likho)$/i,
      /^(?:isko\s+likho|ye\s+likho|likho|type\s+karo|type\s+this|write\s+this|put\s+this\s+in\s+chat|write\s+it\s+in\s+chat)$/i,
    ];

    for (const pattern of togglePatterns) {
      if (pattern.test(lower)) {
        return { isDictation: true, content: '', isToggleOnly: true };
      }
    }

    // 2. Check for command prefix followed by content
    // Sorted by specificity (longer phrases first)
    const prefixRegexes = [
      // "Jo main bolu woh chat mein likho ..."
      /^(?:jo\s+main\s+bol\s*(?:raha\s+hoon|raha\s+hu|u)?\s*(?:woh|use)?\s*(?:chat\s+(?:mein|me|par|pe)\s+)?(?:type\s*karo|likho))\s*[:,-]?\s+(.+)$/i,

      // "Ye question chat par likho ..." / "Mera ye question likho ..." / "Question likho ..."
      /^(?:(?:ye|mera\s+ye)\s+question\s+(?:chat\s+(?:par|pe|mein|me)\s+)?likho|likho\s+mera\s+ye\s+question|question\s+likho)\s*[:,-]?\s+(.+)$/i,

      // "Isko / Ye chat par / pe / mein likho / type karo ..."
      /^(?:(?:isko|ye)\s+chat\s+(?:par|pe|mein|me)\s+(?:likho|type\s*karo|type))\s*[:,-]?\s+(.+)$/i,

      // "Chat par / pe / mein / me likho / type karo ..."
      /^(?:chat\s+(?:par|pe|mein|me)\s+(?:likho|type\s*karo|type))\s*[:,-]?\s+(.+)$/i,

      // "Put this in / on chat ..." / "Write this / it in chat ..." / "Type this in chat ..."
      /^(?:(?:put|write|type)\s+(?:this|it)\s+(?:in|into|on)\s+chat)\s*[:,-]?\s+(.+)$/i,

      // "Isko likho ..." / "Ye likho ..." / "Ye chat mein type karo ..."
      /^(?:(?:isko|ye)\s+(?:likho|type\s*karo|type))\s*[:,-]?\s+(.+)$/i,

      // "Type this ..." / "Write this ..." / "Dictate this ..."
      /^(?:(?:type|write|dictate)\s+(?:this|it))\s*[:,-]?\s+(.+)$/i,

      // "Likho ..."
      /^likho\s*[:,-]?\s+(.+)$/i,
    ];

    for (const regex of prefixRegexes) {
      const match = stripped.match(regex);
      if (match && match[1]) {
        let content = match[1].trim();
        // Remove leading colon, dash, comma if any remained
        content = content.replace(/^[:,\-\s]+/, '').trim();

        if (content.length > 0) {
          // Clean up first letter capitalization if appropriate
          const formatted = content.charAt(0).toUpperCase() + content.slice(1);
          return {
            isDictation: true,
            content: formatted,
            isToggleOnly: false,
          };
        }
      }
    }

    return { isDictation: false, content: '', isToggleOnly: false };
  }

  /**
   * Main detector evaluating full command intent.
   */
  public static detect(text: string): DetectedCommand {
    if (CommandDetector.isSendCommand(text)) {
      return { type: 'SEND' };
    }

    if (CommandDetector.isCancelCommand(text)) {
      return { type: 'CANCEL' };
    }

    const dictation = CommandDetector.parseDictationCommand(text);
    if (dictation.isDictation) {
      return {
        type: 'DICTATION',
        content: dictation.content,
        isToggleOnly: dictation.isToggleOnly,
      };
    }

    return { type: 'NONE' };
  }
}
