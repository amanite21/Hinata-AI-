/**
 * DictationManager - Central state manager for Hinata "Likho / Type this" Dictation Mode.
 *
 * Architecture:
 * VoiceController / VoiceInputService
 *       ↓
 * CommandDetector
 *       ↓
 * DictationManager
 *       ↓
 * ChatState
 *       ↓
 * ChatComposer
 *
 * States:
 * NORMAL_VOICE | DICTATION | SENDING | THINKING | SPEAKING | ERROR
 *
 * Functions:
 * - startDictation(initialContent?: string)
 * - stopDictation()
 * - setComposerText(text: string)
 * - appendComposerText(text: string)
 * - clearComposerText()
 * - sendComposerMessage()
 */

import { ConversationManager } from '../conversation/ConversationManager';

export type DictationState =
  | 'NORMAL_VOICE'
  | 'DICTATION'
  | 'SENDING'
  | 'THINKING'
  | 'SPEAKING'
  | 'ERROR';

export interface DictationSnapshot {
  state: DictationState;
  composerText: string;
  isDictating: boolean;
  statusMessage: string | null;
}

export type DictationListener = (snapshot: DictationSnapshot) => void;

export class DictationManager {
  private static instance: DictationManager | null = null;

  private state: DictationState = 'NORMAL_VOICE';
  private committedText: string = '';
  private interimText: string = '';
  private statusMessage: string | null = null;
  private statusMessageTimer: any = null;

  private convManager: ConversationManager;
  private listeners: DictationListener[] = [];

  private constructor() {
    this.convManager = ConversationManager.getInstance();
    this.setupSubscriptions();
  }

  public static getInstance(): DictationManager {
    if (!DictationManager.instance) {
      DictationManager.instance = new DictationManager();
    }
    return DictationManager.instance;
  }

  private setupSubscriptions(): void {
    // Sync speaking / thinking states from ConversationManager
    this.convManager.onChatStateChange((chatState) => {
      if (this.state === 'DICTATION') {
        // While user is in dictation mode, keep DICTATION state active
        return;
      }

      if (chatState === 'speaking') {
        this.state = 'SPEAKING';
      } else if (chatState === 'thinking' || chatState === 'streaming') {
        this.state = 'THINKING';
      } else if (chatState === 'sending') {
        this.state = 'SENDING';
      } else {
        this.state = 'NORMAL_VOICE';
      }
      this.notify();
    });
  }

  public subscribe(listener: DictationListener): () => void {
    this.listeners.push(listener);
    listener(this.getSnapshot());
    return () => {
      this.listeners = this.listeners.filter((l) => l !== listener);
    };
  }

  public getSnapshot(): DictationSnapshot {
    return {
      state: this.state,
      composerText: this.getComposerText(),
      isDictating: this.state === 'DICTATION',
      statusMessage: this.statusMessage,
    };
  }

  public getState(): DictationState {
    return this.state;
  }

  public isDictating(): boolean {
    return this.state === 'DICTATION';
  }

  public getComposerText(): string {
    if (!this.interimText) {
      return this.committedText;
    }
    if (!this.committedText) {
      return this.interimText;
    }
    return `${this.committedText} ${this.interimText}`;
  }

  private notify(): void {
    const snapshot = this.getSnapshot();
    for (const listener of this.listeners) {
      try {
        listener(snapshot);
      } catch (e) {
        console.error('[DictationManager] Listener error:', e);
      }
    }
  }

  public setStatusMessage(msg: string | null, durationMs: number = 3500): void {
    this.statusMessage = msg;
    this.notify();
    if (this.statusMessageTimer) clearTimeout(this.statusMessageTimer);
    if (msg) {
      this.statusMessageTimer = setTimeout(() => {
        this.statusMessage = null;
        this.notify();
      }, durationMs);
    }
  }

  /**
   * Starts Dictation Mode.
   * If initial content is passed (e.g. from "Chat par likho What is photosynthesis"),
   * places that content directly into the composer.
   * Plays a short prompt "Sure, I'm ready." if toggle-only.
   * Then remains silent.
   */
  public startDictation(initialContent?: string): void {
    this.state = 'DICTATION';
    this.interimText = '';

    if (initialContent && initialContent.trim()) {
      const clean = initialContent.trim();
      this.committedText = clean;
      this.setStatusMessage(`Drafted in Chat: "${clean.slice(0, 32)}${clean.length > 32 ? '...' : ''}"`);
      // When content was immediately supplied, remain completely silent (do NOT speak content back)
    } else {
      this.setStatusMessage('✎ Dictation Mode active. Listening for text...');
      // Short vocal feedback
      this.speakVoiceShort("Sure, I'm ready.");
    }

    this.notify();
  }

  /**
   * Stops Dictation Mode and returns to NORMAL_VOICE.
   */
  public stopDictation(): void {
    if (this.state === 'DICTATION') {
      this.state = 'NORMAL_VOICE';
      this.interimText = '';
      this.setStatusMessage(null);
      this.notify();
    }
  }

  /**
   * Sets composer text directly (e.g. from manual textarea typing or full replace).
   */
  public setComposerText(text: string): void {
    this.committedText = text;
    this.interimText = '';
    this.notify();
  }

  /**
   * Appends text to the composer without duplicating existing words.
   */
  public appendComposerText(text: string): void {
    const clean = text.trim();
    if (!clean) return;

    if (!this.committedText) {
      this.committedText = clean;
    } else {
      const separator = this.committedText.endsWith(' ') ? '' : ' ';
      this.committedText = `${this.committedText}${separator}${clean}`;
    }
    this.interimText = '';
    this.notify();
  }

  /**
   * Clears the composer text and resets interim state.
   */
  public clearComposerText(): void {
    this.committedText = '';
    this.interimText = '';
    this.setStatusMessage('Composer cleared.');
    this.notify();
  }

  /**
   * Handles real-time speech results while in DICTATION mode.
   * Prevents word duplication by separating interim and final transcript accumulation.
   */
  public handleSpeechResult(transcript: string, isFinal: boolean): void {
    if (this.state !== 'DICTATION') return;
    const clean = transcript.trim();
    if (!clean) return;

    if (!isFinal) {
      // Live partial preview
      this.interimText = clean;
      this.setStatusMessage('✎ Writing to Chat...');
      this.notify();
    } else {
      // Finalized sentence chunk -> merge into committedText
      this.interimText = '';
      this.appendComposerText(clean);
      this.setStatusMessage('Text added to composer. Say "Send this" or edit.');
    }
  }

  /**
   * Sends the current composer message to Hinata AI / Gemini.
   */
  public async sendComposerMessage(): Promise<void> {
    const textToSend = this.getComposerText().trim();
    if (!textToSend) {
      this.setStatusMessage('Composer is empty. Speak or type a message first.');
      return;
    }

    // Clear composer and exit dictation mode
    this.committedText = '';
    this.interimText = '';
    this.state = 'SENDING';
    this.setStatusMessage('Sending message...');
    this.notify();

    try {
      await this.convManager.sendMessage({
        text: textToSend,
        speakVoice: true, // Speak response for voice-initiated commands
      });
      this.state = 'NORMAL_VOICE';
      this.setStatusMessage(null);
      this.notify();
    } catch (err: any) {
      console.error('[DictationManager] Failed to send composer message:', err);
      this.state = 'ERROR';
      this.setStatusMessage('Failed to send message.');
      this.notify();
    }
  }

  /**
   * Short TTS feedback (e.g. "Sure, I'm ready.")
   */
  private speakVoiceShort(text: string): void {
    if (typeof window === 'undefined' || !window.speechSynthesis) return;
    try {
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 1.15;
      utterance.pitch = 1.12;
      const voices = window.speechSynthesis.getVoices();
      const femaleVoice = voices.find(
        (v) =>
          v.lang.startsWith('en') &&
          (v.name.toLowerCase().includes('female') ||
            v.name.toLowerCase().includes('samantha') ||
            v.name.toLowerCase().includes('natural'))
      );
      if (femaleVoice) utterance.voice = femaleVoice;
      window.speechSynthesis.speak(utterance);
    } catch (e) {
      console.warn('[DictationManager] Speech feedback error:', e);
    }
  }
}
