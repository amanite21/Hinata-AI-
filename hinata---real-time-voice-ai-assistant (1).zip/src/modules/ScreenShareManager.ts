/**
 * ScreenShareManager - Handles official Web / Android MediaProjection screen capture,
 * intelligent low-latency frame extraction, battery optimization, and lifecycle events.
 */

import { ScreenShareState } from '../types';

export type ScreenFrameCallback = (frameBase64: string, mimeType: string) => void;
export type ScreenStateListener = (state: ScreenShareState) => void;

export class ScreenShareManager {
  private static instance: ScreenShareManager | null = null;
  private mediaStream: MediaStream | null = null;
  private hiddenVideo: HTMLVideoElement | null = null;
  private offscreenCanvas: HTMLCanvasElement | null = null;
  private changeDetectCanvas: HTMLCanvasElement | null = null;
  private prevThumbData: Uint8ClampedArray | null = null;
  private captureIntervalId: any = null;
  private heartbeatTimerId: any = null;
  private frameCallback: ScreenFrameCallback | null = null;
  private stateListeners: ScreenStateListener[] = [];
  private lastMeaningfulChangeTime: number = 0;

  private state: ScreenShareState = {
    isActive: false,
    fps: 0,
    lastFrameTimestamp: 0,
    error: null,
  };

  // Frame capture rate: 1 frame every 1.2s on active changes, throttled to 8s heartbeat on static screen
  private readonly ACTIVE_CAPTURE_INTERVAL_MS = 1200;
  private readonly STATIC_HEARTBEAT_INTERVAL_MS = 8000;
  private readonly MAX_DIMENSION = 1024;
  private readonly JPEG_QUALITY = 0.72;
  private readonly CHANGE_THRESHOLD_PERCENT = 2.5; // 2.5% pixel diff threshold

  private constructor() {}

  public static getInstance(): ScreenShareManager {
    if (!ScreenShareManager.instance) {
      ScreenShareManager.instance = new ScreenShareManager();
    }
    return ScreenShareManager.instance;
  }

  public subscribe(listener: ScreenStateListener): () => void {
    this.stateListeners.push(listener);
    listener({ ...this.state });
    return () => {
      this.stateListeners = this.stateListeners.filter((l) => l !== listener);
    };
  }

  private notifyState(partial: Partial<ScreenShareState>): void {
    this.state = { ...this.state, ...partial };
    for (const listener of this.stateListeners) {
      try {
        listener({ ...this.state });
      } catch (e) {
        console.error('[ScreenShareManager] Listener error:', e);
      }
    }
  }

  public getState(): Readonly<ScreenShareState> {
    return { ...this.state };
  }

  public isScreenSharing(): boolean {
    return this.state.isActive && !!this.mediaStream && this.mediaStream.active;
  }

  public setFrameCallback(callback: ScreenFrameCallback | null): void {
    this.frameCallback = callback;
  }

  /**
   * Requests official screen capture permission via navigator.mediaDevices.getDisplayMedia (MediaProjection).
   * Explicit user permission is strictly required before any capture occurs.
   */
  public async startScreenShare(onFrame?: ScreenFrameCallback): Promise<boolean> {
    if (this.isScreenSharing()) {
      return true;
    }

    if (onFrame) {
      this.frameCallback = onFrame;
    }

    if (
      typeof navigator === 'undefined' ||
      !navigator.mediaDevices ||
      !navigator.mediaDevices.getDisplayMedia
    ) {
      const errMsg = 'Screen sharing is not supported by your current browser or platform.';
      this.notifyState({ error: errMsg, isActive: false });
      throw new Error(errMsg);
    }

    try {
      this.notifyState({ error: null });

      // Request official Android / browser display permission
      const stream = await navigator.mediaDevices.getDisplayMedia({
        video: {
          displaySurface: 'monitor' as any,
          frameRate: { ideal: 5, max: 10 },
        },
        audio: false,
      });

      this.mediaStream = stream;

      // Handle user terminating stream via native system bar / banner
      const videoTrack = stream.getVideoTracks()[0];
      if (videoTrack) {
        videoTrack.onended = () => {
          console.log('[ScreenShareManager] Video track ended by user/system');
          this.stopScreenShare();
        };
      }

      // Create hidden video element to render incoming display stream
      this.hiddenVideo = document.createElement('video');
      this.hiddenVideo.autoplay = true;
      this.hiddenVideo.muted = true;
      this.hiddenVideo.playsInline = true;
      this.hiddenVideo.srcObject = stream;

      await this.hiddenVideo.play();

      // Create reusable canvases
      this.offscreenCanvas = document.createElement('canvas');
      this.changeDetectCanvas = document.createElement('canvas');
      this.changeDetectCanvas.width = 16;
      this.changeDetectCanvas.height = 16;
      this.prevThumbData = null;
      this.lastMeaningfulChangeTime = Date.now();

      this.notifyState({
        isActive: true,
        error: null,
        lastFrameTimestamp: Date.now(),
      });

      // Capture initial immediate frame
      this.captureAndEmitFrame(true);

      // Start intelligent change-detected frame pipeline
      this.startOptimizedPipeline();

      return true;
    } catch (err: any) {
      const isCancellation =
        err?.name === 'NotAllowedError' ||
        err?.name === 'AbortError' ||
        err?.message?.includes('Permission denied') ||
        err?.message?.includes('cancelled');

      const message = isCancellation
        ? 'Screen sharing permission was cancelled.'
        : err?.message || 'Unable to access screen capture.';

      console.warn('[ScreenShareManager] Screen share start error:', err);
      this.stopScreenShare();
      this.notifyState({
        error: isCancellation ? null : message,
        isActive: false,
      });
      return false;
    }
  }

  /**
   * Evaluates whether screen has changed significantly using a fast 16x16 thumbnail diff.
   */
  private checkScreenChanged(): boolean {
    if (!this.hiddenVideo || !this.changeDetectCanvas) return true;
    const ctx = this.changeDetectCanvas.getContext('2d', { willReadFrequently: true });
    if (!ctx) return true;

    ctx.drawImage(this.hiddenVideo, 0, 0, 16, 16);
    const imgData = ctx.getImageData(0, 0, 16, 16).data;

    if (!this.prevThumbData) {
      this.prevThumbData = new Uint8ClampedArray(imgData);
      return true;
    }

    let diffSum = 0;
    const totalPixels = 16 * 16;
    for (let i = 0; i < imgData.length; i += 4) {
      const dr = Math.abs(imgData[i] - this.prevThumbData[i]);
      const dg = Math.abs(imgData[i + 1] - this.prevThumbData[i + 1]);
      const db = Math.abs(imgData[i + 2] - this.prevThumbData[i + 2]);
      diffSum += (dr + dg + db) / 3;
    }

    const avgDiff = diffSum / totalPixels; // 0 to 255
    const diffPercent = (avgDiff / 255) * 100;

    // Update reference thumbnail
    this.prevThumbData.set(imgData);

    return diffPercent >= this.CHANGE_THRESHOLD_PERCENT;
  }

  private startOptimizedPipeline(): void {
    if (this.captureIntervalId) clearInterval(this.captureIntervalId);

    this.captureIntervalId = setInterval(() => {
      if (!this.isScreenSharing()) return;

      const hasChanged = this.checkScreenChanged();
      const now = Date.now();

      if (hasChanged) {
        this.lastMeaningfulChangeTime = now;
        this.captureAndEmitFrame(false);
      } else if (now - this.lastMeaningfulChangeTime > this.STATIC_HEARTBEAT_INTERVAL_MS) {
        // Send a keepalive frame only every 8 seconds on static screen
        this.lastMeaningfulChangeTime = now;
        this.captureAndEmitFrame(false);
      }
    }, this.ACTIVE_CAPTURE_INTERVAL_MS);
  }

  /**
   * Captures an optimized frame from the active video stream and dispatches it.
   */
  private captureAndEmitFrame(force: boolean = false): string | null {
    if (!this.hiddenVideo || !this.offscreenCanvas || !this.mediaStream || !this.mediaStream.active) {
      return null;
    }

    const vw = this.hiddenVideo.videoWidth;
    const vh = this.hiddenVideo.videoHeight;
    if (!vw || !vh) {
      return null;
    }

    // Downscale while preserving aspect ratio (capped at 1024px max dimension)
    let targetW = vw;
    let targetH = vh;
    if (vw > this.MAX_DIMENSION || vh > this.MAX_DIMENSION) {
      if (vw >= vh) {
        targetW = this.MAX_DIMENSION;
        targetH = Math.round((vh * this.MAX_DIMENSION) / vw);
      } else {
        targetH = this.MAX_DIMENSION;
        targetW = Math.round((vw * this.MAX_DIMENSION) / vh);
      }
    }

    this.offscreenCanvas.width = targetW;
    this.offscreenCanvas.height = targetH;
    const ctx = this.offscreenCanvas.getContext('2d');
    if (!ctx) return null;

    ctx.drawImage(this.hiddenVideo, 0, 0, targetW, targetH);
    const dataUrl = this.offscreenCanvas.toDataURL('image/jpeg', this.JPEG_QUALITY);
    const base64 = dataUrl.replace(/^data:image\/jpeg;base64,/, '');

    this.notifyState({
      lastFrameTimestamp: Date.now(),
      fps: 1,
    });

    if (this.frameCallback) {
      try {
        this.frameCallback(base64, 'image/jpeg');
      } catch (err) {
        console.error('[ScreenShareManager] Frame callback error:', err);
      }
    }

    return base64;
  }

  /**
   * Immediately captures a single frame on demand (e.g. when user asks "What's on my screen?").
   */
  public captureImmediateFrame(): { base64: string; dataUrl: string; mimeType: string } | null {
    if (!this.isScreenSharing() || !this.hiddenVideo || !this.offscreenCanvas) {
      return null;
    }

    const vw = this.hiddenVideo.videoWidth;
    const vh = this.hiddenVideo.videoHeight;
    if (!vw || !vh) return null;

    const targetW = Math.min(vw, 1280);
    const targetH = Math.round((vh * targetW) / vw);
    this.offscreenCanvas.width = targetW;
    this.offscreenCanvas.height = targetH;
    const ctx = this.offscreenCanvas.getContext('2d');
    if (!ctx) return null;

    ctx.drawImage(this.hiddenVideo, 0, 0, targetW, targetH);
    const dataUrl = this.offscreenCanvas.toDataURL('image/jpeg', 0.82);
    const base64 = dataUrl.replace(/^data:image\/jpeg;base64,/, '');

    return {
      base64,
      dataUrl,
      mimeType: 'image/jpeg',
    };
  }

  /**
   * Completely terminates screen sharing, stops all video hardware tracks, and clears resources.
   * Ensures no hidden capture continues after stop.
   */
  public stopScreenShare(): void {
    if (this.captureIntervalId) {
      clearInterval(this.captureIntervalId);
      this.captureIntervalId = null;
    }
    if (this.heartbeatTimerId) {
      clearInterval(this.heartbeatTimerId);
      this.heartbeatTimerId = null;
    }

    if (this.mediaStream) {
      try {
        this.mediaStream.getTracks().forEach((track) => {
          track.stop();
        });
      } catch (e) {
        console.warn('[ScreenShareManager] Track stop warning:', e);
      }
      this.mediaStream = null;
    }

    if (this.hiddenVideo) {
      this.hiddenVideo.srcObject = null;
      this.hiddenVideo.remove();
      this.hiddenVideo = null;
    }

    this.offscreenCanvas = null;
    this.changeDetectCanvas = null;
    this.prevThumbData = null;

    this.notifyState({
      isActive: false,
      fps: 0,
    });
  }
}
