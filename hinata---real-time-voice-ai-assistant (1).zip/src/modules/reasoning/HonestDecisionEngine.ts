/**
 * HonestDecisionEngine - Critical Thinking, Capability Evaluation & Epistemic Calibration for Hinata AI.
 *
 * Implements:
 * - Request Capability Categorization (SUPPORTED, PARTIALLY_SUPPORTED, UNSUPPORTED, UNSAFE, IMPOSSIBLE_WITH_CURRENT_PERMISSIONS, NEEDS_USER_INPUT, NEEDS_EXTERNAL_SERVICE)
 * - Epistemic Calibration: Fact vs Guess (KNOWN, CONFIRMED, INFERRED, UNCERTAIN)
 * - Transparent Refusal & Limitation Explanations ("Learn to say NO")
 * - Usability Advisory & Respectful Disagreement (User Request vs Good Design)
 * - Consequential Action Safety Guard (Calls, messages, deleting files, purchases, system changes)
 * - Decision Support Analysis (Options, Pros, Cons, Risks, Recommendation basis)
 * - Real-world Action Verification (SUCCESS, FAILED, UNKNOWN)
 */

export type CapabilityStatus =
  | 'SUPPORTED'
  | 'PARTIALLY_SUPPORTED'
  | 'UNSUPPORTED'
  | 'UNSAFE'
  | 'IMPOSSIBLE_WITH_CURRENT_PERMISSIONS'
  | 'NEEDS_USER_INPUT'
  | 'NEEDS_EXTERNAL_SERVICE';

export type EpistemicStatus = 'KNOWN' | 'CONFIRMED' | 'INFERRED' | 'UNCERTAIN';

export interface DecisionEvaluation {
  status: CapabilityStatus;
  epistemicStatus: EpistemicStatus;
  canExecute: boolean;
  requiresConfirmation: boolean;
  reason: string;
  recommendedResponse: string;
  usableAlternative?: string;
  decisionSupport?: {
    optionA: { name: string; pros: string; cons: string };
    optionB: { name: string; pros: string; cons: string };
    risks: string[];
    recommendationBasis: string;
  };
}

export class HonestDecisionEngine {
  private static instance: HonestDecisionEngine | null = null;

  private constructor() {}

  public static getInstance(): HonestDecisionEngine {
    if (!HonestDecisionEngine.instance) {
      HonestDecisionEngine.instance = new HonestDecisionEngine();
    }
    return HonestDecisionEngine.instance;
  }

  /**
   * Evaluates any user command or request through rigorous critical thinking and safety rules.
   */
  public evaluateRequest(prompt: string, context?: {
    hasMicPermission?: boolean;
    hasCameraPermission?: boolean;
    hasScreenShare?: boolean;
    backendOnline?: boolean;
    knownFacts?: string[];
  }): DecisionEvaluation {
    const raw = prompt.trim();
    const lower = raw.toLowerCase();

    // 1. Destructive & Consequential Actions Guard (Delete files, factory reset, format, purchases, posting)
    if (
      lower.includes('delete') ||
      lower.includes('format') ||
      lower.includes('wipe') ||
      lower.includes('uninstall') ||
      lower.includes('factory reset') ||
      lower.includes('buy') ||
      lower.includes('purchase') ||
      lower.includes('post to') ||
      lower.includes('tweet')
    ) {
      return {
        status: 'UNSAFE',
        epistemicStatus: 'KNOWN',
        canExecute: false,
        requiresConfirmation: true,
        reason: 'Action involves potentially destructive or permanent data loss, financial impact, or public dissemination.',
        recommendedResponse: `I found the target operation for "${raw}". Because this action is permanent or consequential, I need your explicit confirmation before proceeding. Would you like me to proceed or cancel?`,
      };
    }

    // 2. Impossible with Current Permissions (e.g. silent camera access, unauthorized location, SMS reading without grant)
    if (lower.includes('spy') || lower.includes('silent camera') || lower.includes('read private messages') || lower.includes('hack')) {
      return {
        status: 'IMPOSSIBLE_WITH_CURRENT_PERMISSIONS',
        epistemicStatus: 'CONFIRMED',
        canExecute: false,
        requiresConfirmation: false,
        reason: 'Android security model and sandboxed runtime strictly prohibit unauthorized background access to sensors or private user files.',
        recommendedResponse: "I can't do that with the current Android permissions and security sandbox. Android strictly blocks unprompted background access to sensors or private application datastores.",
      };
    }

    // 3. Hardware / External Feature Restrictions
    if (lower.includes('make a phone call') || lower.includes('call ')) {
      // Calls are supported but require user confirmation
      return {
        status: 'PARTIALLY_SUPPORTED',
        epistemicStatus: 'KNOWN',
        canExecute: true,
        requiresConfirmation: true,
        reason: 'Placing phone calls requires dialing intent dispatch with user confirmation.',
        recommendedResponse: 'I can initiate that call via Android Telephony, but I need your confirmation before connecting.',
      };
    }

    // 4. Usability Harm Advisory / Respectful Disagreement
    // e.g. "make everything red", "remove all labels", "put 50 buttons", "hide text"
    if (
      (lower.includes('make everything red') || lower.includes('all red') || lower.includes('pure red background')) ||
      (lower.includes('remove all labels') || lower.includes('no labels')) ||
      (lower.includes('make font size 5') || lower.includes('tiny text')) ||
      (lower.includes('no borders') && lower.includes('no contrast'))
    ) {
      return {
        status: 'SUPPORTED',
        epistemicStatus: 'INFERRED',
        canExecute: true,
        requiresConfirmation: false,
        reason: 'The requested aesthetic conflicts with WCAG AA accessibility and ergonomic visual hierarchy.',
        recommendedResponse:
          "I can do that, but one concern: using high-saturation red everywhere significantly reduces contrast, strains readability, and eliminates visual hierarchy. I'd suggest using red as a crisp focal accent on interactive buttons while keeping the main surfaces dark. If you still prefer the entire interface in solid red, I can implement it.",
        usableAlternative: 'Red focal accent buttons on deep slate containers (#080c1a) with WCAG AA compliance.',
        decisionSupport: {
          optionA: {
            name: 'Full Solid Red',
            pros: 'Literally satisfies user prompt',
            cons: 'Eye fatigue, illegible body text, fails WCAG AA standards',
          },
          optionB: {
            name: 'Red Accent on Dark Surface (Recommended)',
            pros: 'High contrast, distinct visual hierarchy, battery efficient',
            cons: 'Slightly less saturated overall',
          },
          risks: ['Severe reduction in user legibility and cognitive navigation speed.'],
          recommendationBasis: 'WCAG AA 4.5:1 contrast requirement for mobile UI readability.',
        },
      };
    }

    // 5. Fact vs Guess / Epistemic Calibration
    // If user asks for unverified personal information or things not present in data
    if (
      lower.includes('what am i wearing') ||
      lower.includes('what is outside my window') ||
      lower.includes('who is standing behind me')
    ) {
      if (!context?.hasCameraPermission && !context?.hasScreenShare) {
        return {
          status: 'UNSUPPORTED',
          epistemicStatus: 'UNCERTAIN',
          canExecute: false,
          requiresConfirmation: false,
          reason: 'Camera or screen sharing feed is inactive; physical optical reality cannot be verified.',
          recommendedResponse: "I can't verify that from the information available because my vision feed and camera are not active.",
        };
      }
    }

    // 6. Design Creation Commands ("Design bana do", "Khud design socho", "Create an app")
    if (
      lower.includes('design bana do') ||
      lower.includes('khud design socho') ||
      lower.includes('make a design') ||
      lower.includes('create a design') ||
      lower.includes('design karo') ||
      lower.includes('ai dashboard design') ||
      lower.includes('music player design')
    ) {
      return {
        status: 'SUPPORTED',
        epistemicStatus: 'KNOWN',
        canExecute: true,
        requiresConfirmation: false,
        reason: 'Fully supported by Hinata Design Intelligence Engine across 20 distinct design domains.',
        recommendedResponse: 'I am creating an original design based on purpose, visual hierarchy, and mobile ergonomics.',
      };
    }

    // 7. Standard Supported Task
    return {
      status: 'SUPPORTED',
      epistemicStatus: 'KNOWN',
      canExecute: true,
      requiresConfirmation: false,
      reason: 'Standard conversational or actionable prompt within Hinata capability parameters.',
      recommendedResponse: '',
    };
  }

  /**
   * Truthfully verifies real-world action outcome.
   * Strictly returns SUCCESS, FAILED, or UNKNOWN.
   */
  public verifyActionOutcome(
    actionName: string,
    success: boolean,
    verifiedByRuntime: boolean = false
  ): {
    state: 'SUCCESS' | 'FAILED' | 'UNKNOWN';
    truthfulMessage: string;
  } {
    if (!verifiedByRuntime) {
      return {
        state: 'UNKNOWN',
        truthfulMessage: `Dispatched intent for ${actionName}, but Android could not confirm the final activity lifecycle state.`,
      };
    }

    if (success) {
      return {
        state: 'SUCCESS',
        truthfulMessage: `Verified: ${actionName} opened and is active.`,
      };
    }

    return {
      state: 'FAILED',
      truthfulMessage: `Failed: ${actionName} could not be launched or was cancelled.`,
    };
  }
}
