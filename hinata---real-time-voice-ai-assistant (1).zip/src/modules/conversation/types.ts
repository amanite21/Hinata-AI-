export type MessageRole = 'user' | 'assistant' | 'system';

export type MessageStatus = 'sending' | 'streaming' | 'sent' | 'error';

export interface ChatMessage {
  id: string;
  role: MessageRole;
  content: string;
  timestamp: number;
  image?: {
    dataUrl: string;
    name?: string;
  };
  status?: MessageStatus;
  emotion?: string;
  toolsUsed?: string[];
  error?: string;
  authFailed?: boolean;
}

export interface Conversation {
  id: string;
  title: string;
  createdAt: number;
  updatedAt: number;
  messages: ChatMessage[];
}

export type ChatState =
  | 'idle'
  | 'sending'
  | 'thinking'
  | 'streaming'
  | 'speaking'
  | 'error';
