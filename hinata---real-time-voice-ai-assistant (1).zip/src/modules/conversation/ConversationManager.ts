import { ChatMessage, Conversation, ChatState, MessageRole } from './types';
import { MemoryManager } from '../memory/MemoryManager';
import { EmotionManager } from '../EmotionManager';
import { EmotionalState } from '../../types';
import { backendConfig } from '../../config/backendConfig';
import { HinataBrain } from '../HinataBrain';
import { ClientAIProvider } from '../ai/AIProvider';

const STORAGE_CONVERSATIONS_KEY = 'hinata_conversations_v1';
const STORAGE_ACTIVE_ID_KEY = 'hinata_active_conv_id_v1';
const STORAGE_AUTO_VOICE_REPLY_KEY = 'hinata_auto_voice_reply_v1';

export type ConversationListener = (conversations: Conversation[], active: Conversation) => void;
export type ChatStateListener = (state: ChatState, details?: string) => void;
export type VolumeListener = (volume: number) => void;

export class ConversationManager {
  private static instance: ConversationManager | null = null;

  private conversations: Conversation[] = [];
  private activeConversationId: string = '';
  private chatState: ChatState = 'idle';
  private stateDetails: string = '';
  private autoVoiceReply: boolean = true;

  private listeners: ConversationListener[] = [];
  private stateListeners: ChatStateListener[] = [];
  private volumeListeners: VolumeListener[] = [];

  private currentAbortController: AbortController | null = null;
  private currentUtterance: SpeechSynthesisUtterance | null = null;
  private speakingInterval: any = null;
  private currentlySpeakingMessageId: string | null = null;

  private constructor() {
    this.loadFromStorage();
  }

  public static getInstance(): ConversationManager {
    if (!ConversationManager.instance) {
      ConversationManager.instance = new ConversationManager();
    }
    return ConversationManager.instance;
  }

  public subscribe(listener: ConversationListener): () => void {
    this.listeners.push(listener);
    const active = this.getActiveConversation();
    listener(this.conversations, active);
    return () => {
      this.listeners = this.listeners.filter((l) => l !== listener);
    };
  }

  public onChatStateChange(listener: ChatStateListener): () => void {
    this.stateListeners.push(listener);
    listener(this.chatState, this.stateDetails);
    return () => {
      this.stateListeners = this.stateListeners.filter((l) => l !== listener);
    };
  }

  public onSpeechVolume(listener: VolumeListener): () => void {
    this.volumeListeners.push(listener);
    return () => {
      this.volumeListeners = this.volumeListeners.filter((l) => l !== listener);
    };
  }

  public getChatState(): ChatState {
    return this.chatState;
  }

  public getCurrentlySpeakingMessageId(): string | null {
    return this.currentlySpeakingMessageId;
  }

  public getAutoVoiceReply(): boolean {
    return this.autoVoiceReply;
  }

  public setAutoVoiceReply(enabled: boolean): void {
    this.autoVoiceReply = enabled;
    try {
      localStorage.setItem(STORAGE_AUTO_VOICE_REPLY_KEY, String(enabled));
    } catch (e) {}
    this.notify();
  }

  private setChatState(state: ChatState, details: string = ''): void {
    this.chatState = state;
    this.stateDetails = details;
    for (const listener of this.stateListeners) {
      try {
        listener(state, details);
      } catch (err) {
        console.error('[ConversationManager] State listener error:', err);
      }
    }
  }

  private notifyVolume(vol: number): void {
    for (const listener of this.volumeListeners) {
      try {
        listener(vol);
      } catch (err) {
        console.error('[ConversationManager] Volume listener error:', err);
      }
    }
  }

  private notify(): void {
    this.saveToStorage();
    const active = this.getActiveConversation();
    for (const listener of this.listeners) {
      try {
        listener([...this.conversations], active);
      } catch (err) {
        console.error('[ConversationManager] Listener error:', err);
      }
    }
  }

  // ----------------------------------------------------
  // Storage & Conversation Lifecycle
  // ----------------------------------------------------

  private loadFromStorage(): void {
    try {
      const autoVoice = localStorage.getItem(STORAGE_AUTO_VOICE_REPLY_KEY);
      if (autoVoice !== null) {
        this.autoVoiceReply = autoVoice === 'true';
      }
    } catch (e) {}

    try {
      const raw = localStorage.getItem(STORAGE_CONVERSATIONS_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed) && parsed.length > 0) {
          this.conversations = parsed;
        }
      }
    } catch (e) {
      console.warn('[ConversationManager] Storage load warning:', e);
    }

    // Default conversation if empty
    if (this.conversations.length === 0) {
      const initialConv: Conversation = {
        id: 'conv-' + Date.now(),
        title: 'New Conversation',
        createdAt: Date.now(),
        updatedAt: Date.now(),
        messages: [
          {
            id: 'msg-welcome',
            role: 'assistant',
            content:
              "Hello! I am Hinata, your personal AI companion. You can converse with me here through text, attach images or screenshots for visual analysis, or use voice input anytime. How can I assist you today, Aman?",
            timestamp: Date.now(),
            status: 'sent',
            emotion: 'happy',
          },
        ],
      };
      this.conversations = [initialConv];
      this.activeConversationId = initialConv.id;
    } else {
      const savedActiveId = localStorage.getItem(STORAGE_ACTIVE_ID_KEY);
      if (savedActiveId && this.conversations.some((c) => c.id === savedActiveId)) {
        this.activeConversationId = savedActiveId;
      } else {
        this.activeConversationId = this.conversations[0].id;
      }
    }
    backendConfig.setActiveConversationId(this.activeConversationId);
  }

  private saveToStorage(): void {
    try {
      backendConfig.setActiveConversationId(this.activeConversationId);
      // Keep only last 20 conversations and up to 100 messages each to avoid storage bloat
      const sanitized = this.conversations.slice(0, 20).map((conv) => ({
        ...conv,
        messages: conv.messages.slice(-80).map((msg) => {
          // Do not store large base64 image data permanently in conversation history
          if (msg.image && msg.image.dataUrl.length > 200000) {
            return {
              ...msg,
              image: {
                ...msg.image,
                dataUrl: 'data:image/jpeg;base64,...[saved-reference]',
              },
            };
          }
          return msg;
        }),
      }));
      localStorage.setItem(STORAGE_CONVERSATIONS_KEY, JSON.stringify(sanitized));
      localStorage.setItem(STORAGE_ACTIVE_ID_KEY, this.activeConversationId);
    } catch (e) {
      console.warn('[ConversationManager] Storage save warning:', e);
    }
  }

  public getActiveConversation(): Conversation {
    const found = this.conversations.find((c) => c.id === this.activeConversationId);
    if (found) return found;
    if (this.conversations.length > 0) {
      this.activeConversationId = this.conversations[0].id;
      return this.conversations[0];
    }
    return this.createConversation();
  }

  public getAllConversations(): Conversation[] {
    return [...this.conversations];
  }

  public createConversation(title?: string): Conversation {
    this.interrupt();
    const newConv: Conversation = {
      id: 'conv-' + Date.now() + '-' + Math.random().toString(36).substring(2, 6),
      title: title || 'New Conversation',
      createdAt: Date.now(),
      updatedAt: Date.now(),
      messages: [
        {
          id: 'msg-' + Date.now(),
          role: 'assistant',
          content: 'Started a fresh conversation context. What would you like to explore or work on?',
          timestamp: Date.now(),
          status: 'sent',
          emotion: 'calm',
        },
      ],
    };
    this.conversations.unshift(newConv);
    this.activeConversationId = newConv.id;
    this.notify();
    return newConv;
  }

  public switchConversation(id: string): Conversation {
    this.interrupt();
    const found = this.conversations.find((c) => c.id === id);
    if (found) {
      this.activeConversationId = id;
      this.notify();
      return found;
    }
    return this.getActiveConversation();
  }

  public deleteConversation(id: string): void {
    this.interrupt();
    this.conversations = this.conversations.filter((c) => c.id !== id);
    if (this.conversations.length === 0) {
      this.createConversation();
    } else if (this.activeConversationId === id) {
      this.activeConversationId = this.conversations[0].id;
      this.notify();
    } else {
      this.notify();
    }
  }

  public renameConversation(id: string, newTitle: string): void {
    const conv = this.conversations.find((c) => c.id === id);
    if (conv && newTitle.trim()) {
      conv.title = newTitle.trim();
      conv.updatedAt = Date.now();
      this.notify();
    }
  }

  public clearMessages(id?: string): void {
    this.interrupt();
    const targetId = id || this.activeConversationId;
    const conv = this.conversations.find((c) => c.id === targetId);
    if (conv) {
      conv.messages = [
        {
          id: 'msg-' + Date.now(),
          role: 'assistant',
          content: 'Conversation history cleared. Ready for your next question or task.',
          timestamp: Date.now(),
          status: 'sent',
          emotion: 'calm',
        },
      ];
      conv.updatedAt = Date.now();
      this.notify();
    }
  }

  // ----------------------------------------------------
  // Voice <-> Chat Cross-Modal Synchronization
  // ----------------------------------------------------

  /**
   * Synchronizes live speech transcripts from Voice Mode into the conversation context.
   * This guarantees that when switching from Voice to Chat (or vice-versa),
   * Hinata has the full preceding context.
   */
  public syncVoiceTurn(role: MessageRole, text: string): void {
    if (!text || !text.trim()) return;
    const active = this.getActiveConversation();
    const lastMsg = active.messages[active.messages.length - 1];

    // Avoid duplicate insertions if transcript is identical to last message
    if (lastMsg && lastMsg.content.trim() === text.trim() && lastMsg.role === role) {
      return;
    }

    const newMsg: ChatMessage = {
      id: 'voice-' + Date.now() + '-' + Math.random().toString(36).substring(2, 6),
      role,
      content: text.trim(),
      timestamp: Date.now(),
      status: 'sent',
    };

    active.messages.push(newMsg);
    active.updatedAt = Date.now();
    this.notify();
  }

  // ----------------------------------------------------
  // Message Sending & Streaming Pipeline
  // ----------------------------------------------------

  public async sendMessage(params: {
    text: string;
    image?: { dataUrl: string; name?: string };
    speakVoice?: boolean;
  }): Promise<void> {
    const { text, image, speakVoice } = params;
    const cleanText = (text || '').trim();

    if (!cleanText && !image) {
      return;
    }

    this.interrupt();

    const active = this.getActiveConversation();

    // Generate auto-title from first user message if still default
    if (
      active.title === 'New Conversation' &&
      cleanText &&
      active.messages.filter((m) => m.role === 'user').length === 0
    ) {
      active.title = cleanText.slice(0, 32) + (cleanText.length > 32 ? '...' : '');
    }

    // 1. Add user message immediately
    const userMsg: ChatMessage = {
      id: 'user-' + Date.now() + '-' + Math.random().toString(36).substring(2, 6),
      role: 'user',
      content: cleanText,
      timestamp: Date.now(),
      status: 'sent',
      image,
    };
    active.messages.push(userMsg);
    active.updatedAt = Date.now();
    this.notify();

    // 2. Hinata enters THINKING state
    this.setChatState('thinking', 'Analyzing request...');
    try {
      EmotionManager.getInstance().transitionEmotion('curious', 2, 'Processing user prompt');
    } catch {}

    // 3. Process explicit memory commands ("remember...", "forget...", "what do you remember")
    this.handleExplicitMemoryCommands(cleanText);

    // 3.5. Evaluate with HinataBrain (Honest Decision, Local Device Actions, Design Intelligence)
    try {
      const brain = HinataBrain.getInstance();
      const brainEval = await brain.processNaturalCommand(cleanText);
      if (brainEval.handled) {
        let replyText = '';
        if (brainEval.clarificationPrompt) {
          replyText = brainEval.clarificationPrompt;
        } else if (brainEval.result?.message) {
          replyText = brainEval.result.message;
        } else if (brainEval.result?.success) {
          replyText = `Action executed successfully: ${brainEval.result.action}`;
        }

        if (replyText) {
          const assistantMsgId = 'asst-' + Date.now() + '-' + Math.random().toString(36).substring(2, 6);
          const assistantMsg: ChatMessage = {
            id: assistantMsgId,
            role: 'assistant',
            content: replyText,
            timestamp: Date.now(),
            status: 'sent',
            emotion: 'confident',
          };
          active.messages.push(assistantMsg);
          active.updatedAt = Date.now();
          this.notify();
          this.setChatState('idle');

          if (this.autoVoiceReply) {
            this.speakMessage(assistantMsgId).catch(() => {});
          }
          return;
        }
      }
    } catch (e) {
      console.warn('[ConversationManager] HinataBrain evaluation note:', e);
    }

    // 4. Retrieve relevant long-term memories
    let relevantMemories: Array<{ category: string; content: string }> = [];
    try {
      const mm = MemoryManager.getInstance();
      const scored = mm.retriever.search({ query: cleanText, limit: 4, minImportance: 2 });
      relevantMemories = scored.map((s) => ({
        category: s.category,
        content: s.content,
      }));
    } catch (e) {
      console.warn('[ConversationManager] Memory retrieval warning:', e);
    }

    // Check if backend is configured before attempting network call
    if (!backendConfig.isConfigured()) {
      const assistantMsgId = 'asst-' + Date.now() + '-' + Math.random().toString(36).substring(2, 6);
      const assistantMsg: ChatMessage = {
        id: assistantMsgId,
        role: 'assistant',
        content: 'Backend not configured. HINATA_BACKEND_URL is optional during development. When you deploy your backend, configure the URL in Settings or your environment to enable AI chat.',
        timestamp: Date.now(),
        status: 'error',
        error: 'Backend not configured',
      };
      active.messages.push(assistantMsg);
      this.notify();
      this.setChatState('idle');
      return;
    }

    // 5. Create assistant placeholder message
    const assistantMsgId = 'asst-' + Date.now() + '-' + Math.random().toString(36).substring(2, 6);
    const assistantMsg: ChatMessage = {
      id: assistantMsgId,
      role: 'assistant',
      content: '',
      timestamp: Date.now(),
      status: 'streaming',
    };
    active.messages.push(assistantMsg);
    this.notify();

    // 6. Send request to server /api/assistant with streaming SSE
    this.currentAbortController = new AbortController();

    try {
      this.setChatState('sending');

      // Prepare conversation history (last 10 messages)
      const historyPayload = active.messages.slice(-10, -1).map((m) => ({
        role: m.role,
        content: m.content,
      }));

      const res = await backendConfig.fetchWithHeaders('/api/assistant', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          message: cleanText,
          history: historyPayload,
          relevantMemories,
          conversationId: active.id,
          image: image ? { dataUrl: image.dataUrl } : undefined,
          stream: true,
        }),
        signal: this.currentAbortController.signal,
      });

      if (!res.ok) {
        const errJson = await res.json().catch(() => ({}));
        throw new Error(errJson.error || 'Something went wrong while connecting to the AI.');
      }

      // 7. Progressive Streaming Response Reading
      this.setChatState('streaming', 'Hinata is replying...');
      const reader = res.body?.getReader();
      const decoder = new TextDecoder();
      let accumulatedText = '';
      let detectedEmotion: string = 'calm';

      if (reader) {
        let buffer = '';
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;

          buffer += decoder.decode(value, { stream: true });
          const lines = buffer.split('\n');
          buffer = lines.pop() || '';

          for (const line of lines) {
            const trimmed = line.trim();
            if (!trimmed.startsWith('data:')) continue;
            const dataStr = trimmed.slice(5).trim();
            if (!dataStr) continue;

            try {
              const parsed = JSON.parse(dataStr);
              if (parsed.authFailed) {
                assistantMsg.authFailed = true;
                assistantMsg.content = 'AI service authentication failed. Please update the API key.';
                ClientAIProvider.getInstance().reportAuthFailure(
                  parsed.error || 'AI service authentication failed. Please update the API key.'
                );
                this.notify();
              }
              if (parsed.delta) {
                accumulatedText += parsed.delta;
                assistantMsg.content = accumulatedText;
                this.notify();
              }
              if (parsed.emotion) {
                detectedEmotion = parsed.emotion;
              }
              if (parsed.fullText) {
                accumulatedText = parsed.fullText;
                assistantMsg.content = accumulatedText;
              }
              if (parsed.error) {
                if (
                  parsed.error.includes('API_KEY_INVALID') ||
                  parsed.error.includes('auth') ||
                  parsed.error.includes('expired') ||
                  parsed.error.includes('revoked')
                ) {
                  assistantMsg.authFailed = true;
                  ClientAIProvider.getInstance().reportAuthFailure(
                    'AI service authentication failed. Please update the API key.'
                  );
                }
                throw new Error(parsed.error);
              }
            } catch (parseErr) {
              console.warn('[ConversationManager] SSE parse warning:', parseErr);
            }
          }
        }
      } else {
        // Fallback for non-streamable bodies
        const data = await res.json();
        accumulatedText = data.reply || '';
        detectedEmotion = data.emotion || 'calm';
        assistantMsg.content = accumulatedText;
      }

      // Finalize assistant response
      assistantMsg.content = accumulatedText.trim() || 'I am with you.';
      assistantMsg.status = 'sent';
      assistantMsg.emotion = detectedEmotion;
      this.notify();

      // Update Hinata Emotion
      try {
        EmotionManager.getInstance().transitionEmotion(
          (detectedEmotion as EmotionalState) || 'calm',
          2,
          'Chat response'
        );
      } catch {}

      this.setChatState('idle');

      // Voice Reply: Speak response aloud if requested or auto-voice reply is active
      const shouldSpeak =
        speakVoice === true || (speakVoice !== false && this.autoVoiceReply);
      if (shouldSpeak && assistantMsg.content && assistantMsg.id) {
        this.speakMessage(assistantMsg.id).catch((e) => {
          console.warn('[ConversationManager] Auto voice reply playback error:', e);
        });
      }
    } catch (err: any) {
      if (err.name === 'AbortError') {
        console.log('[ConversationManager] Request aborted by user.');
        assistantMsg.content = assistantMsg.content || 'Response paused.';
        assistantMsg.status = 'sent';
        this.notify();
        this.setChatState('idle');
        return;
      }

      console.error('[ConversationManager] Send error:', err);
      let userFacingError = 'Something went wrong while connecting to the AI.';
      const errMsg = err?.message || '';

      if (
        errMsg.includes('API_KEY_INVALID') ||
        errMsg.includes('auth') ||
        errMsg.includes('401') ||
        errMsg.includes('403') ||
        errMsg.includes('expired') ||
        errMsg.includes('revoked') ||
        errMsg.includes('authentication failed')
      ) {
        userFacingError = 'AI service authentication failed. Please update the API key.';
        assistantMsg.authFailed = true;
        ClientAIProvider.getInstance().reportAuthFailure(userFacingError);
      } else if (
        err.message === 'Connection unavailable.' ||
        err.message?.includes('Failed to fetch') ||
        err.message?.includes('NetworkError') ||
        err.message?.includes('network')
      ) {
        userFacingError = 'Connection unavailable.';
      } else if (err.message && err.message.includes('Something went wrong while connecting to the AI.')) {
        userFacingError = 'Something went wrong while connecting to the AI.';
      }

      assistantMsg.content = assistantMsg.content || userFacingError;
      assistantMsg.status = 'error';
      assistantMsg.error = userFacingError;
      this.notify();

      try {
        EmotionManager.getInstance().transitionEmotion('concerned', 2, 'Connection error');
      } catch {}

      this.setChatState('error', userFacingError);
    } finally {
      this.currentAbortController = null;
    }
  }

  /**
   * Synchronizes conversation threads with the backend (GET /api/conversations).
   * Enables seamless conversation continuity across multiple Android phones.
   */
  public async syncWithBackend(): Promise<void> {
    try {
      const res = await backendConfig.fetchWithHeaders('/api/conversations', { method: 'GET' });
      if (!res.ok) return;
      const data = await res.json();
      if (!data.conversations || !Array.isArray(data.conversations)) return;

      const remoteConvs = data.conversations;
      let hasChanges = false;

      for (const remote of remoteConvs) {
        const localIdx = this.conversations.findIndex((c) => c.id === remote.id);
        if (localIdx === -1) {
          this.conversations.push({
            id: remote.id,
            title: remote.title || 'Conversation',
            createdAt: remote.createdAt,
            updatedAt: remote.updatedAt,
            messages: (remote.messages || []).map((m: any) => ({
              id: m.id,
              role: m.role,
              content: m.content,
              timestamp: m.timestamp,
              status: 'sent',
            })),
          });
          hasChanges = true;
        } else {
          const local = this.conversations[localIdx];
          if ((remote.messages?.length || 0) > local.messages.length) {
            local.messages = (remote.messages || []).map((m: any) => ({
              id: m.id,
              role: m.role,
              content: m.content,
              timestamp: m.timestamp,
              status: 'sent',
            }));
            local.updatedAt = remote.updatedAt;
            hasChanges = true;
          }
        }
      }

      if (hasChanges) {
        this.notify();
      }
    } catch (err) {
      console.warn('[ConversationManager] Backend sync skipped or offline:', err);
    }
  }

  /**
   * Retries sending a failed message.
   */
  public async retryMessage(failedMsgId: string): Promise<void> {
    const active = this.getActiveConversation();
    const index = active.messages.findIndex((m) => m.id === failedMsgId);
    if (index === -1) return;

    // Find the preceding user message
    let precedingUserMsg: ChatMessage | null = null;
    for (let i = index - 1; i >= 0; i--) {
      if (active.messages[i].role === 'user') {
        precedingUserMsg = active.messages[i];
        break;
      }
    }

    // Remove the failed assistant message
    active.messages.splice(index, 1);
    this.notify();

    if (precedingUserMsg) {
      await this.sendMessage({
        text: precedingUserMsg.content,
        image: precedingUserMsg.image,
      });
    }
  }

  // ----------------------------------------------------
  // Text-To-Speech Audio & Viseme Synthesis
  // ----------------------------------------------------

  /**
   * Speaks the selected assistant message aloud, driving Hinata's real-time
   * mouth animation, face visemes, and emotional state.
   */
  public async speakMessage(messageId: string): Promise<void> {
    const active = this.getActiveConversation();
    const msg = active.messages.find((m) => m.id === messageId);
    if (!msg || !msg.content) return;

    // If currently speaking this message, toggle interrupt/stop
    if (this.currentlySpeakingMessageId === messageId) {
      this.stopSpeaking();
      return;
    }

    this.stopSpeaking();

    if (typeof window === 'undefined' || !window.speechSynthesis) {
      console.warn('[ConversationManager] SpeechSynthesis not supported.');
      return;
    }

    this.currentlySpeakingMessageId = messageId;
    this.setChatState('speaking', 'Hinata is speaking...');

    try {
      EmotionManager.getInstance().transitionEmotion(
        (msg.emotion as EmotionalState) || 'happy',
        3,
        'Reading response'
      );
    } catch {}

    // Clean up markdown syntax for voice playback (remove code fences, stars, links)
    const voiceText = msg.content
      .replace(/```[\s\S]*?```/g, 'Code block omitted for speech.')
      .replace(/`([^`]+)`/g, '$1')
      .replace(/\[([^\]]+)\]\([^)]+\)/g, '$1')
      .replace(/[*_#~]/g, '')
      .trim();

    const utterance = new SpeechSynthesisUtterance(voiceText);
    utterance.rate = 1.05;
    utterance.pitch = 1.1;

    // Choose voice
    const voices = window.speechSynthesis.getVoices();
    const preferredVoice = voices.find(
      (v) =>
        v.lang.startsWith('en') &&
        (v.name.toLowerCase().includes('female') ||
          v.name.toLowerCase().includes('samantha') ||
          v.name.toLowerCase().includes('zira') ||
          v.name.toLowerCase().includes('natural') ||
          v.name.toLowerCase().includes('google'))
    );
    if (preferredVoice) {
      utterance.voice = preferredVoice;
    }

    // Simulate audio-reactive mouth volume cadence synchronized with speech
    let phase = 0;
    this.speakingInterval = setInterval(() => {
      phase += 0.25;
      // Modulate speech volume between 0.15 and 0.75 for viseme motion
      const simulatedVol = 0.2 + Math.abs(Math.sin(phase) * 0.45) + Math.cos(phase * 2.1) * 0.1;
      this.notifyVolume(Math.max(0.05, Math.min(1, simulatedVol)));
    }, 45);

    utterance.onend = () => {
      this.cleanupSpeech();
    };

    utterance.onerror = (e) => {
      console.warn('[ConversationManager] Speech error:', e);
      this.cleanupSpeech();
    };

    this.currentUtterance = utterance;
    window.speechSynthesis.speak(utterance);
  }

  public stopSpeaking(): void {
    if (typeof window !== 'undefined' && window.speechSynthesis) {
      window.speechSynthesis.cancel();
    }
    this.cleanupSpeech();
  }

  private cleanupSpeech(): void {
    if (this.speakingInterval) {
      clearInterval(this.speakingInterval);
      this.speakingInterval = null;
    }
    this.currentUtterance = null;
    this.currentlySpeakingMessageId = null;
    this.notifyVolume(0);
    this.setChatState('idle');
  }

  /**
   * Immediately interrupts any active generation or speech playback.
   */
  public interrupt(): void {
    if (this.currentAbortController) {
      this.currentAbortController.abort();
      this.currentAbortController = null;
    }
    this.stopSpeaking();
  }

  // ----------------------------------------------------
  // Explicit Memory Handling Helper
  // ----------------------------------------------------

  private handleExplicitMemoryCommands(text: string): void {
    const lower = text.toLowerCase().trim();

    // Check "remember that..." or "remember this..."
    const rememberMatch = lower.match(/^remember\s+(?:that|this)?\s*(.+)/i);
    if (rememberMatch && rememberMatch[1]) {
      const toRemember = rememberMatch[1].trim();
      if (toRemember.length > 3) {
        try {
          MemoryManager.getInstance().longTerm.saveMemory({
            content: toRemember,
            category: 'important',
            importance: 7,
            tags: ['user_note'],
          });
        } catch (e) {
          console.warn('[ConversationManager] Quick remember warning:', e);
        }
      }
    }

    // Check "forget that..."
    const forgetMatch = lower.match(/^forget\s+(?:that|this)?\s*(.+)/i);
    if (forgetMatch && forgetMatch[1]) {
      const toForget = forgetMatch[1].trim();
      try {
        const mm = MemoryManager.getInstance();
        mm.longTerm.deleteByQuery(toForget);
      } catch (e) {
        console.warn('[ConversationManager] Quick forget warning:', e);
      }
    }
  }
}
