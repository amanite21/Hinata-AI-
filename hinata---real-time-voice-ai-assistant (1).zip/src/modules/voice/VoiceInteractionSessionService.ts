/**
 * VoiceInteractionSessionService - Session provider for Hinata Voice Assistant.
 *
 * Implements Android's `VoiceInteractionSessionService`:
 * - Spawns and manages VoiceInteractionSessions
 * - Captures context assist data (screen text, focused package)
 * - Handles screenshot capture for visual question answering
 * - Directs floating UI presentation during hands-free activation
 */

import { AssistContextData } from './VoiceInteractionService';

export class VoiceInteractionSessionService {
  private static instance: VoiceInteractionSessionService | null = null;
  private activeSession: boolean = false;
  private currentAssistData: AssistContextData | null = null;

  private constructor() {}

  public static getInstance(): VoiceInteractionSessionService {
    if (!VoiceInteractionSessionService.instance) {
      VoiceInteractionSessionService.instance = new VoiceInteractionSessionService();
    }
    return VoiceInteractionSessionService.instance;
  }

  /**
   * Called by the system when a new voice interaction session is requested.
   */
  public onNewSession(): void {
    this.activeSession = true;
    this.currentAssistData = {
      appName: 'Current Device App',
      visibleText: document?.title || 'Hinata System Screen',
      hasScreenshot: false,
    };
  }

  /**
   * Simulates receiving onHandleAssist data from Android OS.
   */
  public handleAssist(data: AssistContextData): void {
    this.currentAssistData = data;
    console.log('[VoiceInteractionSessionService] Context assist data captured:', data);
  }

  /**
   * Simulates receiving onHandleScreenshot from Android OS.
   */
  public handleScreenshot(hasScreenshot: boolean): void {
    if (this.currentAssistData) {
      this.currentAssistData.hasScreenshot = hasScreenshot;
    }
  }

  public getAssistContext(): AssistContextData | null {
    return this.currentAssistData;
  }

  public finishSession(): void {
    this.activeSession = false;
    this.currentAssistData = null;
  }
}
