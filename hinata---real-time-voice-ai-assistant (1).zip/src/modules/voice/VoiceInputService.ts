/**
 * VoiceInputService - Speech recognition & acoustic monitoring pipeline.
 * Integrates with centralized MicrophoneManager for hardware stream and volume metering.
 */

import { MicrophoneManager, MicrophoneOwner } from '../audio/MicrophoneManager';

export interface VoiceInputOptions {
  onTranscript: (text: string, isFinal: boolean) => void;
  onSpeechStart?: () => void;
  onVolumeChange?: (volume: number) => void;
  onError?: (error: string) => void;
  onEnd?: () => void;
  lang?: string;
  owner?: MicrophoneOwner;
}

export class VoiceInputService {
  private static instance: VoiceInputService | null = null;
  private recognition: any = null;
  private isRecognizing: boolean = false;
  private onTranscriptCallback: ((text: string, isFinal: boolean) => void) | null = null;
  private onSpeechStartCallback: (() => void) | null = null;
  private onVolumeChangeCallback: ((volume: number) => void) | null = null;
  private onErrorCallback: ((error: string) => void) | null = null;
  private onEndCallback: (() => void) | null = null;

  private micManager: MicrophoneManager;
  private unsubs: Array<() => void> = [];
  private currentLang: string = 'en-IN';
  private currentOwner: MicrophoneOwner = 'chat_voice';

  private constructor() {
    this.micManager = MicrophoneManager.getInstance();
    this.micManager.onTeardown(() => {
      if (this.recognition && this.isRecognizing) {
        try {
          this.recognition.abort();
        } catch {}
        this.isRecognizing = false;
        this.cleanupListeners();
      }
    });
    this.initRecognition();
  }

  public static getInstance(): VoiceInputService {
    if (!VoiceInputService.instance) {
      VoiceInputService.instance = new VoiceInputService();
    }
    return VoiceInputService.instance;
  }

  private initRecognition(): void {
    if (typeof window === 'undefined') return;

    const SpeechRecognitionClass =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (SpeechRecognitionClass) {
      try {
        this.recognition = new SpeechRecognitionClass();
        this.recognition.continuous = true;
        this.recognition.interimResults = true;
        this.recognition.lang = this.currentLang;

        this.recognition.onspeechstart = () => {
          if (this.onSpeechStartCallback) {
            this.onSpeechStartCallback();
          }
        };

        this.recognition.onresult = (event: any) => {
          let interimTranscript = '';
          let finalTranscript = '';

          for (let i = event.resultIndex; i < event.results.length; ++i) {
            if (event.results[i].isFinal) {
              finalTranscript += event.results[i][0].transcript;
            } else {
              interimTranscript += event.results[i][0].transcript;
            }
          }

          const text = (finalTranscript || interimTranscript).trim();
          if (text && this.onTranscriptCallback) {
            this.onTranscriptCallback(text, Boolean(finalTranscript));
          }
        };

        this.recognition.onerror = (event: any) => {
          console.warn('[VoiceInputService] Speech recognition error:', event.error);
          if (event.error !== 'no-speech') {
            this.isRecognizing = false;
            this.cleanupListeners();
            this.micManager.stopListening(this.currentOwner).catch(() => {});
          }
          if (this.onErrorCallback) {
            if (event.error === 'not-allowed') {
              this.onErrorCallback('Microphone permission was denied.');
            } else if (event.error === 'no-speech') {
              // Benign silence
            } else {
              this.onErrorCallback(`Speech error: ${event.error}`);
            }
          }
        };

        this.recognition.onend = () => {
          this.isRecognizing = false;
          this.cleanupListeners();
          // Ensure hardware microphone capture cleanly transitions to IDLE when recognition ends
          this.micManager.stopListening(this.currentOwner).catch(() => {});
          if (this.onEndCallback) {
            this.onEndCallback();
          }
        };
      } catch (e) {
        console.warn('[VoiceInputService] Initialization error:', e);
      }
    }
  }

  public isSupported(): boolean {
    return Boolean(
      typeof window !== 'undefined' &&
        ((window as any).SpeechRecognition || (window as any).webkitSpeechRecognition)
    );
  }

  public getIsRecognizing(): boolean {
    return this.isRecognizing;
  }

  public async startListeningAsync(
    param1: ((text: string, isFinal: boolean) => void) | VoiceInputOptions,
    onErrorParam?: (error: string) => void
  ): Promise<boolean> {
    if (!this.recognition) {
      this.initRecognition();
    }

    if (!this.recognition) {
      const err = 'Speech recognition is not supported in this browser.';
      if (typeof param1 === 'object' && param1.onError) {
        param1.onError(err);
      } else if (onErrorParam) {
        onErrorParam(err);
      }
      return false;
    }

    if (this.micManager.isBusy()) {
      console.log('[VoiceInputService] MicrophoneManager is busy. Request ignored.');
      return false;
    }

    if (this.isRecognizing) {
      this.stopListening();
    }

    let owner: MicrophoneOwner = 'chat_voice';
    if (typeof param1 === 'function') {
      this.onTranscriptCallback = param1;
      this.onErrorCallback = onErrorParam || null;
      this.onSpeechStartCallback = null;
      this.onVolumeChangeCallback = null;
      this.onEndCallback = null;
    } else {
      this.onTranscriptCallback = param1.onTranscript;
      this.onSpeechStartCallback = param1.onSpeechStart || null;
      this.onVolumeChangeCallback = param1.onVolumeChange || null;
      this.onErrorCallback = param1.onError || null;
      this.onEndCallback = param1.onEnd || null;
      if (param1.owner) {
        owner = param1.owner;
      }
      if (param1.lang) {
        this.currentLang = param1.lang;
        this.recognition.lang = param1.lang;
      }
    }

    this.currentOwner = owner;

    // 1. Activate hardware microphone via centralized MicrophoneManager
    const micStarted = await this.micManager.startListening(owner, {
      echoCancellation: true,
      noiseSuppression: true,
    });

    if (!micStarted) {
      const err = 'Microphone permission or hardware access was not granted.';
      if (this.onErrorCallback) this.onErrorCallback(err);
      return false;
    }

    // 2. Subscribe to centralized volume changes
    const unVol = this.micManager.onVolume((vol) => {
      if (this.isRecognizing && this.onVolumeChangeCallback) {
        this.onVolumeChangeCallback(vol);
      }
    });
    this.unsubs.push(unVol);

    // 3. Start Web Speech Recognition
    try {
      this.recognition.start();
      this.isRecognizing = true;
      return true;
    } catch (err: any) {
      console.warn('[VoiceInputService] Could not start speech recognition:', err);
      const errMsg = 'Could not start speech recognition engine.';
      if (this.onErrorCallback) this.onErrorCallback(errMsg);
      this.isRecognizing = false;
      this.cleanupListeners();
      this.micManager.stopListening(owner).catch(() => {});
      return false;
    }
  }

  public startListening(
    param1: ((text: string, isFinal: boolean) => void) | VoiceInputOptions,
    onErrorParam?: (error: string) => void
  ): boolean {
    this.startListeningAsync(param1, onErrorParam).catch((e) => {
      console.error('[VoiceInputService] startListening error:', e);
    });
    return true;
  }

  public stopListening(): void {
    if (this.recognition && this.isRecognizing) {
      try {
        this.recognition.stop();
      } catch (e) {}
    }
    this.isRecognizing = false;
    this.cleanupListeners();

    // Release microphone session from manager (does NOT revoke Android permission!)
    this.micManager.stopListening(this.currentOwner).catch(() => {});
  }

  private cleanupListeners(): void {
    this.unsubs.forEach((un) => un());
    this.unsubs = [];
    if (this.onVolumeChangeCallback) {
      this.onVolumeChangeCallback(0);
    }
  }
}
