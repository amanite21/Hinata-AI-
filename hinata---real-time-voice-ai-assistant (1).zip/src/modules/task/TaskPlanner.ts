/**
 * TaskPlanner - Multi-Step Sequential Task Planner for Hinata AI.
 *
 * Deconstructs multi-step user commands into verified sequential plans.
 * Tracks task lifecycle (Planning -> Executing -> Completed / Failed).
 * Enforces confirmation before sensitive steps.
 */

import { TaskPlan, TaskStep, DeviceActionResult } from '../device/types';
import { DeviceActionManager } from '../device/DeviceActionManager';

export class TaskPlanner {
  private static instance: TaskPlanner | null = null;
  private activePlan: TaskPlan | null = null;
  private planListeners: Array<(plan: TaskPlan | null) => void> = [];

  private isCancelled: boolean = false;

  private constructor() {}

  public static getInstance(): TaskPlanner {
    if (!TaskPlanner.instance) {
      TaskPlanner.instance = new TaskPlanner();
    }
    return TaskPlanner.instance;
  }

  public subscribe(listener: (plan: TaskPlan | null) => void): () => void {
    this.planListeners.push(listener);
    listener(this.activePlan);
    return () => {
      this.planListeners = this.planListeners.filter((l) => l !== listener);
    };
  }

  private notify(): void {
    const current = this.activePlan ? { ...this.activePlan } : null;
    for (const listener of this.planListeners) {
      try {
        listener(current);
      } catch (err) {
        console.error('[TaskPlanner] Notification error:', err);
      }
    }
  }

  public getActivePlan(): TaskPlan | null {
    return this.activePlan ? { ...this.activePlan } : null;
  }

  /**
   * Plans a multi-step task based on user prompt.
   * Example: "Open Maps and navigate to the nearest hospital."
   */
  public createPlan(userPrompt: string): TaskPlan {
    const clean = userPrompt.toLowerCase().trim();
    const planId = `plan_${Date.now()}`;
    const steps: TaskStep[] = [];

    // Pattern 1: Maps & Navigation to location/hospital
    if (clean.includes('map') && (clean.includes('navigate') || clean.includes('hospital') || clean.includes('nearest') || clean.includes('directions'))) {
      const targetQuery = clean.replace(/.*(navigate to|find|locate)\s+/i, '').replace(/and\s+navigate.*/i, 'nearest hospital').trim() || 'nearest hospital';
      
      steps.push({
        id: `${planId}_s1`,
        title: 'Check Location Access',
        description: 'Verify device geolocation permissions for navigation',
        actionType: 'check_location',
        status: 'pending',
      });
      steps.push({
        id: `${planId}_s2`,
        title: 'Determine GPS Coordinates',
        description: 'Read current device coordinates via GPS',
        actionType: 'get_coordinates',
        status: 'pending',
      });
      steps.push({
        id: `${planId}_s3`,
        title: 'Search Destination',
        description: `Locate ${targetQuery} in Google Maps`,
        actionType: 'search_maps',
        status: 'pending',
      });
      steps.push({
        id: `${planId}_s4`,
        title: 'Start Navigation',
        description: `Launch turn-by-turn navigation to ${targetQuery}`,
        actionType: 'open_maps',
        status: 'pending',
      });

      this.activePlan = {
        id: planId,
        userPrompt,
        summary: `Navigate to ${targetQuery}`,
        steps,
        currentStepIndex: 0,
        status: 'planning',
        requiresConfirmation: false,
        createdAt: Date.now(),
      };
      this.notify();
      return this.activePlan;
    }

    // Pattern 2: Open app and search (e.g. "Open YouTube and search Python tutorials")
    if ((clean.includes('youtube') || clean.includes('yt')) && clean.includes('search')) {
      const query = userPrompt.replace(/.*search\s+(for\s+)?/i, '').trim() || 'Python tutorials';
      steps.push({
        id: `${planId}_s1`,
        title: 'Launch YouTube',
        description: 'Open YouTube application via Android intent',
        actionType: 'open_app',
        status: 'pending',
      });
      steps.push({
        id: `${planId}_s2`,
        title: 'Search Query',
        description: `Search for "${query}" inside YouTube`,
        actionType: 'in_app_action',
        status: 'pending',
      });

      this.activePlan = {
        id: planId,
        userPrompt,
        summary: `Search "${query}" in YouTube`,
        steps,
        currentStepIndex: 0,
        status: 'planning',
        requiresConfirmation: false,
        createdAt: Date.now(),
      };
      this.notify();
      return this.activePlan;
    }

    // Pattern 3: Communication with message drafting
    if (clean.includes('call') || clean.includes('message') || clean.includes('send')) {
      steps.push({
        id: `${planId}_s1`,
        title: 'Draft Communication Intent',
        description: 'Prepare communication parameters and recipient',
        actionType: clean.includes('call') ? 'phone_call' : 'send_message',
        status: 'pending',
      });
      steps.push({
        id: `${planId}_s2`,
        title: 'Request Confirmation',
        description: 'Verify with owner before initiating communication',
        actionType: 'confirm',
        status: 'pending',
      });

      this.activePlan = {
        id: planId,
        userPrompt,
        summary: clean.includes('call') ? 'Place phone call' : 'Send message',
        steps,
        currentStepIndex: 0,
        status: 'planning',
        requiresConfirmation: true,
        confirmationPrompt: clean.includes('call') ? 'Should I place this call?' : 'Do you want me to send this message?',
        createdAt: Date.now(),
      };
      this.notify();
      return this.activePlan;
    }

    // Generic single/dual step plan
    steps.push({
      id: `${planId}_s1`,
      title: 'Analyze Command Intent',
      description: `Process intent for "${userPrompt}"`,
      actionType: 'analyze',
      status: 'pending',
    });
    steps.push({
      id: `${planId}_s2`,
      title: 'Execute Device Action',
      description: 'Perform requested operation and verify outcome',
      actionType: 'execute',
      status: 'pending',
    });

    this.activePlan = {
      id: planId,
      userPrompt,
      summary: userPrompt,
      steps,
      currentStepIndex: 0,
      status: 'planning',
      requiresConfirmation: false,
      createdAt: Date.now(),
    };
    this.notify();
    return this.activePlan;
  }

  /**
   * Executes the active plan sequentially.
   */
  public async executeActivePlan(): Promise<DeviceActionResult> {
    if (!this.activePlan) {
      return {
        success: false,
        action: 'task_plan',
        message: 'No active task plan to execute.',
        timestamp: Date.now(),
      };
    }

    this.isCancelled = false;
    const plan = this.activePlan;
    plan.status = 'executing';
    this.notify();

    const deviceManager = DeviceActionManager.getInstance();

    for (let i = 0; i < plan.steps.length; i++) {
      if (this.isCancelled) {
        plan.status = 'failed';
        this.notify();
        return {
          success: false,
          action: 'task_plan',
          target: plan.summary,
          message: 'Task plan execution was cancelled by user.',
          timestamp: Date.now(),
        };
      }

      plan.currentStepIndex = i;
      const step = plan.steps[i];
      step.status = 'executing';
      this.notify();

      try {
        if (step.actionType === 'open_maps') {
          const res = await deviceManager.executeAction('open_maps', {
            destination: plan.userPrompt.replace(/.*(navigate to|find)\s+/i, '').trim() || 'nearest hospital',
          });
          step.result = res;
          step.status = res.success ? 'completed' : 'failed';
        } else if (step.actionType === 'check_location' || step.actionType === 'get_coordinates') {
          const coords = await deviceManager.navigation.getCurrentCoordinates();
          step.result = {
            success: true,
            action: 'device_info',
            target: 'GPS',
            message: coords ? `Location acquired: ${coords.lat.toFixed(4)}, ${coords.lng.toFixed(4)}` : 'Location retrieved via network.',
            data: coords,
            timestamp: Date.now(),
          };
          step.status = 'completed';
        } else if (step.actionType === 'open_app') {
          const res = await deviceManager.executeAction('open_app', { target: 'YouTube' });
          step.result = res;
          step.status = res.success ? 'completed' : 'failed';
        } else if (step.actionType === 'in_app_action') {
          const query = plan.userPrompt.replace(/.*search\s+(for\s+)?/i, '').trim();
          const res = await deviceManager.executeAction('open_app', { target: 'YouTube', searchQuery: query });
          step.result = res;
          step.status = res.success ? 'completed' : 'failed';
        } else {
          step.status = 'completed';
        }
      } catch (err: any) {
        step.status = 'failed';
        step.result = {
          success: false,
          action: step.actionType,
          message: err.message,
          timestamp: Date.now(),
        };
        plan.status = 'failed';
        this.notify();
        return {
          success: false,
          action: 'task_plan',
          target: plan.summary,
          message: `Task plan failed at step: ${step.title}`,
          timestamp: Date.now(),
        };
      }

      this.notify();
    }

    plan.status = 'completed';
    this.notify();

    return {
      success: true,
      action: 'task_plan',
      target: plan.summary,
      message: `Completed plan: ${plan.summary}`,
      timestamp: Date.now(),
    };
  }

  public cancelPlan(): void {
    this.isCancelled = true;
    if (this.activePlan && this.activePlan.status === 'executing') {
      this.activePlan.status = 'failed';
      this.notify();
    }
  }

  public clearActivePlan(): void {
    this.activePlan = null;
    this.notify();
  }
}
