/**
 * VoiceManager - Voice Lifecycle & Real-Time Audio Orchestrator for Hinata AI.
 *
 * Coordinates:
 * - Gemini Live bidirectional audio streaming
 * - AudioPlayer & AudioStreamer synchronization
 * - Mic permissions, mute/unmute, volume metering
 * - Interruption handling & latency telemetry
 */

import { LiveSession, LiveSessionCallbacks } from './LiveSession';
import { LiveSessionState, AssistantMood, ToolCallItem, EmotionalState, EmotionalIntensity } from '../types';

export class VoiceManager {
  private static instance: VoiceManager | null = null;
  private session: LiveSession | null = null;
  private isMuted: boolean = false;
  private currentVoice: string = 'Kore';
  private callbacks: LiveSessionCallbacks | null = null;

  private constructor() {}

  public static getInstance(): VoiceManager {
    if (!VoiceManager.instance) {
      VoiceManager.instance = new VoiceManager();
    }
    return VoiceManager.instance;
  }

  public init(callbacks: LiveSessionCallbacks, voice: string = 'Kore'): LiveSession {
    this.callbacks = callbacks;
    this.currentVoice = voice;
    this.session = new LiveSession(callbacks);
    return this.session;
  }

  public getSession(): LiveSession | null {
    return this.session;
  }

  public async connect(voice?: string): Promise<void> {
    if (voice) {
      this.currentVoice = voice;
    }
    if (this.session) {
      await this.session.connect(this.currentVoice);
    }
  }

  public disconnect(): void {
    if (this.session) {
      this.session.disconnect();
    }
  }

  public toggleMute(): boolean {
    this.isMuted = !this.isMuted;
    if (this.session) {
      if (this.isMuted) {
        this.session.pauseStreaming();
      } else {
        this.session.resumeStreaming();
      }
    }
    return this.isMuted;
  }

  public isMicrophoneMuted(): boolean {
    return this.isMuted;
  }

  public setVoice(voice: string): void {
    this.currentVoice = voice;
    if (this.session) {
      this.session.setVoice(voice);
    }
  }

  public getVoice(): string {
    return this.currentVoice;
  }
}
