/**
 * Visual Design Intelligence Types for Hinata AI
 * Supports deep layout, color, typography, component, and style analysis of user-provided designs.
 */

export type ReferenceRole =
  | 'layout'
  | 'color'
  | 'mascot'
  | 'typography'
  | 'components'
  | 'general';

export interface VisualReferenceImage {
  id: string;
  name: string;
  dataUrl: string; // base64 data url for preview and API
  mimeType: string;
  role: ReferenceRole;
  uploadedAt: number;
  width?: number;
  height?: number;
  analysis?: VisualDesignAnalysis;
  status: 'idle' | 'analyzing' | 'ready' | 'error';
  errorMessage?: string;
}

export interface DesignPalette {
  primary: string;
  secondary: string;
  accent: string;
  background: string;
  surface: string;
  textPrimary: string;
  textSecondary: string;
  glowColor: string;
  gradient?: string;
  rawSwatches?: string[];
}

export interface DesignLayoutAnalysis {
  composition: string;
  positioning: string;
  spacing: string;
  alignment: string;
  proportions: string;
  hierarchy: string[];
}

export interface DesignTypographyAnalysis {
  fontStyle: string;
  approximateSizes: {
    hero?: string;
    heading?: string;
    body?: string;
    caption?: string;
  };
  weightDistribution: string;
  letterSpacing: string;
  hierarchy: string;
}

export interface DesignComponentAnalysis {
  buttons: string;
  cards: string;
  navigation: string;
  headers: string;
  icons: string;
  inputFields: string;
  statusIndicators: string;
  menus: string;
  avatars: string;
  decorativeElements: string;
}

export interface VisualDesignAnalysis {
  summary: string;
  visualStyle: {
    category: string; // Minimal, Futuristic, Glassmorphism, Holographic, Cinematic, Material, Flat, 3D, Anime, etc.
    characteristics: string[];
    moodKeywords: string[];
  };
  layout: DesignLayoutAnalysis;
  colors: DesignPalette;
  typography: DesignTypographyAnalysis;
  components: DesignComponentAnalysis;
  reconstructionPlan: {
    suggestedTailwindClasses: string[];
    cssVariables: Record<string, string>;
    reactComponentSnippet?: string;
    keyRecommendations: string[];
  };
  analyzedAt: number;
}

export interface AppliedDesignTheme {
  id: string;
  name: string;
  sourceReferenceId?: string;
  palette: DesignPalette;
  styleCategory: string;
  mascotGlowColor: string;
  accentGlowColor: string;
  bgAtmosphere: string;
  borderAccent: string;
  isCustomApplied: boolean;
}

export type DesignActionType =
  | 'analyze'
  | 'recreate'
  | 'modify'
  | 'improve'
  | 'combine'
  | 'generate'
  | 'apply_to_ui';
