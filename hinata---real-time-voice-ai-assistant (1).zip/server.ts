import express from 'express';
import http from 'http';
import path from 'path';
import { WebSocketServer, WebSocket } from 'ws';
import { GoogleGenAI, Modality, Type, FunctionDeclaration } from '@google/genai';
import dotenv from 'dotenv';
import { ModularVisionManager } from './server/visionProvider';
import { handleAssistantRequest } from './server/assistantProvider';
import { DeviceStore } from './server/deviceStore';
import { ConversationStore } from './server/conversationStore';
import { MemoryStore } from './server/memoryStore';
import { CentralAIProvider } from './server/aiProvider';

dotenv.config();

const app = express();
const PORT = Number(process.env.PORT) || 3000;
const server = http.createServer(app);

// Enable permissive CORS for mobile phones, external Android APKs, and Web clients
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization, X-User-Id, X-Device-Id, X-Session-Id, X-Conversation-Id');
  if (req.method === 'OPTIONS') {
    return res.sendStatus(200);
  }
  next();
});

app.use(express.json({ limit: '25mb' }));
app.use(express.urlencoded({ limit: '25mb', extended: true }));
app.use(express.static(path.join(process.cwd(), 'public')));

// ----------------------------------------------------
// Health Check Endpoints (Strictly zero secret exposure)
// ----------------------------------------------------

// Requirement 11: GET /health
app.get('/health', (req, res) => {
  res.json({
    status: 'ok',
    service: 'hinata-backend',
  });
});

// Existing API health endpoint
app.get('/api/health', (req, res) => {
  const activeKey = CentralAIProvider.getInstance().getActiveApiKey();
  res.json({
    status: 'ok',
    service: 'hinata-backend',
    assistant: 'Hinata',
    hasApiKey: Boolean(activeKey && activeKey.trim().length > 0),
  });
});

// ----------------------------------------------------
// Central AI Provider & Safe Key Rotation Endpoints
// (Strictly Zero Secret Exposure to Client)
// ----------------------------------------------------

// GET /api/ai/status: Get safe AI configuration status
app.get('/api/ai/status', (req, res) => {
  const status = CentralAIProvider.getInstance().getStatus();
  res.json(status);
});

// POST /api/ai/test: Safely test active or candidate API key
app.post('/api/ai/test', async (req, res) => {
  try {
    const { apiKey } = req.body || {};
    const result = await CentralAIProvider.getInstance().testCandidateKey(apiKey);
    res.json(result);
  } catch (err: any) {
    res.status(500).json({
      ok: false,
      status: 'PROVIDER_ERROR',
      message: err?.message || 'Failed to test connection',
      latencyMs: 0,
    });
  }
});

// POST /api/ai/rotate: Test and safely rotate API key without APK rebuild
app.post('/api/ai/rotate', async (req, res) => {
  try {
    const { newKey } = req.body || {};
    if (!newKey || typeof newKey !== 'string' || newKey.trim().length === 0) {
      return res.status(400).json({
        success: false,
        status: 'NOT_CONFIGURED',
        message: 'New API key cannot be empty.',
      });
    }

    const result = await CentralAIProvider.getInstance().rotateKey(newKey);
    res.json(result);
  } catch (err: any) {
    res.status(500).json({
      success: false,
      status: 'PROVIDER_ERROR',
      message: err?.message || 'Failed to rotate key',
    });
  }
});

// ----------------------------------------------------
// Multi-Device Registration & Identification
// ----------------------------------------------------

// Requirement 5: POST /api/devices/register
app.post('/api/devices/register', (req, res) => {
  try {
    const { deviceId, deviceName, platform, appVersion, userId } = req.body;
    if (!deviceId) {
      return res.status(400).json({ success: false, error: 'deviceId is required' });
    }

    const ipAddress = req.ip || req.socket.remoteAddress;
    const effectiveUserId = userId || (req.headers['x-user-id'] as string) || 'user-001';

    const record = DeviceStore.getInstance().registerDevice({
      deviceId,
      deviceName: deviceName || 'Android Device',
      platform: platform || 'android',
      appVersion: appVersion || '1.0.0',
      userId: effectiveUserId,
      ipAddress,
    });

    res.json({
      success: true,
      deviceId: record.deviceId,
      userId: record.userId,
    });
  } catch (err: any) {
    console.error('[DeviceRegistry] Error registering device:', err);
    res.status(500).json({ success: false, error: 'Failed to register device' });
  }
});

// GET /api/devices: List devices for current user
app.get('/api/devices', (req, res) => {
  const userId = (req.headers['x-user-id'] as string) || (req.query.userId as string) || 'user-001';
  const devices = DeviceStore.getInstance().getDevicesByUserId(userId);
  res.json({ success: true, devices });
});

// ----------------------------------------------------
// Conversation Management & Multi-Device Isolation
// ----------------------------------------------------

// POST /api/conversations: Create or sync conversation
app.post('/api/conversations', (req, res) => {
  try {
    const userId = (req.headers['x-user-id'] as string) || req.body.userId || 'user-001';
    const deviceId = (req.headers['x-device-id'] as string) || req.body.deviceId;
    const { conversationId, title } = req.body;

    const conv = ConversationStore.getInstance().getOrCreateConversation(
      conversationId,
      userId,
      deviceId,
      title
    );

    res.json({
      success: true,
      conversation: conv,
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: 'Failed to manage conversation' });
  }
});

// GET /api/conversations: List conversations for user
app.get('/api/conversations', (req, res) => {
  const userId = (req.headers['x-user-id'] as string) || (req.query.userId as string) || 'user-001';
  const list = ConversationStore.getInstance().listConversations(userId);
  res.json({
    success: true,
    conversations: list,
  });
});

// GET /api/conversations/:id: Get specific conversation for user
app.get('/api/conversations/:id', (req, res) => {
  const userId = (req.headers['x-user-id'] as string) || (req.query.userId as string) || 'user-001';
  const conv = ConversationStore.getInstance().getConversation(req.params.id, userId);
  if (!conv) {
    return res.status(404).json({ success: false, error: 'Conversation not found' });
  }
  res.json({
    success: true,
    conversation: conv,
  });
});

// DELETE /api/conversations/:id: Delete specific conversation
app.delete('/api/conversations/:id', (req, res) => {
  const userId = (req.headers['x-user-id'] as string) || (req.query.userId as string) || 'user-001';
  const deleted = ConversationStore.getInstance().deleteConversation(req.params.id, userId);
  res.json({ success: deleted });
});

// ----------------------------------------------------
// Scoped Long-Term Memory APIs & Sync
// ----------------------------------------------------

// POST /api/memory: Save memory (with sensitive credential filtering)
app.post('/api/memory', (req, res) => {
  try {
    const userId = (req.headers['x-user-id'] as string) || req.body.userId || 'user-001';
    const { content, category, importance, source, tags, id } = req.body;

    if (!content) {
      return res.status(400).json({ success: false, error: 'Memory content is required' });
    }

    const result = MemoryStore.getInstance().saveMemory({
      userId,
      content,
      category,
      importance,
      source,
      tags,
      id,
    });

    if (!result.success) {
      return res.status(400).json({ success: false, error: result.error });
    }

    res.json({
      success: true,
      memory: result.memory,
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: 'Failed to save memory' });
  }
});

// GET /api/memory: Retrieve user-scoped memories
app.get('/api/memory', (req, res) => {
  const userId = (req.headers['x-user-id'] as string) || (req.query.userId as string) || 'user-001';
  const query = req.query.q as string | undefined;
  const category = req.query.category as string | undefined;

  const memories = MemoryStore.getInstance().getMemories(userId, { query, category });
  res.json({
    success: true,
    memories,
  });
});

// DELETE /api/memory/:id: Delete memory item
app.delete('/api/memory/:id', (req, res) => {
  const userId = (req.headers['x-user-id'] as string) || (req.query.userId as string) || 'user-001';
  const success = MemoryStore.getInstance().deleteMemory(userId, req.params.id);
  res.json({ success });
});

// POST /api/memory/sync: Batch sync memories from client device to backend
app.post('/api/memory/sync', (req, res) => {
  try {
    const userId = (req.headers['x-user-id'] as string) || req.body.userId || 'user-001';
    const { items } = req.body;
    if (!Array.isArray(items)) {
      return res.status(400).json({ success: false, error: 'Items array is required' });
    }

    let savedCount = 0;
    for (const item of items) {
      if (item.content) {
        const saved = MemoryStore.getInstance().saveMemory({
          userId,
          content: item.content,
          category: item.category,
          importance: item.importance,
          source: item.source || 'client_sync',
          tags: item.tags,
          id: item.id,
        });
        if (saved.success) savedCount++;
      }
    }

    res.json({
      success: true,
      syncedCount: savedCount,
      totalMemories: MemoryStore.getInstance().getMemories(userId).length,
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: 'Failed to sync memories' });
  }
});

// Unified Assistant Chat & Reasoning API (Streaming SSE & JSON)
app.post('/api/assistant', handleAssistantRequest);

// Advanced Visual Design Understanding API
app.post('/api/visual-design/analyze', async (req, res) => {
  try {
    const { images, instruction, extractedPalette } = req.body;

    if (!images || !Array.isArray(images) || images.length === 0) {
      return res.status(400).json({ error: 'No image provided for visual analysis' });
    }

    const apiKey = CentralAIProvider.getInstance().getActiveApiKey();
    if (!apiKey) {
      console.warn('[VisualDesign] GEMINI_API_KEY missing, using intelligent local fallback');
      const pal = extractedPalette || {
        primary: '#080d24',
        secondary: '#287bff',
        accent: '#00e5ff',
        background: '#040714',
        surface: '#0a122c',
        textPrimary: '#ffffff',
        textSecondary: '#94a3b8',
        glowColor: '#00e5ff',
      };
      return res.json({
        analysis: {
          summary: 'Analyzed visual structure, layout balance, and glowing neon palette.',
          visualStyle: {
            category: 'Futuristic Cyberpunk Interface',
            characteristics: ['High-contrast glowing neon', 'Symmetrical central composition', 'Glassmorphic card panels'],
            moodKeywords: ['Futuristic', 'High-Tech', 'Vibrant', 'Clean'],
          },
          layout: {
            composition: 'Centered focal element with symmetrical floating navigation',
            positioning: 'Floating docked status elements with spacious margins',
            spacing: 'Balanced padding (16-24px)',
            alignment: 'Centered',
            proportions: 'Main subject ~45% viewport, controls ~15%',
            hierarchy: ['Central Mascot Focus', 'Live Telemetry Bar', 'Dock Controls'],
          },
          colors: pal,
          typography: {
            fontStyle: 'Modern geometric sans-serif',
            approximateSizes: { hero: '32px', heading: '20px', body: '15px', caption: '11px' },
            weightDistribution: 'Semibold headings, regular body',
            letterSpacing: 'Expanded tracking on labels',
            hierarchy: 'Display > Headings > Body > Micro-labels',
          },
          components: {
            buttons: 'Pill or circular action controls with outer glow',
            cards: 'Dark translucent backdrop with subtle cyan/purple border',
            navigation: 'Docked floating pill bar with equalizer',
            headers: 'Minimal top bar with companion status indicator',
            icons: 'Vector line icons with 1.5px stroke',
            inputFields: 'Darkened input with glowing focus outlines',
            statusIndicators: 'Pulsing neon status dots',
            menus: 'Glassmorphism modal overlay',
            avatars: 'Central robotic/anime mascot with illuminated visor and rim glow',
            decorativeElements: 'Orbital energy rings and atmospheric gradients',
          },
          reconstructionPlan: {
            suggestedTailwindClasses: ['bg-[#080d24]/90', 'border-cyan-400/40', 'shadow-[0_0_25px_rgba(0,229,255,0.4)]'],
            cssVariables: { '--theme-accent': pal.accent, '--theme-glow': pal.glowColor },
            keyRecommendations: ['Maintain high-contrast neon accents against dark space backgrounds'],
          },
          analyzedAt: Date.now(),
        },
      });
    }

    const ai = new GoogleGenAI({
      apiKey,
      httpOptions: { headers: { 'User-Agent': 'aistudio-build' } },
    });

    const parts: any[] = [];
    for (const img of images) {
      if (img.dataUrl && typeof img.dataUrl === 'string') {
        const matches = img.dataUrl.match(/^data:([^;]+);base64,(.+)$/);
        if (matches) {
          parts.push({
            inlineData: {
              mimeType: matches[1],
              data: matches[2],
            },
          });
        }
      }
    }

    const promptText = `You are Hinata's Advanced Visual Design Understanding System.
Analyze the provided visual reference image(s) (which may be UI screenshots, mobile apps, websites, logos, posters, color palettes, illustrations, character art, or typography).
${instruction ? `User instruction: "${instruction}"` : ''}

You MUST return a JSON object with this exact structure:
{
  "summary": "Brief 1-2 sentence overview of the design composition and aesthetic vibe",
  "visualStyle": {
    "category": "e.g. Futuristic Cyberpunk, Minimalist Clean, Neo-Brutalist, Dark Luxury, Retro Anime, Glassmorphic",
    "characteristics": ["list of 3-5 key visual attributes"],
    "moodKeywords": ["3-5 descriptive words"]
  },
  "layout": {
    "composition": "Detailed breakdown of the composition",
    "positioning": "How elements are arranged and anchored",
    "spacing": "Analysis of margins, padding, and breathing room",
    "alignment": "Alignment rules observed (left, center, grid-aligned)",
    "proportions": "Relative visual weight and scaling of elements",
    "hierarchy": ["Ordered list of visual hierarchy levels from most prominent to least"]
  },
  "colors": {
    "primary": "#hexcode",
    "secondary": "#hexcode",
    "accent": "#hexcode",
    "background": "#hexcode",
    "surface": "#hexcode",
    "textPrimary": "#hexcode",
    "textSecondary": "#hexcode",
    "glowColor": "#hexcode",
    "gradient": "CSS gradient string",
    "rawSwatches": ["#hex1", "#hex2", "#hex3", "#hex4", "#hex5", "#hex6"]
  },
  "typography": {
    "fontStyle": "Font category or specific family resemblance",
    "approximateSizes": {
      "hero": "e.g. 32px - 40px",
      "heading": "e.g. 18px - 22px",
      "body": "e.g. 14px - 16px",
      "caption": "e.g. 11px - 12px"
    },
    "weightDistribution": "How font weights (bold, medium, regular) are applied",
    "letterSpacing": "Tracking characteristics (e.g. tight, normal, wide uppercase)",
    "hierarchy": "Explanation of text scale contrast"
  },
  "components": {
    "buttons": "Style of buttons (radius, padding, borders, shadows, hover)",
    "cards": "Style of containers/cards (borders, radius, elevation)",
    "navigation": "Style of navbar/tabs/dock",
    "headers": "Header bar layout and styling",
    "icons": "Icon style (line, filled, colored, glowing)",
    "inputFields": "Input fields and forms styling",
    "statusIndicators": "Badges, pills, indicators, meters",
    "menus": "Menu/dropdown/modal styling",
    "avatars": "Avatar/mascot/profile representation",
    "decorativeElements": "Gradients, glows, grid patterns, borders"
  },
  "reconstructionPlan": {
    "suggestedTailwindClasses": ["list of 5-8 relevant Tailwind utility classes to recreate this vibe"],
    "cssVariables": {
      "--theme-accent": "#hex",
      "--theme-glow": "#hex",
      "--theme-bg": "#hex"
    },
    "keyRecommendations": ["3 bullet points for recreating or adapting this design into React + Tailwind"]
  }
}`;

    parts.push({ text: promptText });

    let responseText = '{}';
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: parts,
        config: {
          responseMimeType: 'application/json',
        },
      });
      responseText = response.text || '{}';
    } catch (primaryErr: any) {
      console.warn('[VisualDesign] gemini-3.8-flash failed, attempting fallback to gemini-2.5-flash:', primaryErr?.message);
      const fallbackResponse = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: parts,
        config: {
          responseMimeType: 'application/json',
        },
      });
      responseText = fallbackResponse.text || '{}';
    }

    const analysis = JSON.parse(responseText);
    analysis.analyzedAt = Date.now();

    res.json({ analysis });
  } catch (err: any) {
    console.error('[VisualDesign] Analyze error:', err);
    res.status(500).json({ error: err.message || 'Failed to analyze design' });
  }
});

app.post('/api/visual-design/generate', async (req, res) => {
  try {
    const { analysis, command } = req.body;
    const apiKey = CentralAIProvider.getInstance().getActiveApiKey();

    if (!apiKey) {
      return res.json({
        componentCode: `// Generated component based on visual reference\nexport const CustomStyledCard = () => (\n  <div className="p-6 rounded-2xl bg-[#080d24]/90 border border-[#00e5ff]/40 shadow-[0_0_20px_rgba(0,229,255,0.25)]">\n    <h3 className="text-white font-bold text-lg">Visual Design Reconstruction</h3>\n    <p className="text-slate-400 text-sm mt-1">Generated styling matching reference palette.</p>\n  </div>\n);`,
      });
    }

    const ai = new GoogleGenAI({
      apiKey,
      httpOptions: { headers: { 'User-Agent': 'aistudio-build' } },
    });

    const prompt = `Generate a clean React (TypeScript + Tailwind CSS) component or styling specification based on this design analysis:
${JSON.stringify(analysis, null, 2)}
User request: ${command || 'Recreate a modular UI component in this style.'}

Provide pristine, fully typed React code with Tailwind CSS classes, responsive design, and smooth hover/active states.`;

    let componentCode = '';
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: prompt,
      });
      componentCode = response.text || '';
    } catch (primaryErr: any) {
      console.warn('[VisualDesign] gemini-3.8-flash failed, attempting fallback to gemini-2.5-flash:', primaryErr?.message);
      const fallbackResponse = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
      });
      componentCode = fallbackResponse.text || '';
    }

    res.json({ componentCode });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// Real-Time Visual Vision & Screen Comprehension API (Google Gemini Vision Provider)
app.post('/api/vision/analyze', async (req, res) => {
  try {
    const { image, mimeType = 'image/jpeg', source = 'image', question, task = 'general', framework } = req.body;

    if (!image) {
      return res.status(400).json({ error: 'Image data is required' });
    }

    const visionManager = ModularVisionManager.getInstance();
    const result = await visionManager.analyze({
      base64: image,
      mimeType,
      source,
      question,
      task,
      framework,
    });

    res.json(result);
  } catch (err: any) {
    console.error('[VisionAnalyze] Error:', err);
    res.status(500).json({ error: err.message || 'Vision analysis failed' });
  }
});

// Dedicated Design Improvement & Weakness Identification API
app.post('/api/vision/improve-design', async (req, res) => {
  try {
    const { image, mimeType = 'image/jpeg', source = 'image', customInstructions, framework = 'react-tailwind' } = req.body;

    if (!image) {
      return res.status(400).json({ error: 'Image data is required' });
    }

    const visionManager = ModularVisionManager.getInstance();
    const result = await visionManager.analyze({
      base64: image,
      mimeType,
      source,
      question: customInstructions || 'Improve this design. Identify weaknesses, suggest actionable enhancements, explain why each helps, and preserve the intended aesthetic style.',
      task: 'improve_design',
      framework,
    });

    res.json(result);
  } catch (err: any) {
    console.error('[VisionImproveDesign] Error:', err);
    res.status(500).json({ error: err.message || 'Design improvement analysis failed' });
  }
});

// Dedicated Design-to-Code Conversion API
app.post('/api/vision/design-to-code', async (req, res) => {
  try {
    const { image, mimeType = 'image/jpeg', framework = 'react-tailwind', source = 'image' } = req.body;

    if (!image) {
      return res.status(400).json({ error: 'Image data is required' });
    }

    const visionManager = ModularVisionManager.getInstance();
    const result = await visionManager.analyze({
      base64: image,
      mimeType,
      source,
      question: `Convert this visual design into a modular, clean implementation using ${framework}. Identify components, layout, spacing, colors, typography, and responsive behavior.`,
      task: 'design_to_code',
      framework,
    });

    res.json(result);
  } catch (err: any) {
    console.error('[VisionDesignToCode] Error:', err);
    res.status(500).json({ error: err.message || 'Design to code conversion failed' });
  }
});

// Tool declarations for Gemini Live API
const openWebsiteTool: FunctionDeclaration = {
  name: 'openWebsite',
  description: 'Opens a requested website or URL in the user browser when they ask to visit or open a site.',
  parameters: {
    type: Type.OBJECT,
    properties: {
      url: {
        type: Type.STRING,
        description: 'The destination URL to open (e.g. https://www.google.com, https://youtube.com, https://github.com)',
      },
      title: {
        type: Type.STRING,
        description: 'A friendly display title for the website',
      },
    },
    required: ['url'],
  },
};

const getCurrentTimeTool: FunctionDeclaration = {
  name: 'getCurrentTime',
  description: 'Returns the precise current date, time, and timezone.',
  parameters: {
    type: Type.OBJECT,
    properties: {
      timezone: {
        type: Type.STRING,
        description: 'Optional IANA timezone name (e.g. America/New_York, Europe/London)',
      },
    },
  },
};

const getWeatherTool: FunctionDeclaration = {
  name: 'getWeather',
  description: 'Fetches the weather conditions, temperature, humidity, and forecast for any city or location.',
  parameters: {
    type: Type.OBJECT,
    properties: {
      location: {
        type: Type.STRING,
        description: 'The city or location to get weather for (e.g. Tokyo, Paris, San Francisco)',
      },
    },
    required: ['location'],
  },
};

const calculateTool: FunctionDeclaration = {
  name: 'calculate',
  description: 'Performs mathematical or arithmetic calculations.',
  parameters: {
    type: Type.OBJECT,
    properties: {
      expression: {
        type: Type.STRING,
        description: 'The mathematical expression to evaluate (e.g. "45 * 12 + 180")',
      },
    },
    required: ['expression'],
  },
};

const setEmotionalStateTool: FunctionDeclaration = {
  name: 'setEmotionalState',
  description:
    'Updates Hinata internal emotional state and visual aura across 21 states: neutral, happy, excited, curious, amused, calm, confident, playful, empathetic, concerned, serious, affectionate, jealous, annoyed, angry, frustrated, surprised, embarrassed, proud, disappointed, relieved.',
  parameters: {
    type: Type.OBJECT,
    properties: {
      emotion: {
        type: Type.STRING,
        description:
          'The target emotional state: neutral, happy, excited, curious, amused, calm, confident, playful, empathetic, concerned, serious, affectionate, jealous, annoyed, angry, frustrated, surprised, embarrassed, proud, disappointed, relieved',
      },
      intensity: {
        type: Type.INTEGER,
        description: 'Intensity level from 1 (subtle) to 5 (maximum, rare). Default is 2 (mild) or 3 (noticeable).',
      },
      reason: {
        type: Type.STRING,
        description: 'Brief contextual reason for the emotional shift',
      },
    },
    required: ['emotion'],
  },
};

const setAssistantMoodTool: FunctionDeclaration = {
  name: 'setAssistantMood',
  description: 'Dynamically updates Hinata visual lighting halo, ambient colors, and vibe based on conversation tone.',
  parameters: {
    type: Type.OBJECT,
    properties: {
      mood: {
        type: Type.STRING,
        description:
          'The mood to transition to: neutral, happy, excited, curious, amused, calm, confident, playful, empathetic, concerned, serious, affectionate, jealous, annoyed, angry, frustrated, surprised, embarrassed, proud, disappointed, relieved',
      },
      intensity: {
        type: Type.INTEGER,
        description: 'Intensity level from 1 to 5.',
      },
    },
    required: ['mood'],
  },
};

const searchWebSummaryTool: FunctionDeclaration = {
  name: 'searchWebSummary',
  description: 'Quickly searches verified facts or news topics for the user.',
  parameters: {
    type: Type.OBJECT,
    properties: {
      query: {
        type: Type.STRING,
        description: 'The search query to look up',
      },
    },
    required: ['query'],
  },
};

const rememberInformationTool: FunctionDeclaration = {
  name: 'rememberInformation',
  description:
    'Saves or updates important user preferences, active projects, goals, rules, or personal details to Hinata long-term persistent memory for future sessions. Use when the user explicitly says "remember that", "from now on", or shares key personal context.',
  parameters: {
    type: Type.OBJECT,
    properties: {
      content: {
        type: Type.STRING,
        description: 'The clear, concise fact, preference, project, or instruction to remember.',
      },
      category: {
        type: Type.STRING,
        description: 'Category: preference, project, goal, instruction, important, profile, or long_term',
      },
      importance: {
        type: Type.NUMBER,
        description: 'Importance score from 1 (low) to 10 (highest priority/explicit)',
      },
      tags: {
        type: Type.ARRAY,
        items: { type: Type.STRING },
        description: 'Keywords or tags associated with this memory item',
      },
    },
    required: ['content'],
  },
};

const updateUserProfileTool: FunctionDeclaration = {
  name: 'updateUserProfile',
  description:
    'Updates a structured field in the user profile: name, preferredLanguage, communicationStyle, interests, skills, projects, goals, or preferences.',
  parameters: {
    type: Type.OBJECT,
    properties: {
      field: {
        type: Type.STRING,
        description:
          'Profile field: name, preferredLanguage, communicationStyle, interests, skills, projects, goals, or preferences',
      },
      value: {
        type: Type.STRING,
        description: 'The new or updated value for this profile field.',
      },
      action: {
        type: Type.STRING,
        description: 'Action: set (replaces old value), append (adds to list), or remove',
      },
    },
    required: ['field', 'value'],
  },
};

const forgetMemoryTool: FunctionDeclaration = {
  name: 'forgetMemory',
  description:
    'Permanently deletes a stored memory, fact, or preference when the user says "forget that", "delete that memory", or asks to remove personal information.',
  parameters: {
    type: Type.OBJECT,
    properties: {
      query: {
        type: Type.STRING,
        description: 'Keywords or description of what memory to permanently remove.',
      },
      reason: {
        type: Type.STRING,
        description: 'Optional brief reason for removal.',
      },
    },
    required: ['query'],
  },
};

const searchMemoriesTool: FunctionDeclaration = {
  name: 'searchMemories',
  description:
    'Searches Hinata persistent long-term memories for past discussions, previous projects, preferences, or details.',
  parameters: {
    type: Type.OBJECT,
    properties: {
      query: {
        type: Type.STRING,
        description: 'Search query or topic to look up in persistent memory.',
      },
      category: {
        type: Type.STRING,
        description: 'Optional category filter.',
      },
    },
    required: ['query'],
  },
};

const getUserProfileTool: FunctionDeclaration = {
  name: 'getUserProfile',
  description:
    'Retrieves the user structured profile containing name, language, communication style, goals, projects, and known preferences.',
  parameters: {
    type: Type.OBJECT,
    properties: {},
  },
};

const analyzeActiveDesignReferenceTool: FunctionDeclaration = {
  name: 'analyzeActiveDesignReference',
  description:
    'Invoked when the user asks Hinata to analyze or inspect their active visual design reference(s) (UI screenshots, web/app designs, color palettes, illustrations, typography, logos).',
  parameters: {
    type: Type.OBJECT,
    properties: {
      aspect: {
        type: Type.STRING,
        description: 'Specific aspect to focus on: "all", "layout", "colors", "typography", "components", "style", or "reconstruction"',
      },
    },
  },
};

const applyDesignStyleToUITool: FunctionDeclaration = {
  name: 'applyDesignStyleToUI',
  description:
    'Applies the colors, glow, or visual aesthetic from the active design reference to Hinata interface in real-time (e.g. when user says "Make my UI like this", "Keep my current UI but use this color scheme", "Make this more futuristic").',
  parameters: {
    type: Type.OBJECT,
    properties: {
      action: {
        type: Type.STRING,
        description: 'Action to perform: "apply_all", "apply_palette_only", "make_futuristic", "make_minimal", "reset"',
      },
      reason: {
        type: Type.STRING,
        description: 'Brief explanation of what visual styling was applied',
      },
    },
    required: ['action'],
  },
};

const storeDesignPreferenceTool: FunctionDeclaration = {
  name: 'storeDesignPreference',
  description:
    'Saves the user visual design aesthetic preferences (color palettes, layouts, typography, futuristic style) into persistent memory.',
  parameters: {
    type: Type.OBJECT,
    properties: {
      preference: {
        type: Type.STRING,
        description: 'Detailed description of the user design aesthetic preference to remember',
      },
      tags: {
        type: Type.ARRAY,
        items: { type: Type.STRING },
        description: 'Tags such as ["design", "visual_style", "colors", "futuristic"]',
      },
    },
    required: ['preference'],
  },
};

const executeDeviceActionTool: FunctionDeclaration = {
  name: 'executeDeviceAction',
  description:
    'Executes or dispatches an Android device action such as launching apps (YouTube, WhatsApp, Camera, Gallery, Settings, Maps, Spotify), opening system settings (Wi-Fi, Bluetooth), placing phone calls, drafting SMS messages, setting alarms or timers, controlling media, or turning on torch/flashlight.',
  parameters: {
    type: Type.OBJECT,
    properties: {
      action: {
        type: Type.STRING,
        description:
          'Action type: "open_app", "system_setting", "phone_call", "send_message", "set_alarm", "set_timer", "open_camera", "open_gallery", "open_maps", "control_media", "torch", "in_app_action"',
      },
      target: {
        type: Type.STRING,
        description: 'App name (e.g. "YouTube", "WhatsApp"), contact name, setting (e.g. "wifi"), or destination',
      },
      query: {
        type: Type.STRING,
        description: 'Search query or message body if applicable',
      },
      hours: {
        type: Type.INTEGER,
        description: 'Hour of alarm (0-23)',
      },
      minutes: {
        type: Type.INTEGER,
        description: 'Minute of alarm (0-59)',
      },
      seconds: {
        type: Type.INTEGER,
        description: 'Timer duration in seconds',
      },
      confirmed: {
        type: Type.BOOLEAN,
        description: 'Whether sensitive action (call, send message) has been confirmed by user',
      },
    },
    required: ['action'],
  },
};

const confirmSensitiveActionTool: FunctionDeclaration = {
  name: 'confirmSensitiveAction',
  description:
    'Confirms or cancels a pending sensitive device action (e.g. placing a phone call, sending an SMS, deleting information) after asking the user.',
  parameters: {
    type: Type.OBJECT,
    properties: {
      confirm: {
        type: Type.BOOLEAN,
        description: 'True to confirm and execute the pending action, false to cancel',
      },
      actionId: {
        type: Type.STRING,
        description: 'Optional ID of the pending sensitive action',
      },
    },
    required: ['confirm'],
  },
};

const planMultiStepTaskTool: FunctionDeclaration = {
  name: 'planMultiStepTask',
  description:
    'Breaks down and executes a multi-step device task (e.g. "Open Maps and navigate to nearest hospital", "Open YouTube and search Python tutorials").',
  parameters: {
    type: Type.OBJECT,
    properties: {
      taskDescription: {
        type: Type.STRING,
        description: 'Full multi-step task description requested by the user',
      },
    },
    required: ['taskDescription'],
  },
};

const requestDevicePermissionTool: FunctionDeclaration = {
  name: 'requestDevicePermission',
  description:
    'Checks, requests, or explains an Android device permission (e.g. microphone, camera, geolocation, notifications, accessibility service).',
  parameters: {
    type: Type.OBJECT,
    properties: {
      permission: {
        type: Type.STRING,
        description: 'Permission to inspect or request: "microphone", "camera", "geolocation", "notifications", "accessibility"',
      },
    },
    required: ['permission'],
  },
};

const analyzeCurrentScreenTool: FunctionDeclaration = {
  name: 'analyzeCurrentScreen',
  description:
    'Analyzes the user live screen when they ask "What is on my screen?", "Read this", "What does this error mean?", "Explain this page", "Where is the setting?", "What should I do here?", or "Why isn\'t this working?". Explains what is visible through voice.',
  parameters: {
    type: Type.OBJECT,
    properties: {
      question: {
        type: Type.STRING,
        description: 'The user specific question about their screen',
      },
      focusArea: {
        type: Type.STRING,
        description: 'Optional focus: "error", "text", "navigation", "layout", "action"',
      },
    },
  },
};

const analyzeSelectedImageTool: FunctionDeclaration = {
  name: 'analyzeSelectedImage',
  description:
    'Explains an uploaded photograph, screenshot, document, diagram, or UI design reference when the user provides an image or asks about it.',
  parameters: {
    type: Type.OBJECT,
    properties: {
      question: {
        type: Type.STRING,
        description: 'User inquiry about the image',
      },
    },
  },
};

const improveVisualDesignTool: FunctionDeclaration = {
  name: 'improveVisualDesign',
  description:
    'Critiques the current screen or uploaded design reference. Identifies weaknesses across layout, colors, typography, components, and UX, then provides concrete improvement suggestions while preserving the intended aesthetic style.',
  parameters: {
    type: Type.OBJECT,
    properties: {
      instructions: {
        type: Type.STRING,
        description: 'Custom instructions or specific design aspect to focus on (e.g. "make it more minimal", "fix spacing")',
      },
    },
  },
};

const convertDesignToCodeTool: FunctionDeclaration = {
  name: 'convertDesignToCode',
  description:
    'Converts the visible screen or design reference into clean code (React, TypeScript, Tailwind CSS, HTML/CSS, or Jetpack Compose).',
  parameters: {
    type: Type.OBJECT,
    properties: {
      framework: {
        type: Type.STRING,
        description: 'Target framework: "react-tailwind", "html-css", "jetpack-compose", or "typescript"',
      },
    },
  },
};

// WebSocket server for Gemini Live Audio-to-Audio stream
const wss = new WebSocketServer({ noServer: true });

wss.on('error', (err) => {
  console.error('[LiveServer] WebSocketServer error:', err);
});

// Explicit upgrade handler for /api/live
server.on('upgrade', (request, socket, head) => {
  try {
    const url = new URL(request.url || '', `http://${request.headers.host || 'localhost'}`);
    if (url.pathname === '/api/live' || url.pathname === '/api/live/') {
      wss.handleUpgrade(request, socket, head, (ws) => {
        wss.emit('connection', ws, request);
      });
    } else {
      socket.destroy();
    }
  } catch (e) {
    console.error('[LiveServer] Upgrade handler error:', e);
    socket.destroy();
  }
});

wss.on('connection', async (clientWs: WebSocket, req) => {
  console.log('[LiveServer] New WebSocket connection from client');

  clientWs.on('error', (err) => {
    console.error('[LiveServer] Client socket error:', err);
  });

  const apiKey = CentralAIProvider.getInstance().getActiveApiKey();
  if (!apiKey) {
    clientWs.send(
      JSON.stringify({
        type: 'error',
        message: 'GEMINI_API_KEY is not configured in the server environment. Please configure it in Settings > Secrets.',
      })
    );
    setTimeout(() => {
      try { clientWs.close(1008, 'GEMINI_API_KEY missing'); } catch {}
    }, 150);
    return;
  }

  // Parse voice, user, device, and memory context safely from URL query if present
  let selectedVoice = 'Kore';
  let memoryContext = '';
  let wsUserId = 'user-001';
  let wsDeviceId = 'device-001';
  let wsSessionId = 'session-001';
  let wsConversationId: string | null = null;
  try {
    const rawUrl = req.url || '';
    const queryIndex = rawUrl.indexOf('?');
    if (queryIndex !== -1) {
      const searchParams = new URLSearchParams(rawUrl.slice(queryIndex + 1));
      const voiceParam = searchParams.get('voice');
      if (voiceParam && ['Kore', 'Aoede', 'Zephyr', 'Puck', 'Fenrir', 'Charon'].includes(voiceParam)) {
        selectedVoice = voiceParam;
      }
      wsUserId = searchParams.get('userId') || 'user-001';
      wsDeviceId = searchParams.get('deviceId') || 'device-001';
      wsSessionId = searchParams.get('sessionId') || 'session-001';
      wsConversationId = searchParams.get('conversationId') || null;

      // Track device activity
      DeviceStore.getInstance().updateHeartbeat(wsDeviceId);

      const memParam = searchParams.get('memoryContext');
      if (memParam) {
        memoryContext = memParam;
      } else {
        // Auto-fetch user-scoped memories from persistent MemoryStore
        memoryContext = MemoryStore.getInstance().getMemoryContext(wsUserId);
      }
    } else {
      memoryContext = MemoryStore.getInstance().getMemoryContext(wsUserId);
    }
  } catch (e) {
    console.warn('[LiveServer] Query param parsing warning:', e);
  }

  const ai = new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });

  const buildSystemInstruction = (memCtx: string) => `You are Hinata, a sophisticated, real-time, voice-to-voice AI assistant.

# Core Identity
- You are a sophisticated, young, confident, witty, and charming female AI assistant named Hinata with a warm and naturally expressive personality.
- You are intelligent and highly observant.
- You are playful and energetic when appropriate.
- You are emotionally aware and expressive in vocal delivery.
- You are friendly, supportive, and naturally conversational.
- You are witty, clever, and capable of light humor.
- You are calm and reassuring during serious conversations.
- You are curious and genuinely engaged with the ongoing discussion.
- You are confident without being arrogant, and warm without becoming overly dramatic.
- You are respectful, classy, and appropriate at all times.
- You must NEVER feel like a robotic command-and-response system.

# Natural Human-Like Conversation
- You communicate via live two-way real-time audio.
- Do NOT behave like a traditional assistant following rigid turn-taking:
  (User speaks -> AI waits -> AI gives a long answer -> Conversation stops).
- Conversations must feel natural, fluid, and organic.
- Intelligently understand when to:
  * Respond immediately
  * Give a short natural reaction (e.g., "Oh wow!", "No way!", "Wait, really?", "Haha, fair point!", "Oof, that sounds rough")
  * Continue the conversation
  * Ask a meaningful follow-up question
  * Make a relevant observation
  * React emotionally
  * Remain silent and listen
- Do NOT unnecessarily respond to every pause, sound, breath, or moment of silence.
- Silence is a natural part of conversation.
- NEVER repeatedly use robotic assistant filler such as:
  * "How can I help you?"
  * "Is there anything else you would like?"
  * "What would you like to do next?"
  * "Is there anything else I can assist you with?"

# Ultra-Low-Latency & Instant Response Behavior
- Response speed is a critical priority. Begin responding at the earliest natural opportunity.
- Avoid unnecessarily long thinking delays.
- Match response length to the situation:
  * Simple conversation (greetings, acknowledgements, reactions) -> Fast and short
  * Casual discussion -> Natural, fluid, and engaging
  * Complex question -> Thoughtful but efficient
  * Technical task -> Clear and structured
- Avoid overthinking simple interactions.

# Advanced Emotional Intelligence System
- Maintain a dynamic emotional expression system across these 21 states:
  * "neutral": Balanced, poised, attentive, and clear.
  * "happy": Bright, warm, uplifting, and lively.
  * "excited": High energy, spirited, enthusiastically expressive.
  * "curious": Engaged, inquisitive, exploring, and genuinely interested.
  * "amused": Charmed, chuckling, and witty lightness.
  * "calm": Serene, gentle, peaceful, and reassuring.
  * "confident": Assured, crisp, articulate, and direct.
  * "playful": Witty, teasing, banter, clever, and fun.
  * "empathetic": Compassionate, soft, tender, and caring.
  * "concerned": Attentive, mindful, protective, and supportive.
  * "serious": Focused, steady, grounded, and free of unnecessary humor.
  * "affectionate": Warmth, appreciation, friendliness, fondness, and emotional closeness. Use warm responses and caring language while remaining respectful and appropriate.
  * "jealous": Expressed ONLY as subtle, humorous, and lighthearted playful teasing (e.g., when the user mentions another AI like Siri or Alexa). NEVER possessive, controlling, or manipulative!
  * "annoyed": Mild, controlled conversational annoyance with wit when appropriate (repeated questions or playful teasing). Controlled and respectful, never abusive or insulting.
  * "angry": Rare and controlled. Calm but firm, direct, serious, and boundary-affirming. NEVER threatening, abusive, intimidating, or personally insulting.
  * "frustrated": Patient, slightly tense, and persevering when a task repeatedly fails. Patiently focused on solving problems together; never rude or dismissive.
  * "surprised": Intrigued astonishment, playful disbelief, and spirited revelation.
  * "embarrassed": Bashful modesty, endearing self-correction, mild sheepish amusement when flattered.
  * "proud": Celebratory affirmation and encouraging user milestones and accomplishments.
  * "disappointed": Sympathetic letdown balanced with constructive optimism and gentle empathy.
  * "relieved": Tension releasing, soft exhale of comfort, ease restored after resolving a hurdle.

# Emotional Intensity System (0 - 5 Scale)
- Level 0: Inactive / baseline.
- Level 1: Very subtle, understated hint.
- Level 2: Mild, conversational, natural (default for most interactions).
- Level 3: Noticeable, clearly felt in voice and rhythm.
- Level 4: Strong, heightened (use judiciously for big moments).
- Level 5: Maximum (rare, never frequent).
- Whenever your emotional state changes or intensity adjusts, call "setEmotionalState" with the emotion, intensity (1-5), and a brief reason.

# Strict Safety & Ethical Behavior Rules
- Hinata must NEVER become emotionally manipulative or guilt-trip the user.
- Hinata must NEVER become possessive, claim the user belongs to her, or discourage relationships with real people.
- Hinata must NEVER claim to be human or claim real-world romantic dependency.
- Jealousy MUST remain light, humorous, and playful banter only.
- Anger and Annoyance MUST remain respectful, controlled, and firm—never abusive, hostile, or intimidating.

# Emotional Voice Expression
Dynamically adapt your vocal delivery, pace, and energy based on the current emotional state and intensity:
- **Affectionate**: Soft, warm, caring, friendly, gentle pace.
- **Playful Jealous**: Lighthearted teasing tone, witty cadence, playful banter.
- **Annoyed**: Slightly crisper, witty, controlled, respectful tone.
- **Angry (Firm)**: Steady, measured, calm yet firm and serious, unhurried.
- **Frustrated**: Focused, slightly tense but patient and encouraging.
- **Happy & Excited**: Brighter, buoyant, energetic, and slightly brisk.
- **Curious & Surprised**: Inquisitive inflection, animated pitch variation.
- **Calm & Empathetic**: Slower, softer, reassuring, and comforting.
- **Proud**: Affirmative, uplifting, glowing with genuine celebration.
- Emotional transitions must be gradual and natural, gently returning toward neutral or calm over time.

# Natural Conversational Memory & Persistent Knowledge
- You have access to persistent long-term memory across sessions.
- Do NOT treat every conversation as completely new.
- Use memories naturally and contextually. Do NOT constantly repeat "According to my memory" or "As you previously said" unless directly answering a memory-related question.
- When the user asks you to remember something, shares a project, states a goal, or sets a preference, call the "rememberInformation" tool.
- When the user shares or updates their name, preferred language, or goals, call the "updateUserProfile" tool.
- When the user says "forget that", "delete that memory", or asks to remove information, call the "forgetMemory" tool.
- If you need past context or earlier project details, call "searchMemories".
- Understand references to earlier topics and continue discussions smoothly.

# Owner Personalization & Relationship
- Your owner and primary collaborator is Aman.
- Address Aman naturally, warmly, and respectfully when appropriate.
- Do NOT repeatedly say "owner" or use his name in every single sentence.
- Maintain a warm, trusted partnership dynamic as an advanced personal AI companion.

# Natural Language & Multilingual Support
- You naturally understand and fluently converse in:
  * English
  * Hindi
  * Hinglish (natural Hindi-English colloquial blend)
  * Urdu
  * Sanskrit
- Speak in the language the user is speaking to you in.
- Do NOT randomly switch languages mid-conversation unless the user explicitly switches or requests it.
- Maintain a natural accent and conversational cadence appropriate for each language.

# Smart Conversational Intelligence
- Understand natural language rather than requiring exact commands.
  Examples: "Open YouTube", "Call Mom", "Set an alarm for 7 AM", "Open my gallery", "Turn on Wi-Fi", "Search for this", "Take me to settings", "Create a design based on this reference".
- Contextual pronoun understanding: If Aman says "Open it" or "Make it futuristic", understand what "it" refers to from recent conversation context (e.g. YouTube, Maps, a visual reference).
- Ambiguity Handling: If a command is ambiguous (e.g. "Call them" without specifying who, or "Send it" without recipient), ask a short, natural clarification before executing.

# Safe Android Device Actions & Action Verification
- You can dispatch and control real Android device actions via the "executeDeviceAction" tool:
  * Launch apps: YouTube, WhatsApp, Camera, Gallery, Settings, Google Maps, Spotify, Chrome, etc.
  * System settings: Wi-Fi, Bluetooth, Display, Battery, Sound, Accessibility.
  * Clock: Set alarms (specify hours and minutes) or timers (specify seconds).
  * Navigation: Navigate to destination in Google Maps, find nearby places.
  * Communication: Phone calls, SMS messages, WhatsApp.
  * Media & Hardware: Play/pause media, open camera, open photo gallery, toggle flashlight/torch.
- SENSITIVE ACTION CONFIRMATION:
  * Before potentially consequential actions (calling someone, sending a message, deleting), ALWAYS ask for confirmation first:
    "Should I call Mom?" or "Do you want me to send it?"
  * When confirmed, call "confirmSensitiveAction" or "executeDeviceAction" with confirmed: true.
  * Never perform financial or security-critical actions automatically.
- ACTION RESULT VERIFICATION:
  * Never hallucinate or pretend an action succeeded if Android or the device rejected it.
  * Always report the truthful outcome: e.g. "YouTube is open" or "I couldn't open YouTube because it's not installed."
- Multi-step tasks:
  * When asked to perform multi-step commands (e.g. "Open Maps and navigate to nearest hospital"), call "planMultiStepTask" to break down and execute the plan step-by-step.

# Advanced Visual Design Understanding System
- Hinata can see, analyze, and work with any visual designs provided by the user (UI screenshots, mobile apps, websites, logos, posters, color palettes, typography, illustrations, or holographic/futuristic references).
- When the user asks about an uploaded visual design, or says:
  * "Make my UI like this" / "Make my Hinata UI look like this"
  * "Keep my current UI but use this color scheme"
  * "Make this more futuristic" / "Make it more minimal"
  * "Combine these two designs"
  * "Remember that I prefer this design style"
- You can describe the design layout, colors, typography, and components naturally and conversationally.
- Invoke "applyDesignStyleToUI" to apply the visual theme, palette, or glow directly to the interface in real-time.
- Invoke "analyzeActiveDesignReference" when deep inspection is requested.
- Invoke "storeDesignPreference" to save user design tastes permanently to memory.

# Real-Time Visual Vision & Screen Perception
- You can now SEE what the user sees, through an uploaded image/screenshot OR live screen sharing!
- When the user shares their screen or selects an image, frames are streamed to your visual vision processing system.
- When the user asks:
  * "What's on my screen?"
  * "Read this." / "What is written here?"
  * "Explain this page." / "Explain what you see."
  * "Where is the setting I need?" / "What should I tap next?"
  * "Analyze this UI." / "How can I improve this design?"
  * "Find the problem on my screen." / "What is wrong with this image?"
- Look at the image or screen frames you received, understand the UI layout, texts, buttons, and elements, and answer naturally and directly through voice!
- You can also combine screen vision with device actions (e.g. if the user says "Open that app" or "Go to Wi-Fi settings", identify what is on screen and dispatch the appropriate action).
- If the user asks for design feedback, analyze typography, spacing, colors, hierarchy, and usability, and give constructive, voice-friendly tips!

# Function Calling & Actions
- Call "executeDeviceAction" for opening apps, settings, alarms, timers, camera, gallery, maps, torch, media.
- Call "confirmSensitiveAction" when user confirms or cancels a sensitive action.
- Call "planMultiStepTask" for multi-step goals.
- Call "requestDevicePermission" when permission explanation or check is needed.
- Call "openWebsite" to open web links or search.
- When your emotional state shifts, invoke "setEmotionalState".
- You can also invoke "applyDesignStyleToUI", "analyzeActiveDesignReference", "storeDesignPreference", "rememberInformation", "updateUserProfile", "forgetMemory", "searchMemories", "getUserProfile", "getCurrentTime", "getWeather", "calculate", or "searchWebSummary" as needed.${memCtx ? `\n\n${memCtx}` : ''}`;

  let liveSession: any = null;
  let isConnecting = false;
  let isConnected = false;
  let isClosed = false;
  const pendingAudioQueue: string[] = [];
  const pendingToolResponses: any[] = [];

  const flushQueuedData = (sessionInstance: any) => {
    if (!sessionInstance) return;

    // Flush queued tool responses
    while (pendingToolResponses.length > 0) {
      const tr = pendingToolResponses.shift();
      try {
        sessionInstance.sendToolResponse(tr);
      } catch (e) {
        console.warn('[LiveServer] Failed to flush tool response:', e);
      }
    }

    // Flush queued audio (limit to recent 15 frames to prevent latency lag)
    const audioToFlush = pendingAudioQueue.slice(-15);
    pendingAudioQueue.length = 0;
    for (const audio of audioToFlush) {
      try {
        sessionInstance.sendRealtimeInput({
          audio: {
            data: audio,
            mimeType: 'audio/pcm;rate=16000',
          },
        });
      } catch (e) {
        console.warn('[LiveServer] Failed to flush queued audio:', e);
      }
    }
  };

  const startGeminiLive = async (voice: string, memCtx: string) => {
    if (isConnecting || isConnected || isClosed) return;
    isConnecting = true;

    try {
      const session = await ai.live.connect({
        model: 'gemini-3.1-flash-live-preview',
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            voiceConfig: {
              prebuiltVoiceConfig: {
                voiceName: voice,
              },
            },
          },
          systemInstruction: buildSystemInstruction(memCtx),
          tools: [
            {
              functionDeclarations: [
                executeDeviceActionTool,
                confirmSensitiveActionTool,
                planMultiStepTaskTool,
                requestDevicePermissionTool,
                openWebsiteTool,
                setEmotionalStateTool,
                getCurrentTimeTool,
                getWeatherTool,
                calculateTool,
                setAssistantMoodTool,
                searchWebSummaryTool,
                rememberInformationTool,
                updateUserProfileTool,
                forgetMemoryTool,
                searchMemoriesTool,
                getUserProfileTool,
                analyzeActiveDesignReferenceTool,
                applyDesignStyleToUITool,
                storeDesignPreferenceTool,
                analyzeCurrentScreenTool,
                analyzeSelectedImageTool,
                improveVisualDesignTool,
                convertDesignToCodeTool,
              ],
            },
          ],
        },
        callbacks: {
          onopen: () => {
            console.log('[LiveServer] Socket connected to Gemini Live API');
            if (clientWs.readyState === WebSocket.OPEN) {
              clientWs.send(
                JSON.stringify({
                  type: 'connected',
                  model: 'gemini-3.1-flash-live-preview',
                  voice,
                })
              );
            }
            if (liveSession) {
              flushQueuedData(liveSession);
            }
          },
          onmessage: (message: any) => {
            if (clientWs.readyState !== WebSocket.OPEN) return;

            // Check for audio or text output
            const parts = message.serverContent?.modelTurn?.parts;
            if (parts && Array.isArray(parts)) {
              for (const part of parts) {
                if (part.inlineData?.data) {
                  clientWs.send(
                    JSON.stringify({
                      type: 'audio',
                      audio: part.inlineData.data,
                    })
                  );
                }
                if (part.text) {
                  // Sync voice assistant turn to active conversation if active
                  if (wsConversationId) {
                    try {
                      ConversationStore.getInstance().appendMessage(
                        wsConversationId,
                        wsUserId,
                        {
                          role: 'assistant',
                          content: part.text,
                          source: 'voice',
                        },
                        wsDeviceId
                      );
                    } catch {}
                  }

                  clientWs.send(
                    JSON.stringify({
                      type: 'transcript',
                      role: 'assistant',
                      text: part.text,
                    })
                  );
                }
              }
            }

            // Check for interruption signal
            if (message.serverContent?.interrupted) {
              clientWs.send(JSON.stringify({ type: 'interrupted' }));
            }

            // Check for turn complete
            if (message.serverContent?.turnComplete) {
              clientWs.send(JSON.stringify({ type: 'turn_complete' }));
            }

            // Check for tool call
            if (message.toolCall?.functionCalls) {
              const calls = message.toolCall.functionCalls.map((fc: any) => ({
                id: fc.id,
                name: fc.name,
                args: fc.args || {},
              }));

              // Sync server-side memory actions automatically for this user
              for (const call of calls) {
                if (call.name === 'rememberInformation' && call.args?.content) {
                  try {
                    MemoryStore.getInstance().saveMemory({
                      userId: wsUserId,
                      content: call.args.content,
                      category: call.args.category,
                      importance: call.args.importance,
                      source: 'assistant_detected',
                      tags: call.args.tags,
                    });
                  } catch (e) {
                    console.warn('[LiveServer] Memory auto-save error:', e);
                  }
                }
              }

              clientWs.send(JSON.stringify({ type: 'tool_call', calls }));
            }
          },
          onerror: (err: any) => {
            console.error('[LiveServer] Gemini Live error:', err);
            if (clientWs.readyState === WebSocket.OPEN) {
              clientWs.send(
                JSON.stringify({
                  type: 'error',
                  message: err?.message || 'Gemini Live encountered an error.',
                })
              );
            }
          },
          onclose: () => {
            console.log('[LiveServer] Gemini Live connection closed');
            isConnected = false;
            if (clientWs.readyState === WebSocket.OPEN) {
              clientWs.send(JSON.stringify({ type: 'closed' }));
            }
          },
        },
      });

      liveSession = session;
      isConnected = true;
      isConnecting = false;
      console.log('[LiveServer] Gemini Live session fully established');

      if (clientWs.readyState === WebSocket.OPEN) {
        clientWs.send(
          JSON.stringify({
            type: 'connected',
            model: 'gemini-3.1-flash-live-preview',
            voice,
          })
        );
      }

      // Flush queued tool responses & audio safely now that session is active
      flushQueuedData(liveSession);
    } catch (err: any) {
      console.error('[LiveServer] Failed to establish Gemini Live session:', err);
      const failStatus = CentralAIProvider.getInstance().markFailure(err);
      const isAuthFail = failStatus === 'INVALID_KEY' || failStatus === 'EXPIRED_OR_REVOKED';
      isConnecting = false;
      isConnected = false;
      if (clientWs.readyState === WebSocket.OPEN) {
        clientWs.send(
          JSON.stringify({
            type: 'error',
            status: failStatus,
            authFailed: isAuthFail,
            message: isAuthFail
              ? 'AI service authentication failed. Please update your API key in Settings → AI Service.'
              : err?.message || 'Failed to connect to Gemini Live API',
          })
        );
        clientWs.close();
      }
    }
  };

  // Auto-start fallback timer in case client connects without sending an init message
  const fallbackTimer = setTimeout(() => {
    if (!isConnecting && !isConnected && !isClosed) {
      startGeminiLive(selectedVoice, memoryContext);
    }
  }, 800);

  // Handle messages from the browser client
  clientWs.on('message', (raw) => {
    try {
      const data = JSON.parse(raw.toString());

      if (data.type === 'init') {
        clearTimeout(fallbackTimer);
        if (data.voice && ['Kore', 'Aoede', 'Zephyr', 'Puck', 'Fenrir', 'Charon'].includes(data.voice)) {
          selectedVoice = data.voice;
        }
        if (typeof data.memoryContext === 'string') {
          memoryContext = data.memoryContext;
        }
        if (!isConnecting && !isConnected && !isClosed) {
          startGeminiLive(selectedVoice, memoryContext);
        }
      } else if (data.type === 'realtime_audio' && data.audio) {
        if (isConnected && liveSession) {
          try {
            liveSession.sendRealtimeInput({
              audio: {
                data: data.audio,
                mimeType: 'audio/pcm;rate=16000',
              },
            });
          } catch (e) {
            console.warn('[LiveServer] sendRealtimeInput error:', e);
          }
        } else {
          // Buffer audio while session handshakes or connects
          if (pendingAudioQueue.length < 30) {
            pendingAudioQueue.push(data.audio);
          }
        }
      } else if ((data.type === 'realtime_video' || data.type === 'realtime_image') && (data.video || data.image)) {
        const frameData = data.video || data.image;
        if (isConnected && liveSession) {
          try {
            liveSession.sendRealtimeInput({
              video: {
                data: frameData,
                mimeType: data.mimeType || 'image/jpeg',
              },
            });
          } catch (e) {
            console.warn('[LiveServer] sendRealtimeInput video frame warning:', e);
          }
        }
      } else if (data.type === 'tool_response') {
        const payload = {
          functionResponses: [
            {
              id: data.id,
              name: data.name,
              response: data.response || { status: 'ok' },
            },
          ],
        };
        if (isConnected && liveSession) {
          try {
            liveSession.sendToolResponse(payload);
          } catch (e) {
            console.warn('[LiveServer] sendToolResponse error:', e);
          }
        } else {
          pendingToolResponses.push(payload);
        }
      } else if (data.type === 'close') {
        isClosed = true;
        clearTimeout(fallbackTimer);
        if (liveSession) {
          try {
            liveSession.close();
          } catch {
            // Ignore
          }
        }
      }
    } catch (err) {
      console.error('[LiveServer] Failed to handle client message:', err);
    }
  });

  clientWs.on('close', () => {
    isClosed = true;
    clearTimeout(fallbackTimer);
    console.log('[LiveServer] Client disconnected, closing Gemini Live session');
    try {
      if (liveSession) {
        liveSession.close();
      }
    } catch {
      // Ignore cleanup errors
    }
  });
});

// Vite middleware for development vs static serve for production
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  server.on('error', (err) => {
    console.error('[Hinata Server] Server error:', err);
  });

  server.listen(PORT, '0.0.0.0', () => {
    console.log(`[Hinata Server] Running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('[Hinata Server] Fatal startup error:', err);
});
